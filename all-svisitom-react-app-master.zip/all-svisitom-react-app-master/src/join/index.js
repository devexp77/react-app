import React from 'react';
import ReactDOM from 'react-dom';
import { Provider } from 'react-redux';
import { createStore, applyMiddleware } from 'redux';
import { routerMiddleware } from 'react-router-redux';
import {createLogger} from 'redux-logger';
import { composeWithDevTools } from 'redux-devtools-extension';
import thunk from 'redux-thunk';
import { Router, Route, hashHistory, IndexRoute } from 'react-router';
import { syncHistoryWithStore } from 'react-router-redux';
import 'babel-polyfill';

import reducer from './reducers/'

import configRoutes from './routes.js'
import NotFound from '../common/components/Errors/notFound';

const middleware = applyMiddleware(
  // createLogger(),
  routerMiddleware(hashHistory),
  thunk
);

const store = createStore(reducer, composeWithDevTools(middleware
));
const history = syncHistoryWithStore(hashHistory, store);

ReactDOM.render(

  <Provider store={store}>
    
      <Router history={history}>
         {configRoutes(store)}
         <Route path='*' component={NotFound} />
         
      </Router>
   
  </Provider>,
  document.getElementById('root')
);

