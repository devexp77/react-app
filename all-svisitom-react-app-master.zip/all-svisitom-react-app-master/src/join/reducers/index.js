import { combineReducers } from "redux";
import { routerReducer } from "react-router-redux";

import user from "../../common/reducers/user";
import notifications from "../../common/reducers/notifications";
import objects from "../../common/reducers/objects";
import addressee from '../../common/reducers/addressee';
import roles from '../../common/reducers/roles';
import router from "../../common/reducers/router";
import image from "../../common/reducers/image";
import geocoder from "../../common/reducers/geocoder";
import bento from '../../common/reducers/bento';

export default combineReducers({
  routing: routerReducer,
  router,
  user,
  objects,
  addressee,
  roles,
  notifications,
  image,
  geocoder,
  bento,
});
