import { Route, IndexRoute } from "react-router";
import React from "react";

import App from "./containers/App";
import ObjectAdd from "./containers/objectAddContainer";

export default function configRoutes(store) {
  return (
    <Route path="/" component={App}>
      <IndexRoute component={ObjectAdd} />
    </Route>
  );
}
