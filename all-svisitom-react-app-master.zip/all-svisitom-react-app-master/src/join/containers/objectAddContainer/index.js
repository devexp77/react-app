import React, { Component } from "react";
import { connect } from "react-redux";

import { slugify } from "transliteration";

slugify.config({ separator: "" });

import {
  addUserObjectsRequest,
  checkObjectDomainNameRequest,
  toSuccessPage
} from "../../../common/actions/objects";

import { fetchAddAddressee } from "../../../common/actions/addressee";

import { fetchSetEntityRoles } from "../../../common/actions/roles";

import {
  ObjectNameValid,
  AddressValid,
  CityValid,
  CountryValid
} from "../../../common/validation/object";

import strings from "../../localization/all";
import error_strings from "../../../common/localization/errors";
import { ErrorToast } from "../../../common/Toasts/error";
import MaterialSurface from "../../../common/components/PageContainers/materialSurface";
import ProfileInfo from "../../../common/components/ProfileInfo";
import common_strings from "../../../common/localization/all";
import { ErrorClass } from "../../../common/validation/errorClass";
import InputField from "../../../common/components/Inputs/inputField";
import SinglePageCustomPadding from "../../../common/components/PageContainers/singlePageCustomPadding";
import { MapWithDragMarker } from "../../../common/components/Map";
import { fetchAddressByGeoPoint } from "../../../common/actions/geocoder";
import Buttons from "../../../common/components/ButtonsPanel";
import AutoScroll from "../../../common/components/AutoScroll";
import { FULL_HOST_NAME, HOST_NAME, PROTOCOL } from "../../../common/constants";

import localForage from "localforage";

class ObjectAddContainer extends Component {
  constructor() {
    super();
    this.state = {
      object_name: "",
      type: "basic",
      domain: "",
      address: "",
      city: "",
      country: "",
      postcode: "",
      allowRender: false,

      mapInit: new Date().toISOString(),
      mapLat: 55.755826,
      mapLng: 37.617299900000035,
      lat: 55.755826,
      lng: 37.617299900000035,
      zoom: 17,

      formErrors: {
        object_name: "init",
        city: "init",
        domain: "init",
        address: "init",
        country: "init",
        postcode: "init"
      }
    };
  }

  componentDidMount() {
    window.scrollTo(0, 0);
    localForage.getItem("objectAddData").then(value => {
      if (value) {
        this.setState(
          {
            object_name: value.name || "",
            type: value.object_type || "basic",
            domain: value.domain_name || "",
            city: value.city || "",
            address: value.address || "",
            postcode: value.postcode || "",
            country: value.country || "",
            lat:
              value.geo_point && value.geo_point.length > 0
                ? value.geo_point[0]
                : 55.755826,
            lng:
              value.geo_point && value.geo_point.length > 0
                ? value.geo_point[1]
                : 37.617299900000035,
            mapLat:
              value.geo_point && value.geo_point.length > 0
                ? value.geo_point[0]
                : 55.755826,
            mapLng:
              value.geo_point && value.geo_point.length > 0
                ? value.geo_point[1]
                : 37.617299900000035,
            allowRender: true
          },
          () => {
            localForage
              .setItem("objectAddData", null)
              .then(() => this.handleSubmit());
          }
        );
      } else {
        this.setState({ allowRender: true });
        this.getBrowserGeoLocation();
      }
    });
  }

  getBrowserGeoLocation() {
    if (navigator.geolocation) {
      const _this = this;
      navigator.geolocation.getCurrentPosition(
        function(position) {
          if (
            position &&
            position.coords &&
            position.coords.latitude &&
            position.coords.longitude
          ) {
            _this.mapReInit(
              position.coords.latitude,
              position.coords.longitude
            );
            _this.setState(
              {
                lat: position.coords.latitude,
                lng: position.coords.longitude
              },
              function() {
                _this.getAddressByGeoPoint();
              }
            );
          }
        },
        function() {
          _this.mapReInit(55.755826, 37.617299900000035);
        }
      );
    } else {
      console.log("Browser doesn't support Geolocation");
    }
  }

  mapReInit(lat, lng) {
    this.setState({
      mapLat: lat,
      mapLng: lng,
      mapInit: new Date().toISOString()
    });
  }

  onMapClick(event) {
    const _this = this;
    this.setState(
      {
        lat: event.latLng.lat(),
        lng: event.latLng.lng()
      },
      function() {
        _this.getAddressByGeoPoint();
      }
    );
  }

  onMarkerDragEnd(event) {
    const _this = this;
    this.setState(
      {
        lat: event.latLng.lat(),
        lng: event.latLng.lng()
      },
      function() {
        _this.getAddressByGeoPoint();
      }
    );
  }

  getAddressByGeoPoint() {
    const { dispatch } = this.props;

    const data = {
      latlng: this.state.lat + "," + this.state.lng
    };

    (async () => {
      await dispatch(fetchAddressByGeoPoint(data));
      const { addressByGeoPoint } = this.props.geocoder;
      if (
        addressByGeoPoint.results &&
        addressByGeoPoint.results[0] &&
        addressByGeoPoint.results[0].address_components
      ) {
        this.setState(
          {
            postcode: "",
            country: "",
            city: "",
            address: ""
          },
          function() {
            this.initGeoResult(addressByGeoPoint.results[0].address_components);
          }
        );
      }
    })();
  }

  initGeoResult(result) {
    let postcode = "";
    let country = "";
    let city = "";
    let state = "";
    let street = "";
    let number = "";

    for (let key in result) {
      if (result[key].types.indexOf("country") > -1) {
        country = result[key].long_name;
      }

      if (result[key].types.indexOf("administrative_area_level_1") > -1) {
        state = result[key].long_name;
      }

      if (result[key].types.indexOf("locality") > -1) {
        city = result[key].long_name;
      }

      if (result[key].types.indexOf("route") > -1) {
        street = result[key].short_name;
      }

      if (result[key].types.indexOf("street_number") > -1) {
        number = result[key].short_name;
      }

      if (result[key].types.indexOf("postal_code") > -1) {
        postcode = result[key].short_name;
      }
    }

    this.setState(
      {
        postcode: postcode,
        country: country,
        city: `${state}${state && city && ", "}${city}`,
        address: `${street}${street && number && ", "}${number}`
      },
      function() {
        this.validateField("country", this.state.country);
        this.validateField("city", this.state.city);
        this.validateField("address", this.state.address);
      }
    );
  }

  onSearch(address) {
    if (address && address[0] && address[0].address_components) {
      this.setState(
        {
          postcode: "",
          country: "",
          city: "",
          address: ""
        },
        function() {
          this.initGeoResult(address[0].address_components);

          this.setState(
            {
              lat: parseFloat(address[0].geometry.location.lat()),
              lng: parseFloat(address[0].geometry.location.lng())
            },
            function() {
              this.mapReInit(this.state.lat, this.state.lng);
            }
          );
        }
      );
    }
  }

  handleInputChange(event) {
    const id = event.target.id;
    let value = event.target.value.replace(/\s+/g, " ");

    this.setState({ [id]: value }, () => {
      this.validateField(id, value.trim());
    });
  }

  validateField(fieldId, value) {
    switch (fieldId) {
      case "object_name":
        const checkObjectName = this.validateObjectName(value);
        this.setDomainName(checkObjectName, value);
        break;

      case "domain":
        const checkName = this.checkDomainName(value);
        if (checkName) {
          this.checkDomainAvailable(value);
        }
        break;

      case "country":
        this.validateObjectCountry(value);
        break;

      case "city":
        this.validateObjectCity(value);
        break;

      case "address":
        this.validateObjectAddress(value);
        break;

      default:
        break;
    }
  }

  setDomainName(checkObjectName, value) {
    if (checkObjectName) {
      this.state.domain = slugify(value);
      const checkName = this.checkDomainName(slugify(value));
      if (checkName) {
        this.checkDomainAvailable(slugify(value));
      }
    } else {
      let fieldValidationErrors = this.state.formErrors;

      this.state.domain = "";
      fieldValidationErrors.domain = "init";

      this.setState({
        formErrors: fieldValidationErrors
      });
    }
  }

  validateObjectName(value) {
    let fieldValidationErrors = this.state.formErrors;
    const validate = ObjectNameValid(value);
    fieldValidationErrors.object_name = validate.hint;

    this.setState({
      formErrors: fieldValidationErrors
    });

    return validate.result;
  }

  validateObjectAddress(value) {
    let fieldValidationErrors = this.state.formErrors;
    const validate = AddressValid(value);
    fieldValidationErrors.address = validate.hint;
    this.setState({
      formErrors: fieldValidationErrors
    });
    return validate.result;
  }

  validateObjectCountry(value) {
    let fieldValidationErrors = this.state.formErrors;
    const validate = CountryValid(value);
    fieldValidationErrors.country = validate.hint;
    this.setState({
      formErrors: fieldValidationErrors
    });
    return validate.result;
  }

  validateObjectCity(value) {
    let fieldValidationErrors = this.state.formErrors;
    const validate = CityValid(value);
    fieldValidationErrors.city = validate.hint;
    this.setState({
      formErrors: fieldValidationErrors
    });
    return validate.result;
  }

  checkDomainAvailable(value) {
    const { dispatch } = this.props;
    let fieldValidationErrors = this.state.formErrors;
    let domainValid = this.state.domainValid;
    const data = {
      domain_name: value.toLowerCase()
    };
    const _this = this;

    return dispatch(checkObjectDomainNameRequest(data)).then(function(value) {
      if (value.domainStatus.result) {
        fieldValidationErrors.domain = "init";
        domainValid = true;
      } else {
        fieldValidationErrors.domain =
          error_strings[
            value.domainStatus.error.code.toString().replace(/^-/, "")
          ];
        domainValid = false;
      }

      _this.setState({
        formErrors: fieldValidationErrors,
        domainValid: domainValid
      });

      return domainValid;
    });
  }

  checkDomainName(value) {
    let fieldValidationErrors = this.state.formErrors;
    let domainValid = this.state.domainValid;
    if (value.length >= 1 && value.length <= 30) {
      if (value.match(/^([A-Za-z0-9]+)+$/i)) {
        fieldValidationErrors.domain = "init";
        domainValid = true;
      } else {
        domainValid = false;
        fieldValidationErrors.domain = strings["hint_invalid_domain_name"];
      }
    }
    if (value.length < 1) {
      domainValid = false;
      fieldValidationErrors.domain = strings["hint_domain_name_too_short"];
    }
    if (value.length > 20) {
      domainValid = false;
      fieldValidationErrors.domain = strings["hint_domain_name_too_long"];
    }

    this.setState({
      formErrors: fieldValidationErrors
    });
    return domainValid;
  }

  errorClass(error) {
    if (error.length === 0) {
      return "success";
    } else if (error === "init") {
      return "";
    } else {
      return "wrong";
    }
  }

  validateBeforeAddObject() {
    let nameValid = this.validateObjectName(this.state.object_name);
    let domainValid = this.checkDomainName(this.state.domain);
    let addressValid = this.validateObjectAddress(this.state.address);
    let cityValid = this.validateObjectCity(this.state.city);

    return nameValid && domainValid && addressValid && cityValid;
  }

  handleSubmit() {
    const { dispatch } = this.props;

    const error = {
      code: -31001
    };

    const formValid = this.validateBeforeAddObject();

    if (formValid) {
      (async () => {
        try {
          let domainCheck = await this.checkDomainAvailable(this.state.domain);

          if (domainCheck) {
            const data = {
              name: this.state.object_name.trim(),
              object_type: this.state.type.trim(),
              domain_name: this.state.domain.trim(),
              city: this.state.city.trim(),
              address: this.state.address.trim(),
              postcode: this.state.postcode.trim(),
              country: this.state.country.trim(),
              geo_point:
                this.state.lat && this.state.lng
                  ? [this.state.lat, this.state.lng]
                  : []
            };

            if (!this.props.user.user.result) {
              localForage
                .setItem("objectAddData", data)
                .then(function() {
                  const url = encodeURIComponent(
                    `${PROTOCOL}//${FULL_HOST_NAME}/#/`
                  );
                  return (window.location.href = `${PROTOCOL}//${HOST_NAME}/login?next=${url}`);
                })
                .catch(function(error) {
                  console.log(error);
                });
              return;
            }

            await dispatch(addUserObjectsRequest(data));
            var { addObjectStatus } = this.props.objects;

            if (addObjectStatus.error) {
              ErrorToast(addObjectStatus.error);
              return;
            }

            if (addObjectStatus.result) {
              var object_id = addObjectStatus.result;
              await dispatch(
                fetchAddAddressee({
                  name: strings.default_addressee_administration_name,
                  description: "",
                  object_id: object_id
                })
              );

              var { addresseeOperationStatus } = this.props.addressee;
              if (addresseeOperationStatus.error) {
                ErrorToast(addresseeOperationStatus.error);
                return;
              }

              var addressee_id = addresseeOperationStatus.result;
              var { user } = this.props.user;

              await dispatch(
                fetchSetEntityRoles({
                  user_id: user.result.user_id,
                  entity_type: "addressee",
                  entity_id: addressee_id,
                  roles: ["responsible"]
                })
              );

              var { rolesOperationStatus } = this.props.roles;
              if (rolesOperationStatus.error) {
                ErrorToast(rolesOperationStatus.error);
                return;
              }

              location.href = `${PROTOCOL}//manage.${HOST_NAME}/#/${object_id}`;
            }
          } else {
            ErrorToast(error);
          }
        } catch (e) {
          console.log(e);
          ErrorToast();
        } finally {
        }
      })();
    } else {
      ErrorToast(error);
    }
  }

  render() {
    if (this.state.allowRender) {
      return (
        <SinglePageCustomPadding>
          <ProfileInfo.Title title={strings.title_fill_fields} />
          <MaterialSurface marginBottom>
            <AutoScroll>
              <InputField
                handleInputChange={this.handleInputChange.bind(this)}
                id={`object_name`}
                value={this.state.object_name}
                label={common_strings.label_object_name + " *"}
                errorClass={this.errorClass.bind(this)}
                error={this.state.formErrors.object_name}
              />
            </AutoScroll>

            <AutoScroll>
              <InputField
                handleInputChange={this.handleInputChange.bind(this)}
                id={`domain`}
                value={this.state.domain}
                label={common_strings.label_domain + " *"}
                errorClass={this.errorClass.bind(this)}
                error={this.state.formErrors.domain}
                afterText={"." + HOST_NAME}
              />
            </AutoScroll>
          </MaterialSurface>

          <ProfileInfo.Title title={strings.title_select_object} />
          <MaterialSurface noPadding marginBottom>
            <MapWithDragMarker
              key={this.state.mapInit}
              onClick={this.onMapClick.bind(this)}
              onDragEnd={this.onMarkerDragEnd.bind(this)}
              onSearch={this.onSearch.bind(this)}
              lat={this.state.lat}
              lng={this.state.lng}
              mapLat={this.state.mapLat}
              mapLng={this.state.mapLng}
              zoom={this.state.zoom}
            />
          </MaterialSurface>

          <ProfileInfo.Title title={strings.title_enter_address} />
          <MaterialSurface>
            <AutoScroll>
              <InputField
                handleInputChange={this.handleInputChange.bind(this)}
                id={`postcode`}
                value={this.state.postcode}
                label={common_strings.label_postcode}
                errorClass={ErrorClass}
                error={this.state.formErrors.postcode}
              />
            </AutoScroll>

            <AutoScroll>
              <InputField
                handleInputChange={this.handleInputChange.bind(this)}
                id={`country`}
                value={this.state.country}
                label={common_strings.label_country + " *"}
                errorClass={ErrorClass}
                error={this.state.formErrors.country}
              />
            </AutoScroll>

            <AutoScroll>
              <InputField
                handleInputChange={this.handleInputChange.bind(this)}
                id={`city`}
                value={this.state.city}
                label={common_strings.label_city + " *"}
                errorClass={ErrorClass}
                error={this.state.formErrors.city}
              />
            </AutoScroll>

            <AutoScroll>
              <InputField
                handleInputChange={this.handleInputChange.bind(this)}
                id={`address`}
                value={this.state.address}
                label={common_strings.label_address + " *"}
                errorClass={ErrorClass}
                error={this.state.formErrors.address}
              />
            </AutoScroll>
          </MaterialSurface>
          <Buttons
            Submit={this.handleSubmit.bind(this)}
            submitText={
              this.props.user.user.result
                ? common_strings.button_continue
                : common_strings.button_sign_in_and_continue
            }
          />
        </SinglePageCustomPadding>
      );
    } else return null;
  }
}

const mapStateToProps = state => {
  return {
    objects: state.objects,
    addressee: state.addressee,
    roles: state.roles,
    user: state.user,
    geocoder: state.geocoder
  };
};

export default connect(mapStateToProps)(ObjectAddContainer);
