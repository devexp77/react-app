import React, { Component } from "react";
import { connect } from "react-redux";
import { fetchUserGlobal } from "../../common/actions/user";

import { HOST_NAME, PROTOCOL } from "../../common/constants";

import Header from "../../common/containers/headerContainer/header";
import Preloader from "../../common/components/Preloader/preloader";
import FormSubmitCircleLoader from "../../common/components/FormSubmitCircleLoader";
import DemoModeWidget from '../../common/components/demo'

import strings from "../localization/all";
import common_strings from "../../common/localization/all";

import { init_support } from "../../common/util/support";
import SupportWidget from "../../common/components/support";
import Footer from "../../common/components/Footer/footer";
import UseCookies from "../../common/components/UseCookies";
import connectSocket from "../../common/util/socket";

class AppContainer extends Component {
  constructor() {
    super();
    this.socket = null;
    this.state = {
      socket: null
    };
  }

  componentDidMount() {
    document.title =
      strings.title_add_object + " - " + common_strings.product_name;

    const { dispatch } = this.props;

    (async () => {
      await dispatch(fetchUserGlobal());

      const { user } = this.props.user;
      if (user.result) {
        init_support(user.result);
        this.setState({socket: connectSocket(user)});
      }
    })();
  }

  render() {
    const { userGlobalIsFetching } = this.props.user;
    if (userGlobalIsFetching) {
      return <Preloader />;
    } else {
      return [
        <Header
          key={`header`}
          logout={`${PROTOCOL}//${HOST_NAME}/logout`}
          login={`${PROTOCOL}//${HOST_NAME}/authorize/svisitom?next=${encodeURIComponent(
            window.location.href
          )}`}
          mainPage={`/#/`}
          productName={strings.title_add_object}
          containerClass={"container"}
          socket={this.state.socket}
        />,
        <FormSubmitCircleLoader key={`loader`} />,
        React.cloneElement(this.props.children, { key: "children" }),
        <Footer key={`footer`} containerClass={"container"}/>,
        <SupportWidget key={`support`} />,
        <UseCookies key={`cookies`}/>,
        <DemoModeWidget key={"demo-mode-widget"}/>,
        <div key="video-tips" id="video-tips" />
      ];
    }
  }
  componentWillUnmount() {
    this.state.socket.close();
    this.state.socket = null;
  }
}

const mapStateToProps = state => {
  return {
    user: state.user
  };
};

export default connect(mapStateToProps)(AppContainer);
