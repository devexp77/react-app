import strings from "../../join/localization/all";

export const AddressValid = value => {
  let valid = true;
  let hint = "";

  if (value.length < 5) {
    valid = false;
    hint = strings.hint_address_too_short;
  }

  if (value.length > 100) {
    valid = false;
    hint = strings.hint_address_too_long;
  }

  return {
    result: valid,
    hint: hint
  };
};

export const CountryValid = value => {
  let valid = true;
  let hint = "";

  if (value.length < 4) {
    valid = false;
    hint = strings.hint_country_too_short;
  }

  if (value.length > 50) {
    valid = false;
    hint = strings.hint_country_too_long;
  }

  return {
    result: valid,
    hint: hint
  };
};

export const CityValid = value => {
  let valid = true;
  let hint = "";

  if (value.length < 1) {
    valid = false;
    hint = strings.hint_city_name_too_short;
  }

  if (value.length > 100) {
    valid = false;
    hint = strings.hint_city_name_too_long;
  }

  return {
    result: valid,
    hint: hint
  };
};

export const ObjectNameValid = value => {
  let valid = true;
  let hint = "";

  if (value.length > 50) {
    valid = false;
    hint = strings.hint_object_name_too_long;
  }

  if (value.length < 2) {
    valid = false;
    hint = strings.hint_object_name_too_short;
  }

  return {
    result: valid,
    hint: hint
  };
};
