export const ErrorClass = (error) => {

    if (error.length === 0) {
        return 'success';
    }
    else if (error === 'init') {
        return '';
    }
    else {
        return 'wrong';
    }
};

