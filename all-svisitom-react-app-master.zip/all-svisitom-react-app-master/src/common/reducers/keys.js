import {
  RECEIVE_KEYS,
  REQUEST_KEYS,
  REQUEST_MORE_KEYS,
  RECEIVE_MORE_KEYS,
  CLEAR_KEYS,
  REQUEST_REGISTER_KEY_MOVE,
  RECEIVE_REGISTER_KEY_MOVE,
  SAVE_KEY_MOVE_INFO,
  CLEAR_KEY_MOVE_INFO,
  REQUEST_KEY_BY_ID,
  RECEIVE_KEY_BY_ID,
  CLEAR_KEY_BY_ID,
  REQUEST_ADD_KEY,
  RECEIVE_ADD_KEY,
  REQUEST_SET_KEY,
  RECEIVE_SET_KEY,
  REQUEST_DELETE_KEYS,
  RECEIVE_DELETE_KEYS,
  REQUEST_KEY_USERS,
  RECEIVE_KEY_USERS,
  CLEAR_KEY_USERS,
  REQUEST_SET_KEY_PERMISSIONS,
  RECEIVE_SET_KEY_PERMISSIONS,
  RECEIVE_DELETE_KEY_PERMISSIONS,
  REQUEST_DELETE_KEY_PERMISSIONS,
  REQUEST_GET_USER_FAVORITE_KEYS,
  RECEIVE_GET_USER_FAVORITE_KEYS,
  REQUEST_SET_USER_FAVORITE_KEYS,
  RECEIVE_SET_USER_FAVORITE_KEYS,
  REQUEST_GET_USER_FAVORITE_KEYS_FULL,
  RECEIVE_GET_USER_FAVORITE_KEYS_FULL,
} from "../actions/keys";

export default function rooms(
  state = {
    keys: {},
    keysIsFetching: false,

    keyById: {},
    keyByIdIsFetching: false,

    keyOperationStatus: [],
    keyOperationIsFetching: false,

    keyUsers: [],
    keyUsersIsFetching: false,

    keyUsersFavorites: [],
    keyUsersFavoritesIsFetching: false,

    keyUsersFavoritesFull: [],
    keyUsersFavoritesFullIsFetching: false,

    keyMoveInfo: [],

  },
  action
) {
  switch (action.type) {
    /************ get keys ************/
    case REQUEST_KEYS:
    case REQUEST_MORE_KEYS:
      return {
        ...state,
        keysIsFetching: true
      };

    case RECEIVE_KEYS:
      return {
        ...state,
        keysIsFetching: false,
        keys: action.payload
      };

    case RECEIVE_MORE_KEYS:
      let obj = state.keys;
      obj.result = obj.result.concat(action.payload.result);
      return {
        ...state,
        keys: obj,
        keysIsFetching: false
      };

    case CLEAR_KEYS:
      return {
        ...state,
        keys: []
      };

    /*****************************************/
    /*
      Key Operations
    */
    case REQUEST_REGISTER_KEY_MOVE:
    case REQUEST_ADD_KEY:
    case REQUEST_SET_KEY:
    case REQUEST_DELETE_KEYS:
      return {
        ...state,
        keyOperationIsFetching: true
      };

    case RECEIVE_REGISTER_KEY_MOVE:
    case RECEIVE_ADD_KEY:
    case RECEIVE_SET_KEY:
    case RECEIVE_DELETE_KEYS:
      return {
        ...state,
        keyOperationIsFetching: false,
        keyOperationStatus: action.payload
      };


    /*****************************************/

    case SAVE_KEY_MOVE_INFO:
      return {
        ...state,
        keyMoveInfo: action.payload
      };

      case CLEAR_KEY_MOVE_INFO:
      return {
        ...state,
        keyMoveInfo: []
      };

    /*****************************************/


    /*
      get key by id
     */
    case REQUEST_KEY_BY_ID:
      return {
        ...state,
        keyByIdIsFetching: true
      };

    case RECEIVE_KEY_BY_ID:
      return {
        ...state,
        keyByIdIsFetching: false,
        keyById: action.payload
      };

    case CLEAR_KEY_BY_ID:
      return {
        ...state,
        keyByIdIsFetching: false,
        keyById: {}
      };

    /*
      Get key users
     */
    case REQUEST_KEY_USERS:
      return {
        ...state,
        keyUsersIsFetching: true
      };

    case RECEIVE_KEY_USERS:
      return {
        ...state,
        keyUsersIsFetching: false,
        keyUsers: action.payload
      };

    case CLEAR_KEY_USERS:
      return {
        ...state,
        keyUsersIsFetching: false,
        keyUsers: []
      };


      /*
      set key-user permissions
     */
    case REQUEST_SET_KEY_PERMISSIONS:
      return {
        ...state,
        keyOperationIsFetching: true
      };

    case RECEIVE_SET_KEY_PERMISSIONS:
      return {
        ...state,
        keyOperationIsFetching: false,
        keyOperationStatus: action.payload
      };

 /*
      delete key-user permissions
     */
    case REQUEST_DELETE_KEY_PERMISSIONS:
      return {
        ...state,
        keyOperationIsFetching: true
      };

    case RECEIVE_DELETE_KEY_PERMISSIONS:
      return {
        ...state,
        keyOperationIsFetching: false,
        keyOperationStatus: action.payload
      };


    /*
      get user favorites keys
     */
    case REQUEST_GET_USER_FAVORITE_KEYS:
      return {
        ...state,
        keyUsersFavoritesIsFetching: true
      };

    case RECEIVE_GET_USER_FAVORITE_KEYS:
      return {
        ...state,
        keyUsersFavoritesIsFetching: false,
        keyUsersFavorites: action.payload
      };

      /*
      get user favorites keys full
     */
    case REQUEST_GET_USER_FAVORITE_KEYS_FULL:
      return {
        ...state,
        keyUsersFavoritesFullIsFetching: true
      };

    case RECEIVE_GET_USER_FAVORITE_KEYS_FULL:
      return {
        ...state,
        keyUsersFavoritesFullIsFetching: false,
        keyUsersFavoritesFull: action.payload
      };

      /*
      set user favorites keys
     */
    case REQUEST_SET_USER_FAVORITE_KEYS:
      return {
        ...state,
        keyOperationIsFetching: true
      };

    case RECEIVE_SET_USER_FAVORITE_KEYS:
      return {
        ...state,
        keyOperationIsFetching: false,
        keyOperationStatus: action.payload
      };



    default:
      return state;
  }
}
