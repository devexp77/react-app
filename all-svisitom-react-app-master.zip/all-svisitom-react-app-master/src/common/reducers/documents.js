import {
  REQUEST_USER_DOC,
  RECEIVE_USER_DOC,
  REQUEST_ADD_USER_DOC,
  RECEIVE_ADD_USER_DOC,
  REQUEST_SET_USER_DOC,
  RECEIVE_SET_USER_DOC,
  REQUEST_DELETE_USER_DOC,
  RECEIVE_DELETE_USER_DOC,
  REQUEST_USER_DOC_BY_ID,
  RECEIVE_USER_DOC_BY_ID,
  CLEAR_USER_DOC_OPERATION_STATUS,
  CLEAR_USER_DOC_BY_ID,
} from "../actions/documents";

export default function user(
  state = {
    userDocIsFetching: false,
    userDoc: [],
    userDocByIdIsFetching: false,
    userDocById: [],
    userDocOperationIsFetching: false,
    userDocOperationStatus: []
  },
  action
) {
  switch (action.type) {
    /*********** get user doc *************/
    case REQUEST_USER_DOC:
      return {
        ...state,
        userDocIsFetching: true
      };
    case RECEIVE_USER_DOC:
      return {
        ...state,
        userDocIsFetching: false,
        userDoc: action.payload
      };
    /*************************************/

    /*********** get doc by id *************/
    case REQUEST_USER_DOC_BY_ID:
      return {
        ...state,
        userDocByIdIsFetching: true
      };
    case RECEIVE_USER_DOC_BY_ID:
      return {
        ...state,
        userDocByIdIsFetching: false,
        userDocById: action.payload
      };
    /**************************************/

    /************** add doc ****************/
    case REQUEST_ADD_USER_DOC:
      return {
        ...state,
        userDocOperationIsFetching: true
      };
      
      case RECEIVE_ADD_USER_DOC:
      return {
        ...state,
        userDocOperationStatus: action.payload,
        userDocOperationIsFetching: false
      };
    /*************************************/

    /************* set doc ***************/
    case REQUEST_SET_USER_DOC:
      return {
        ...state,
        userDocOperationIsFetching: true
      };
      
      case RECEIVE_SET_USER_DOC:
      return {
        ...state,
        userDocOperationIsFetching: false,
        userDocOperationStatus: action.payload
      };
    /**************************************/

    /*********** delete doc ************/
    case REQUEST_DELETE_USER_DOC:
      return {
        ...state,
        userDocOperationIsFetching: true
      };
      
      case RECEIVE_DELETE_USER_DOC:
      return {
        ...state,
        userDocOperationIsFetching: false,
        userDocOperationStatus: action.payload
      };
    /********************************/
    case CLEAR_USER_DOC_OPERATION_STATUS:
      return {
        ...state,
        userDocOperationStatus: []
      };

    case CLEAR_USER_DOC_BY_ID:
      return {
        ...state,
        userDocById: []
      };

    default:
      return state;
  }
}
