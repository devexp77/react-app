import {
    ADD_ACTIVITY_REQUEST,
    ADD_ACTIVITY_RESULT,

    REQUEST_ACTIVITIES,
    RECEIVE_ACTIVITIES,
    CLEAR_ACTIVITIES,
} from '../actions/activity'


export default function activity(state = {
    addActivityIsFetching: false,
    addActivityStatus: {},

    activitiesIsFetching: false,
    activities: {},
}, action) {
    switch (action.type) {

        /************ add activity ************/
        case ADD_ACTIVITY_REQUEST:
            return {
                ...state,
                addActivityIsFetching: true
            };

        case ADD_ACTIVITY_RESULT:
            return {
                ...state,
                addActivityIsFetching: false,
                addActivityStatus    : action.payload
            };
        /*****************************************/


        /************ get activities ************/
        case REQUEST_ACTIVITIES:
            return {
                ...state,
                activitiesIsFetching: true
            };

        case RECEIVE_ACTIVITIES:
            return {
                ...state,
                activitiesIsFetching: false,
                activities: action.payload
            };

        case CLEAR_ACTIVITIES:
            return {
                ...state,
                activitiesIsFetching: false,
                activities          : {}
            };
        /*****************************************/

        default:
            return state
    }
}
