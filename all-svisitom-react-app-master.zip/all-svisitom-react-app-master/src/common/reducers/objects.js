import {
  REQUEST_USER_OBJECTS,
  RECEIVE_USER_OBJECTS,
  REQUEST_OBJECT_BY_ID,
  RECEIVE_OBJECT_BY_ID,
  CLEAR_OBJECT_BY_ID,
  REQUEST_ADD_USER_OBJECT,
  RECEIVE_ADD_USER_OBJECT,
  DELETE_USER_OBJECT,
  REQUEST_DELETE_USER_OBJECT,
  CHECK_OBJECT_DOMAIN,
  REQUEST_CHECK_OBJECT_DOMAIN,
  CLEAR_OBJECTS,
  REQUEST_OBJECTS,
  RECEIVE_OBJECTS,
  RECEIVE_MORE_OBJECTS,
  REQUEST_CURRENT_OBJECT,
  RECEIVE_CURRENT_OBJECT,
  REQUEST_OBJECTS_BY_ROLES,
  RECEIVE_OBJECTS_BY_ROLES,
  CLEAR_OBJECTS_BY_ROLES,
  REQUEST_SET_OBJECT,
  RECEIVE_SET_OBJECT,
  REQUEST_OBJECT_EMPLOYEES,
  RECEIVE_OBJECT_EMPLOYEES,
  RECEIVE_MORE_OBJECT_EMPLOYEES,
  CLEAR_OBJECT_EMPLOYEES,
  REQUEST_SET_OBJECT_PERMISSIONS,
  RECEIVE_SET_OBJECT_PERMISSIONS,
  REQUEST_OBJECT_PERMISSIONS,
  RECEIVE_OBJECT_PERMISSIONS,
  REQUEST_DELETE_OBJECT_PERMISSIONS,
  RECEIVE_DELETE_OBJECT_PERMISSIONS,
  REQUEST_OBJECTS_BY_IDS,
  RECEIVE_OBJECTS_BY_IDS,
  CLEAR_OBJECTS_BY_IDS,
  RECEIVE_OBJECTS_COUNT,
  REQUEST_OBJECTS_COUNT,
  REQUEST_RESTORE_USER_OBJECT,
  RECEIVE_RESTORE_USER_OBJECT,
} from "../actions/objects";

export default function objects(
  state = {
    objectsIsFetching: false,
    objects: [],
    objectsCountIsFetching: false,
    objectsCount: [],


    objectByIdIsFetching: false,
    objectById: [],
    allObjects: [],
    domainIsFetching: false,
    domainStatus: [],
    addObjectStatus: [],

    deleteObjectStatus: [],
    restoreObjectStatus: {},
    currentObjectIsFetching: false,
    currentObject: [],

    objectOperationStatusIsFetching: false,
    objectOperationStatus: [],

    objectEmployeesIsFetching: false,
    objectEmployees: [],

    objectsByRolesIsFetching: false,
    objectsByRoles: [],

    objectPermissionsIsFetching: false,
    objectPermissions: [],

    objectsByIdsIsFetching: false,
    objectsByIds: [],
  },
  action
) {
  switch (action.type) {
    case REQUEST_USER_OBJECTS:
      return {
        ...state,
        objectsIsFetching: true
      };

    case RECEIVE_USER_OBJECTS:
      return {
        ...state,
        objectsIsFetching: false,
        objects: action.payload
      };

    case REQUEST_OBJECT_BY_ID:
      return {
        ...state,
        objectByIdIsFetching: true
      };

    case RECEIVE_OBJECT_BY_ID:
      return {
        ...state,
        objectByIdIsFetching: false,
        objectById: action.payload
      };

    case CLEAR_OBJECT_BY_ID:
      return {
        ...state,
        objectById: []
      };

    case CLEAR_OBJECTS:
      return {
        ...state,
        allObjects: [],
        objects: []
      };

    case REQUEST_OBJECTS_COUNT:
      return {
        ...state,
        objectsCountIsFetching: true
      };

    case RECEIVE_OBJECTS_COUNT:
      return {
        ...state,
        objectsCountIsFetching: false,
        objectsCount: action.payload
      };

      case REQUEST_OBJECTS:
      return {
        ...state,
        objectsIsFetching: true
      };

    case RECEIVE_OBJECTS:
      return {
        ...state,
        objectsIsFetching: false,
        allObjects: action.payload
      };

    case RECEIVE_MORE_OBJECTS:
      if (action.payload.result) {
        if (state.allObjects.result) {
          let obj = state.allObjects;
          let length = obj.result.length;
          let i = 0;
          for (let prop in action.payload.result) {
            obj.result[length] = action.payload.result[prop];
            length++;
            i++;
          }
          return {
            ...state,
            objectsIsFetching: false,
            allObjects: obj
          };
        } else {
          return {
            ...state,
            objectsIsFetching: false,
            allObjects: action.payload
          };
        }
      } else {
        return {
          ...state,
          objectsIsFetching: false
        };
      }

    case REQUEST_OBJECTS_BY_ROLES:
      return {
        ...state,
        objectsByRolesIsFetching: true
      };

    case RECEIVE_OBJECTS_BY_ROLES:
      return {
        ...state,
        objectsByRolesIsFetching: false,
        objectsByRoles: action.payload
      };

    case CLEAR_OBJECTS_BY_ROLES:
      return {
        ...state,
        objectsByRoles: []
      };

    case REQUEST_ADD_USER_OBJECT:
      return {
        ...state,
        objectOperationStatusIsFetching: true
      };

    case RECEIVE_ADD_USER_OBJECT:
      return {
        ...state,
        objectOperationStatusIsFetching: false,
        addObjectStatus: action.addObjectStatus
      };

    case REQUEST_DELETE_USER_OBJECT:
      return {
        ...state,
        objectOperationStatusIsFetching: true
      };

    case DELETE_USER_OBJECT:
      return {
        ...state,
        objectOperationStatusIsFetching: false,
        deleteObjectStatus: action.deleteObjectStatus
      };

    case REQUEST_RESTORE_USER_OBJECT:
      return {
        ...state,
        objectOperationStatusIsFetching: true
      };

    case RECEIVE_RESTORE_USER_OBJECT:
      return {
        ...state,
        objectOperationStatusIsFetching: false,
        restoreObjectStatus: action.restoreObjectStatus
      };

    case REQUEST_CHECK_OBJECT_DOMAIN:
      return {
        ...state,
        domainIsFetching: true
      };

    case CHECK_OBJECT_DOMAIN:
      return {
        ...state,
        domainIsFetching: false,
        domainStatus: action.domainStatus
      };

    case REQUEST_CURRENT_OBJECT:
      return {
        ...state,
        currentObjectIsFetching: true
      };

    case RECEIVE_CURRENT_OBJECT:
      return {
        ...state,
        currentObjectIsFetching: false,
        currentObject: action.payload
      };

    case REQUEST_SET_OBJECT:
      return {
        ...state,
        objectOperationStatusIsFetching: true
      };

    case RECEIVE_SET_OBJECT:
      return {
        ...state,
        objectOperationStatusIsFetching: false,
        objectOperationStatus: action.payload
      };

    case REQUEST_SET_OBJECT_PERMISSIONS:
      return {
        ...state,
        objectOperationStatusIsFetching: true
      };

    case RECEIVE_SET_OBJECT_PERMISSIONS:
      return {
        ...state,
        objectOperationStatusIsFetching: false,
        objectOperationStatus: action.payload
      };

    case REQUEST_OBJECT_PERMISSIONS:
      return {
        ...state,
        objectPermissionsIsFetching: true
      };

    case RECEIVE_OBJECT_PERMISSIONS:
      return {
        ...state,
        objectPermissionsIsFetching: false,
        objectPermissions: action.payload
      };

    case REQUEST_DELETE_OBJECT_PERMISSIONS:
      return {
        ...state,
        objectOperationStatusIsFetching: true
      };

    case RECEIVE_DELETE_OBJECT_PERMISSIONS:
      return {
        ...state,
        objectOperationStatusIsFetching: false,
        objectOperationStatus: action.payload
      };

    case REQUEST_OBJECT_EMPLOYEES:
      return {
        ...state,
        objectEmployeesIsFetching: true
      };

    case RECEIVE_OBJECT_EMPLOYEES:
      return {
        ...state,
        objectEmployeesIsFetching: false,
        objectEmployees: action.payload
      };

    case RECEIVE_MORE_OBJECT_EMPLOYEES:
      let obj = state.objectEmployees;
      obj.result = obj.result.concat(action.payload.result);
      return {
        ...state,
        objectEmployeesIsFetching: false,
        objectEmployees: obj
      };

    case CLEAR_OBJECT_EMPLOYEES:
      return {
        ...state,
        objectEmployees: {}
      };

    case REQUEST_OBJECTS_BY_IDS:
      return {
        ...state,
        objectsByIdsIsFetching: true
      };

    case RECEIVE_OBJECTS_BY_IDS:
      return {
        ...state,
        objectsByIdsIsFetching: false,
        objectsByIds: action.payload
      };

    case CLEAR_OBJECTS_BY_IDS:
      return {
        ...state,
        objectsByIdsIsFetching: false,
        objectsByIds: {}
      };

    default:
      return state;
  }
}
