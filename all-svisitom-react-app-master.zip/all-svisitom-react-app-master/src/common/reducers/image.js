import {
  REQUEST_SET_IMAGE,
  RECEIVE_SET_IMAGE,
  REQUEST_DELETE_IMAGE,
  RECEIVE_DELETE_IMAGE,
  REQUEST_CURRENT_USER_IMAGE,
  RECEIVE_CURRENT_USER_IMAGE,
  CLEAR_CURRENT_USER_IMAGE,
  SET_CURRENT_USER_IMG_SUFFIX,
  REQUEST_CURRENT_OBJECT_IMAGE,
  RECEIVE_CURRENT_OBJECT_IMAGE,
  CLEAR_CURRENT_OBJECT_IMAGE,
  REQUEST_ADDRESSEE_IMAGE,
  RECEIVE_ADDRESSEE_IMAGE,
  SET_ADDRESSEE_IMG_SUFFIX,
  CLEAR_ROOM_IMAGE,
  REQUEST_ROOM_IMAGE,
  RECEIVE_ROOM_IMAGE,
  SET_ROOM_IMG_SUFFIX,
  CLEAR_ADDRESSEE_IMAGE,
  SET_CURRENT_OBJECT_IMG_SUFFIX,
  REQUEST_CURRENT_OBJECT_MAIN_IMAGE,
  RECEIVE_CURRENT_OBJECT_MAIN_IMAGE,
  REQUEST_OBJECTS_IMAGE,
  RECEIVE_OBJECTS_IMAGE,
  CLEAR_OBJECTS_IMAGE,
  RECEIVE_MORE_OBJECTS_IMAGE,
  REQUEST_USERS_IMAGE,
  RECEIVE_USERS_IMAGE,
  RECEIVE_MORE_USERS_IMAGE,
  CLEAR_USERS_IMAGE,
  REQUEST_LOGBOOK_IMAGES,
  RECEIVE_LOGBOOK_IMAGES,
  CLEAR_LOGBOOK_IMAGES,
  REQUEST_FM_REQUEST_IMAGES,
  CLEAR_FM_REQUEST_IMAGES,
  RECEIVE_FM_REQUEST_IMAGES,
  REQUEST_ADDRESSEES_IMAGES,
  RECEIVE_ADDRESSEES_IMAGES,
  RECEIVE_MORE_ADDRESSEES_IMAGES,
  CLEAR_ADDRESSEES_IMAGES,
  REQUEST_ROOMS_IMAGES,
  RECEIVE_ROOMS_IMAGES,
  RECEIVE_MORE_ROOMS_IMAGES,
  CLEAR_ROOMS_IMAGES,
  REQUEST_COMMENTS_IMAGES,
  RECEIVE_COMMENTS_IMAGES,
  CLEAR_COMMENTS_IMAGES,
  REQUEST_FM_SIGNATURES,
  RECEIVE_FM_SIGNATURES,
  CLEAR_FM_SIGNATURES
} from "../actions/image";

const date = new Date();
export default function image(
  state = {
    imageOperationIsFetching: false,
    imageOperationStatus: [],

    currentUserImageIsFetching: false,
    currentUserImage: [],

    currentObjectImageIsFetching: false,
    currentObjectImage: [],

    addresseeImageIsFetching: false,
    addresseeImage: [],

    roomImageIsFetching: false,
    roomImage: {},

    logbookImageIsFetching: false,
    logbookImage: [],

    fmSignaturesIsFetching: false,
    fmSignatures: [],

    currentObjectMainImagesIsFetching: false,
    currentObjectMainImage: [],

    objectsImageIsFetching: false,
    objectsImage: [],

    addresseesImagesIsFetching: false,
    addresseesImages: {},

    roomsImagesIsFetching: false,
    roomsImages: {},

    usersImageIsFetching: false,
    usersImage: [],

    fmRequestImagesIsFetching: false,
    fmRequestImages: [],

    commentsImagesIsFetching: false,
    commentsImages: [],

    imgSuffix: `${date.getDate()}${date.getHours()}${date.getMinutes()}${date.getSeconds()}${date.getMilliseconds()}`,
    imgObjectSuffix: `${date.getDate()}${date.getHours()}${date.getMinutes()}${date.getSeconds()}${date.getMilliseconds()}`,
    imgAddresseeSuffix: `${date.getDate()}${date.getHours()}${date.getMinutes()}${date.getSeconds()}${date.getMilliseconds()}`,
    imgRoomSuffix: `${date.getDate()}${date.getHours()}${date.getMinutes()}${date.getSeconds()}${date.getMilliseconds()}`
  },
  action
) {
  switch (action.type) {
    /*********** add image ***********/
    case REQUEST_SET_IMAGE:
      return {
        ...state,
        imageOperationIsFetching: true
      };
    case RECEIVE_SET_IMAGE:
      return {
        ...state,
        imageOperationIsFetching: false,
        imageOperationStatus: action.payload
      };

    /******************************************/

    /*********** delete image ***********/
    case REQUEST_DELETE_IMAGE:
      return {
        ...state,
        imageOperationIsFetching: true
      };
    case RECEIVE_DELETE_IMAGE:
      return {
        ...state,
        imageOperationIsFetching: false,
        imageOperationStatus: action.payload
      };
    /******************************************/

    /*********** user image ***********/
    case REQUEST_CURRENT_USER_IMAGE:
      return {
        ...state,
        currentUserImageIsFetching: true
      };
    case RECEIVE_CURRENT_USER_IMAGE:
      return {
        ...state,
        currentUserImageIsFetching: false,
        currentUserImage: action.payload
      };

    case CLEAR_CURRENT_USER_IMAGE:
      return {
        ...state,
        imageOperationIsFetching: false,
        currentUserImage: []
      };

    case SET_CURRENT_USER_IMG_SUFFIX:
      return {
        ...state,
        imgSuffix: action.payload
      };
    /******************************************/

    /*********** object image ***********/
    case REQUEST_CURRENT_OBJECT_IMAGE:
      return {
        ...state,
        currentObjectImageIsFetching: true
      };
    case RECEIVE_CURRENT_OBJECT_IMAGE:
      return {
        ...state,
        currentObjectImageIsFetching: false,
        currentObjectImage: action.payload
      };

    case CLEAR_CURRENT_OBJECT_IMAGE:
      return {
        ...state,
        imageOperationIsFetching: false,
        currentObjectImage: []
      };

    case SET_CURRENT_OBJECT_IMG_SUFFIX:
      return {
        ...state,
        imgObjectSuffix: action.payload
      };

    case REQUEST_CURRENT_OBJECT_MAIN_IMAGE:
      return {
        ...state,
        currentObjectMainImageIsFetching: true
      };
    case RECEIVE_CURRENT_OBJECT_MAIN_IMAGE:
      return {
        ...state,
        currentObjectMainImagesIsFetching: false,
        currentObjectMainImage: action.payload
      };

    /******************************************/

    /*********** objects image ***********/
    case REQUEST_OBJECTS_IMAGE:
      return {
        ...state,
        objectsImageIsFetching: true
      };
    case RECEIVE_OBJECTS_IMAGE:
      return {
        ...state,
        objectsImageIsFetching: false,
        objectsImage: action.payload
      };

    case RECEIVE_MORE_OBJECTS_IMAGE:
      let img = state.objectsImage;

      if (action.payload.result) {
        for (let attr in action.payload.result) {
          img.result[attr] = action.payload.result[attr];
        }
      } else {
        img.error = action.payload.error;
      }
      return {
        ...state,
        objectsImageIsFetching: false,
        objectsImage: img
      };

    case CLEAR_OBJECTS_IMAGE:
      return {
        ...state,
        objectsImage: []
      };

    /******************************************/

    /*********** users image ***********/
    case REQUEST_USERS_IMAGE:
      return {
        ...state,
        usersImageIsFetching: true
      };
    case RECEIVE_USERS_IMAGE:
      return {
        ...state,
        usersImageIsFetching: false,
        usersImage: action.payload
      };

    case RECEIVE_MORE_USERS_IMAGE:
      let userImg = state.usersImage;

      if (!userImg.result) {
        userImg = action.payload;
      } else if (action.payload.result) {
        for (let attr in action.payload.result) {
          userImg.result[attr] = action.payload.result[attr];
        }
      } else {
        userImg.error = action.payload.error;
      }
      return {
        ...state,
        usersImageIsFetching: false,
        usersImage: userImg
      };

    case CLEAR_USERS_IMAGE:
      return {
        ...state,
        usersImage: []
      };

    /******************************************/

    /*****get addressee image****/
    case REQUEST_ADDRESSEE_IMAGE:
      return {
        ...state,
        addresseeImageIsFetching: true
      };
    case RECEIVE_ADDRESSEE_IMAGE:
      return {
        ...state,
        addresseeImageIsFetching: false,
        addresseeImage: action.payload
      };

    case CLEAR_ADDRESSEE_IMAGE:
      return {
        ...state,
        imageOperationIsFetching: false,
        addresseeImage: []
      };

    case SET_ADDRESSEE_IMG_SUFFIX:
      return {
        ...state,
        imgAddresseeSuffix: action.payload
      };
    /***************************/


    /*****get room image****/
    case REQUEST_ROOM_IMAGE:
      return {
        ...state,
        roomImageIsFetching: true
      };
    case RECEIVE_ROOM_IMAGE:
      return {
        ...state,
        roomImageIsFetching: false,
        roomImage: action.payload
      };

    case CLEAR_ROOM_IMAGE:
      return {
        ...state,
        imageOperationIsFetching: false,
        roomImage: []
      };

    case SET_ROOM_IMG_SUFFIX:
      return {
        ...state,
        imgRoomSuffix: action.payload
      };
    /***************************/

    /*****get logbook image****/
    case REQUEST_LOGBOOK_IMAGES:
      return {
        ...state,
        logbookImageIsFetching: true
      };
    case RECEIVE_LOGBOOK_IMAGES:
      return {
        ...state,
        logbookImageIsFetching: false,
        logbookImage: action.payload
      };

    case CLEAR_LOGBOOK_IMAGES:
      return {
        ...state,
        logbookImage: []
      };

    /***************************/

    /*****get fm signatures****/
    case REQUEST_FM_SIGNATURES:
      return {
        ...state,
        fmSignaturesIsFetching: true
      };
    case RECEIVE_FM_SIGNATURES:
      return {
        ...state,
        fmSignaturesIsFetching: false,
        fmSignatures: action.payload
      };

    case CLEAR_FM_SIGNATURES:
      return {
        ...state,
        fmSignatures: []
      };

    /***************************/

    /*****get fm request images ****/
    case REQUEST_FM_REQUEST_IMAGES:
      return {
        ...state,
        fmRequestImagesIsFetching: true
      };
    case RECEIVE_FM_REQUEST_IMAGES:
      return {
        ...state,
        fmRequestImagesIsFetching: false,
        fmRequestImages: action.payload
      };

    case CLEAR_FM_REQUEST_IMAGES:
      return {
        ...state,
        fmRequestImages: []
      };

    /***************************/

    /*****get comments images ****/
    case REQUEST_COMMENTS_IMAGES:
      return {
        ...state,
        commentsImagesIsFetching: true
      };
    case RECEIVE_COMMENTS_IMAGES:
      return {
        ...state,
        commentsImagesIsFetching: false,
        commentsImages: action.payload
      };

    case CLEAR_COMMENTS_IMAGES:
      return {
        ...state,
        commentsImages: []
      };

    /***************************/



    /*********** addressees images ***********/
    case REQUEST_ADDRESSEES_IMAGES:
      return {
        ...state,
        addresseesImagesIsFetching: true
      };
    case RECEIVE_ADDRESSEES_IMAGES:
      return {
        ...state,
        addresseesImagesIsFetching: false,
        addresseesImages: action.payload
      };

    case RECEIVE_MORE_ADDRESSEES_IMAGES:
      let currentAddresseesImages = state.addresseesImages;

      if (action.payload.result) {
        for (let attr in action.payload.result) {
          currentAddresseesImages.result[attr] = action.payload.result[attr];
        }
      } else {
        currentAddresseesImages.error = action.payload.error;
      }
      return {
        ...state,
        addresseesImagesIsFetching: false,
        addresseesImages: currentAddresseesImages
      };

    case CLEAR_ADDRESSEES_IMAGES:
      return {
        ...state,
        addresseesImages: {}
      };



    /*********** rooms images ***********/
    case REQUEST_ROOMS_IMAGES:
      return {
        ...state,
        roomsImagesIsFetching: true
      };
    case RECEIVE_ROOMS_IMAGES:
      return {
        ...state,
        roomsImagesIsFetching: false,
        roomsImages: action.payload
      };

    case RECEIVE_MORE_ROOMS_IMAGES:
      let currentRoomsImages = state.roomsImages;

      if (action.payload.result) {
        for (let attr in action.payload.result) {
          currentRoomsImages.result[attr] = action.payload.result[attr];
        }
      } else {
        currentRoomsImages.error = action.payload.error;
      }
      return {
        ...state,
        roomsImagesIsFetching: false,
        roomsImages: currentRoomsImages
      };

    case CLEAR_ROOMS_IMAGES:
      return {
        ...state,
        roomsImages: {}
      };


    default:
      return state;
  }
}
