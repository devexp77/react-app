import {
  SET_ROUTE_PATH,
  SET_HISTORY,
  CLEAR_HISTORY,
  SET_TITLE,
  SET_CUSTOM_HISTORY_PATH,
  SET_NAV_PANEL_CONTAINER,
  SET_KIOSK_MODE
} from "../actions/router";

export default function router(
  state = {
    routerPrevPath: "",
    history: [],
    title: '',
    customHistoryPath: '',
    navPanelContainer: {},
    kioskMode: []
  },
  action
) {
  switch (action.type) {
    case SET_ROUTE_PATH:
      return {
        ...state,
        routerPrevPath: action.payload
      };

      case SET_NAV_PANEL_CONTAINER:
      return {
        ...state,
        navPanelContainer: action.payload
      };

    case SET_HISTORY:
      return {
        ...state,
        history: [...state.history, action.payload]
      };

      case SET_KIOSK_MODE:
      return {
        ...state,
        kioskMode: state.kioskMode.concat(action.payload)
      };

    case CLEAR_HISTORY:
      return {
        ...state,
        history: []
      };

    case SET_TITLE:
      return {
        ...state,
        title: action.payload
      };

      case SET_CUSTOM_HISTORY_PATH:
      return {
        ...state,
        customHistoryPath: action.payload
      };
    default:
      return state;
  }
}
