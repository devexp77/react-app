import {} from "../actions/ios";
import { RECEIVE_ALL_IOS_IDS } from "../actions/ios";
import { REQUEST_ALL_IOS_IDS } from "../actions/ios";
import { REQUEST_SET_IOS } from "../actions/ios";
import { RECEIVE_SET_IOS } from "../actions/ios";
import { REQUEST_IOS_BY_ID } from "../actions/ios";
import { RECEIVE_IOS_BY_ID } from "../actions/ios";
import { CLEAR_IOS_BY_ID } from "../actions/ios";
import { REQUEST_IOS_META_BY_ID } from "../actions/ios";
import { RECEIVE_IOS_META_BY_ID } from "../actions/ios";
import { CLEAR_IOS_META_BY_ID } from "../actions/ios";
import { DELETE_IOS } from "../actions/ios";
import { REQUEST_IOS_URL } from "../actions/ios";
import { RECEIVE_IOS_URL } from "../actions/ios";
import { CLEAR_IOS_URL } from "../actions/ios";
import { REQUEST_IOS_META_URL } from "../actions/ios";
import { RECEIVE_IOS_META_URL } from "../actions/ios";
import { CLEAR_IOS_META_URL } from "../actions/ios";
import { REQUEST_CREATE_META_DATA } from "../actions/ios";
import { RECEIVE_CREATE_META_DATA } from "../actions/ios";


export default function image(
  state = {
    allIosIds: [],
    allIosIdsIsFetching: false,

    iosById: [],
    iosByIdIsFetching: false,

    iosMetaById: [],
    iosMetaByIdIsFetching: false,

    iosOperationStatus: [],
    iosOperationIsFetching: false,

    iosUrlIsFetching: false,
    iosUrl: [],

    iosMetaUrlIsFetching: false,
    iosMetaUrl: [],

    metaDataIsFetching: false,
    metaData: []
  },
  action
) {
  switch (action.type) {
    /*********** ***********/
    case REQUEST_ALL_IOS_IDS:
      return {
        ...state,
        allIosIdsIsFetching: true
      };
    case RECEIVE_ALL_IOS_IDS:
      return {
        ...state,
        allIosIdsIsFetching: false,
        allIosIds: action.payload
      };

    /******************************************/

    case REQUEST_IOS_URL:
      return {
        ...state,
        iosUrlIsFetching: true
      };
    case RECEIVE_IOS_URL:
      return {
        ...state,
        iosUrlIsFetching: false,
        iosUrl: action.payload
      };

      case CLEAR_IOS_URL:
      return {
        ...state,
        iosUrl: []
      };

    /******************************************/

    /******************************************/

    case REQUEST_IOS_META_URL:
      return {
        ...state,
        iosMetaUrlIsFetching: true
      };
    case RECEIVE_IOS_META_URL:
      return {
        ...state,
        iosMetaUrlIsFetching: false,
        iosMetaUrl: action.payload
      };

      case CLEAR_IOS_META_URL:
      return {
        ...state,
        iosMetaUrl: []
      };

    /******************************************/

    /***********  ***********/
    case REQUEST_SET_IOS:
      return {
        ...state,
        iosOperationIsFetching: true
      };
    case RECEIVE_SET_IOS:
      return {
        ...state,
        iosOperationIsFetching: false,
        iosOperationStatus: action.payload
      };
    /******************************************/

    /***********  ***********/
    case REQUEST_IOS_BY_ID:
      return {
        ...state,
        iosByIdIsFetching: true
      };
    case RECEIVE_IOS_BY_ID:
      return {
        ...state,
        iosByIdIsFetching: false,
        iosById: action.payload
      };

    case CLEAR_IOS_BY_ID:
      return {
        ...state,
        iosById: []
      };
    /******************************************/

    /***********  ***********/
    case REQUEST_IOS_META_BY_ID:
      return {
        ...state,
        iosMetaByIdIsFetching: true
      };
    case RECEIVE_IOS_META_BY_ID:
      return {
        ...state,
        iosMetaByIdIsFetching: false,
        iosMetaById: action.payload
      };

    case CLEAR_IOS_META_BY_ID:
      return {
        ...state,
        iosMetaById: []
      };
    /******************************************/

    /***********  ***********/
    case DELETE_IOS:
      return {
        ...state,
        iosOperationStatus: action.payload
      };

    /******************************************/

    /***********  ***********/
    case REQUEST_CREATE_META_DATA:
      return {
        ...state,
        metaDataIsFetching: true
      };
    case RECEIVE_CREATE_META_DATA:
      return {
        ...state,
        metaDataIsFetching: false,
        metaData: action.payload
      };

    /******************************************/

    default:
      return state;
  }
}
