import {
  REQUEST_LOGBOOK_RECORDS_COUNT,
  RECEIVE_LOGBOOK_RECORDS_COUNT,
  CLEAR_LOGBOOK_RECORDS_COUNT,
  REQUEST_LOGBOOK_RECORDS,
  RECEIVE_LOGBOOK_RECORDS,
  RECEIVE_SCROLL_LOGBOOK_RECORDS,
  CLEAR_LOGBOOK_RECORDS,
  REQUEST_LOGBOOK_RECORDS_ID,
  RECEIVE_LOGBOOK_RECORDS_ID,
  CLEAR_LOGBOOK_RECORDS_ID,
  REQUEST_LOGBOOK_RECORD_ID,
  RECEIVE_LOGBOOK_RECORD_ID,
  CLEAR_LOGBOOK_RECORD_ID,
  REQUEST_ADD_LOGBOOK_RECORD,
  RECEIVE_ADD_LOGBOOK_RECORD,
  REQUEST_SET_LOGBOOK_RECORD,
  RECEIVE_SET_LOGBOOK_RECORD
} from "../actions/logbook";

export default function logbook(
  state = {
    logBookRecordsIsFetching: false,
    logBookRecordsCountIsFetching: false,
    logBookRecordsByIdsIsFetching: false,
    logBookRecordByIdIsFetching: false,
    logBookRecords: [],
    logBookRecordsCount: [],
    logBookRecordsByIds: [],
    logBookRecordById: [],

    logbookOperationIsFetching: false,
    logbookOperationStatus: []
  },
  action
) {
  switch (action.type) {
    case REQUEST_LOGBOOK_RECORDS_COUNT:
      return {
        ...state,
        logBookRecordsCountIsFetching: true
      };

    case RECEIVE_LOGBOOK_RECORDS_COUNT:
      return {
        ...state,
        logBookRecordsCountIsFetching: false,
        logBookRecordsCount: action.logBookRecords
      };

    case CLEAR_LOGBOOK_RECORDS_COUNT:
      return {
        ...state,
        logBookRecordsCount: []
      };

    case REQUEST_LOGBOOK_RECORDS:
      return {
        ...state,
        logBookRecordsIsFetching: true
      };

    case RECEIVE_LOGBOOK_RECORDS:
      return {
        ...state,
        logBookRecordsIsFetching: false,
        logBookRecords: action.logBookRecords
      };

    case CLEAR_LOGBOOK_RECORDS:
      return {
        ...state,
        logBookRecords: []
      };

    case RECEIVE_SCROLL_LOGBOOK_RECORDS:
      if (action.logBookRecords.result) {
        if (state.logBookRecords.result) {
          let obj = state.logBookRecords;
          let length = obj.result.length;

          for (let prop in action.logBookRecords.result) {
            obj.result[length] = action.logBookRecords.result[prop];
            length++;
          }
          return {
            ...state,
            logBookRecordsIsFetching: false,
            logBookRecords: obj
          };
        } else {
          return {
            ...state,
            logBookRecordsIsFetching: false,
            logBookRecords: action.logBookRecords
          };
        }
      } else {
        return {
          ...state,
          logBookRecordsIsFetching: false
        };
      }

    case REQUEST_LOGBOOK_RECORDS_ID:
      return {
        ...state,
        logBookRecordsByIdsIsFetching: true
      };

    case RECEIVE_LOGBOOK_RECORDS_ID:
      let logBookRecordsByIds = state.logBookRecordsByIds;

      if (!logBookRecordsByIds.result) {
        logBookRecordsByIds = action.payload;
      } else if (action.payload.result) {
        logBookRecordsByIds.result = logBookRecordsByIds.result.concat(
          action.payload.result
        );
      } else {
        logBookRecordsByIds.error = action.payload.error;
      }

      return {
        ...state,
        logBookRecordsByIdsIsFetching: false,
        logBookRecordsByIds: logBookRecordsByIds
      };

    case CLEAR_LOGBOOK_RECORDS_ID:
      return {
        ...state,
        logBookRecordsByIds: []
      };

    case REQUEST_LOGBOOK_RECORD_ID:
      return {
        ...state,
        logBookRecordByIdIsFetching: true
      };

    case RECEIVE_LOGBOOK_RECORD_ID:
      return {
        ...state,
        logBookRecordByIdIsFetching: false,
        logBookRecordById: action.logBookRecordById
      };

    case CLEAR_LOGBOOK_RECORD_ID:
      return {
        ...state,
        logBookRecordById: []
      };

    /********************* add logbook record ****************/
    case REQUEST_ADD_LOGBOOK_RECORD:
    case REQUEST_SET_LOGBOOK_RECORD:
      return {
        ...state,
        logbookOperationIsFetching: true
      };

    case RECEIVE_ADD_LOGBOOK_RECORD:
    case RECEIVE_SET_LOGBOOK_RECORD:
      return {
        ...state,
        logbookOperationIsFetching: false,
        logbookOperationStatus: action.payload
      };
    /********************************************************/
    default:
      return state;
  }
}
