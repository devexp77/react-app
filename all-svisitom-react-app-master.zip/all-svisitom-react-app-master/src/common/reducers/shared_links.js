import {
  REQUEST_ADD_SHARED_LINK,
  RECEIVE_ADD_SHARED_LINK,
  REQUEST_SHARED_LINKS,
  RECEIVE_SHARED_LINKS,
  CLEAR_SHARED_LINKS,
  REQUEST_DELETE_SHARED_LINKS,
  RECEIVE_DELETE_SHARED_LINKS
} from "../actions/shared_links";

export default function shared_links(
  state = {
    sharedLinksOperationIsFetching: false,
    sharedLinksOperationStatus: {},

    sharedLinksIsFetching: false,
    sharedLinks: {}
  },
  action
) {
  switch (action.type) {
    /************  ************/
    case REQUEST_ADD_SHARED_LINK:
    case REQUEST_DELETE_SHARED_LINKS:
      return {
        ...state,
        sharedLinksOperationIsFetching: true
      };

    case RECEIVE_ADD_SHARED_LINK:
    case RECEIVE_DELETE_SHARED_LINKS:
      return {
        ...state,
        sharedLinksOperationIsFetching: false,
        sharedLinksOperationStatus: action.payload
      };
    /*****************************************/

    /************ get tasks ************/
    case REQUEST_SHARED_LINKS:
      return {
        ...state,
        sharedLinksIsFetching: true
      };

    case RECEIVE_SHARED_LINKS:
      return {
        ...state,
        sharedLinksIsFetching: false,
        sharedLinks: action.payload
      };

    case CLEAR_SHARED_LINKS:
      return {
        ...state,
        sharedLinks: {}
      };
    /*****************************************/

    default:
      return state;
  }
}
