import {
  REQUEST_DEVICES,
  RECEIVE_DEVICES,
  REQUEST_MORE_DEVICES,
  RECEIVE_MORE_DEVICES,
  CLEAR_DEVICES,
  REQUEST_DEVICE_BY_ID,
  RECEIVE_DEVICE_BY_ID,
  CLEAR_DEVICE_BY_ID,
  REQUEST_DEVICE_EXECUTE_METHOD,
  RECEIVE_DEVICE_EXECUTE_METHOD,
  CLEAR_DEVICE_EXECUTE_METHOD,
  REQUEST_DEVICE_EXECUTE_METHOD_SET_CONFIG,
  RECEIVE_DEVICE_EXECUTE_METHOD_SET_CONFIG,
  CLEAR_DEVICE_EXECUTE_METHOD_SET_CONFIG,
  REQUEST_DEVICE_EXECUTE_METHOD_GET_CONFIG,
  RECEIVE_DEVICE_EXECUTE_METHOD_GET_CONFIG,
  CLEAR_DEVICE_EXECUTE_METHOD_GET_CONFIG,
  SELECT_DEVICE,
  REQUEST_DEVICE_EXECUTE_METHOD_GET_DOORS,
  RECEIVE_DEVICE_EXECUTE_METHOD_GET_DOORS,
  CLEAR_DEVICE_EXECUTE_METHOD_GET_DOORS,
  REQUEST_ADD_DEVICE,
  RECEIVE_ADD_DEVICE,
  REQUEST_DELETE_DEVICE,
  RECEIVE_DELETE_DEVICE,
  REQUEST_USER_DOORS,
  RECEIVE_USER_DOORS,
  CLEAR_USER_DOORS,
  REQUEST_ATTACH_DEVICE_TO_OBJECT,
  RECEIVE_ATTACH_DEVICE_TO_OBJECT,
  RECEIVE_DETACH_DEVICE_FROM_OBJECT,
  REQUEST_DETACH_DEVICE_FROM_OBJECT,
  REQUEST_SET_DEVICE,
  RECEIVE_SET_DEVICE,
  REQUEST_SET_ACCESS_POINT_PERMISSIONS,
  RECEIVE_SET_ACCESS_POINT_PERMISSIONS,
  REQUEST_GET_ACCESS_POINT_USERS,
  RECEIVE_GET_ACCESS_POINT_USERS,
  CLEAR_ACCESS_POINT_USERS,
  REQUEST_DELETE_ACCESS_POINT_PERMISSIONS,
  RECEIVE_DELETE_ACCESS_POINT_PERMISSIONS,
  RECEIVE_OPEN_ACCESS_POINT,
  REQUEST_OPEN_ACCESS_POINT,
  REQUEST_DISTANCE_TO_ACCESS_POINTS,
  RECEIVE_DISTANCE_TO_ACCESS_POINTS,
  CLEAR_DISTANCE_TO_ACCESS_POINTS,
  REQUEST_OPEN_ACCESS_POINT_AND_REGISTER_PASS,
  RECEIVE_OPEN_ACCESS_POINT_AND_REGISTER_PASS,
  RECEIVE_CHECK_DEVICES_ONLINE,
  REQUEST_CHECK_DEVICES_ONLINE,
  REQUEST_TEMPORARY_DEVICES_IDS,
  RECEIVE_TEMPORARY_DEVICES_IDS,
  REQUEST_REGISTER_TEMPORARY_DEVICE,
  RECEIVE_REGISTER_TEMPORARY_DEVICE,
  REQUEST_TOUCH_TEMPORARY_DEVICE, RECEIVE_TOUCH_TEMPORARY_DEVICE,
  RECEIVE_DOORS,
  REQUEST_DOORS,
  CLEAR_DOORS,
  REQUEST_OPEN_ACCESS_POINT_BY_SHARED_LINK,
  RECEIVE_OPEN_ACCESS_POINT_BY_SHARED_LINK,
  REQUEST_DEVICE_BY_ACCESS_POINT_ID,
  RECEIVE_DEVICE_BY_ACCESS_POINT_ID,
} from "../actions/devices";

export default function activity(
  state = {
    devicesIsFetching: false,
    devices: {},

    deviceByIdIsFetching: false,
    deviceById: {},

    setConfigExecuteMethodIsFetching: false,
    setConfigExecuteMethodResult: {},

    getConfigExecuteMethodIsFetching: false,
    getConfigExecuteMethodResult: {},

    getDoorsExecuteMethodIsFetching: false,
    getDoorsExecuteMethodResult: {},

    executeMethodIsFetching: false,
    executeMethodResult: {},

    deviceOperationIsFetching: false,
    deviceOperation: {},

    selectedDevices: {},

    userDoorsIsFetching: false,
    userDoors: {},

    doorsIsFetching: false,
    doors: {},

    accessPointUsersIsFetching: false,
    accessPointUsers: {},

    distanceToAccessPointsIsFetching: false,
    distanceToAccessPoints: {},

    checkDevicesOnline: {},
    checkDevicesOnlineIsFetching: {},

    temporaryDevicesIsFetching: false,
    temporaryDevices: {},

    deviceByAccessPointIdIsFetching: false,
    deviceByAccessPointId: {}
  },
  action
) {
  switch (action.type) {
    /************ get devices ************/
    case REQUEST_DEVICES:
      return {
        ...state,
        devicesIsFetching: true
      };

    case RECEIVE_DEVICES:
      return {
        ...state,
        devicesIsFetching: false,
        devices: action.payload
      };

    case REQUEST_MORE_DEVICES:
      return {
        ...state,
        devicesIsFetching: true
      };

    case RECEIVE_MORE_DEVICES:
      let obj = state.devices;
      obj.result = obj.result.concat(action.payload.result);
      return {
        ...state,
        devicesIsFetching: false,
        devices: obj
      };

    case CLEAR_DEVICES:
      return {
        ...state,
        devicesIsFetching: false,
        devices: {}
      };
    /*****************************************/

    /************ get device by id ************/
    case REQUEST_DEVICE_BY_ID:
      return {
        ...state,
        deviceByIdIsFetching: true
      };

    case RECEIVE_DEVICE_BY_ID:
      return {
        ...state,
        deviceByIdIsFetching: false,
        deviceById: action.payload
      };

    case CLEAR_DEVICE_BY_ID:
      return {
        ...state,
        deviceByIdIsFetching: false,
        deviceById: {}
      };
    /*****************************************/

    /************ execute method on device ************/
    case REQUEST_DEVICE_EXECUTE_METHOD:
      return {
        ...state,
        executeMethodIsFetching: true
      };

    case RECEIVE_DEVICE_EXECUTE_METHOD:
      return {
        ...state,
        executeMethodIsFetching: false,
        executeMethodResult: action.payload
      };

    case CLEAR_DEVICE_EXECUTE_METHOD:
      return {
        ...state,
        executeMethodResult: {}
      };

    /************ set config execute method on device ************/
    case REQUEST_DEVICE_EXECUTE_METHOD_SET_CONFIG:
      return {
        ...state,
        setConfigExecuteMethodIsFetching: true
      };

    case RECEIVE_DEVICE_EXECUTE_METHOD_SET_CONFIG:
      return {
        ...state,
        setConfigExecuteMethodIsFetching: false,
        setConfigExecuteMethodResult: action.payload
      };

    case CLEAR_DEVICE_EXECUTE_METHOD_SET_CONFIG:
      return {
        ...state,
        setConfigExecuteMethodResult: {}
      };

    /************ get config execute method on device ************/
    case REQUEST_DEVICE_EXECUTE_METHOD_GET_CONFIG:
      return {
        ...state,
        getConfigExecuteMethodIsFetching: true
      };

    case RECEIVE_DEVICE_EXECUTE_METHOD_GET_CONFIG:
      return {
        ...state,
        getConfigExecuteMethodIsFetching: false,
        getConfigExecuteMethodResult: action.payload
      };

    case CLEAR_DEVICE_EXECUTE_METHOD_GET_CONFIG:
      return {
        ...state,
        getConfigExecuteMethodResult: {}
      };

    /************ get config execute method on device ************/
    case REQUEST_DEVICE_EXECUTE_METHOD_GET_DOORS:
      return {
        ...state,
        getDoorsExecuteMethodIsFetching: true
      };

    case RECEIVE_DEVICE_EXECUTE_METHOD_GET_DOORS:
      return {
        ...state,
        getDoorsExecuteMethodIsFetching: false,
        getDoorsExecuteMethodResult: action.payload
      };

    case CLEAR_DEVICE_EXECUTE_METHOD_GET_DOORS:
      return {
        ...state,
        getDoorsExecuteMethodResult: {}
      };

    /************ execute method on device ************/
    case SELECT_DEVICE:
      let selectedDevices = state.selectedDevices;
      selectedDevices[action.payload.kind] = action.payload.device;
      return {
        ...state,
        selectedDevices: selectedDevices
      };

    /*
    add_device
     */
    case REQUEST_ADD_DEVICE:
    case REQUEST_ATTACH_DEVICE_TO_OBJECT:
    case REQUEST_DETACH_DEVICE_FROM_OBJECT:
    case REQUEST_SET_DEVICE:
    case REQUEST_SET_ACCESS_POINT_PERMISSIONS:
    case REQUEST_DELETE_ACCESS_POINT_PERMISSIONS:
    case REQUEST_OPEN_ACCESS_POINT:
    case REQUEST_OPEN_ACCESS_POINT_AND_REGISTER_PASS:
    case REQUEST_REGISTER_TEMPORARY_DEVICE:
    case REQUEST_TOUCH_TEMPORARY_DEVICE:
    case REQUEST_OPEN_ACCESS_POINT_BY_SHARED_LINK:
      return {
        ...state,
        deviceOperationIsFetching: true
      };

    case RECEIVE_ADD_DEVICE:
    case RECEIVE_ATTACH_DEVICE_TO_OBJECT:
    case RECEIVE_DETACH_DEVICE_FROM_OBJECT:
    case RECEIVE_SET_DEVICE:
    case RECEIVE_SET_ACCESS_POINT_PERMISSIONS:
    case RECEIVE_DELETE_ACCESS_POINT_PERMISSIONS:
    case RECEIVE_OPEN_ACCESS_POINT:
    case RECEIVE_OPEN_ACCESS_POINT_AND_REGISTER_PASS:
    case RECEIVE_REGISTER_TEMPORARY_DEVICE:
    case RECEIVE_TOUCH_TEMPORARY_DEVICE:
    case RECEIVE_OPEN_ACCESS_POINT_BY_SHARED_LINK:
      return {
        ...state,
        deviceOperationIsFetching: false,
        deviceOperation: action.payload
      };

    /*
      delete device
     */
    case REQUEST_DELETE_DEVICE:
      return {
        ...state,
        deviceOperationIsFetching: true
      };

    case RECEIVE_DELETE_DEVICE:
      return {
        ...state,
        deviceOperationIsFetching: false,
        deviceOperation: action.payload
      };

    /*
      get_user_doors
     */
    case REQUEST_USER_DOORS:
      return {
        ...state,
        userDoorsIsFetching: true
      };

    case RECEIVE_USER_DOORS:
      return {
        ...state,
        userDoorsIsFetching: false,
        userDoors: action.payload
      };

    case CLEAR_USER_DOORS:
      return {
        ...state,
        userDoors: {}
      };


      /*
      get_doors
     */
    case REQUEST_DOORS:
      return {
        ...state,
       doorsIsFetching: true
      };

    case RECEIVE_DOORS:
      return {
        ...state,
       doorsIsFetching: false,
       doors: action.payload
      };

    case CLEAR_DOORS:
      return {
        ...state,
       doors: {}
      };

    case REQUEST_GET_ACCESS_POINT_USERS:
      return {
        ...state,
        accessPointUsersIsFetching: true
      };

    case RECEIVE_GET_ACCESS_POINT_USERS:
      return {
        ...state,
        accessPointUsersIsFetching: false,
        accessPointUsers: action.payload
      };

    case CLEAR_ACCESS_POINT_USERS:
      return {
        ...state,
        accessPointUsers: []
      };

      case REQUEST_DISTANCE_TO_ACCESS_POINTS:
      return {
        ...state,
        distanceToAccessPointsIsFetching: true
      };

    case RECEIVE_DISTANCE_TO_ACCESS_POINTS:
      return {
        ...state,
        distanceToAccessPointsIsFetching: false,
        distanceToAccessPoints: action.payload
      };

    case CLEAR_DISTANCE_TO_ACCESS_POINTS:
      return {
        ...state,
        distanceToAccessPoints: []
      };

    case REQUEST_CHECK_DEVICES_ONLINE:
      return {
        ...state,
        checkDevicesOnlineIsFetching: true
      };

    case RECEIVE_CHECK_DEVICES_ONLINE:
      return {
        ...state,
        checkDevicesOnlineIsFetching: false,
        checkDevicesOnline: action.payload
      };

    case REQUEST_TEMPORARY_DEVICES_IDS:
      return {
        ...state,
        temporaryDevicesIsFetching: true
      };

    case RECEIVE_TEMPORARY_DEVICES_IDS:
      return {
        ...state,
        temporaryDevicesIsFetching: false,
        temporaryDevices: action.payload
      };

    /*
      get device by access point id
     */
    case REQUEST_DEVICE_BY_ACCESS_POINT_ID:
      return {
        ...state,
        deviceByAccessPointIdIsFetching: true,
      };

    case RECEIVE_DEVICE_BY_ACCESS_POINT_ID:
      return {
        ...state,
        deviceByAccessPointIdIsFetching: false,
        deviceByAccessPointId: action.payload,
      };


    default:
      return state;
  }
}
