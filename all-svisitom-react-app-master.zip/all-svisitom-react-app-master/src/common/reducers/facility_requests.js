import {
  REQUEST_ADD_FM_REQUEST,
  RECEIVE_ADD_FM_REQUEST,
  SAVE_FM_REQUEST_DATA,
  CLEAR_FM_REQUEST_DATA,
  REQUEST_FM_REQUEST_RECORDS,
  RECEIVE_FM_REQUEST_RECORDS,
  RECEIVE_SCROLL_FM_REQUEST_RECORDS,
  CLEAR_FM_REQUEST_RECORDS,
  REQUEST_FM_REQUEST_RECORD_ID,
  RECEIVE_FM_REQUEST_RECORD_ID,
  CLEAR_FM_REQUEST_RECORD_BY_ID,
  SAVE_FM_REQUESTS_FILTER,
  REQUEST_SET_FACILITY_REQUEST,
  RECEIVE_SET_FACILITY_REQUEST,
  SAVE_FM_REQUESTS_OFFSET,
  RECEIVE_IS_FM_REQUEST_IN_FILTER,
  REQUEST_SET_FACILITY_REQUEST_STATUS,
  RECEIVE_SET_FACILITY_REQUEST_STATUS,
  CLEAR_FM_ALLOWED_ACTIONS,
  REQUEST_FM_ALLOWED_ACTIONS,
  RECEIVE_FM_ALLOWED_ACTIONS,
  RECEIVE_FM_REQUESTS_COUNT,
  REQUEST_FM_REQUESTS_COUNT,
  REQUEST_FM_REQUESTS_COUNT_BY_ROOMS_IDS,
  RECEIVE_FM_REQUESTS_COUNT_BY_ROOMS_IDS,
  REQUEST_GET_FM_REQUEST_IN_WORK,
  RECEIVE_GET_FM_REQUEST_IN_WORK,
  REQUEST_SET_FACILITY_REQUEST_PAID_STATUS,
  RECEIVE_SET_FACILITY_REQUEST_PAID_STATUS,
  REQUEST_ADD_GROUP_FM_REQUEST,
  RECEIVE_ADD_GROUP_FM_REQUEST,
  CLEAR_CHILD_FM_REQUEST_RECORDS,
  RECEIVE_CHILD_FM_REQUEST_RECORDS,
  REQUEST_CHILD_FM_REQUEST_RECORDS,
  REQUEST_UPDATE_WORK_INTERVAL,
  RECEIVE_UPDATE_WORK_INTERVAL
} from "../actions/facility_requests";

export default function requests(
  state = {
    requestOperationIsFetching: false,
    requestOperationStatus: [],
    requestData: [],

    requestRecordsIsFetching: false,
    requestRecords: [],

    childRequestRecordsIsFetching: false,
    childRequestRecords: [],

    requestRecordByIdIsFetching: false,
    requestRecordById: [],

    requestsFilter: [],

    fmRequestsOffset: 0,

    isFmRequestInFilter: [],

    allowedActionsIsFetching: false,
    allowedActions: [],

    requestCountIsFetching: [],
    allRequestsCount: [],
    acceptedRequestsCount: [],
    rejectedRequestsCount: [],
    in_workRequestsCount: [],
    doneRequestsCount: [],
    closedRequestsCount: [],
    expiredRequestsCount: [],

    requestsCountByRoomIds: [],
    requestsCountByRoomIdsIsFetching: false
  },
  action
) {
  switch (action.type) {
    /************** set request *******************/
    case REQUEST_SET_FACILITY_REQUEST:
    case REQUEST_GET_FM_REQUEST_IN_WORK:
    case REQUEST_UPDATE_WORK_INTERVAL:
      return {
        ...state,
        requestOperationIsFetching: true
      };

    case RECEIVE_SET_FACILITY_REQUEST:
    case RECEIVE_GET_FM_REQUEST_IN_WORK:
    case RECEIVE_UPDATE_WORK_INTERVAL:
      return {
        ...state,
        requestOperationIsFetching: false,
        requestOperationStatus: action.payload
      };

    /********************************************/

    /************** set request status*******************/
    case REQUEST_SET_FACILITY_REQUEST_STATUS:
    case REQUEST_SET_FACILITY_REQUEST_PAID_STATUS:
      return {
        ...state,
        requestOperationIsFetching: true
      };

    case RECEIVE_SET_FACILITY_REQUEST_STATUS:
    case RECEIVE_SET_FACILITY_REQUEST_PAID_STATUS:
      return {
        ...state,
        requestOperationIsFetching: false,
        requestOperationStatus: action.payload
      };

    /********************************************/

    /******************* add request *********************/
    case REQUEST_ADD_FM_REQUEST:
    case REQUEST_ADD_GROUP_FM_REQUEST:
      return {
        ...state,
        requestOperationIsFetching: true
      };

    case RECEIVE_ADD_FM_REQUEST:
    case RECEIVE_ADD_GROUP_FM_REQUEST:
      return {
        ...state,
        requestOperationIsFetching: false,
        requestOperationStatus: action.payload
      };

    /*************************************************************/

    /******************** get request records *****************/
    case REQUEST_FM_REQUEST_RECORDS:
      return {
        ...state,
        requestRecordsIsFetching: true
      };

    case RECEIVE_FM_REQUEST_RECORDS:
      return {
        ...state,
        requestRecordsIsFetching: false,
        requestRecords: action.payload
      };

    case RECEIVE_SCROLL_FM_REQUEST_RECORDS:
      let records = state.requestRecords;
      if (action.payload.result) {
        records.result = records.result.concat(action.payload.result);
      } else {
        records.error = action.payload.error;
      }
      return {
        ...state,
        requestRecordsIsFetching: false,
        requestRecords: records
      };

    case CLEAR_FM_REQUEST_RECORDS:
      return {
        ...state,
        requestRecords: []
      };

    /*************************************************************/

    /******************** get child request records *****************/
    case REQUEST_CHILD_FM_REQUEST_RECORDS:
      return {
        ...state,
        childRequestRecordsIsFetching: true
      };

    case RECEIVE_CHILD_FM_REQUEST_RECORDS:
      return {
        ...state,
        childRequestRecordsIsFetching: false,
        childRequestRecords: action.payload
      };

    case CLEAR_CHILD_FM_REQUEST_RECORDS:
      return {
        ...state,
        childRequestRecords: []
      };

    /*************************************************************/

    /******************* get request by id ***********************/
    case REQUEST_FM_REQUEST_RECORD_ID:
      return {
        ...state,
        requestRecordByIdIsFetching: true
      };

    case RECEIVE_FM_REQUEST_RECORD_ID:
      return {
        ...state,
        requestRecordByIdIsFetching: false,
        requestRecordById: action.payload
      };

    case CLEAR_FM_REQUEST_RECORD_BY_ID:
      return {
        ...state,
        requestRecordById: []
      };
    /*************************************************************/

    /******************* get allowed actions ***********************/
    case REQUEST_FM_ALLOWED_ACTIONS:
      return {
        ...state,
        allowedActionsIsFetching: true
      };

    case RECEIVE_FM_ALLOWED_ACTIONS:
      return {
        ...state,
        allowedActionsIsFetching: false,
        allowedActions: action.payload
      };

    case CLEAR_FM_ALLOWED_ACTIONS:
      return {
        ...state,
        allowedActions: []
      };
    /*************************************************************/

    /******************* get facility requests count ***********************/
    case REQUEST_FM_REQUESTS_COUNT:
      return {
        ...state,
        requestCountIsFetching: true
      };

    case RECEIVE_FM_REQUESTS_COUNT:
      return {
        ...state,
        requestCountIsFetching: false,
        [action.field + "RequestsCount"]: action.payload
      };
    /*************************************************************/

    /******************* get facility requests count by rooms ids***********************/
    case REQUEST_FM_REQUESTS_COUNT_BY_ROOMS_IDS:
      return {
        ...state,
        requestsCountByRoomIdsIsFetching: true
      };

    case RECEIVE_FM_REQUESTS_COUNT_BY_ROOMS_IDS:
      return {
        ...state,
        requestsCountByRoomIdsIsFetching: false,
        requestsCountByRoomIds: state.requestsCountByRoomIds.result
          ? Object.assign(state.requestsCountByRoomIds, action.payload)
          : action.payload
      };
    /*************************************************************/

    case SAVE_FM_REQUEST_DATA:
      return {
        ...state,
        requestData: action.payload
      };

    case CLEAR_FM_REQUEST_DATA:
      return {
        ...state,
        requestData: []
      };

    case SAVE_FM_REQUESTS_FILTER:
      return {
        ...state,
        requestsFilter: action.payload
      };

    case SAVE_FM_REQUESTS_OFFSET:
      return {
        ...state,
        fmRequestsOffset: action.payload
      };

    case RECEIVE_IS_FM_REQUEST_IN_FILTER:
      return {
        ...state,
        isFmRequestInFilter: action.payload
      };

    default:
      return state;
  }
}
