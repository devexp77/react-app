import {
    REQUEST_ADD_MAP_ROUTE,
    RECEIVE_ADD_MAP_ROUTE,
    RECEIVE_SET_MAP_ROUTE,
    REQUEST_SET_MAP_ROUTE,
    REQUEST_DELETE_MAP_ROUTE,
    RECEIVE_DELETE_MAP_ROUTE,
    REQUEST_MAP_ROUTES,
    RECEIVE_MAP_ROUTES,
    CLEAR_MAP_ROUTES,
    REQUEST_MAP_ROUTE_BY_ID,
    RECEIVE_MAP_ROUTE_BY_ID,
    CLEAR_MAP_ROUTE_BY_ID,
} from '../actions/map_routes'


export default function map_routes(state = {
    mapRouteOperationIsFetching: false,
    mapRouteOperationStatus: {},

    mapRoutesIsFetching: false,
    mapRoutes: {},

    allBeaconsIsFetching: false,
    allBeacons: {},

    mapRouteByIdIsFetching: false,
    mapRouteById: {},
}, action) {
    switch (action.type) {

        /************ add, set, delete mapRoute ************/
        case REQUEST_ADD_MAP_ROUTE:
        case REQUEST_DELETE_MAP_ROUTE:
        case REQUEST_SET_MAP_ROUTE:
            return {
                ...state,
                mapRouteOperationIsFetching: true
            };

        case RECEIVE_ADD_MAP_ROUTE:
        case RECEIVE_DELETE_MAP_ROUTE:
        case RECEIVE_SET_MAP_ROUTE:
            return {
                ...state,
                mapRouteOperationIsFetching: false,
                mapRouteOperationStatus: action.payload
            };

        /************ get mapRoute ************/
        case REQUEST_MAP_ROUTE_BY_ID:
            return {
                ...state,
                mapRouteByIdIsFetching: true
            };

        case RECEIVE_MAP_ROUTE_BY_ID:
            return {
                ...state,
                mapRouteByIdIsFetching: false,
                mapRouteById: action.payload
            };

        case CLEAR_MAP_ROUTE_BY_ID:
            return {
                ...state,
                mapRouteById: {}
            };

        /************ get mapRoutes ************/
        case REQUEST_MAP_ROUTES:
            return {
                ...state,
                mapRoutesIsFetching: true
            };

        case RECEIVE_MAP_ROUTES:
            return {
                ...state,
                mapRoutesIsFetching: false,
                mapRoutes: action.payload
            };


        case CLEAR_MAP_ROUTES:
            return {
                ...state,
                mapRoutesIsFetching: false,
                mapRoutes: {}
            };

        /*****************************************/

        default:
            return state
    }
}
