import {
    REQUEST_ADD_BEACON,
    RECEIVE_ADD_BEACON,
    RECEIVE_SET_BEACON,
    REQUEST_SET_BEACON,
    REQUEST_DELETE_BEACONS,
    RECEIVE_DELETE_BEACONS,
    REQUEST_BEACONS,
    RECEIVE_BEACONS,
    RECEIVE_MORE_BEACONS,
    CLEAR_BEACONS,
    REQUEST_BEACON_BY_ID,
    RECEIVE_BEACON_BY_ID,
    CLEAR_BEACON_BY_ID,
  REQUEST_ATTACH_BEACON,
  RECEIVE_ATTACH_BEACON,
  RECEIVE_DETACH_BEACON,
  REQUEST_DETACH_BEACON,
  REQUEST_ALL_BEACONS,
  RECEIVE_ALL_BEACONS,
  CLEAR_ALL_BEACONS
} from '../actions/beacons'


export default function activity(state = {
    beaconOperationIsFetching: false,
    beaconOperationStatus: {},

    beaconsIsFetching: false,
    beacons: {},

    allBeaconsIsFetching: false,
    allBeacons: {},

    beaconByIdIsFetching: false,
    beaconById: {},
}, action) {
    switch (action.type) {

        /************ add, set, delete beacon ************/
        case REQUEST_ADD_BEACON:
        case REQUEST_DELETE_BEACONS:
        case REQUEST_SET_BEACON:
        case REQUEST_ATTACH_BEACON:
        case REQUEST_DETACH_BEACON:
            return {
                ...state,
                beaconOperationIsFetching: true
            };

        case RECEIVE_ADD_BEACON:
        case RECEIVE_DELETE_BEACONS:
        case RECEIVE_SET_BEACON:
        case RECEIVE_ATTACH_BEACON:
        case RECEIVE_DETACH_BEACON:
            return {
                ...state,
                beaconOperationIsFetching: false,
                beaconOperationStatus: action.payload
            };

        /************ get beacon ************/
        case REQUEST_BEACON_BY_ID:
            return {
                ...state,
                beaconByIdIsFetching: true
            };

        case RECEIVE_BEACON_BY_ID:
            return {
                ...state,
                beaconByIdIsFetching: false,
                beaconById: action.payload
            };

        case CLEAR_BEACON_BY_ID:
            return {
                ...state,
                beaconById: {}
            };

        /************ get beacons ************/
        case REQUEST_BEACONS:
            return {
                ...state,
                beaconsIsFetching: true
            };

        case RECEIVE_BEACONS:
            return {
                ...state,
                beaconsIsFetching: false,
                beacons: action.payload
            };

        case RECEIVE_MORE_BEACONS:
            let obj = state.beacons;
            obj.result = obj.result.concat(action.payload.result);
            return {
                ...state,
                beacons: obj,
                beaconsIsFetching: false
            };


        case CLEAR_BEACONS:
            return {
                ...state,
                beaconsIsFetching: false,
                beacons: {}
            };

        /*****************************************/

      /************ get beacons ************/
        case REQUEST_ALL_BEACONS:
            return {
                ...state,
                allBeaconsIsFetching: true
            };

        case RECEIVE_ALL_BEACONS:
            return {
                ...state,
                allBeaconsIsFetching: false,
                allBeacons: action.payload
            };

        case CLEAR_ALL_BEACONS:
            return {
                ...state,
                allBeaconsIsFetching: false,
                allBeacons: {}
            };

        /*****************************************/
        default:
            return state
    }
}
