import {
  REQUEST_ADD_DOCUMENT,
  RECEIVE_ADD_DOCUMENT,
  REQUEST_FACILITY_PROBLEM_DOCUMENTS,
  RECEIVE_FACILITY_PROBLEM_DOCUMENTS,
  REQUEST_OBJECT_DOCUMENTS,
  RECEIVE_OBJECT_DOCUMENTS,
  REQUEST_DOCUMENT_BY_ID,
  RECEIVE_DOCUMENT_BY_ID,
  CLEAR_DOCUMENT_BY_ID,
  CLEAR_FACILITY_PROBLEM_DOCUMENTS,
  CLEAR_OBJECT_DOCUMENTS
} from "../actions/document_attachments";

const date = new Date();
export default function document_attachments(
  state = {
    documentOperationIsFetching: false,
    documentOperationStatus: [],

    facilityProblemDocumentsIsFetching: false,
    facilityProblemDocuments: [],

    objectDocumentsIsFetching: false,
    objectDocuments: [],

    documentByIdIsFetching: false,
    documentById: []
  },
  action
) {
  switch (action.type) {
    /*********** add document ***********/
    case REQUEST_ADD_DOCUMENT:
      return {
        ...state,
        documentOperationIsFetching: true
      };
    case RECEIVE_ADD_DOCUMENT:
      return {
        ...state,
        documentOperationIsFetching: false,
        documentOperationStatus: action.payload
      };

    /******************************************/

    /*********** get facility problem documents ***********/
    case REQUEST_FACILITY_PROBLEM_DOCUMENTS:
      return {
        ...state,
        facilityProblemDocumentsIsFetching: true
      };
    case RECEIVE_FACILITY_PROBLEM_DOCUMENTS:
      return {
        ...state,
        facilityProblemDocumentsIsFetching: false,
        facilityProblemDocuments: action.payload
      };

    case CLEAR_FACILITY_PROBLEM_DOCUMENTS:
      return {
        ...state,
        facilityProblemDocuments: []
      };
    /******************************************/

    /*********** get object documents ***********/
    case REQUEST_OBJECT_DOCUMENTS:
      return {
        ...state,
        objectDocumentsIsFetching: true
      };
    case RECEIVE_OBJECT_DOCUMENTS:
      return {
        ...state,
        objectDocumentsIsFetching: false,
        objectDocuments: action.payload
      };

      case CLEAR_OBJECT_DOCUMENTS:
      return {
        ...state,
        objectDocuments: []
      };

    /******************************************/

    /*********** get document by id***********/
    case REQUEST_DOCUMENT_BY_ID:
      return {
        ...state,
        documentByIdIsFetching: true
      };
    case RECEIVE_DOCUMENT_BY_ID:
      return {
        ...state,
        documentByIdIsFetching: false,
        documentById: action.payload
      };

      case CLEAR_DOCUMENT_BY_ID:
      return {
        ...state,
        documentById: []
      };

    /******************************************/

    default:
      return state;
  }
}
