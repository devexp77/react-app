import {
  REQUEST_ADDRESS_BY_GEO_POINT,
  RECEIVE_ADDRESS_BY_GEO_POINT,
  CLEAR_ADDRESS_BY_GEO_POINT,
  REQUEST_GEO_POINT_BY_ADDRESS,
  RECEIVE_GEO_POINT_BY_ADDRESS,
  CLEAR_GEO_POINT_BY_ADDRESS
} from "../actions/geocoder";

export default function plans(
  state = {
    addressByGeoPointIsFetching: false,
    geoPointByAddress: [],
    addressByGeoPoint: [],
  },
  action
) {
  switch (action.type) {

    /************ get addressByGeoPoint ************/
    case REQUEST_ADDRESS_BY_GEO_POINT:
      return {
        ...state,
        addressByGeoPointIsFetching: true
      };

    case RECEIVE_ADDRESS_BY_GEO_POINT:
      return {
        ...state,
        addressByGeoPointIsFetching: false,
        addressByGeoPoint: action.payload
      };

    case CLEAR_ADDRESS_BY_GEO_POINT:
      return {
        ...state,
        addressByGeoPoint: []
      };
    /*****************************************/

    /************ get GeoPoint by Address ************/
    case REQUEST_GEO_POINT_BY_ADDRESS:
      return {
        ...state,
        geoPointByAddressIsFetching: true
      };

    case RECEIVE_GEO_POINT_BY_ADDRESS:
      return {
        ...state,
        geoPointByAddressIsFetching: false,
        geoPointByAddress: action.payload
      };

    case CLEAR_GEO_POINT_BY_ADDRESS:
      return {
        ...state,
        geoPointByAddress: []
      };
    /*****************************************/


    default:
      return state;
  }
}
