import {
  REQUEST_USER_TRANSPORT,
  RECEIVE_USER_TRANSPORT,
  REQUEST_ADD_USER_TRANSPORT,
  RECEIVE_ADD_USER_TRANSPORT,
  REQUEST_SET_USER_TRANSPORT,
  RECEIVE_SET_USER_TRANSPORT,
  REQUEST_DELETE_USER_TRANSPORT,
  RECEIVE_DELETE_USER_TRANSPORT,
  REQUEST_USER_TRANSPORT_BY_ID,
  RECEIVE_USER_TRANSPORT_BY_ID,
  CLEAR_USER_TRANSPORT_OPERATION_STATUS,
  CLEAR_USER_TRANSPORT_BY_ID
} from "../actions/transport";

export default function user(
  state = {
    userTransportIsFetching: false,
    userTransport: [],

    userTransportByIdIsFetching: false,
    userTransportById: [],

    userTransportOperationIsFetching: false,
    userTransportOperationStatus: []
  },
  action
) {
  switch (action.type) {
    case REQUEST_USER_TRANSPORT:
      return {
        ...state,
        userTransportIsFetching: true
      };
    case RECEIVE_USER_TRANSPORT:
      return {
        ...state,
        userTransportIsFetching: false,
        userTransport: action.payload
      };

    case REQUEST_USER_TRANSPORT_BY_ID:
      return {
        ...state,
        userTransportByIdIsFetching: true
      };
    case RECEIVE_USER_TRANSPORT_BY_ID:
      return {
        ...state,
        userTransportByIdIsFetching: false,
        userTransportById: action.payload
      };

    case REQUEST_ADD_USER_TRANSPORT:
      return {
        ...state,
        userTransportOperationIsFetching: true
      };

    case RECEIVE_ADD_USER_TRANSPORT:
      return {
        ...state,
        userTransportOperationIsFetching: false,
        userTransportOperationStatus: action.payload
      };

    case REQUEST_SET_USER_TRANSPORT:
      return {
        ...state,
        userTransportOperationIsFetching: true
      };

    case RECEIVE_SET_USER_TRANSPORT:
      return {
        ...state,
        userTransportOperationIsFetching: false,
        userTransportOperationStatus: action.payload
      };

    case REQUEST_DELETE_USER_TRANSPORT:
      return {
        ...state,
        userTransportOperationIsFetching: true
      };

    case RECEIVE_DELETE_USER_TRANSPORT:
      return {
        ...state,
        userTransportOperationIsFetching: false,
        userTransportOperationStatus: action.payload
      };

    case CLEAR_USER_TRANSPORT_OPERATION_STATUS:
      return {
        ...state,
        userTransportOperationStatus: []
      };

    case CLEAR_USER_TRANSPORT_BY_ID:
      return {
        ...state,
        userTransportById: []
      };

    default:
      return state;
  }
}
