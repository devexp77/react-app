import {
  REQUEST_CONTACTS,
  RECEIVE_CONTACTS,
  CLEAR_CONTACTS, REQUEST_ALL_CONTACTS, RECEIVE_ALL_CONTACTS, CLEAR_ALL_CONTACTS
} from "../actions/contacts";

export default function plans(
  state = {
    contactsIsFetching: false,
    contacts: [],

    allContactsIsFetching: false,
    allContacts: []
  },
  action
) {
  switch (action.type) {
    /************ get contacts ************/
    case REQUEST_CONTACTS:
      return {
        ...state,
        contactsIsFetching: true
      };

    case RECEIVE_CONTACTS:
      return {
        ...state,
        contactsIsFetching: false,
        contacts: {...state.contacts, [action.id] : action.payload}
      };

    case CLEAR_CONTACTS:
      return {
        ...state,
        contacts: []
      };
    /*****************************************/

    /************ get contacts ************/
    case REQUEST_ALL_CONTACTS:
      return {
        ...state,
        allContactsIsFetching: true
      };

    case RECEIVE_ALL_CONTACTS:
      return {
        ...state,
        allContactsIsFetching: false,
        allContacts: action.payload
      };

    case CLEAR_ALL_CONTACTS:
      return {
        ...state,
        allContacts: []
      };
    /*****************************************/

    default:
      return state;
  }
}
