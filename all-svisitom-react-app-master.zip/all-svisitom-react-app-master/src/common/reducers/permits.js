import {
  REQUEST_PERMIT_RECORDS,
  RECEIVE_PERMIT_RECORDS,
  CLEAR_PERMIT_RECORDS,
  RECEIVE_SCROLL_PERMIT_RECORDS,
  REQUEST_PERMIT_RECORD_ID,
  RECEIVE_PERMIT_RECORD_ID,
  CLEAR_PERMIT_RECORD_BY_ID,
  REQUEST_REGISTER_PASS,
  RECEIVE_REGISTER_PASS,
  REQUEST_PERMIT_RECORDS_IDS,
  RECEIVE_PERMIT_RECORDS_IDS,
  SAVE_PERMITS_FILTER,
  REQUEST_PERMIT_ALLOWED_ACTIONS,
  RECEIVE_PERMIT_ALLOWED_ACTIONS,
  REQUEST_CHANGE_PERMIT_STATUS,
  RECEIVE_CHANGE_PERMIT_STATUS,
  RECEIVE_IS_PERMIT_IN_FILTER,
  REQUEST_PERMIT_COUNT,
  RECEIVE_PERMIT_COUNT,
  SAVE_PERMITS_OFFSET,
  CLEAR_PERMIT_ALLOWED_ACTIONS,
  REQUEST_NOTIFY_VISITOR_IS_WAITING,
  RECEIVE_NOTIFY_VISITOR_IS_WAITING,
  REQUEST_SET_PERMIT_RECORD,
  RECEIVE_SET_PERMIT_RECORD,
  RECEIVE_CHANGE_PERMIT_SUSPEND_STATE,
  REQUEST_CHANGE_PERMIT_SUSPEND_STATE
} from "../actions/permits";

export default function permits(
  state = {
    permitRecordsIsFetching: false,
    permitRecords: [],

    permitRecordByIdIsFetching: false,
    permitRecordById: [],

    permitRecordsByIdsIsFetching: false,
    permitRecordsByIds: [],

    registerPassStatus: [],
    permitAllowedActionsIsFetching: false,
    permitAllowedActions: [],
    permitOperationIsFetching: false,
    permitOperationStatus: [],
    permitsFilter: [],
    permitsOffset: 0,

    isPermitInFilter: [],

    arrivesPermitCount: [],
    inPermitCount: [],
    outPermitCount: [],
    allPermitCount: [],
    permitCountIsFetching: false
  },
  action
) {
  switch (action.type) {
    case REQUEST_PERMIT_RECORDS:
      return {
        ...state,
        permitRecordsIsFetching: true
      };

    case RECEIVE_PERMIT_RECORDS:
      return {
        ...state,
        permitRecordsIsFetching: false,
        permitRecords: action.permitRecords
      };

    case CLEAR_PERMIT_RECORDS:
      return {
        ...state,
        permitRecords: []
      };

    case RECEIVE_SCROLL_PERMIT_RECORDS:
      let permits = state.permitRecords;
      if (action.permitRecords.result) {
        permits.result = permits.result.concat(action.permitRecords.result);
      } else {
        permits.error = action.permitRecords.error;
      }
      return {
        ...state,
        permitRecordsIsFetching: false,
        permitRecords: permits
      };

    case REQUEST_PERMIT_RECORD_ID:
      return {
        ...state,
        permitRecordByIdIsFetching: true
      };

    case RECEIVE_PERMIT_RECORD_ID:
      return {
        ...state,
        permitRecordByIdIsFetching: false,
        permitRecordById: action.permitRecordById
      };

    case CLEAR_PERMIT_RECORD_BY_ID:
      return {
        ...state,
        permitRecordById: []
      };

    case REQUEST_REGISTER_PASS:
      return {
        ...state,
        permitOperationIsFetching: true
      };

    case RECEIVE_REGISTER_PASS:
      return {
        ...state,
        permitOperationIsFetching: false,
        registerPassStatus: action.registerPassStatus
      };

    case REQUEST_PERMIT_RECORDS_IDS:
      return {
        ...state,
        permitRecordsByIdsIsFetching: true
      };

    case RECEIVE_PERMIT_RECORDS_IDS:
      let permitByIds = state.permitRecordsByIds;
      if (permitByIds.result) {
        if (action.payload.result) {
          permitByIds.result = permitByIds.result.concat(action.payload.result);
        } else {
          permitByIds.error = action.payload.error;
        }
      } else {
        permitByIds = action.payload;
      }
      return {
        ...state,
        permitRecordsByIdsIsFetching: false,
        permitRecordsByIds: permitByIds
      };

    case REQUEST_PERMIT_ALLOWED_ACTIONS:
      return {
        ...state,
        permitAllowedActionsIsFetching: true
      };

    case RECEIVE_PERMIT_ALLOWED_ACTIONS:
      return {
        ...state,
        permitAllowedActionsIsFetching: false,
        permitAllowedActions: action.payload
      };

    case CLEAR_PERMIT_ALLOWED_ACTIONS:
      return {
        ...state,
        permitAllowedActions: []
      };

    case SAVE_PERMITS_FILTER:
      return {
        ...state,
        permitsFilter: action.payload
      };

    case SAVE_PERMITS_OFFSET:
      return {
        ...state,
        permitsOffset: action.payload
      };

    case REQUEST_CHANGE_PERMIT_STATUS:
    case REQUEST_CHANGE_PERMIT_SUSPEND_STATE:
      return {
        ...state,
        permitOperationIsFetching: true
      };

    case RECEIVE_CHANGE_PERMIT_STATUS:
    case RECEIVE_CHANGE_PERMIT_SUSPEND_STATE:
      return {
        ...state,
        permitOperationIsFetching: false,
        permitOperationStatus: action.registerPassStatus
      };

    case REQUEST_SET_PERMIT_RECORD:
      return {
        ...state,
        permitOperationIsFetching: true
      };

    case RECEIVE_SET_PERMIT_RECORD:
      return {
        ...state,
        permitOperationIsFetching: false,
        permitOperationStatus: action.payload
      };

    case REQUEST_NOTIFY_VISITOR_IS_WAITING:
      return {
        ...state,
        permitOperationIsFetching: true
      };

    case RECEIVE_NOTIFY_VISITOR_IS_WAITING:
      return {
        ...state,
        permitOperationIsFetching: false,
        permitOperationStatus: action.registerPassStatus
      };

    case RECEIVE_IS_PERMIT_IN_FILTER:
      return {
        ...state,
        isPermitInFilter: action.payload
      };

    case REQUEST_PERMIT_COUNT:
      return {
        ...state,
        permitCountIsFetching: true
      };

    case RECEIVE_PERMIT_COUNT:
      return {
        ...state,
        permitCountIsFetching: false,
        [action.field + "PermitCount"]: action.payload
      };

    default:
      return state;
  }
}
