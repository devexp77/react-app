import {
  CLEAR_FACILITY_PROBLEM_BY_ID,
  RECEIVE_FACILITY_PROBLEM_BY_ID,
  REQUEST_FACILITY_PROBLEM_BY_ID,
  REQUEST_ROOM_FACILITY_CONFIG_BY_ROOM_ID,
  REQUEST_ADD_FACILITY_PROBLEM,
  RECEIVE_ADD_FACILITY_PROBLEM,
  REQUEST_SET_FACILITY_PROBLEM,
  RECEIVE_SET_FACILITY_PROBLEM,
  REQUEST_DELETE_FACILITY_PROBLEM,
  RECEIVE_DELETE_FACILITY_PROBLEM,
  REQUEST_SET_ROOM_FACILITY_CONFIG,
  RECEIVE_SET_ROOM_FACILITY_CONFIG,
  REQUEST_ADD_ROOM_FACILITY_CONFIG,
  RECEIVE_ADD_ROOM_FACILITY_CONFIG,
  REQUEST_DELETE_ROOM_FACILITY_CONFIG,
  RECEIVE_DELETE_ROOM_FACILITY_CONFIG,
  REQUEST_FACILITY_AVAILABLE_MASTERS,
  RECEIVE_FACILITY_AVAILABLE_MASTERS,
  CLEAR_FACILITY_AVAILABLE_MASTERS,
  RECEIVE_ROOM_FACILITY_CONFIG_BY_ROOM_ID,
  REQUEST_FACILITY_PROBLEMS,
  RECEIVE_FACILITY_PROBLEMS,
  CLEAR_FACILITY_PROBLEMS,
  CLEAR_ROOM_FACILITY_CONFIG_BY_ROOM_ID,
  REQUEST_USER_SPECIALIZATION,
  RECEIVE_USER_SPECIALIZATION,
  CLEAR_USER_SPECIALIZATION,
  REQUEST_ATTACH_DOCUMENT_TO_PROBLEM,
  RECEIVE_ATTACH_DOCUMENT_TO_PROBLEM,
  REQUEST_DETACH_DOCUMENT_TO_PROBLEM,
  RECEIVE_DETACH_DOCUMENT_TO_PROBLEM,
  SET_FROM_OBJECT_FLAG
} from "../actions/facility";

export default function facility(
  state = {
    roomFacilityConfigByRoomId: [],
    roomFacilityConfigByRoomIdIsFetching: false,

    facilityProblems: [],
    facilityProblemsIsFetching: false,

    facilityProblemById: [],
    facilityProblemByIdIsFetching: false,

    facilityProblemActionStatus: {},
    facilityProblemActionIsFetching: false,

    facilityAvailableMasters: [],
    facilityAvailableMastersIsFetching: false,

    userSpecialization: [],
    userSpecializationIsFetching: false,

    fromObject: false
  },
  action
) {
  switch (action.type) {
    case SET_FROM_OBJECT_FLAG:
      return {
        ...state,
        fromObject: true
      };

    /************ get room facility config  ************/
    case REQUEST_ROOM_FACILITY_CONFIG_BY_ROOM_ID:
      return {
        ...state,
        roomFacilityConfigByRoomIdIsFetching: true
      };

    case RECEIVE_ROOM_FACILITY_CONFIG_BY_ROOM_ID:
      return {
        ...state,
        roomFacilityConfigByRoomIdIsFetching: false,
        roomFacilityConfigByRoomId: action.payload
      };

    case CLEAR_ROOM_FACILITY_CONFIG_BY_ROOM_ID:
      return {
        ...state,
        roomFacilityConfigByRoomId: []
      };

    /************ get facility problems  ************/
    case REQUEST_FACILITY_PROBLEMS:
      return {
        ...state,
        facilityProblemsIsFetching: true
      };

    case RECEIVE_FACILITY_PROBLEMS:
      return {
        ...state,
        facilityProblemsIsFetching: false,
        facilityProblems: action.payload
      };

    case CLEAR_FACILITY_PROBLEMS:
      return {
        ...state,
        facilityProblems: []
      };

    /************ get facility problem by id  ************/
    case REQUEST_FACILITY_PROBLEM_BY_ID:
      return {
        ...state,
        facilityProblemByIdIsFetching: true
      };

    case RECEIVE_FACILITY_PROBLEM_BY_ID:
      return {
        ...state,
        facilityProblemByIdIsFetching: false,
        facilityProblemById: action.payload
      };

    case CLEAR_FACILITY_PROBLEM_BY_ID:
      return {
        ...state,
        facilityProblemById: []
      };

    /*** available masters ***/

    case REQUEST_FACILITY_AVAILABLE_MASTERS:
      return {
        ...state,
        facilityAvailableMastersIsFetching: true
      };

    case RECEIVE_FACILITY_AVAILABLE_MASTERS:
      return {
        ...state,
        facilityAvailableMastersIsFetching: false,
        facilityAvailableMasters: action.payload
      };

    case CLEAR_FACILITY_AVAILABLE_MASTERS:
      return {
        ...state,
        facilityAvailableMasters: []
      };

    /************************/

    /*** user specialization ***/

    case REQUEST_USER_SPECIALIZATION:
      return {
        ...state,
        userSpecializationIsFetching: true
      };

    case RECEIVE_USER_SPECIALIZATION:
      return {
        ...state,
        userSpecializationIsFetching: false,
        userSpecialization: action.payload
      };

    case CLEAR_USER_SPECIALIZATION:
      return {
        ...state,
        userSpecialization: []
      };

    /************************/

    /*************** actions **************/
    case REQUEST_ADD_FACILITY_PROBLEM:
    case REQUEST_SET_FACILITY_PROBLEM:
    case REQUEST_DELETE_FACILITY_PROBLEM:
    case REQUEST_SET_ROOM_FACILITY_CONFIG:
    case REQUEST_ADD_ROOM_FACILITY_CONFIG:
    case REQUEST_DELETE_ROOM_FACILITY_CONFIG:
    case REQUEST_ATTACH_DOCUMENT_TO_PROBLEM:
    case REQUEST_DETACH_DOCUMENT_TO_PROBLEM:
      return {
        ...state,
        facilityProblemActionIsFetching: true
      };

    case RECEIVE_ADD_FACILITY_PROBLEM:
    case RECEIVE_SET_FACILITY_PROBLEM:
    case RECEIVE_DELETE_FACILITY_PROBLEM:
    case RECEIVE_SET_ROOM_FACILITY_CONFIG:
    case RECEIVE_ADD_ROOM_FACILITY_CONFIG:
    case RECEIVE_DELETE_ROOM_FACILITY_CONFIG:
    case RECEIVE_ATTACH_DOCUMENT_TO_PROBLEM:
    case RECEIVE_DETACH_DOCUMENT_TO_PROBLEM:
      return {
        ...state,
        facilityProblemActionIsFetching: false,
        facilityProblemActionStatus: action.payload
      };

    default:
      return state;
  }
}
