import {
  REQUEST_BILLING_ACCOUNT,
  RECEIVE_BILLING_ACCOUNT,
  CLEAR_BILLING_ACCOUNT,
  UPDATE_BILLING_ACCOUNT_BALANCE,

  REQUEST_BILLING_TRANSACTIONS,
  RECEIVE_BILLING_TRANSACTIONS,
  RECEIVE_MORE_BILLING_TRANSACTIONS,
  CLEAR_BILLING_TRANSACTIONS,

  REQUEST_ADD_BILLING_TRANSACTION,
  RECEIVE_ADD_BILLING_TRANSACTION,

  REQUEST_PAYMENT_URL,
  RECEIVE_PAYMENT_URL,
  CLEAR_PAYMENT_URL,

  REQUEST_BILLS,
  RECEIVE_BILLS,
  RECEIVE_MORE_BILLS,
  CLEAR_BILLS,

  REQUEST_BILL_BY_ID,
  RECEIVE_BILL_BY_ID,
  CLEAR_BILL_BY_ID,
} from '../actions/billing'


export default function addressee(state = {
  accountIsFetching: false,
  account: {},

  paymentUrlIsFetching: false,
  paymentUrl: {},

  transactionsIsFetching: false,
  transactions: {},

  addTransactionIsFetching: false,
  addTransaction: {},

  billsIsFetching: false,
  bills: {},

  billIsFetching: false,
  bill: {},
}, action){
  switch (action.type) {

    /*
      get account
    */
    case REQUEST_BILLING_ACCOUNT:
    return {
      ...state,
      accountIsFetching: true
    }

    case RECEIVE_BILLING_ACCOUNT:
    return {
      ...state,
      accountIsFetching: false,
      account: action.payload
    }

    case CLEAR_BILLING_ACCOUNT:
    return {
      ...state,
      account: {}
    }

    case UPDATE_BILLING_ACCOUNT_BALANCE:
    let obj = state.account
    if (obj.result) {
      obj.result.balance = action.payload.balance
      return {
        ...state,
        account: obj
      }
    } else {
      return state
    }

    /*
      get_transactions
    */

    case REQUEST_BILLING_TRANSACTIONS:
    return {
      ...state,
      transactionsIsFetching: true
    }

    case RECEIVE_BILLING_TRANSACTIONS:
    return {
      ...state,
      transactionsIsFetching: false,
      transactions: action.payload
    }

    case RECEIVE_MORE_BILLING_TRANSACTIONS:
    var obj = state.transactions
    if (action.payload.result) {
      obj.result = obj.result.concat(action.payload.result)
    } else {
      obj.error = action.payload.error
    }
    return {
      ...state,
      transactionsIsFetching: false,
      transactions: obj
    }

    case CLEAR_BILLING_TRANSACTIONS:
    return {
      ...state,
      transactionsIsFetching: false,
      transactions: []
    }

    /*
      add_transaction
    */
    case REQUEST_ADD_BILLING_TRANSACTION:
    return {
      ...state,
      addTransactionIsFetching: true
    }

    case RECEIVE_ADD_BILLING_TRANSACTION:
    return {
      ...state,
      addTransactionIsFetching: false,
      addTransaction: action.payload
    }

    /*
      get_product_url
    */

    case REQUEST_PAYMENT_URL:
    return {
      ...state,
      paymentUrlIsFetching: true
    }

    case RECEIVE_PAYMENT_URL:
    return {
      ...state,
      paymentUrlIsFetching: false,
      paymentUrl: action.payload
    }

    case CLEAR_PAYMENT_URL:
    return {
      ...state,
      paymentUrlIsFetching: false,
      paymentUrl: {}
    }


    /*
      bills
    */

    case REQUEST_BILLS:
      return {
        ...state,
        billsIsFetching: true
      }

    case RECEIVE_BILLS:
      return {
        ...state,
        billsIsFetching: false,
        bills: action.payload
      }

    case RECEIVE_MORE_BILLS:
      var obj = state.bills
      if (action.payload.result) {
        obj.result = obj.result.concat(action.payload.result)
      } else {
        obj.error = action.payload.error
      }
      return {
        ...state,
        billsIsFetching: false,
        bills: obj
      }

    case CLEAR_BILLS:
      return {
        ...state,
        billsIsFetching: false,
        bills: {}
      }

    case REQUEST_BILL_BY_ID:
      return {
        ...state,
        billIsFetching: true,
      }

    case RECEIVE_BILL_BY_ID:
      return {
        ...state,
        billIsFetching: false,
        bill: action.payload
      }

    case CLEAR_BILL_BY_ID:
      return {
        ...state,
        billIsFetching: false,
        bill: {}
      }


    default:
      return state
  }
}
