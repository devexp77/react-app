import {
  REQUEST_KEYS_LOGBOOK_RECORDS,
  RECEIVE_KEYS_LOGBOOK_RECORDS,
  RECEIVE_SCROLL_KEYS_LOGBOOK_RECORDS,
  CLEAR_KEYS_LOGBOOK_RECORDS,
  REQUEST_KEYS_LOGBOOK_RECORDS_ID,
  RECEIVE_KEYS_LOGBOOK_RECORDS_ID,
  CLEAR_KEYS_LOGBOOK_RECORDS_ID,
  REQUEST_KEYS_LOGBOOK_RECORD_ID,
  RECEIVE_KEYS_LOGBOOK_RECORD_ID,
  CLEAR_KEYS_LOGBOOK_RECORD_ID,
  REQUEST_ADD_KEYS_LOGBOOK_RECORD,
  RECEIVE_ADD_KEYS_LOGBOOK_RECORD,
  REQUEST_SET_KEYS_LOGBOOK_RECORD,
  RECEIVE_SET_KEYS_LOGBOOK_RECORD,
  REQUEST_KEYS_LOGBOOK_RECORDS_COUNT,
  RECEIVE_KEYS_LOGBOOK_RECORDS_COUNT,
  CLEAR_KEYS_LOGBOOK_RECORDS_COUNT,
} from "../actions/keysLogbook";


export default function transportLogbook(
  state = {
    keysLogBookRecordsIsFetching: false,
    keysLogBookRecordsCountIsFetching: false,
    keysLogBookRecordByIdListIsFetching: false,
    keysLogBookRecordByIdIsFetching: false,
    keysLogBookRecords: [],
    keysLogBookRecordsCount: [],
    keysLogBookRecordByIdList: [],
    keysLogBookRecordById: [],

    keysLogbookOperationIsFetching: false,
    keysLogbookOperationStatus: []
  },
  action
) {
  switch (action.type) {
    case REQUEST_KEYS_LOGBOOK_RECORDS_COUNT:
      return {
        ...state,
        keysLogBookRecordsCountIsFetching: true
      };

    case RECEIVE_KEYS_LOGBOOK_RECORDS_COUNT:
      return {
        ...state,
        keysLogBookRecordsCountIsFetching: false,
        keysLogBookRecordsCount: action.payload
      };

    case CLEAR_KEYS_LOGBOOK_RECORDS_COUNT:
      return {
        ...state,
        keysLogBookRecordsCount: []
      };

    case REQUEST_KEYS_LOGBOOK_RECORDS:
      return {
        ...state,
        keysLogBookRecordsIsFetching: true
      };

    case RECEIVE_KEYS_LOGBOOK_RECORDS:
      return {
        ...state,
        keysLogBookRecordsIsFetching: false,
        keysLogBookRecords: action.payload
      };

    case CLEAR_KEYS_LOGBOOK_RECORDS:
      return {
        ...state,
        keysLogBookRecords: []
      };

    case RECEIVE_SCROLL_KEYS_LOGBOOK_RECORDS:
      if (action.payload.result) {
        if (state.keysLogBookRecords.result) {
          let obj = state.keysLogBookRecords;
          let length = obj.result.length;

          for (let prop in action.payload.result) {
            obj.result[length] = action.payload.result[prop];
            length++;
          }
          return {
            ...state,
            keysLogBookRecordsIsFetching: false,
            keysLogBookRecords: obj
          };
        } else {
          return {
            ...state,
            keysLogBookRecordsIsFetching: false,
            keysLogBookRecords: action.payload
          };
        }
      } else {
        return {
          ...state,
          keysLogBookRecordsIsFetching: false
        };
      }

    case REQUEST_KEYS_LOGBOOK_RECORDS_ID:
      return {
        ...state,
        keysLogBookRecordByIdListIsFetching: true
      };

    case RECEIVE_KEYS_LOGBOOK_RECORDS_ID:
      if (action.payload.result) {
        if (state.keysLogBookRecordByIdList.result) {
          let obj = state.keysLogBookRecordByIdList;
          let length = obj.result.length;
          for (let prop in action.payload.result) {
            obj.result[length] = action.payload.result[prop];
            length++;
          }
          return {
            ...state,
            keysLogBookRecordByIdListIsFetching: false,
            keysLogBookRecordByIdList: obj
          };
        } else {
          return {
            ...state,
            keysLogBookRecordByIdListIsFetching: false,
            keysLogBookRecordByIdList: action.payload
          };
        }
      } else {
        return {
          ...state,
          keysLogBookRecordByIdListIsFetching: false
        };
      }

    case CLEAR_KEYS_LOGBOOK_RECORDS_ID:
      return {
        ...state,
        keysLogBookRecordByIdList: []
      };

    case REQUEST_KEYS_LOGBOOK_RECORD_ID:
      return {
        ...state,
        keysLogBookRecordByIdIsFetching: true
      };

    case RECEIVE_KEYS_LOGBOOK_RECORD_ID:
      return {
        ...state,
        keysLogBookRecordByIdIsFetching: false,
        keysLogBookRecordById: action.payload
      };

    case CLEAR_KEYS_LOGBOOK_RECORD_ID:
      return {
        ...state,
        keysLogBookRecordById: []
      };

    /********************* add logbook record ****************/
    case REQUEST_ADD_KEYS_LOGBOOK_RECORD:
    case REQUEST_SET_KEYS_LOGBOOK_RECORD:
      return {
        ...state,
        keysLogbookOperationIsFetching: true
      };

    case RECEIVE_ADD_KEYS_LOGBOOK_RECORD:
    case RECEIVE_SET_KEYS_LOGBOOK_RECORD:
      return {
        ...state,
        keysLogbookOperationIsFetching: false,
        keysLogbookOperationStatus: action.payload
      };
    /********************************************************/
    default:
      return state;
  }
}
