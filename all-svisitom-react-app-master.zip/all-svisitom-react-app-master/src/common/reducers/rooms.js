import {
  ADD_ROOM_REQUEST,
  ADD_ROOM_RESULT,
  IMPORT_ROOM_REQUEST,
  IMPORT_ROOM_RESULT,
  SET_ROOM_REQUEST,
  SET_ROOM_RESULT,
  DELETE_ROOMS_REQUEST,
  DELETE_ROOMS_RESULT,
  REQUEST_ROOMS,
  RECEIVE_ROOMS,
  RECEIVE_MORE_ROOMS,
  CLEAR_ROOMS,
  REQUEST_ROOM_BY_ID,
  RECEIVE_ROOM_BY_ID,
  CLEAR_ROOM_BY_ID,
  ATTACH_IOS_ZONE_TO_ROOM_REQUEST,
  ATTACH_IOS_ZONE_TO_ROOM_RESULT,
  DETACH_IOS_ZONE_TO_ROOM_REQUEST,
  DETACH_IOS_ZONE_TO_ROOM_RESULT
} from "../actions/rooms";

export default function rooms(
  state = {
    roomOperationIsFetching: false,
    roomOperationStatus: [],

    roomsIsFetching: false,
    rooms: [],
    addresseesIdList: [],

    roomByIdIsFetching: false,
    roomById: []
  },
  action
) {
  switch (action.type) {
    /************ add room ************/
    case ADD_ROOM_REQUEST:
      return {
        ...state,
        roomOperationIsFetching: true
      };

    case ADD_ROOM_RESULT:
      return {
        ...state,
        roomOperationIsFetching: false,
        roomOperationStatus: action.payload
      };
    /*****************************************/

    /************ import room ************/
    case IMPORT_ROOM_REQUEST:
      return {
        ...state,
      };

    case IMPORT_ROOM_RESULT:
      return {
        ...state,
        roomOperationStatus: action.payload
      };
    /*****************************************/


    /************ set room ************/
    case SET_ROOM_REQUEST:
      return {
        ...state,
        roomOperationIsFetching: true
      };

    case SET_ROOM_RESULT:
      return {
        ...state,
        roomOperationIsFetching: false,
        roomOperationStatus: action.payload
      };
    /*****************************************/

    /************ attach ios zone ************/
    case ATTACH_IOS_ZONE_TO_ROOM_REQUEST:
      return {
        ...state,
        roomOperationIsFetching: true
      };

    case ATTACH_IOS_ZONE_TO_ROOM_RESULT:
      return {
        ...state,
        roomOperationIsFetching: false,
        roomOperationStatus: action.payload
      };
    /*****************************************/

    /************ detach ios zone ************/
    case DETACH_IOS_ZONE_TO_ROOM_REQUEST:
      return {
        ...state,
        roomOperationIsFetching: true
      };

    case DETACH_IOS_ZONE_TO_ROOM_RESULT:
      return {
        ...state,
        roomOperationIsFetching: false,
        roomOperationStatus: action.payload
      };
    /*****************************************/

    /************ delete rooms ************/
    case DELETE_ROOMS_REQUEST:
      return {
        ...state,
        roomOperationIsFetching: true
      };

    case DELETE_ROOMS_RESULT:
      return {
        ...state,
        roomOperationIsFetching: false,
        roomOperationStatus: action.payload
      };
    /*****************************************/

    /************ get rooms ************/
    case REQUEST_ROOMS:
      return {
        ...state,
        roomsIsFetching: true
      };

    case RECEIVE_ROOMS:
      return {
        ...state,
        roomsIsFetching: false,
        rooms: action.payload
      };

    case RECEIVE_MORE_ROOMS:
      let obj = state.rooms;
      obj.result = obj.result.concat(action.payload.result);
      return {
        ...state,
        rooms: obj,
        roomsIsFetching: false
      };

    case CLEAR_ROOMS:
      return {
        ...state,
        rooms: {}
      };
    /*****************************************/

    /********* get room by id **********/
    case REQUEST_ROOM_BY_ID:
      return {
        ...state,
        roomByIdIsFetching: true
      };

    case RECEIVE_ROOM_BY_ID:
      return {
        ...state,
        roomByIdIsFetching: false,
        roomById: action.payload
      };

      case CLEAR_ROOM_BY_ID:
      return {
        ...state,
        roomById: []
      };
    /*****************************************/

    default:
      return state;
  }
}
