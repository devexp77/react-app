import {
  REQUEST_TRANSPORT_LOGBOOK_RECORDS,
  RECEIVE_TRANSPORT_LOGBOOK_RECORDS,
  RECEIVE_SCROLL_TRANSPORT_LOGBOOK_RECORDS,
  CLEAR_TRANSPORT_LOGBOOK_RECORDS,
  REQUEST_TRANSPORT_LOGBOOK_RECORDS_ID,
  RECEIVE_TRANSPORT_LOGBOOK_RECORDS_ID,
  CLEAR_TRANSPORT_LOGBOOK_RECORDS_ID,
  REQUEST_TRANSPORT_LOGBOOK_RECORD_ID,
  RECEIVE_TRANSPORT_LOGBOOK_RECORD_ID,
  CLEAR_TRANSPORT_LOGBOOK_RECORD_ID,
  REQUEST_ADD_TRANSPORT_LOGBOOK_RECORD,
  RECEIVE_ADD_TRANSPORT_LOGBOOK_RECORD,
  REQUEST_SET_TRANSPORT_LOGBOOK_RECORD,
  RECEIVE_SET_TRANSPORT_LOGBOOK_RECORD,
  REQUEST_TRANSPORT_LOGBOOK_RECORDS_COUNT,
  RECEIVE_TRANSPORT_LOGBOOK_RECORDS_COUNT,
  CLEAR_TRANSPORT_LOGBOOK_RECORDS_COUNT
} from "../actions/transportLogbook";

export default function transportLogbook(
  state = {
    transportLogBookRecordsIsFetching: false,
    transportLogBookRecordsCountIsFetching: false,
    transportLogBookRecordsByIdsIsFetching: false,
    transportLogBookRecordByIdIsFetching: false,
    transportLogBookRecords: [],
    transportLogBookRecordsCount: [],
    transportLogBookRecordsByIds: [],
    transportLogBookRecordById: [],

    transportLogbookOperationIsFetching: false,
    transportLogbookOperationStatus: []
  },
  action
) {
  switch (action.type) {
    case REQUEST_TRANSPORT_LOGBOOK_RECORDS_COUNT:
      return {
        ...state,
        transportLogBookRecordsCountIsFetching: true
      };

    case RECEIVE_TRANSPORT_LOGBOOK_RECORDS_COUNT:
      return {
        ...state,
        transportLogBookRecordsCountIsFetching: false,
        transportLogBookRecordsCount: action.payload
      };

    case CLEAR_TRANSPORT_LOGBOOK_RECORDS_COUNT:
      return {
        ...state,
        transportLogBookRecordsCount: []
      };

    case REQUEST_TRANSPORT_LOGBOOK_RECORDS:
      return {
        ...state,
        transportLogBookRecordsIsFetching: true
      };

    case RECEIVE_TRANSPORT_LOGBOOK_RECORDS:
      return {
        ...state,
        transportLogBookRecordsIsFetching: false,
        transportLogBookRecords: action.payload
      };

    case CLEAR_TRANSPORT_LOGBOOK_RECORDS:
      return {
        ...state,
        transportLogBookRecords: []
      };

    case RECEIVE_SCROLL_TRANSPORT_LOGBOOK_RECORDS:
      if (action.payload.result) {
        if (state.transportLogBookRecords.result) {
          let obj = state.transportLogBookRecords;
          let length = obj.result.length;

          for (let prop in action.payload.result) {
            obj.result[length] = action.payload.result[prop];
            length++;
          }
          return {
            ...state,
            transportLogBookRecordsIsFetching: false,
            transportLogBookRecords: obj
          };
        } else {
          return {
            ...state,
            transportLogBookRecordsIsFetching: false,
            transportLogBookRecords: action.payload
          };
        }
      } else {
        return {
          ...state,
          transportLogBookRecordsIsFetching: false
        };
      }

    case REQUEST_TRANSPORT_LOGBOOK_RECORDS_ID:
      return {
        ...state,
        transportLogBookRecordsByIdsIsFetching: true
      };

    case RECEIVE_TRANSPORT_LOGBOOK_RECORDS_ID:
      let transportLogBookRecordsByIds = state.transportLogBookRecordsByIds;

      if (!transportLogBookRecordsByIds.result) {
        transportLogBookRecordsByIds = action.payload;
      } else if (action.payload.result) {
        transportLogBookRecordsByIds.result = transportLogBookRecordsByIds.result.concat(
          action.payload.result
        );
      } else {
        transportLogBookRecordsByIds.error = action.payload.error;
      }

      return {
        ...state,
        transportLogBookRecordsByIdsIsFetching: false,
        transportLogBookRecordsByIds: transportLogBookRecordsByIds
      };

    case CLEAR_TRANSPORT_LOGBOOK_RECORDS_ID:
      return {
        ...state,
        transportLogBookRecordsByIds: []
      };

    case REQUEST_TRANSPORT_LOGBOOK_RECORD_ID:
      return {
        ...state,
        transportLogBookRecordByIdIsFetching: true
      };

    case RECEIVE_TRANSPORT_LOGBOOK_RECORD_ID:
      return {
        ...state,
        transportLogBookRecordByIdIsFetching: false,
        transportLogBookRecordById: action.payload
      };

    case CLEAR_TRANSPORT_LOGBOOK_RECORD_ID:
      return {
        ...state,
        transportLogBookRecordById: []
      };

    /********************* add logbook record ****************/
    case REQUEST_ADD_TRANSPORT_LOGBOOK_RECORD:
    case REQUEST_SET_TRANSPORT_LOGBOOK_RECORD:
      return {
        ...state,
        transportLogbookOperationIsFetching: true
      };

    case RECEIVE_ADD_TRANSPORT_LOGBOOK_RECORD:
    case RECEIVE_SET_TRANSPORT_LOGBOOK_RECORD:
      return {
        ...state,
        transportLogbookOperationIsFetching: false,
        transportLogbookOperationStatus: action.payload
      };
    /********************************************************/
    default:
      return state;
  }
}
