import {
  ADD_ADDRESSEE_REQUEST,
  ADD_ADDRESSEE_RESULT,
  SET_ADDRESSEE_REQUEST,
  SET_ADDRESSEE_RESULT,
  DELETE_ADDRESSEES_REQUEST,
  DELETE_ADDRESSEES_RESULT,
  IMPORT_ADDRESSEE_REQUEST,
  IMPORT_ADDRESSEE_RESULT,
  REQUEST_ADDRESSEES,
  RECEIVE_ADDRESSEES,
  RECEIVE_SIDEBAR_ADDRESSEES,
  RECEIVE_MORE_ADDRESSES,
  CLEAR_ADDRESSEES,
  REQUEST_ADDRESSEE_BY_ID,
  RECEIVE_ADDRESSEE_BY_ID,
  CLEAR_ADDRESSEE_BY_ID,
  REQUEST_ADDRESSEES_BY_IDS,
  RECEIVE_ADDRESSEES_BY_IDS,
  CLEAR_ADDRESSEES_BY_IDS,
  REQUEST_ADDRESSEE_EMPLOYEES,
  RECEIVE_ADDRESSEE_EMPLOYEES,
  RECEIVE_MORE_ADDRESSEE_EMPLOYEES,
  CLEAR_ADDRESSEE_EMPLOYEES,
  RECEIVE_ADDRESSEE_ACCOMPANY_EMPLOYEES,
  REQUEST_ADDRESSEE_ACCOMPANY_EMPLOYEES,
  CLEAR_ADDRESSEE_ACCOMPANY_EMPLOYEES,
  REQUEST_SET_ADDRESSEE_PERMISSIONS,
  RECEIVE_SET_ADDRESSEE_PERMISSIONS,
  REQUEST_ADDRESSEE_PERMISSIONS,
  RECEIVE_ADDRESSEE_PERMISSIONS,
  CLEAR_ADDRESSEE_PERMISSIONS,
  REQUEST_DELETE_ADDRESSEE_PERMISSIONS,
  RECEIVE_DELETE_ADDRESSEE_PERMISSIONS
} from "../actions/addressee";

export default function addressee(
  state = {
    addresseeOperationIsFetching: false,
    addresseeOperationStatus: [],

    addresseesIsFetching: false,
    addressees: [],
    addresseesSidebar: [],

    addresseeByIdIsFetching: false,
    addresseeById: [],

    addresseesByIdsIsFetching: false,
    addresseesByIds: [],

    addresseeEmployeesIsFetching: false,
    addresseeEmployees: [],

    addresseeAccompanyEmployeesIsFetching: false,
    addresseeAccompanyEmployees: [],

    addresseePermissionsIsFetching: false,
    addresseePermissions: []
  },
  action
) {
  switch (action.type) {
    /************ add addressee ************/
    case ADD_ADDRESSEE_REQUEST:
      return {
        ...state,
        addresseeOperationIsFetching: true
      };

    case ADD_ADDRESSEE_RESULT:
      return {
        ...state,
        addresseeOperationIsFetching: false,
        addresseeOperationStatus: action.payload
      };
    /*****************************************/

    /************ add addressee ************/
    case IMPORT_ADDRESSEE_REQUEST:
      return {
        ...state
      };

    case IMPORT_ADDRESSEE_RESULT:
      return {
        ...state,
        addresseeOperationStatus: action.payload
      };
    /*****************************************/

    /************ set addressee ************/
    case SET_ADDRESSEE_REQUEST:
      return {
        ...state,
        addresseeOperationIsFetching: true
      };

    case SET_ADDRESSEE_RESULT:
      return {
        ...state,
        addresseeOperationIsFetching: false,
        addresseeOperationStatus: action.payload
      };
    /*****************************************/

    /************ delete addressees ************/
    case DELETE_ADDRESSEES_REQUEST:
      return {
        ...state,
        addresseeOperationIsFetching: true
      };

    case DELETE_ADDRESSEES_RESULT:
      return {
        ...state,
        addresseeOperationIsFetching: false,
        addresseeOperationStatus: action.payload
      };
    /*****************************************/

    /************ get addressees ************/
    case REQUEST_ADDRESSEES:
      return {
        ...state,
        addresseesIsFetching: true
      };

    case RECEIVE_ADDRESSEES:
      return {
        ...state,
        addresseesIsFetching: false,
        addressees: action.payload
      };

    case RECEIVE_SIDEBAR_ADDRESSEES:
      return {
        ...state,
        addresseesIsFetching: false,
        addresseesSidebar: action.payload
      };

    case RECEIVE_MORE_ADDRESSES:
      let obj = state.addressees;
      obj.result = obj.result.concat(action.payload.result);
      return {
        ...state,
        addresseesIsFetching: false,
        addressees: obj
      };

    case CLEAR_ADDRESSEES:
      return {
        ...state,
        addresseesIsFetching: false,
        addressees: {}
      };
    /*****************************************/

    /********* get addressee by id **********/
    case REQUEST_ADDRESSEE_BY_ID:
      return {
        ...state,
        addresseeByIdIsFetching: true
      };

    case RECEIVE_ADDRESSEE_BY_ID:
      return {
        ...state,
        addresseeByIdIsFetching: false,
        addresseeById: action.payload
      };

    case CLEAR_ADDRESSEE_BY_ID:
      return {
        ...state,
        addresseeById: []
      };
    /*****************************************/

    /********* get addressees by ids **********/
    case REQUEST_ADDRESSEES_BY_IDS:
      return {
        ...state,
        addresseesByIdsIsFetching: true
      };

    case RECEIVE_ADDRESSEES_BY_IDS:
      if (action.payload.result) {
        if (state.addresseesByIds.result) {
          let obj = state.addresseesByIds;
          let length = obj.result.length;
          for (let prop in action.payload.result) {
            obj.result[length] = action.payload.result[prop];
            length++;
          }

          return {
            ...state,
            addresseesByIdsIsFetching: false,
            addresseesByIds: obj
          };
        } else {
          return {
            ...state,
            addresseesByIdsIsFetching: false,
            addresseesByIds: action.payload
          };
        }
      } else {
        return {
          ...state,
          addresseesByIdsIsFetching: false
        };
      }

    case CLEAR_ADDRESSEES_BY_IDS:
      return {
        ...state,
        addresseesByIds: []
      };
    /*****************************************/

    /********* get addressee users **********/
    case REQUEST_ADDRESSEE_EMPLOYEES:
      return {
        ...state,
        addresseeEmployeesIsFetching: true
      };

    case RECEIVE_ADDRESSEE_EMPLOYEES:
      return {
        ...state,
        addresseeEmployeesIsFetching: false,
        addresseeEmployees: action.payload
      };

    case RECEIVE_MORE_ADDRESSEE_EMPLOYEES:
      let obj_employees = state.addresseeEmployees;
      obj_employees.result = obj_employees.result.concat(action.payload.result);
      return {
        ...state,
        addresseeEmployeesIsFetching: false,
        addresseeEmployees: obj_employees
      };

    case CLEAR_ADDRESSEE_EMPLOYEES:
      return {
        ...state,
        addresseeEmployees: []
      };
    /******
     *
     *
     */


    case REQUEST_ADDRESSEE_ACCOMPANY_EMPLOYEES:
      return {
        ...state,
        addresseeAccompanyEmployeesIsFetching: true
      };

    case RECEIVE_ADDRESSEE_ACCOMPANY_EMPLOYEES:
      return {
        ...state,
        addresseeAccompanyEmployeesIsFetching: false,
        addresseeAccompanyEmployees: action.payload
      };

    case CLEAR_ADDRESSEE_ACCOMPANY_EMPLOYEES:
      return {
        ...state,
        addresseeAccompanyEmployees: []
      };
    /*****************************************/

    /************ set addressee permissions ************/
    case REQUEST_SET_ADDRESSEE_PERMISSIONS:
      return {
        ...state,
        addresseeOperationIsFetching: true
      };

    case RECEIVE_SET_ADDRESSEE_PERMISSIONS:
      return {
        ...state,
        addresseeOperationIsFetching: false,
        addresseeOperationStatus: action.payload
      };
    /*****************************************/

    /************ get addressee permitions ************/
    case REQUEST_ADDRESSEE_PERMISSIONS:
      return {
        ...state,
        addresseePermissionsIsFetching: true
      };

    case RECEIVE_ADDRESSEE_PERMISSIONS:
      return {
        ...state,
        addresseePermissionsIsFetching: false,
        addresseePermissions: action.payload
      };

    case CLEAR_ADDRESSEE_PERMISSIONS:
      return {
        ...state,
        addresseePermissions: []
      };

    /*****************************************/

    /************ delete addressee permitions ************/
    case REQUEST_DELETE_ADDRESSEE_PERMISSIONS:
      return {
        ...state,
        addresseeOperationIsFetching: true
      };

    case RECEIVE_DELETE_ADDRESSEE_PERMISSIONS:
      return {
        ...state,
        addresseeOperationIsFetching: false,
        addresseeOperationStatus: action.payload
      };
    /*****************************************/

    default:
      return state;
  }
}
