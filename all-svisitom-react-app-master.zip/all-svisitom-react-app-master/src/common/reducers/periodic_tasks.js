import {
  REQUEST_ADD_PERIODIC_TASK,
  RECEIVE_ADD_PERIODIC_TASK,
  REQUEST_PERIODIC_TASKS,
  RECEIVE_PERIODIC_TASKS,
  CLEAR_PERIODIC_TASKS,
  REQUEST_PERIODIC_TASK_BY_ID,
  RECEIVE_PERIODIC_TASK_BY_ID,
  CLEAR_PERIODIC_TASK_BY_ID,
  REQUEST_DELETE_PERIODIC_TASKS,
  RECEIVE_DELETE_PERIODIC_TASKS,
  RECEIVE_SET_PERIODIC_TASK,
  REQUEST_SET_PERIODIC_TASK
} from "../actions/periodic_tasks";

export default function periodic_tasks(
  state = {
    taskOperationIsFetching: false,
    taskOperationStatus: {},

    tasksIsFetching: false,
    tasks: {},

    taskByIdIsFetching: false,
    taskById: {}
  },
  action
) {
  switch (action.type) {
    /************  ************/
    case REQUEST_ADD_PERIODIC_TASK:
    case REQUEST_DELETE_PERIODIC_TASKS:
    case REQUEST_SET_PERIODIC_TASK:
      return {
        ...state,
        taskOperationIsFetching: true
      };

    case RECEIVE_ADD_PERIODIC_TASK:
    case RECEIVE_DELETE_PERIODIC_TASKS:
    case RECEIVE_SET_PERIODIC_TASK:
      return {
        ...state,
        taskOperationIsFetching: false,
        taskOperationStatus: action.payload
      };
    /*****************************************/

    /************ get tasks ************/
    case REQUEST_PERIODIC_TASKS:
      return {
        ...state,
        tasksIsFetching: true
      };

    case RECEIVE_PERIODIC_TASKS:
      return {
        ...state,
        tasksIsFetching: false,
        tasks: action.payload
      };

    case CLEAR_PERIODIC_TASKS:
      return {
        ...state,
        tasks: {}
      };
    /*****************************************/

    /************ get task ************/
    case REQUEST_PERIODIC_TASK_BY_ID:
      return {
        ...state,
        taskByIdIsFetching: true
      };

    case RECEIVE_PERIODIC_TASK_BY_ID:
      return {
        ...state,
        taskByIdIsFetching: false,
        taskById: action.payload
      };

    case CLEAR_PERIODIC_TASK_BY_ID:
      return {
        ...state,
        taskById: {}
      };
    /*****************************************/

    default:
      return state;
  }
}
