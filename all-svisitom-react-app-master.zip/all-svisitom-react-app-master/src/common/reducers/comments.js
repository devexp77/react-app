import {
  REQUEST_GET_COMMENTS,
  RECEIVE_GET_COMMENTS,
  CLEAR_COMMENTS,
  RECEIVE_ADD_COMMENT,
  REQUEST_ADD_COMMENT,
  RECEIVE_SET_COMMENT,
  REQUEST_SET_COMMENT
} from "../actions/comments";

export default function comments(
  state = {
    comments: [],
    commentsIsFetching: false,

    commentsOperation: [],
    commentsOperationIsFetching: false
  },
  action
) {
  switch (action.type) {
    case REQUEST_GET_COMMENTS:
      return {
        ...state,
        commentsIsFetching: true
      };

    case RECEIVE_GET_COMMENTS:
      return {
        ...state,
        commentsIsFetching: false,
        comments: action.payload
      };

    case CLEAR_COMMENTS:
      return {
        ...state,
        comments: []
      };

    case REQUEST_ADD_COMMENT:
    case REQUEST_SET_COMMENT:
      return {
        ...state,
        commentsOperationIsFetching: true
      };

    case RECEIVE_ADD_COMMENT:
    case RECEIVE_SET_COMMENT:
      return {
        ...state,
        commentsOperationIsFetching: false,
        commentsOperation: action.payload
      };

    default:
      return state;
  }
}
