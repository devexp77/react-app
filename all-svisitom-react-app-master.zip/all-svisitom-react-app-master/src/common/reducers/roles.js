import {
  REQUEST_ENTITY_ROLES,
  RECEIVE_ENTITY_ROLES,
  CLEAR_ENTITY_ROLES,
  REQUEST_SET_ENTITY_ROLES,
  RECEIVE_SET_ENTITY_ROLES,
} from '../actions/roles'


export default function rooms(state = {
  entityRolesIsFetching: false,
  entityRoles: [],

  rolesOperationStatus: {},
  rolesOperationIsFetching: false,

}, action){
  switch (action.type) {

    /************ get entity_ids_by_roless ************/
    case REQUEST_ENTITY_ROLES:
    return {
      ...state,
      entityRolesIsFetching: true
    }

    case RECEIVE_ENTITY_ROLES:
    return {
      ...state,
      entityRolesIsFetching: false,
      entityRoles: action.payload
    }

    case CLEAR_ENTITY_ROLES:
    return {
      ...state,
      entityRolesIsFetching: false,
      entityRoles: []
    }

    /*****************************************/

    /************ set_roles ************/
    case REQUEST_SET_ENTITY_ROLES:
    return {
      ...state,
      rolesOperationIsFetching: true
    }

    case RECEIVE_SET_ENTITY_ROLES:
    return {
      ...state,
      rolesOperationIsFetching: false,
      rolesOperationStatus: action.payload
    }

    default:
    return state
  }
}
