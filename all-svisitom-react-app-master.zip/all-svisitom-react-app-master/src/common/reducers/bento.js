import {
  REQUEST_ENTITY_ROLES_BENTO,
  RECEIVE_ENTITY_ROLES_BENTO,
  CLEAR_ENTITY_ROLES_BENTO,

  REQUEST_ACTIVITIES_BENTO,
  RECEIVE_ACTIVITIES_BENTO,
  CLEAR_ACTIVITIES_BENTO,

  REQUEST_OBJECTS_BENTO,
  RECEIVE_OBJECTS_BENTO,
  CLEAR_OBJECTS_BENTO,

  REQUEST_OBJECTS_IMAGE_BENTO,
  RECEIVE_OBJECTS_IMAGE_BENTO,
  CLEAR_OBJECTS_IMAGE_BENTO,

  REQUEST_ADDRESSEES_BENTO,
  RECEIVE_ADDRESSEES_BENTO,
  CLEAR_ADDRESSEES_BENTO,
} from '../actions/bento'


export default function bento(state = {
  entityRolesIsFetching: false,
  entityRoles: {},

  activitiesIsFetching: false,
  activities: {},

  objectsIsFetching: false,
  objects: [],

  addresseesIsFetching: false,
  addressees: [],

  objectsImageIsFetching: false,
  objectsImage: [],

}, action){
  switch (action.type) {

    /************ ROLES ************/
    case REQUEST_ENTITY_ROLES_BENTO:
    return {
      ...state,
      entityRolesIsFetching: true
    }

    case RECEIVE_ENTITY_ROLES_BENTO:
    return {
      ...state,
      entityRolesIsFetching: false,
      entityRoles: action.payload
    }

    case CLEAR_ENTITY_ROLES_BENTO:
    return {
      ...state,
      entityRolesIsFetching: false,
      entityRoles: []
    }

    /************ ACTIVITY ************/

    case REQUEST_ACTIVITIES_BENTO:
      return {
        ...state,
        activitiesIsFetching: true
      };

    case RECEIVE_ACTIVITIES_BENTO:
      return {
        ...state,
        activitiesIsFetching: false,
        activities: action.payload
      };

    case CLEAR_ACTIVITIES_BENTO:
      return {
        ...state,
        activitiesIsFetching: false,
        activities: {}
      };

    /************ OBJECTS ************/

    case REQUEST_OBJECTS_BENTO:
      return {
        ...state,
        objectsIsFetching: true
      };

    case RECEIVE_OBJECTS_BENTO:
      return {
        ...state,
        objectsIsFetching: false,
        objects: action.payload
      };

    case CLEAR_OBJECTS_BENTO:
      return {
        ...state,
        objectsIsFetching: false,
        objects: {}
      };

      /************ ADDRESSEES ************/

      case REQUEST_ADDRESSEES_BENTO:
        return {
          ...state,
          addresseesIsFetching: true
        };

      case RECEIVE_ADDRESSEES_BENTO:
        return {
          ...state,
          addresseesIsFetching: false,
          addressees: action.payload
        };

      case CLEAR_ADDRESSEES_BENTO:
        return {
          ...state,
          addresseesIsFetching: false,
          addressees: {}
        };

    /************ IMAGES ************/
    case REQUEST_OBJECTS_IMAGE_BENTO:
      return {
        ...state,
        objectsImageIsFetching: true
      };

    case RECEIVE_OBJECTS_IMAGE_BENTO:
      return {
        ...state,
        objectsImageIsFetching: false,
        objectsImage: action.payload
      };

    case CLEAR_OBJECTS_IMAGE_BENTO:
      return {
        ...state,
        objectsImageIsFetching: false,
        objectsImage: {}
      };

    default:
      return state
  }
}
