import {
  REQUEST_WEB_PUSH_SENDER_ID,
  RECEIVE_WEB_PUSH_SENDER_ID,
  REQUEST_ADD_WEB_PUSH,
  RECEIVE_ADD_WEB_PUSH,
  REQUEST_DELETE_WEB_PUSH,
  RECEIVE_DELETE_WEB_PUSH
} from "../actions/webPush";


export default function webPush(
  state = {
    operationIsFetching: false,
    operationStatus: []
  },
  action
) {
  switch (action.type) {
    case REQUEST_WEB_PUSH_SENDER_ID:
    case REQUEST_ADD_WEB_PUSH:
    case REQUEST_DELETE_WEB_PUSH:
      return {
        ...state,
        operationIsFetching: true
      };

    case RECEIVE_WEB_PUSH_SENDER_ID:
    case RECEIVE_ADD_WEB_PUSH:
    case RECEIVE_DELETE_WEB_PUSH:
      return {
        ...state,
        operationIsFetching: false,
        operationStatus: action.payload
      };
    default:
      return state;
  }
}
