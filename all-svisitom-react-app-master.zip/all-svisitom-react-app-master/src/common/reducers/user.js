import {
  REQUEST_USER_GLOBAL,
  RECEIVE_USER_GLOBAL,
  REQUEST_USER,
  RECEIVE_USER,
  REQUEST_SET_USER,
  RECEIVE_SET_USER,
  CLEAR_SET_USER_STATUS,
  REQUEST_USER_BY_ID,
  RECEIVE_USER_BY_ID,
  CLEAR_USER_BY_ID,
  REQUEST_DELETE_CURRENT_USER,
  RECEIVE_DELETE_CURRENT_USER,
  REQUEST_CHANGE_PASSWORD,
  RECEIVE_CHANGE_PASSWORD,
  REQUEST_SET_IDENTIFIER,
  RECEIVE_SET_IDENTIFIER,
  REQUEST_CONFIRM_IDENTIFIER,
  RECEIVE_CONFIRM_IDENTIFIER,
  REQUEST_GENERATE_PERSONAL_CODE,
  RECEIVE_GENERATE_PERSONAL_CODE,
  REQUEST_CHECK_USER_EXISTS,
  RECEIVE_CHECK_USER_EXISTS,
  REQUEST_ADD_DEPENDENT_USER,
  RECEIVE_ADD_DEPENDENT_USER,
  REQUEST_PROFILE_USER,
  RECEIVE_PROFILE_USER,
  CLEAR_PROFILE_USER,
  RECEIVE_GLOBAL_PROFILE_USER,
  REQUEST_GLOBAL_PROFILE_USER,
  REQUEST_SET_DO_NOT_DISTURB_STATE,
  RECEIVE_SET_DO_NOT_DISTURB_STATE
} from "../actions/user";

export default function user(
  state = {
    isFetching: false,
    userGlobalIsFetching: false,
    user: [],
    setUserStatus: [],
    userByIdIsFetching: false,
    userById: [],

    userOperationStatus: [],
    userOperationIsFetching: false,

    profileUser: [],
    profileUserIsFetching: false,
    globalProfileUserIsFetching: false,
  },
  action
) {
  switch (action.type) {
    case REQUEST_USER_GLOBAL:
      return {
        ...state,
        userGlobalIsFetching: true
      };
    case RECEIVE_USER_GLOBAL:
      return {
        ...state,
        userGlobalIsFetching: false,
        user: action.payload
      };

    case REQUEST_USER:
      return {
        ...state,
        isFetching: true
      };
    case RECEIVE_USER:
      return {
        ...state,
        isFetching: false,
        user: action.payload
      };

    case REQUEST_USER_BY_ID:
      return {
        ...state,
        userByIdIsFetching: true
      };
    case RECEIVE_USER_BY_ID:
      return {
        ...state,
        userByIdIsFetching: false,
        userById: action.payload
      };

    case CLEAR_USER_BY_ID:
      return {
        ...state,
        userById: []
      };

    case REQUEST_SET_USER:
      return {
        ...state,
        userOperationIsFetching: true
      };

    case RECEIVE_SET_USER:
      return {
        ...state,
        userOperationIsFetching: false,
        setUserStatus: action.payload
      };

    case CLEAR_SET_USER_STATUS:
      return {
        ...state,
        setUserStatus: []
      };
    default:
      return state;

    /*********** delete current user ***********/
    case REQUEST_DELETE_CURRENT_USER:
      return {
        ...state,
        userOperationIsFetching: true
      };
    case RECEIVE_DELETE_CURRENT_USER:
      return {
        ...state,
        userOperationIsFetching: false,
        userOperationStatus: action.payload
      };

    /******************************************/

    /*********** user operations ***********/
    case REQUEST_CHANGE_PASSWORD:
    case REQUEST_SET_IDENTIFIER:
    case REQUEST_CONFIRM_IDENTIFIER:
    case REQUEST_GENERATE_PERSONAL_CODE:
    case REQUEST_CHECK_USER_EXISTS:
    case REQUEST_ADD_DEPENDENT_USER:
    case REQUEST_SET_DO_NOT_DISTURB_STATE:
      return {
        ...state,
        userOperationIsFetching: true
      };

    case RECEIVE_CHANGE_PASSWORD:
    case RECEIVE_SET_IDENTIFIER:
    case RECEIVE_CONFIRM_IDENTIFIER:
    case RECEIVE_GENERATE_PERSONAL_CODE:
    case RECEIVE_CHECK_USER_EXISTS:
    case RECEIVE_ADD_DEPENDENT_USER:
    case RECEIVE_SET_DO_NOT_DISTURB_STATE:
      return {
        ...state,
        userOperationIsFetching: false,
        userOperationStatus: action.payload
      };

    /******************************************/

    case REQUEST_PROFILE_USER:
      return {
        ...state,
        profileUserIsFetching: true
      };

      case REQUEST_GLOBAL_PROFILE_USER:
      return {
        ...state,
        globalProfileUserIsFetching: true
      };

    case RECEIVE_PROFILE_USER:
      return {
        ...state,
        profileUserIsFetching: false,
        profileUser: action.payload
      };

    case RECEIVE_GLOBAL_PROFILE_USER:
      return {
        ...state,
        globalProfileUserIsFetching: false,
        profileUser: action.payload
      };

    case CLEAR_PROFILE_USER:
      return {
        ...state,
        profileUser: []
      };
  }
}
