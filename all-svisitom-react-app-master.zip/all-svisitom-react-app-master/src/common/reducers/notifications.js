import {
  REQUEST_USER_NOTIFICATIONS,
  RECEIVE_USER_NOTIFICATIONS,
  RECEIVE_USER_SCROLL_NOTIFICATIONS,
  REQUEST_USER_NOTIFICATIONS_COUNT,
  RECEIVE_USER_NOTIFICATIONS_COUNT,
  REQUEST_DELETE_NOTIFICATIONS_BY_ID,
  RECEIVE_DELETE_NOTIFICATIONS_BY_ID,
  CLEAR_USER_NOTIFICATIONS,
  FIX_USER_NOTIFICATIONS_COUNT,
  REQUEST_NOTIFICATION_SETTINGS,
  RECEIVE_NOTIFICATION_SETTINGS,
  REQUEST_SET_NOTIFICATION_SETTINGS,
  RECEIVE_SET_NOTIFICATION_SETTINGS,
  REQUEST_SET_SINGLE_NOTIFICATION_SETTINGS,
  RECEIVE_SET_SINGLE_NOTIFICATION_SETTINGS
} from "../actions/notifications";

export default function user(
  state = {
    userNotificationsIsFetching: false,
    userNotifications: [],

    userNotificationsCount: [],
    fixedUserNotificationsCount: [],

    deleteNotificationsIsFetching: false,
    deleteNotificationsStatus: [],

    notificationSettingsIsFetching: false,
    notificationSettings: [],

    notificationOperationIsFetching: false,
    notificationOperationStatus: [],

    notificationSetSingleSettingIsFetching: false,
    notificationSetSingleSetting: []
  },
  action
) {
  switch (action.type) {
    case REQUEST_USER_NOTIFICATIONS:
      return {
        ...state,
        userNotificationsIsFetching: true
      };

    case RECEIVE_USER_NOTIFICATIONS:
      return {
        ...state,
        userNotificationsIsFetching: false,
        userNotifications: action.payload
      };

    case CLEAR_USER_NOTIFICATIONS:
      return {
        ...state,
        userNotifications: []
      };

    case FIX_USER_NOTIFICATIONS_COUNT:
      return {
        ...state,
        fixedUserNotificationsCount: state.userNotificationsCount
      };

    case RECEIVE_USER_SCROLL_NOTIFICATIONS:
      if (action.payload.result) {
        var obj = state.userNotifications;
        var i = 0;
        var length = obj.result.length;
        for (var prop in action.payload.result) {
          obj.result[length] = action.payload.result[prop];
          length++;
          i++;
        }
        return {
          ...state,
          userNotificationsIsFetching: false,
          userNotifications: obj
        };
      } else {
        return {
          ...state,
          userNotificationsIsFetching: false,
          userNotifications: action.payload
        };
      }

    case REQUEST_USER_NOTIFICATIONS_COUNT:
      return {
        ...state
      };

    case RECEIVE_USER_NOTIFICATIONS_COUNT:
      return {
        ...state,
        userNotificationsCount: action.payload
      };

    case REQUEST_DELETE_NOTIFICATIONS_BY_ID:
      return {
        ...state,
        deleteNotificationsIsFetching: true
      };

    case RECEIVE_DELETE_NOTIFICATIONS_BY_ID:
      return {
        ...state,
        deleteNotificationsIsFetching: false,
        deleteNotificationsStatus: action.payload
      };

    case REQUEST_NOTIFICATION_SETTINGS:
      return {
        ...state,
        notificationSettingsIsFetching: true
      };

    case RECEIVE_NOTIFICATION_SETTINGS:
      return {
        ...state,
        notificationSettingsIsFetching: false,
        notificationSettings: action.payload
      };

    case REQUEST_SET_NOTIFICATION_SETTINGS:
      return {
        ...state,
        notificationOperationIsFetching: true
      };

    case RECEIVE_SET_NOTIFICATION_SETTINGS:
      return {
        ...state,
        notificationOperationIsFetching: false,
        notificationOperationStatus: action.payload
      };

    case REQUEST_SET_SINGLE_NOTIFICATION_SETTINGS:
      return {
        ...state,
        notificationSetSingleSettingIsFetching: true
      };

    case RECEIVE_SET_SINGLE_NOTIFICATION_SETTINGS:
      return {
        ...state,
        notificationSetSingleSettingIsFetching: false,
        notificationSetSingleSetting: action.payload
      };

    default:
      return state;
  }
}
