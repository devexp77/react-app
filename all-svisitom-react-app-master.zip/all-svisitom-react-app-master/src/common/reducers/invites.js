import {
  ADD_INVITE_REQUEST,
  ADD_INVITE_RESULT,
  IMPORT_INVITE_REQUEST,
  IMPORT_INVITE_RESULT,

  REQUEST_INVITES,
  RECEIVE_INVITES,
  RECEIVE_MORE_INVITES,
  CLEAR_INVITES,

  REQUEST_CURRENT_USER_INVITES,
  RECEIVE_CURRENT_USER_INVITES,
  CLEAR_CURRENT_USER_INVITES,

  REQUEST_FROM_CURRENT_USER_INVITES,
  RECEIVE_FROM_CURRENT_USER_INVITES,
  CLEAR_FROM_CURRENT_USER_INVITES,

  REQUEST_INVITE_BY_ID,
  RECEIVE_INVITE_BY_ID,
  CLEAR_INVITE_BY_ID,

  REQUEST_DELETE_INVITE,
  RECEIVE_DELETE_INVITE,

  REQUEST_ACCEPT_INVITE,
  RECEIVE_ACCEPT_INVITE,

  REQUEST_REJECT_INVITE,
  RECEIVE_REJECT_INVITE,

  REQUEST_SEND_INVITE,
  RECEIVE_SEND_INVITE,

} from '../actions/invites'


export default function invites(state = {
  inviteOperationIsFetching: false,
  inviteOperationStatus: [],

  invitesIsFetching: false,
  invites: [],

  userInvitesIsFetching: false,
  userInvites: [],

  fromUserInvitesIsFetching: false,
  fromUserInvites: [],

  inviteByIdIsFetching: false,
  inviteById: [],
}, action){
  switch (action.type) {

    /************ import invite ************/
    case IMPORT_INVITE_REQUEST:
      return {
        ...state,
      };

    case IMPORT_INVITE_RESULT:
      return {
        ...state,
        inviteOperationStatus: action.payload
      };
    /*****************************************/

    /************ get invites ************/
    case REQUEST_INVITES:
    return {
      ...state,
      invitesIsFetching: true
    };

    case RECEIVE_INVITES:
    return {
      ...state,
      invitesIsFetching: false,
      invites: action.payload
    };

    case RECEIVE_MORE_INVITES:
    var obj=state.invites;
    obj.result = obj.result.concat(action.payload.result);
    return {
      ...state,
      invitesIsFetching: false,
      invites: obj
    };

    case CLEAR_INVITES:
    return {
      ...state,
      invites: {}
    };
    /*****************************************/

    /************ get current user invites ************/
    case REQUEST_CURRENT_USER_INVITES:
    return {
      ...state,
      userInvitesIsFetching: true
    };

    case RECEIVE_CURRENT_USER_INVITES:
    return {
      ...state,
      userInvitesIsFetching: false,
      userInvites: action.payload
    };

    case CLEAR_CURRENT_USER_INVITES:
    return {
      ...state,
      userInvites: []
    };
    /*****************************************/

     /************ get from current user invites ************/
    case REQUEST_FROM_CURRENT_USER_INVITES:
    return {
      ...state,
      fromUserInvitesIsFetching: true
    };

    case RECEIVE_FROM_CURRENT_USER_INVITES:
    return {
      ...state,
      fromUserInvitesIsFetching: false,
      fromUserInvites: action.payload
    };

    case CLEAR_FROM_CURRENT_USER_INVITES:
    return {
      ...state,
      fromUserInvites: []
    };
    /*****************************************/

    /************ get invite by id ************/
    case REQUEST_INVITE_BY_ID:
    return {
      ...state,
      inviteByIdIsFetching: true
    };

    case RECEIVE_INVITE_BY_ID:
    return {
      ...state,
      inviteByIdIsFetching: false,
      inviteById: action.payload
    };

    case CLEAR_INVITE_BY_ID:
    return {
      ...state,
      inviteById: []
    };
    /*****************************************/

    /************ reject invites ************/
    case ADD_INVITE_REQUEST:
    case REQUEST_REJECT_INVITE:
    case REQUEST_ACCEPT_INVITE:
    case REQUEST_DELETE_INVITE:
    case REQUEST_SEND_INVITE:
    return {
      ...state,
      inviteOperationIsFetching: true
    };

    case ADD_INVITE_RESULT:
    case RECEIVE_REJECT_INVITE:
    case RECEIVE_ACCEPT_INVITE:
    case RECEIVE_DELETE_INVITE:
    case RECEIVE_SEND_INVITE:
    return {
      ...state,
      inviteOperationIsFetching: false,
      inviteOperationStatus: action.payload
    };
    /*****************************************/

    default:
    return state
  }
}
