import {
    REQUEST_PLANS,
    RECEIVE_PLANS,
    CLEAR_PLANS,

    REQUEST_OBJECT_PLAN,
    RECEIVE_OBJECT_PLAN,
    CLEAR_OBJECT_PLAN,

    REQUEST_SET_OBJECT_PLAN,
    RECEIVE_SET_OBJECT_PLAN,
} from '../actions/plans'


export default function plans(state = {
    plansIsFetching        : false,
    plans                  : [],
    objectPlanIsFetching   : false,
    objectPlan             : [],
    planOperationIsFetching: false,
    planOperationStatus    : [],
}, action) {
    switch (action.type) {

        /************ get_plans ************/
        case REQUEST_PLANS:
            return {
                ...state,
                plansIsFetching: true
            };

        case RECEIVE_PLANS:
            return {
                ...state,
                plansIsFetching: false,
                plans          : action.payload
            };

        case CLEAR_PLANS:
            return {
                ...state,
                plansIsFetching: false,
                plans          : []
            };
        /*****************************************/

        /************ get_object_plan ************/
        case REQUEST_OBJECT_PLAN:
            return {
                ...state,
                objectPlanIsFetching: true
            };

        case RECEIVE_OBJECT_PLAN:
            return {
                ...state,
                objectPlanIsFetching: false,
                objectPlan          : action.payload
            };

        case CLEAR_OBJECT_PLAN:
            return {
                ...state,
                objectPlan: []
            };
        /*****************************************/

        /************ set_object_plan ************/
        case REQUEST_SET_OBJECT_PLAN:
            return {
                ...state,
                planOperationIsFetching: true
            };

        case RECEIVE_SET_OBJECT_PLAN:
            return {
                ...state,
                planOperationIsFetching: false,
                planOperationStatus          : action.payload
            };

        /*****************************************/

        default:
            return state
    }
}
