import {
  REQUEST_ADD_PROMO,
  RECEIVE_ADD_PROMO,

  REQUEST_ACTIVATE_PROMO,
  RECEIVE_ACTIVATE_PROMO,

  REQUEST_PARTNER_PROMOS,
  RECEIVE_PARTNER_PROMOS,
  RECEIVE_MORE_PARTNER_PROMOS,
  CLEAR_PARTNER_PROMOS,

  REQUEST_PROMO_ACTIVATION_CONDITIONS,
  RECEIVE_PROMO_ACTIVATION_CONDITIONS,
} from '../actions/promo'


export default function addressee(state = {
  promoOperationIsFetching: false,
  addPromo: {},
  activatePromoIsFetching: false,
  activatePromo: {},
  partnerPromosIsFetching: false,
  partnerPromos: [],
  promoActivationConditionsIsFetching: false,
  promoActivationConditions: {}
}, action){
  switch (action.type) {

    /*
      add_promo
    */
    case REQUEST_ADD_PROMO:
      return {
        ...state,
        promoOperationIsFetching: true
      };

    case RECEIVE_ADD_PROMO:
      return {
        ...state,
        promoOperationIsFetching: false,
        addPromo: action.payload
      };

    /*
      activate_promo
    */
    case REQUEST_ACTIVATE_PROMO:
      return {
        ...state,
        activatePromoIsFetching: true
      };

    case RECEIVE_ACTIVATE_PROMO:
      return {
        ...state,
        activatePromoIsFetching: false,
        activatePromo: action.payload
      };


    /*
      get_partner_promos
    */

    case REQUEST_PARTNER_PROMOS:
      return {
        ...state,
        partnerPromosIsFetching: true
      };

    case RECEIVE_PARTNER_PROMOS:
      return {
        ...state,
        partnerPromosIsFetching: false,
        partnerPromos: action.payload
      };

    case RECEIVE_MORE_PARTNER_PROMOS:
      let obj = state.partnerPromos;
      if (action.payload.result) {
        obj.result = obj.result.concat(action.payload.result)
      } else {
        obj.error = action.payload.error
      }
      return {
        ...state,
        partnerPromosIsFetching: false,
        partnerPromos: obj
      };

    case CLEAR_PARTNER_PROMOS:
      return {
        ...state,
        partnerPromosIsFetching: false,
        partnerPromos: []
      };

    case REQUEST_PROMO_ACTIVATION_CONDITIONS:
      return {
        ...state,
        promoActivationConditionsIsFetching: true
      };

    case RECEIVE_PROMO_ACTIVATION_CONDITIONS:
      return {
        ...state,
        promoActivationConditionsIsFetching: false,
        promoActivationConditions: action.payload
      };


    default:
    return state
  }
}
