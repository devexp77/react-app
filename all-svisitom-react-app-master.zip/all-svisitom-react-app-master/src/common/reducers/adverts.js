import {
  REQUEST_ADD_ADVERT,
  RECEIVE_ADD_ADVERT,
  RECEIVE_SET_ADVERT,
  REQUEST_SET_ADVERT,
  REQUEST_DELETE_ADVERT,
  RECEIVE_DELETE_ADVERT,
  REQUEST_ADVERTS,
  RECEIVE_ADVERTS,
  RECEIVE_MORE_ADVERTS,
  CLEAR_ADVERTS,
  REQUEST_ADVERT_BY_ID,
  RECEIVE_ADVERT_BY_ID,
  CLEAR_ADVERT_BY_ID
} from "../actions/adverts";

export default function activity(
  state = {
    advertOperationIsFetching: false,
    advertOperationStatus: {},

    advertsIsFetching: false,
    adverts: {},

    advertByIdIsFetching: false,
    advertById: {}
  },
  action
) {
  switch (action.type) {
    /************ add, set, delete advert ************/
    case REQUEST_ADD_ADVERT:
    case REQUEST_DELETE_ADVERT:
    case REQUEST_SET_ADVERT:
      return {
        ...state,
        advertOperationIsFetching: true
      };

    case RECEIVE_ADD_ADVERT:
    case RECEIVE_DELETE_ADVERT:
    case RECEIVE_SET_ADVERT:
      return {
        ...state,
        advertOperationIsFetching: false,
        advertOperationStatus: action.payload
      };

    /************ get advert ************/
    case REQUEST_ADVERT_BY_ID:
      return {
        ...state,
        advertByIdIsFetching: true
      };

    case RECEIVE_ADVERT_BY_ID:
      return {
        ...state,
        advertByIdIsFetching: false,
        advertById: action.payload
      };

    case CLEAR_ADVERT_BY_ID:
      return {
        ...state,
        advertById: {}
      };

    /************ get adverts ************/
    case REQUEST_ADVERTS:
      return {
        ...state,
        advertsIsFetching: true
      };

    case RECEIVE_ADVERTS:
      return {
        ...state,
        advertsIsFetching: false,
        adverts: action.payload
      };

    case RECEIVE_MORE_ADVERTS:
      let obj = state.adverts;
      obj.result = obj.result.concat(action.payload.result);
      return {
        ...state,
        adverts: obj,
        advertsIsFetching: false
      };

    case CLEAR_ADVERTS:
      return {
        ...state,
        advertsIsFetching: false,
        adverts: {}
      };

    /*****************************************/

    default:
      return state;
  }
}
