import {
  REQUEST_WORKTIME_LOGBOOK_RECORDS_COUNT,
  RECEIVE_WORKTIME_LOGBOOK_RECORDS_COUNT,
  CLEAR_WORKTIME_LOGBOOK_RECORDS_COUNT,
  REQUEST_WORKTIME_LOGBOOK_RECORDS,
  RECEIVE_WORKTIME_LOGBOOK_RECORDS,
  RECEIVE_SCROLL_WORKTIME_LOGBOOK_RECORDS,
  CLEAR_WORKTIME_LOGBOOK_RECORDS,
  REQUEST_WORKTIME_LOGBOOK_RECORDS_ID,
  RECEIVE_WORKTIME_LOGBOOK_RECORDS_ID,
  CLEAR_WORKTIME_LOGBOOK_RECORDS_ID,
  REQUEST_WORKTIME_LOGBOOK_RECORD_ID,
  RECEIVE_WORKTIME_LOGBOOK_RECORD_ID,
  CLEAR_WORKTIME_LOGBOOK_RECORD_ID,
  REQUEST_ADD_WORKTIME_LOGBOOK_RECORD,
  RECEIVE_ADD_WORKTIME_LOGBOOK_RECORD,
  REQUEST_SET_WORKTIME_LOGBOOK_RECORD,
  RECEIVE_SET_WORKTIME_LOGBOOK_RECORD
} from "../actions/worktime_logbook";

export default function worktime_logbook(
  state = {
    workTimeLogBookRecordsIsFetching: false,
    workTimeLogBookRecordsCountIsFetching: false,
    workTimeLogBookRecordsByIdsIsFetching: false,
    workTimeLogBookRecordByIdIsFetching: false,
    workTimeLogBookRecords: [],
    workTimeLogBookRecordsCount: [],
    workTimeLogBookRecordsByIds: [],
    workTimeLogBookRecordById: [],

    workTimeLogbookOperationIsFetching: false,
    workTimeLogbookOperationStatus: []
  },
  action
) {
  switch (action.type) {
    case REQUEST_WORKTIME_LOGBOOK_RECORDS_COUNT:
      return {
        ...state,
        workTimeLogBookRecordsCountIsFetching: true
      };

    case RECEIVE_WORKTIME_LOGBOOK_RECORDS_COUNT:
      return {
        ...state,
        workTimeLogBookRecordsCountIsFetching: false,
        workTimeLogBookRecordsCount: action.payload
      };

    case CLEAR_WORKTIME_LOGBOOK_RECORDS_COUNT:
      return {
        ...state,
        workTimeLogBookRecordsCount: []
      };

    case REQUEST_WORKTIME_LOGBOOK_RECORDS:
      return {
        ...state,
        workTimeLogBookRecordsIsFetching: true
      };

    case RECEIVE_WORKTIME_LOGBOOK_RECORDS:
      return {
        ...state,
        workTimeLogBookRecordsIsFetching: false,
        workTimeLogBookRecords: action.payload
      };

    case CLEAR_WORKTIME_LOGBOOK_RECORDS:
      return {
        ...state,
        workTimeLogBookRecords: []
      };

    case RECEIVE_SCROLL_WORKTIME_LOGBOOK_RECORDS:
      if (action.payload.result) {
        if (state.workTimeLogBookRecords.result) {
          let obj = state.workTimeLogBookRecords;
          let length = obj.result.length;

          for (let prop in action.payload.result) {
            obj.result[length] = action.payload.result[prop];
            length++;
          }
          return {
            ...state,
            workTimeLogBookRecordsIsFetching: false,
            workTimeLogBookRecords: obj
          };
        } else {
          return {
            ...state,
            workTimeLogBookRecordsIsFetching: false,
            workTimeLogBookRecords: action.workTimeLogBookRecords
          };
        }
      } else {
        return {
          ...state,
          workTimeLogBookRecordsIsFetching: false
        };
      }

    case REQUEST_WORKTIME_LOGBOOK_RECORDS_ID:
      return {
        ...state,
        workTimeLogBookRecordsByIdsIsFetching: true
      };

    case RECEIVE_WORKTIME_LOGBOOK_RECORDS_ID:
      let workTimeLogBookRecordsByIds = state.workTimeLogBookRecordsByIds;

      if (!workTimeLogBookRecordsByIds.result) {
        workTimeLogBookRecordsByIds = action.payload;
      } else if (action.payload.result) {
        workTimeLogBookRecordsByIds.result = workTimeLogBookRecordsByIds.result.concat(
          action.payload.result
        );
      } else {
        workTimeLogBookRecordsByIds.error = action.payload.error;
      }

      return {
        ...state,
        workTimeLogBookRecordsByIdsIsFetching: false,
        workTimeLogBookRecordsByIds: workTimeLogBookRecordsByIds
      };

    case CLEAR_WORKTIME_LOGBOOK_RECORDS_ID:
      return {
        ...state,
        workTimeLogBookRecordsByIds: []
      };

    case REQUEST_WORKTIME_LOGBOOK_RECORD_ID:
      return {
        ...state,
        workTimeLogBookRecordByIdIsFetching: true
      };

    case RECEIVE_WORKTIME_LOGBOOK_RECORD_ID:
      return {
        ...state,
        workTimeLogBookRecordByIdIsFetching: false,
        workTimeLogBookRecordById: action.payload
      };

    case CLEAR_WORKTIME_LOGBOOK_RECORD_ID:
      return {
        ...state,
        workTimeLogBookRecordById: []
      };

    /********************* add logbook record ****************/
    case REQUEST_ADD_WORKTIME_LOGBOOK_RECORD:
    case REQUEST_SET_WORKTIME_LOGBOOK_RECORD:
      return {
        ...state,
        workTimeLogbookOperationIsFetching: true
      };

    case RECEIVE_ADD_WORKTIME_LOGBOOK_RECORD:
    case RECEIVE_SET_WORKTIME_LOGBOOK_RECORD:
      return {
        ...state,
        workTimeLogbookOperationIsFetching: false,
        workTimeLogbookOperationStatus: action.payload
      };
    /********************************************************/
    default:
      return state;
  }
}
