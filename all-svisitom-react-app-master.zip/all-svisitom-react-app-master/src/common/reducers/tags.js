import {
  REQUEST_ADD_TAG,
  RECEIVE_ADD_TAG,
  REQUEST_TAGS,
  RECEIVE_TAGS,
  CLEAR_TAGS
} from "../actions/tags";

export default function comments(
  state = {
    tagOperationStatus: [],
    tagOperationStatusIsFetching: false,

    tagsIsFetching: false,
    tags: []
  },
  action
) {
  switch (action.type) {
    case REQUEST_ADD_TAG:
      return {
        ...state,
        tagOperationStatusIsFetching: true
      };

    case RECEIVE_ADD_TAG:
      return {
        ...state,
        tagOperationStatusIsFetching: false,
        tagOperationStatus: action.payload
      };

    case REQUEST_TAGS:
      return {
        ...state,
        tagsIsFetching: true
      };

    case RECEIVE_TAGS:
      return {
        ...state,
        tagsIsFetching: false,
        tags: action.payload
      };

    case CLEAR_TAGS:
      return {
        ...state,
        tags: []
      };

    default:
      return state;
  }
}
