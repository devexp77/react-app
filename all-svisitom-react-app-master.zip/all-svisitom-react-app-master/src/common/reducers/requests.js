import {
  REQUEST_REQUEST_RECORDS,
  RECEIVE_REQUEST_RECORDS,
  CLEAR_REQUEST_RECORDS,
  RECEIVE_SCROLL_REQUEST_RECORDS,
  REQUEST_SET_REQUEST,
  RECEIVE_SET_REQUEST,
  REQUEST_REQUEST_RECORD_ID,
  RECEIVE_REQUEST_RECORD_ID,
  CLEAR_REQUEST_RECORD_BY_ID,
  REQUEST_APPROVE_REQUEST,
  RECEIVE_APPROVE_REQUEST,
  REQUEST_REGISTER_REQUEST,
  RECEIVE_REGISTER_REQUEST,
  REQUEST_REQUEST_HISTORY,
  RECEIVE_REQUEST_HISTORY,
  CLEAR_REQUEST_HISTORY,
  CAN_APPROVE_REQUEST,
  CAN_REGISTER_REQUEST,
  REQUEST_ADD_REQUEST,
  RECEIVE_ADD_REQUEST,
  SAVE_REQUEST_DATA,
  CLEAR_REQUEST_DATA,
  SAVE_REQUESTS_FILTER,
  REQUEST_SEND_FOR_REVIEW,
  RECEIVE_SEND_FOR_REVIEW,
  CAN_SEND_REQUEST_FOR_APPROVAL,
  REQUEST_SEND_FOR_APPROVAL,
  RECEIVE_SEND_FOR_APPROVAL,
  REQUEST_CANCEL_REQUEST,
  RECEIVE_CANCEL_REQUEST
} from "../actions/requests";

export default function requests(
  state = {
    requestOperationIsFetching: false,
    requestOperationStatus: [],

    requestRecordsIsFetching: false,
    requestRecords: [],

    requestRecordByIdIsFetching: false,
    requestRecordById: [],

    requestHistoryIsFetching: false,
    requestHistory: [],

    canApproveRequest: [],
    canRegisterRequest: [],
    canSendRequestForApproval: [],

    addRequestResult: [],

    requestData: [],
    requestsFilter: [],

    permitIdList: []
  },
  action
) {
  switch (action.type) {
    /************** set request *******************/
    case REQUEST_SET_REQUEST:
      return {
        ...state,
        requestOperationIsFetching: true
      };

    case RECEIVE_SET_REQUEST:
      return {
        ...state,
        requestOperationIsFetching: false,
        requestOperationStatus: action.payload
      };

    /********************************************/

    /******************** get request records *****************/
    case REQUEST_REQUEST_RECORDS:
      return {
        ...state,
        requestRecordsIsFetching: true
      };

    case RECEIVE_REQUEST_RECORDS:
      return {
        ...state,
        requestRecordsIsFetching: false,
        requestRecords: action.requestRecords
      };

    case RECEIVE_SCROLL_REQUEST_RECORDS:
      let records = state.requestRecords;
      if (action.requestRecords.result) {
        records.result = records.result.concat(action.requestRecords.result);
      } else {
        records.error = action.requestRecords.error;
      }
      return {
        ...state,
        requestRecordsIsFetching: false,
        requestRecords: records
      };

    case CLEAR_REQUEST_RECORDS:
      return {
        ...state,
        requestRecords: []
      };

    /*************************************************************/

    /******************* get request by id ***********************/
    case REQUEST_REQUEST_RECORD_ID:
      return {
        ...state,
        requestRecordByIdIsFetching: true
      };

    case RECEIVE_REQUEST_RECORD_ID:
      return {
        ...state,
        requestRecordByIdIsFetching: false,
        requestRecordById: action.requestRecordById
      };

    case CLEAR_REQUEST_RECORD_BY_ID:
      return {
        ...state,
        requestRecordById: []
      };
    /*************************************************************/

    /****************** register request ************************/
    case REQUEST_REGISTER_REQUEST:
      return {
        ...state,
        requestOperationIsFetching: true
      };

    case RECEIVE_REGISTER_REQUEST:
      return {
        ...state,
        requestOperationIsFetching: false,
        requestOperationStatus: action.payload
      };
    /*************************************************************/

    /**************** approve request *****************/
    case REQUEST_APPROVE_REQUEST:
      return {
        ...state,
        requestOperationIsFetching: true
      };

    case RECEIVE_APPROVE_REQUEST:
      return {
        ...state,
        requestOperationIsFetching: false,
        requestOperationStatus: action.payload
      };
    /*************************************************************/

    /**************** request history *****************/
    case REQUEST_REQUEST_HISTORY:
      return {
        ...state,
        requestHistoryIsFetching: true
      };

    case RECEIVE_REQUEST_HISTORY:
      return {
        ...state,
        requestHistoryIsFetching: false,
        requestHistory: action.payload
      };

    case CLEAR_REQUEST_HISTORY:
      return {
        ...state,
        requestHistory: []
      };
    /*************************************************************/

    /**************** check can approve request *****************/
    case CAN_APPROVE_REQUEST:
      return {
        ...state,
        canApproveRequest: action.payload
      };
    /*************************************************************/

    /**************** check can register request *****************/
    case CAN_REGISTER_REQUEST:
      return {
        ...state,
        canRegisterRequest: action.payload
      };
    /*************************************************************/

    /**************** check can send request for approval *****************/
    case CAN_SEND_REQUEST_FOR_APPROVAL:
      return {
        ...state,
        canSendRequestForApproval: action.payload
      };
    /*************************************************************/

    /******************* add request *********************/
    case REQUEST_ADD_REQUEST:
      return {
        ...state,
        requestOperationIsFetching: true
      };

    case RECEIVE_ADD_REQUEST:
      return {
        ...state,
        requestOperationIsFetching: false,
        addRequestResult: action.payload
      };

    /*************************************************************/

    /******************* send for review *********************/
    case REQUEST_SEND_FOR_REVIEW:
      return {
        ...state,
        requestOperationIsFetching: true
      };

    case RECEIVE_SEND_FOR_REVIEW:
      return {
        ...state,
        requestOperationIsFetching: false,
        requestOperationStatus: action.payload
      };

    /*************************************************************/

    /******************* send for approval *********************/
    case REQUEST_SEND_FOR_APPROVAL:
      return {
        ...state,
        requestOperationIsFetching: true
      };

    case RECEIVE_SEND_FOR_APPROVAL:
      return {
        ...state,
        requestOperationIsFetching: false,
        requestOperationStatus: action.payload
      };

    /*************************************************************/

    /******************* cancel request *********************/
    case REQUEST_CANCEL_REQUEST:
      return {
        ...state,
        requestOperationIsFetching: true
      };

    case RECEIVE_CANCEL_REQUEST:
      return {
        ...state,
        requestOperationIsFetching: false,
        requestOperationStatus: action.payload
      };

    /*************************************************************/

    case SAVE_REQUEST_DATA:
      return {
        ...state,
        requestData: action.payload
      };

    case CLEAR_REQUEST_DATA:
      return {
        ...state,
        requestData: []
      };

    case SAVE_REQUESTS_FILTER:
      return {
        ...state,
        requestsFilter: action.payload
      };

    default:
      return state;
  }
}
