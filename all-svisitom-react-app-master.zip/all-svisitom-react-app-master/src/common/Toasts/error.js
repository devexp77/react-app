import { toast } from "react-toastify";
import errors from "../localization/errors";

export const ErrorToast = (error, id) => {
  let error_message = null;
  let error_code = null;
  if (typeof error === "string") {
    error_message = error;
  } else {
    error_code = "unexpected_error";

    if (error && error.code) {
      if (error.code === -32023 && error.data) {
        error_code = error.data;
      } else {
        error_code = error.code.toString().replace(/^-/, "");
      }
    }

    error_message = errors[error_code];
    if (!error_message) {
      console.log("Unexpected error: " + JSON.stringify(error));
      error_message = "Unexpected error: " + error_code;
    }
  }

  if (id) {
    if (!toast.isActive(id)) {
      toast(error_message, {
        type: toast.TYPE.ERROR,
        autoClose: 5000,
        toastId: id
      });
    }
  }
  else if (error_code){
    if (!toast.isActive(error_code)) {
      toast(error_message, {
        type: toast.TYPE.ERROR,
        autoClose: 5000,
        toastId: error_code
      });
    }
  }

  else {
    toast(error_message, {
      type: toast.TYPE.ERROR,
      autoClose: 5000
    });
  }
};
