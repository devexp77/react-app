import React from 'react'
import {FlatButton} from '../components/Button'
import Icon from '../components/Icon'
import {toast} from 'react-toastify'

import './style.css'

/**
 * message
 * actionMessage
 * onAction
 * onDisableHint
 */
class HintToastComponent extends React.Component {
  constructor(props) {
    super(props);

    this.state = {
      disabled: false
    }
  }

  componentDidMount() {
    this.setState({
      disabled: this.props.disabled
    })
  }

  render() {
    return (
      <div>
        <div className="pull-right" onClick={this.props.onDisableHint ? this.props.onDisableHint.bind(true): null}><Icon name="close" /></div>
        <div>{this.props.message}</div>
        {
          this.props.onAction &&
          <div className="pull-right">
            <FlatButton onClick={this.props.onAction} position="right">
              {this.props.actionMessage}
            </FlatButton>
          </div>
        }
      </div>
    )
  }
}

export const HintToast = (message, actionMessage=null, onAction=null, onDisableHint=null) => {
    let component = (<HintToastComponent message={message} actionMessage={actionMessage} onAction={onAction} onDisableHint={onDisableHint}/>);

    let toastId = toast(
        component,
        {
            type: toast.TYPE.INFO,
            autoClose: 150000,
            className: 'sv-toast sv-hint-toast',
        });

    return toastId;
};

