import {toast} from 'react-toastify'

export const dismissToast = (toastId)  => {
  toast.dismiss(toastId);
}
