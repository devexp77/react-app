import {toast} from 'react-toastify'
import errors  from '../localization/errors'

export const SuccessToast = (message) => {
    toast(
        message,
        {
            type     : toast.TYPE.SUCCESS,
            autoClose: 5000
        })
};
