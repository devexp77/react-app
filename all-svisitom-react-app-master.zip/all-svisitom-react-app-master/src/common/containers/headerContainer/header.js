import React, { Component } from "react";
import { connect } from "react-redux";
import openSocket from "socket.io-client";
import {
  PROTOCOL,
  FULL_HOST_NAME,
  HOST_NAME,
  NOTIFICATION_LIMIT,
  NOTIFICATION_ORDER
} from "../../../common/constants";
import { toRoot } from "../../../common/actions/router";

import { ToastContainer, toast } from "react-toastify";
import "react-toastify/dist/ReactToastify.min.css";
import {
  Notification,
  notificationAction
} from "../../components/Notification";

import { push } from "react-router-redux";

import {
  fetchUserNotifications,
  fetchUserScrollNotifications,
  fetchUserNotificationsCount,
  fetchDeleteNotificationsById,
  ClearUserNotifications,
  fixUserNotificationsCount,
  receiveUserNotificationsCount
} from "../../actions/notifications";
import { updateBillingAccountBalance } from "../../actions/billing";
import { fetchCurrentUserImage } from "../../actions/image";
import {
  fetchAddresseesBento,
  clearAddresseesBento,
  fetchObjectsBento,
  clearObjectsBento,
  fetchEntityRolesBento,
  fetchObjectsImageBento,
  clearObjectsImageBento,
  fetchActivitiesBento,
  clearActivitiesBento
} from "../../actions/bento";
import {fetchSetDoNotDisturbState, fetchUser} from "../../actions/user";
import { toCustomPath } from "../../actions/router";

import Header from "../../components/Header/header";
import { ErrorToast } from "../../Toasts";

import "./style.css";

const ToastNotification = ({ notification, onClick, onDelete, closeToast }) => {
  return (
    <div className="notification-wrapper">
      <Notification
        notification={notification}
        onClick={event => {
          onClick(event);
          closeToast();
        }}
        onDelete={event => {
          onDelete(event);
          closeToast();
        }}
      />
    </div>
  );
};

class HeaderContainer extends Component {
  constructor() {
    super();
    this.state = {
      limit: NOTIFICATION_LIMIT,
      order: NOTIFICATION_ORDER,
      relevantObjects: []
    };

    this.relevantObjectsCount = 3;
  }

  componentDidMount() {
    const { dispatch } = this.props;
    (async () => {
      try {
        if (!this.props.image.currentUserImage.result) {
          if (!this.props.user.user.result) {
            await dispatch(fetchUser());
          }
          if (this.props.user.user.result) {
            const data = {
              entity_type: "users",
              entity_ids: [this.props.user.user.result.user_id]
            };
            dispatch(fetchCurrentUserImage(data));
          }
        }
      } catch (e) {
      } finally {
      }
    })();

    // $(document).off("click touch", '.profile-li');
    // $(document).on("click touch", '.profile-li', function (e){
    //   var dropdown_profile = $("#dropdown-profile");
    //   var li_profile = $(".profile-li");

    //   if (li_profile.is(e.target) || !li_profile.has(e.target).length == 0) {
    //     if (dropdown_profile.hasClass('show')) {
    //       dropdown_profile.removeClass('show');
    //     }
    //     else{
    //       dropdown_profile.addClass('show');
    //     }
    //   }
    // });

    let this__ = this;
    $(document).off("click touch", "#notification-li");
    $(document).on("click touch", "#notification-li", function(e) {
      var dropdown = $("#dropdown-notifications");
      var li = $("#notification-li");

      if (li.is(e.target) || !li.has(e.target).length == 0) {
        if (dropdown.hasClass("show")) {
          dropdown.removeClass("show");
        } else {
          dropdown.addClass("show");
          this__.setHideDropdownEvent();
        }
      }
    });

    $(document).off("click touch", "#bento-li");
    $(document).on("click touch", "#bento-li", function(e) {
      var dropdown = $("#dropdown-bento");
      var li = $("#bento-li");

      if (li.is(e.target) || !li.has(e.target).length == 0) {
        if (dropdown.hasClass("show")) {
          dropdown.removeClass("show");
        } else {
          dropdown.addClass("show");
          this__.setHideDropdownEvent();
        }
      }
    });

    $(document).off("click touch", "#profile-li");
    $(document).on("click touch", "#profile-li", function(e) {
      var dropdown = $("#dropdown-profile");
      var li = $("#profile-li");

      if (li.is(e.target) || !li.has(e.target).length == 0) {
        if (dropdown.hasClass("show")) {
          dropdown.removeClass("show");
        } else {
          dropdown.addClass("show");
          this__.setHideDropdownEvent();
        }
      }
    });

    var user_id = "";
    if (this.props.user.user.result) {
      user_id = this.props.user.user.result.user_id;

      var dataForCount = {
        user_id: user_id
      };

      dispatch(fetchUserNotificationsCount(dataForCount));

      //  var timerId = setInterval(function() {
      //   dispatch(fetchUserNotificationsCount(dataForCount));
      // }, 10000);

      this.socketConnect();
    }
  }

  socketConnect() {
    if (this.props.user.user.result && this.props.socket) {
      this.props.socket.on("new_notification", data => {
        //console.log("Websocket new notification");
        //console.log(data);
        var notification_count = data.notification_count;
        var notification_data = data.notification_data;
        this.updateNotificationCount(notification_count);

        toast(
          <ToastNotification
            notification={notification_data}
            onClick={() => this.NotificationAction(notification_data)}
            onDelete={() => this.DeleteNotification(notification_data)}
          />
        );

        if (notification_data.message_id == "new_payment") {
          let { dispatch } = this.props;
          dispatch(
            updateBillingAccountBalance(notification_data.other.balance)
          );
        }
      });

      this.props.socket.on("notification_count", data => {
        //console.log("Websocket notification count");
        //console.log(data);
        var notification_count = data.notification_count;
        this.updateNotificationCount(notification_count);
      });
    }
  }

  componentDidUpdate(prevProps) {
    if (prevProps.socket !== this.props.socket) {
      console.log("update socket");
      this.socketConnect();
    }
  }

  setHideDropdownEvent() {
    const { dispatch } = this.props;
    var _this = this;
    $(document).off("mouseup touchend");
    $(document).on("mouseup touchend", function(e) {
      var dropdown = $("#dropdown-notifications");
      var li = $("#notification-li");

      if (
        !dropdown.is(e.target) &&
        dropdown.has(e.target).length == 0 &&
        !li.is(e.target) &&
        li.has(e.target).length == 0
      ) {
        if (dropdown.hasClass("show")) {
          dropdown.removeClass("show");
          dispatch(ClearUserNotifications());
        }
      }

      var dropdown_bento = $("#dropdown-bento");
      var bento_li = $("#bento-li");

      if (
        !dropdown_bento.is(e.target) &&
        dropdown_bento.has(e.target).length == 0 &&
        !bento_li.is(e.target) &&
        bento_li.has(e.target).length == 0
      ) {
        if (dropdown_bento.hasClass("show")) {
          dropdown_bento.removeClass("show");
        }
      }

      var dropdown_profile = $("#dropdown-profile");
      var li_profile = $("#profile-li");


      //  if ( !li_profile.is(e.target) && li_profile.has(e.target).length == 0) {
      //   dropdown_profile.removeClass('show');
      // }
      if (
        (!dropdown_profile.is(e.target) &&
          dropdown_profile.has(e.target).length == 0 &&
          !li_profile.is(e.target) &&
          li_profile.has(e.target).length == 0)
      ) {
        dropdown_profile.removeClass("show");
        _this.clearRelevantObjects();
      }
    });
  }

  updateNotificationCount(count) {
    var json_data = {
      result: count,
      id: "1",
      jsonrpc: "2.0"
    };

    var { dispatch } = this.props;
    dispatch(receiveUserNotificationsCount(json_data));
  }

  DeleteNotification(notification) {
    this.DeleteNotificationById(notification.notification_id);
  }

  NotificationAction(notification) {
    var action = notificationAction(notification);

    $("#dropdown-notifications").removeClass("show");
    this.DeleteNotificationById(notification.notification_id);
    window.location.href = action;
  }

  DeleteNotificationById(notification_id) {
    const { dispatch } = this.props;

    (async () => {
      try {
        var data = {
          notifications_ids: [notification_id]
        };
        await dispatch(fetchDeleteNotificationsById(data));
        if (this.props.notifications.deleteNotificationsStatus.result) {
          var user_id = this.props.user.user.result.user_id;
          var end_date = this.props.notifications.userNotifications.result[0]
            .create_date;
          var offset = this.props.notifications.userNotifications.result.length;
          var data = {
            filter: {
              user_id: user_id,
              end_date: end_date
            },
            limit: offset,
            offset: 0,
            order: this.state.order
          };

          var dataForCount = {
            user_id: user_id
          };

          await dispatch(fetchUserNotificationsCount(dataForCount));
          dispatch(fixUserNotificationsCount());
          dispatch(fetchUserNotifications(data));
        }
      } catch (e) {
      } finally {
      }
    })();
  }

  DeleteNotifications() {
    const { dispatch } = this.props;
    var notificationsIdsList = [];
    var i = 0;
    for (var prop in this.props.notifications.userNotifications.result) {
      notificationsIdsList[
        i
      ] = this.props.notifications.userNotifications.result[
        prop
      ].notification_id;
      i++;
    }

    (async () => {
      try {
        var data = {
          notifications_ids: notificationsIdsList
        };
        await dispatch(fetchDeleteNotificationsById(data));
        if (this.props.notifications.deleteNotificationsStatus.result) {
          var user_id = this.props.user.user.result.user_id;
          var data = {
            filter: {
              user_id: user_id
            },
            limit: this.state.limit,
            offset: 0,
            order: this.state.order
          };

          var dataForCount = {
            user_id: user_id
          };

          await dispatch(fetchUserNotificationsCount(dataForCount));
          dispatch(fixUserNotificationsCount());
          dispatch(fetchUserNotifications(data));
        }
      } catch (e) {
      } finally {
      }
    })();
  }

  async SetDoNotDisturbState(state) {
    const {dispatch} = this.props;
    await dispatch(fetchSetDoNotDisturbState({
      do_not_disturb_state: state
    }));

    let {userOperationStatus} = this.props.user;
    if (userOperationStatus.error) {
      ErrorToast(userOperationStatus.error);
      return
    }

    if (userOperationStatus.result) {
      dispatch(fetchUser())
    }
  }

  NotificationActionById(notification_id) {
    const { dispatch } = this.props;

    var notification = this.props.notifications.userNotifications.result.find(
      notification => notification.notification_id === notification_id
    );
    this.NotificationAction(notification);
  }

  ShowMore() {
    const { dispatch } = this.props;
    var user_id = this.props.user.user.result.user_id;
    var end_date = this.props.notifications.userNotifications.result[0]
      .create_date;
    var offset = this.props.notifications.userNotifications.result.length;
    var data = {
      filter: {
        user_id: user_id,
        end_date: end_date
      },
      limit: this.state.limit,
      offset: offset,
      order: this.state.order
    };
    dispatch(fetchUserScrollNotifications(data));
  }

  UpdateNotifications() {
    const { dispatch } = this.props;
    var user_id = this.props.user.user.result.user_id;
    var data = {
      filter: {
        user_id: user_id
      },
      limit: this.state.limit,
      offset: 0,
      order: this.state.order
    };

    var dataForCount = {
      user_id: user_id
    };

    dispatch(fetchUserNotificationsCount(dataForCount));
    dispatch(fixUserNotificationsCount());
    dispatch(fetchUserNotifications(data));
  }

  ShowNotifications() {
    const { dispatch } = this.props;

    var dropdown = document.querySelector("#dropdown-notifications");

    if (dropdown.classList.contains("show")) {
      var user_id = this.props.user.user.result.user_id;

      var data = {
        filter: {
          user_id: user_id
        },
        limit: this.state.limit,
        offset: 0,
        order: this.state.order
      };

      var dataForCount = {
        user_id: user_id
      };

      dispatch(fetchUserNotificationsCount(dataForCount));
      dispatch(fixUserNotificationsCount());
      dispatch(fetchUserNotifications(data));
    } else {
      dispatch(ClearUserNotifications());
    }
  }

  clearRelevantObjects() {
    let { dispatch } = this.props;
    dispatch(clearActivitiesBento());
    dispatch(clearObjectsBento());
    dispatch(clearAddresseesBento());
    dispatch(clearObjectsImageBento());
    this.setState({
      relevantObjects: []
    });
  }

  loadRelevantObjects() {
    var user_id = this.props.user.user.result.user_id;
    const { dispatch } = this.props;

    (async () => {
      try {
        var dataActivity = {
          filter: {
            user_id: user_id,
            entity_type: "object",
            activity_type: "control"
          },
          limit: this.relevantObjectsCount,
          offset: 0,
          order: "-create_date"
        };
        await dispatch(fetchActivitiesBento(dataActivity));
        var { activities } = this.props.bento;
        if (activities.error) {
          ErrorToast(activities.error);
          return;
        }

        var objects_ids = [];
        for (var i = 0; i < activities.result.length; i++) {
          objects_ids.push(activities.result[i].entity_id);
        }

        if (objects_ids.length < this.relevantObjectsCount) {
          var dataRoles = {
            filter: {
              user_id: user_id
            }
          };
          await dispatch(fetchEntityRolesBento(dataRoles));
          var { entityRoles } = this.props.bento;
          if (entityRoles.error) {
            ErrorToast(entityRoles.error);
          }
          if (entityRoles.result) {
            var addressees_ids = [];
            for (var i = 0; i < entityRoles.result.length; i++) {
              var entityRole = entityRoles.result[i];
              if (entityRole.entity_type == "object") {
                var object_id = entityRole.entity_id;
                if (objects_ids.indexOf(object_id) < 0) {
                  objects_ids.push(object_id);
                }
              } else if (entityRole.entity_type == "addressee") {
                var addressee_id = entityRole.entity_id;
                addressees_ids.push(addressee_id);
              }
            }

            if (objects_ids.length < this.relevantObjectsCount) {
              await dispatch(
                fetchAddresseesBento({ addressees_ids: addressees_ids })
              );
              var { addressees } = this.props.bento;
              if (addressees.error) {
                ErrorToast(addressees.error);
              }

              if (addressees.result) {
                for (var i = 0; i < addressees.result.length; i++) {
                  var addressee = addressees.result[i];
                  var object_id = addressee.object_id;
                  if (objects_ids.indexOf(object_id) < 0) {
                    objects_ids.push(object_id);
                  }
                }
              }
            }

            if (objects_ids.length > this.relevantObjectsCount) {
              objects_ids = objects_ids.slice(0, this.relevantObjectsCount);
            }
          }
        }

        if (objects_ids.length == 0) {
          return;
        }

        const imageData = {
          entity_type: "objects",
          entity_ids: objects_ids
        };

        await Promise.all([
          dispatch(fetchObjectsBento({ objects_ids: objects_ids })),
          dispatch(fetchObjectsImageBento(imageData))
        ]);

        var { objects } = this.props.bento;
        if (objects.error) {
          ErrorToast(objects.error);
          return;
        }

        var { objectsImage } = this.props.bento;
        if (objectsImage.error) {
          ErrorToast(objectsImage.error);
          return;
        }

        var relevantObjects = [];
        for (var i = 0; i < objects_ids.length; i++) {
          var object_id = objects_ids[i];
          var object = objects.result.filter(
            obj => obj.object_id == object_id
          )[0];
          if (object) {
            relevantObjects.push({
              object_id: object_id,
              object_name: object.name,
              image_url: objectsImage.result[object_id],
              control_url: `${PROTOCOL}//${object.domain_name}.${HOST_NAME}/#/`
            });
          }
        }
        this.setState({
          relevantObjects: relevantObjects
        });
      } catch (e) {
        console.log(e);
        ErrorToast();
      }
    })();
  }

  ShowUserDropdown() {
    let dropdown = document.querySelector("#dropdown-profile");
    if (dropdown.classList.contains("show")) {
      this.loadRelevantObjects();
    } else {
      this.clearRelevantObjects();
    }
  }

  ShowBentoDropdown() {
    let dropdown = document.querySelector("#dropdown-bento");
    if (dropdown.classList.contains("show")) {
      //this.loadRelevantObjects();
    }
  }

  toRoot() {
    const { dispatch } = this.props;
    dispatch(toRoot());
  }

  toHistoryPath() {
    const { dispatch } = this.props;
    const fromHistory = this.props.router.history.pop();
    const historyPath = fromHistory
      ? fromHistory
      : this.props.router.customHistoryPath;
    dispatch(toCustomPath(historyPath));
  }

  render() {
    const { isFetching, user } = this.props.user;
    const { notifications } = this.props;
    const { objects } = this.props;

    var containerClass = "container-fluid";
    if (this.props.containerClass) {
      containerClass = this.props.containerClass;
    }

    var marginClass;
    if (this.props.marginClass) {
      marginClass = this.props.marginClass;
    }

    var secondBrand;
    if (this.props.secondBrand) {
      secondBrand = this.props.secondBrand;
    }

    var productName;
    if (this.props.productName) {
      productName = this.props.productName;
    }

    var prevButton = false;
    if (this.props.prevButton) {
      prevButton = this.props.prevButton;
    }

    var customClass = false;
    if (this.props.customClass) {
      customClass = this.props.customClass;
    }

    //style={{minWidth:'500px'}}

    return [
      <ToastContainer
        autoClose={10000}
        hideProgressBar={true}
        closeButton={false}
        key={`toast`}
        className="sv-toast-container"
        toastClassName="sv-toast"
      />,
      <Header
        key={`header`}
        user={user}
        objects={objects}
        containerClass={containerClass}
        customClass={customClass}
        logout={this.props.logout}
        login={this.props.login}
        mainPage={this.props.mainPage}
        marginClass={marginClass}
        secondBrand={secondBrand}
        productName={productName}
        prevButton={prevButton}
        inverseColor={this.props.inverseColor}
        notifications={notifications}
        relevantObjects={this.state.relevantObjects}
        DeleteNotification={this.DeleteNotificationById.bind(this)}
        DeleteNotifications={this.DeleteNotifications.bind(this)}
        ShowNotifications={this.ShowNotifications.bind(this)}
        NotificationAction={this.NotificationActionById.bind(this)}
        UpdateNotifications={this.UpdateNotifications.bind(this)}
        SetDoNotDisturbState={this.SetDoNotDisturbState.bind(this)}
        ShowBentoDropdown={this.ShowBentoDropdown.bind(this)}
        ShowUserDropdown={this.ShowUserDropdown.bind(this)}
        ShowMore={this.ShowMore.bind(this)}
        toRoot={this.toRoot.bind(this)}
        toHistoryPath={this.toHistoryPath.bind(this)}
      />
    ];
  }

  componentWillUnmount() {
    if (this.props.socket) {
      this.props.socket.off("new_notification");
      this.props.socket.off("notification_count");
    }
  }
}

const mapStateToProps = state => {
  return {
    user: state.user,
    objects: state.objects,
    router: state.router,
    notifications: state.notifications,
    image: state.image,
    bento: state.bento
  };
};

export default connect(mapStateToProps)(HeaderContainer);
