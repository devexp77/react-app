import React, { Component } from "react";
import { connect } from "react-redux";

import ImageUpload from "../../../common/components/ImageUpload";
import {
  setCustomHistoryPath,
  setTitle,
  toCustomPath
} from "../../../common/actions/router";
import manage_strings from "../../../manage/localization/all";
import SinglePageWithCustomPaddingNavPanel from "../../../common/components/PageContainers/singlePageCustomPaddingNavPanel";
import { setAddresseeImageSuffix } from "../../actions/image";

class AddresseeImageContainer extends Component {
  constructor() {
    super();
    this.state = {};
  }

  componentDidMount() {
    const { dispatch } = this.props;
    dispatch(setTitle(manage_strings.title_image_upload));
    switch (this.props.route.app) {
      case "object":
        dispatch(
          setCustomHistoryPath(`/addressees/${this.props.params.addressee_id}`)
        );
        break;
      case "manage":
        dispatch(
          setCustomHistoryPath(
            `/${this.props.params.object_id}/addressees/${
              this.props.params.addressee_id
            }`
          )
        );
        break;
      default:
        break;
    }
  }

  successAddedFunction() {
    const { dispatch } = this.props;
    dispatch(setAddresseeImageSuffix());
    this.toHistoryPath();
  }

  toHistoryPath() {
    const { dispatch } = this.props;
    const fromHistory = this.props.router.history.pop();
    const historyPath = fromHistory
      ? fromHistory
      : this.props.router.customHistoryPath;
    dispatch(toCustomPath(historyPath));
  }

  render() {
    return (
      <SinglePageWithCustomPaddingNavPanel>
        <ImageUpload
          entityType={`addressees`}
          entityId={this.props.params.addressee_id}
          SuccessFunction={this.successAddedFunction.bind(this)}
          width={300}
          height={300}
          radius={0}
        />
      </SinglePageWithCustomPaddingNavPanel>
    );
  }
}

const mapStateToProps = state => {
  return {
    user: state.user,
    router: state.router
  };
};

export default connect(mapStateToProps)(AddresseeImageContainer);
