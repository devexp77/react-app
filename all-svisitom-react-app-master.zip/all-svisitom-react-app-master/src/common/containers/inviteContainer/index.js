import React from 'react';
import { connect } from "react-redux";

import InviteCard from '../../components/InviteCard';

import {
  fetchUsersImage,
  fetchObjectsImage
} from '../../actions/image';

import {ErrorToast} from '../../Toasts';

/*
  props:
    invite
*/

class InviteContainer extends React.Component {

  constructor(props) {
    super(props);
    this.state = {
      fromUserImageUrl: null,
      toUserImageUrl: null,
      objectImageUrl: null
    }
  }

  componentDidMount() {
    const {dispatch} = this.props;
    const {invite} = this.props;
    (async () => {
      try {
        var data_users_image = {
          entity_type: "users",
          entity_ids: [invite.from_user_id]
        };
        if (invite.to_user_id) {
          data_users_image.entity_ids.push(invite.to_user_id)
        }

        await dispatch(fetchUsersImage(data_users_image));

        var {usersImage} = this.props.image
        if (usersImage.error) {
          ErrorToast(usersImage.error);
          return;
        }

        if (usersImage.result) {
          var fromUserImageUrl = usersImage.result[invite.from_user_id];
          var toUserImageUrl = null;
          if (invite.to_user_id) {
            toUserImageUrl = usersImage.result[invite.to_user_id];
          }

          this.setState({
            fromUserImageUrl: fromUserImageUrl,
            toUserImageUrl: toUserImageUrl
          })
        }

        var data_objects_image = {
          entity_type: 'objects',
          entity_ids: [invite.object_id]
        }

        await dispatch(fetchObjectsImage(data_objects_image));

        var {objectsImage} = this.props.image;
        if (objectsImage.error) {
          ErrorToast(objectsImage.error);
          return;
        }

        if (objectsImage.result) {
          if (objectsImage.result[invite.object_id]) {
            this.setState({
              objectImageUrl: objectsImage.result[invite.object_id]
            })
          }
        }

      } catch (e) {
        ErrorToast();
        console.log(e);
      } finally {
      }
    })();
  }

  render() {
    return (
      <InviteCard
        invite={this.props.invite}
        {...this.state}
      />
    )
  }
}

const mapStateToProps = state => {
  return {
    image: state.image,
  };
};

export default connect(mapStateToProps)(InviteContainer);
