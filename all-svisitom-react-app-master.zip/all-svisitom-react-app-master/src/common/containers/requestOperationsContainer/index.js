import React, { Component } from "react";
import { connect } from "react-redux";
import update from "immutability-helper";

import {
  fetchRequestRecordById,
  saveRequestData,
  fetchSetRequest,
  fetchSendForReview,
  fetchApproveRequest
} from "../../actions/requests";
import {
  toRoot,
  toRequests,
  toRequestConfirm,
  toCustomPath
} from "../../actions/router";
import { fetchObjectById } from "../../actions/objects";
import { fetchUserDoc } from "../../actions/documents";
import { fetchUserTransport } from "../../actions/transport";
import { fetchAddLogBookRecord } from "../../actions/logbook";
import {
  fetchAddressees,
  clearAddressees,
  fetchAddresseeEmployees,
  clearAddresseeEmployees,
  fetchAddresseeAccompanyEmployees,
  clearAddresseeAccompanyEmployees, fetchAddresseeById
} from "../../actions/addressee";
import {fetchRooms, clearRooms, fetchRoomById} from "../../actions/rooms";

import RequestAdd from "../../../request/components/RequestAdd";
import RequestAddPreloader from "../../../request/components/RequestAdd/preloader";
import RequestEdit from "../../../object/components/RequestEdit";
import AddInvite from "../../../object/components/AddInvite";
import RequestEditPreloader from "../../../object/components/RequestEdit/preloader";

import LogbookRecordAdd from "../../../object/components/LogbookRecordAdd";
import TransportLogbookRecordAdd from "../../../object/components/TransportLogbookRecordAdd";
import LogbookRecordAddPreloader from "../../../object/components/LogbookRecordAdd/preloader";

import { ErrorToast } from "../../Toasts/error";
import strings from "../../../request/localization/all";
import { fetchObjectPlan } from "../../actions/plans";
import { fetchAddTransportLogBookRecord } from "../../actions/transportLogbook";
import { DOCUMENTS } from "../../constants/documents";
import { isValidEmail } from "../../validation/email";
import { fetchAddInvite, fetchInviteById } from "../../actions/invites";
import { isAvailableOperationElement } from "../../../object/helpers/checkObjectStatus";
import { fetchAllContacts, fetchContacts } from "../../actions/contacts";
import fetch from "isomorphic-fetch";
import { fetchSetImage } from "../../actions/image";
import {fetchActivities} from "../../actions/activity";

class RequestOperationContainer extends Component {
  constructor(props) {
    super(props);
    let start_date = this.getStartDate();
    let end_date = this.getEndDate(start_date);
    this.state = {
      request_type: "single_use",
      object: {
        object_id: "",
        name: "",
        geo_point: []
      },
      request_id: "",
      addressee: {
        addressee_id: "",
        name: ""
      },
      room: {
        room_id: "",
        name: ""
      },
      inviter: {
        user_id: "",
        name: "",
        surname: "",
        patronymic: "",
        company: "",
        job_title: ""
      },
      accompany: {
        user_id: "",
        name: "",
        surname: "",
        patronymic: "",
        company: "",
        job_title: ""
      },
      visit_reason: "",
      visitors: [],

      start_date: start_date.toISOString(),
      end_date: end_date,

      vehicles: [],

      formErrors: {
        addressee: "init",
        start_date: "init",
        end_date: "init",
        invite_email: "init",
        surname: ["init"],
        name: ["init"],
        email: ["init"],
        phone_number: ["init"],
        driver_name: ["init"],
        driver_surname: ["init"],
        driver_email: ["init"],
        issueDate: ["init"],
        docNumber: ["init"],
        licensePlate: []
      },

      invite_email: ""
    };
  }

  componentDidMount() {
    window.scrollTo(0, 0);

    const object_id = this.props.params.object_id;
    const request_id = this.props.params.request_id;

    this.setState({ request_id: request_id });

    if (!this.isUserEditRequestPage()) {
      this.getObjectInfo(object_id);
    } else {
      this.dataRouter();
    }

    this.getAllContacts();
  }

  async getReceivingSideInfo() {
    const { dispatch } = this.props;
    const object_id = this.getObjectId();

    if (this.props.user.user.result) {
      const data = {
        filter: {
          object_id: object_id,
          user_id: this.props.user.user.result.user_id,
          roles: ["inviter"]
        },
        order: "+name",
        limit: 100,
        offset: 0
      };
      await dispatch(fetchAddressees(data));
      if (
        this.props.addressee.addressees.result &&
        this.props.addressee.addressees.result.length > 0
      ) {
        this.getRooms(
          null,
          this.props.addressee.addressees.result[0].addressee_id
        ).then(res => {
          if (res.payload.result && res.payload.result.length > 0) {
            this.setState({
              room: res.payload.result[0]
            });
          }
        });
        this.setState({
          addressee: this.props.addressee.addressees.result[0],
          inviter: {
            user_id: this.props.user.user.result.user_id,
            name: this.props.user.user.result.name,
            surname: this.props.user.user.result.surname,
            patronymic: this.props.user.user.result.patronymic,
            company: this.props.user.user.result.company,
            job_title: this.props.user.user.result.job_title
          }
        });
      }

      if (
        this.props.addressee.addressees.result &&
        this.props.addressee.addressees.result.length === 0
      ) {
        this.getAddressees(null);
      }

      if (this.props.addressee.addressees.error) {
        ErrorToast(this.props.addressee.addressees.error);
      }
    }
  }

  dataRouter() {
    const object_id = this.props.params.object_id;
    const request_id = this.props.params.request_id;
    const invite_id = this.props.params.invite_id;
    const { requestData } = this.props.requests;

    /*** add invite ***/
    if (this.isAddInvitePage()) {
      const { currentObject } = this.props.objects;
      const { objectPlan } = this.props.plans;

      if (!isAvailableOperationElement(currentObject.result, objectPlan)) {
        this.toHistoryPath();
      }

      this.getReceivingSideInfo();
      return;
    }
    /**************************************/

    /*** add logbook record ***/
    if (this.isLogbookRecordAddPage()) {
      this.getAddressees(null);
      this.addEmptyVisitor(0);
      return;
    }
    /**************************************/

    /*** add transport logbook record ***/
    if (this.isTransportLogbookRecordAddPage()) {
      const vehicles = [
        {
          transport_id: "new",
          brand: "",
          model: "",
          color: "",
          category: "",
          license_plate: ""
        }
      ];

      let formErrors = Object.assign({}, this.state.formErrors);
      formErrors.licensePlate.push("init");

      this.setState({ vehicles: vehicles, formErrors: formErrors });
      this.getAddressees(null);
      return;
    }
    /**************************************/

    /*** add request from invite***/
    if (request_id && request_id === "invite" && invite_id) {
      this.initInvite(invite_id);

      this.VisitorInitState(
        update(this.props.user.user.result, {
          ["email"]: { $set: "" }
        }),
        0
      );
      this.getUserDocumentsAndTransport();
      this.getAddressees(null);

      return;
    }
    /************************************/

    /*** edit request from object***/
    if (request_id && request_id !== "new" && this.isEditRequestPage()) {
      this.getRequestData(request_id);
      return;
    }
    /************************************/

    /*** edit request from profile***/
    if (request_id && request_id !== "new" && this.isUserEditRequestPage()) {
      this.getRequestData(request_id);
      this.getUserDocumentsAndTransport();
      return;
    }
    /************************************/

    /*** request by registrator from object ***/
    if (request_id && request_id === "new") {
      this.getReceivingSideInfo();
      return;
    }
    /**************************************/

    /*** repeat request from user profile ***/
    if (request_id && request_id !== "new") {
      this.getRequestData(request_id);
      this.getUserDocumentsAndTransport();
      return;
    }
    /************************************/

    /*** edit request, back from check request data***/
    if (requestData.object && requestData.object.object_id === object_id) {
      this.RequestDataInitState(requestData);
      this.DateInitState(requestData);
      if (!(requestData.request_id && requestData.request_id === "new")) {
        this.getUserDocumentsAndTransport();
      }
      return;
    }
    /*************************************/

    /*** standard request ***/
    if (!requestData.object || requestData.object.object_id !== object_id) {
      // this.VisitorInitState(
      //   update(this.props.user.user.result, {
      //     ["email"]: { $set: "" },
      //     ["phone_number"]: { $set: "" },
      //   }),
      //   0
      // );
      this.getUserDocumentsAndTransport();
      this.getAddressees(null);
      this.loadDataFromActivity();
    }
    /*********************/
  }

  initInvite(invite_id) {
    const { dispatch } = this.props;
    (async () => {
      try {
        const data = {
          invite_id: invite_id
        };
        await dispatch(fetchInviteById(data));

        if (this.props.invites.inviteById.error) {
          ErrorToast(this.props.invites.inviteById.error);
        }

        if (
          this.props.invites.inviteById.result &&
          this.props.invites.inviteById.result.request_details
        ) {
          this.RequestDataInitState(
            this.props.invites.inviteById.result.request_details
          );
          this.DateInitState(
            this.props.invites.inviteById.result.request_details
          );
        }
      } catch (e) {
        ErrorToast();
        console.log(e);
      } finally {
      }
    })();
  }

  async loadDataFromActivity() {
    const {dispatch} = this.props;
    const object_id = this.props.params.object_id;

    let dataActivity = {
      filter: {
        user_id: this.props.user.user.result.user_id,
        entity_type: "object",
        entity_id: object_id,
        activity_type: "visit_request"
      },
      limit: this.relevantObjectsCount,
      offset: 0,
      order: "-create_date"
    };
    await dispatch(fetchActivities(dataActivity));
    let { activities } = this.props.activity;
    if (activities.error) {
      ErrorToast(activities.error);
      return;
    }

    if (activities.result && activities.result.length > 0) {
      const activity = activities.result[0];
      const addressee_id = activity.data.addressee_id;
      const room_id = activity.data.room_id;

      await dispatch(fetchAddresseeById({
        addressee_id: addressee_id
      }));

      const {addresseeById} = this.props.addressee;
      if (addresseeById.result) {
        this.setState({
          addressee: {
            addressee_id: addressee_id,
            name: addresseeById.result.name
          }
        });

        if (room_id) {
          await dispatch(fetchRoomById({
            room_id: room_id
          }));

          const {roomById} = this.props.rooms;
          if (roomById.result && roomById.result.addressee_id === addressee_id) {
            this.setState({
              room: {
                room_id: room_id,
                name: roomById.result.name
              }
            });
          }
        }
      }
    }
  }

  getObjectInfo(object_id) {
    const { dispatch } = this.props;
    if (object_id) {
      (async () => {
        try {
          const data = {
            object_id: object_id
          };
          dispatch(fetchObjectPlan(data));
          await dispatch(fetchObjectById(data));

          if (this.props.objects.objectById.error) {
            dispatch(toRoot());
            ErrorToast(this.props.objects.objectById.error);
          }

          if (this.props.objects.objectById.result) {
            const objectData = {
              object_id: object_id,
              name: this.props.objects.objectById.result.name,
              geo_point: this.props.objects.objectById.result.geo_point
            };
            this.setState({
              object: objectData
            });
            this.dataRouter();
          }
        } catch (e) {
          ErrorToast();
          console.log(e);
        } finally {
        }
      })();
    } else if (this.props.objects.currentObject.result) {
      const objectData = {
        object_id: this.props.objects.currentObject.result.object_id,
        name: this.props.objects.currentObject.result.name
      };
      this.setState({
        object: objectData
      });
      this.dataRouter();
    } else {
      dispatch(toRoot());
      const error = {
        code: "-32018"
      };
      ErrorToast(error);
    }
  }

  getRequestData(request_id) {
    const { dispatch } = this.props;
    (async () => {
      try {
        const data = {
          request_id: request_id
        };
        await dispatch(fetchRequestRecordById(data));
        const { requestRecordById } = this.props.requests;
        if (requestRecordById.error) {
          ErrorToast(requestRecordById.error);
        }

        if (requestRecordById.result) {
          if (
            this.isCorrectRequestData(requestRecordById.result) ||
            this.isUserEditRequestPage()
          ) {
            if (this.isUserEditRequestPage()) {
              this.RequestDataInitState(requestRecordById.result);
              this.DateInitState(requestRecordById.result);
              this.ObjectInitState(requestRecordById.result);
            } else if (this.isEditRequestPage()) {
              this.RequestDataInitState(requestRecordById.result);
              this.RequestAccompanyInitState(requestRecordById.result);
              this.DateInitState(requestRecordById.result);
              this.RequestTypeInitState(requestRecordById.result);
            } else {
              this.RequestDataInitState(requestRecordById.result);
            }
          } else {
            const error = {
              code: "request_not_for_this_object"
            };
            this.toPrevPage();
            ErrorToast(error);
          }
        }
      } catch (e) {
        ErrorToast();
        console.log(e);
      } finally {
      }
    })();
  }

  getUserDocumentsAndTransport() {
    const { dispatch } = this.props;
    (async () => {
      try {
        const data = {
          filter: {
            owner_id: this.props.user.user.result.user_id
          },
          limit: null,
          offset: null
        };
        if (!this.props.documents.userDoc.result) {
          await dispatch(fetchUserDoc(data));
        }

        /** standard request -> initUserDoc**/
        // const { userDoc } = this.props.documents;
        // if (userDoc.result && userDoc.result.length > 0) {
        //   const { requestData } = this.props.requests;
        //   const object_id = this.getObjectId();
        //   const request_id = this.props.params.request_id;
        //
        //   if (
        //     !(
        //       requestData.object && requestData.object.object_id === object_id
        //     ) &&
        //     (!request_id || request_id === "invite")
        //   ) {
        //     let request_fields = {};
        //     if (this.props.objects.objectById.result) {
        //       request_fields = this.props.objects.objectById.result.settings
        //         .request_fields;
        //     }
        //
        //     if (userDoc.result.find(doc => doc.doc_type === "passport")) {
        //       const doc = userDoc.result.find(
        //         doc => doc.doc_type === "passport"
        //       );
        //
        //       if (
        //         !(
        //           request_fields &&
        //           request_fields.visitors &&
        //           request_fields.visitors.document.number &&
        //           !request_fields.visitors.document.number.visibility
        //         )
        //       ) {
        //         this.DocInitState(doc, 0);
        //       }
        //     } else {
        //       const doc = userDoc.result[0];
        //       if (
        //         !(
        //           request_fields &&
        //           request_fields.visitors &&
        //           request_fields.visitors.document.number &&
        //           !request_fields.visitors.document.number.visibility
        //         )
        //       ) {
        //         this.DocInitState(doc, 0);
        //       }
        //     }
        //   }
        // }
        /**/

        if (!this.props.transport.userTransport.result) {
          await dispatch(fetchUserTransport(data));
        }
      } catch (e) {
        ErrorToast();
        console.log(e);
      } finally {
      }
    })();
  }

  getObjectId() {
    let object_id = this.props.params.object_id;
    if (!object_id && this.props.objects.currentObject.result) {
      object_id = this.props.objects.currentObject.result.object_id;
    }

    if (
      !object_id &&
      this.props.requests.requestRecordById.result &&
      this.props.requests.requestRecordById.result.object.object_id
    ) {
      object_id = this.props.requests.requestRecordById.result.object.object_id;
    }
    return object_id;
  }

  getStartDate() {
    let selectedDate = new Date();
    const { add_request } = this.props;
    if (
      add_request &&
      add_request.object_query &&
      add_request.object_query.query_date
    ) {
      selectedDate = new Date(add_request.object_query.query_date);
    }
    const newDate = new Date();

    return new Date(
      selectedDate.getFullYear(),
      selectedDate.getMonth(),
      selectedDate.getDate(),
      newDate.getHours(),
      Math.floor(newDate.getMinutes() / 5) * 5 + 5
    );
  }

  getEndDate(start_date = new Date(this.state.start_date)) {
    return new Date(
      start_date.getFullYear(),
      start_date.getMonth(),
      start_date.getDate(),
      23,
      59
    ).toISOString();
  }

  getIssueDate() {
    if (
      !(
        this.state.issue_year === "" &&
        this.state.issue_month === "" &&
        this.state.issue_day === ""
      )
    ) {
      return new Date(
        this.state.issue_year,
        this.state.issue_month - 1,
        this.state.issue_day,
        "12",
        "00"
      );
    } else {
      return null;
    }
  }

  isCorrectRequestData(requestData) {
    const object_id = this.getObjectId();
    return (
      requestData &&
      requestData.object &&
      requestData.object.object_id &&
      requestData.object.object_id === object_id
    );
  }

  isEditRequestPage() {
    return this.props.route.page && this.props.route.page === "edit_request";
  }

  isUserEditRequestPage() {
    return (
      this.props.route.page && this.props.route.page === "edit_user_request"
    );
  }

  isLogbookRecordAddPage() {
    return this.props.route.page && this.props.route.page === "logbook_add";
  }

  isTransportLogbookRecordAddPage() {
    return (
      this.props.route.page && this.props.route.page === "transport_logbook_add"
    );
  }

  isAddInvitePage() {
    return this.props.route.page && this.props.route.page === "add_invite";
  }

  /******* init  *******/
  RequestDataInitState(requestData) {
    if (
      requestData.addressee &&
      requestData.addressee.name &&
      requestData.addressee.addressee_id
    ) {
      const addressee = this.state.addressee;
      addressee.addressee_id = requestData.addressee.addressee_id;
      addressee.name = requestData.addressee.name;
    }

    if (requestData.room && requestData.room.name && requestData.room.room_id) {
      const room = this.state.room;
      room.room_id = requestData.room.room_id;
      room.name = requestData.room.name;
    }

    if (requestData.inviter && requestData.inviter.user_id) {
      const inviter = this.state.inviter;
      inviter.user_id = requestData.inviter.user_id;
      inviter.surname = requestData.inviter.surname;
      inviter.name = requestData.inviter.name;
      inviter.patronymic = requestData.inviter.patronymic;
      inviter.company = requestData.inviter.company;
      inviter.job_title = requestData.inviter.job_title;
    }

    requestData.visit_reason
      ? this.setState({
          visit_reason: requestData.visit_reason
        })
      : null;

    requestData.request_type
      ? this.setState({
          request_type: requestData.request_type
        })
      : null;

    if (requestData.visitors && requestData.visitors.length > 0) {
      requestData.visitors.map((visitor, index) =>
        this.VisitorInitState(visitor, index)
      );
    }

    let request_fields = {};
    if (this.props.objects.objectById.result) {
      request_fields = this.props.objects.objectById.result.settings
        .request_fields;
    }

    if (
      requestData.vehicles &&
      requestData.vehicles.length > 0 &&
      !(
        request_fields &&
        request_fields.vehicles &&
        request_fields.vehicles.license_plate &&
        !request_fields.vehicles.license_plate.visibility
      )
    ) {
      requestData.vehicles.map((transport, index) =>
        this.TransportInitState(transport, index)
      );
    }
  }

  RequestAccompanyInitState(requestData) {
    if (requestData.accompany && requestData.accompany.user_id) {
      const accompany = this.state.accompany;
      accompany.user_id = requestData.accompany.user_id;
      accompany.surname = requestData.accompany.surname;
      accompany.name = requestData.accompany.name;
      accompany.patronymic = requestData.accompany.patronymic;
      accompany.company = requestData.accompany.company;
      accompany.job_title = requestData.accompany.job_title;
    }
  }

  addEmptyVisitor(index) {
    if (!this.state.visitors[index]) {
      const emptyVisitor = {
        user_id: "",
        name: "",
        surname: "",
        patronymic: "",
        company: "",
        job_title: "",
        email: "",
        phone_number: "",
        document: {
          doc_type: "",
          number: "",
          issue_date: "",
          issue_place: "",
          other_info: ""
        }
      };
      const visitors = Object.assign(this.state.visitors);
      visitors.push(emptyVisitor);

      this.setState({ visitors: visitors });
    }
  }

  VisitorInitState(visitor, index) {
    let request_fields = {};
    if (this.props.objects.objectById.result) {
      request_fields = this.props.objects.objectById.result.settings
        .request_fields;
    }

    if (!this.state.formErrors.surname[index]) {
      let formErrors = Object.assign({}, this.state.formErrors);
      formErrors.name.push("init");
      formErrors.surname.push("init");

      this.setState({
        formErrors: formErrors
      });
    }

    this.addEmptyVisitor(index);

    if (visitor.user_id) {
      this.setState({
        visitors: update(this.state.visitors, {
          [index]: { ["user_id"]: { $set: visitor.user_id } }
        })
      });
    }

    if (visitor.surname) {
      this.setState({
        visitors: update(this.state.visitors, {
          [index]: { ["surname"]: { $set: visitor.surname } }
        })
      });
    }

    if (visitor.name) {
      this.setState({
        visitors: update(this.state.visitors, {
          [index]: { ["name"]: { $set: visitor.name } }
        })
      });
    }

    if (
      visitor.patronymic &&
      !(
        request_fields &&
        request_fields.visitors &&
        request_fields.visitors.patronymic &&
        !request_fields.visitors.patronymic.visibility
      )
    ) {
      this.setState({
        visitors: update(this.state.visitors, {
          [index]: { ["patronymic"]: { $set: visitor.patronymic } }
        })
      });
    }

    if (
      visitor.company &&
      !(
        request_fields &&
        request_fields.visitors &&
        request_fields.visitors.company &&
        !request_fields.visitors.company.visibility
      )
    ) {
      this.setState({
        visitors: update(this.state.visitors, {
          [index]: { ["company"]: { $set: visitor.company } }
        })
      });
    }

    if (
      visitor.job_title &&
      !(
        request_fields &&
        request_fields.visitors &&
        request_fields.visitors.job_title &&
        !request_fields.visitors.job_title.visibility
      )
    ) {
      this.setState({
        visitors: update(this.state.visitors, {
          [index]: { ["job_title"]: { $set: visitor.job_title } }
        })
      });
    }

    if (
      visitor.email &&
      !(
        request_fields &&
        request_fields.visitors &&
        request_fields.visitors.email &&
        !request_fields.visitors.email.visibility
      )
    ) {
      this.setState({
        visitors: update(this.state.visitors, {
          [index]: { ["email"]: { $set: visitor.email } }
        })
      });
    }

    if (
      visitor.phone_number &&
      !(
        request_fields &&
        request_fields.visitors &&
        request_fields.visitors.phone_number &&
        !request_fields.visitors.phone_number.visibility
      )
    ) {
      this.setState({
        visitors: update(this.state.visitors, {
          [index]: { ["phone_number"]: { $set: visitor.phone_number } }
        })
      });
    }

    if (
      visitor.document &&
      visitor.document.doc_type &&
      !(
        request_fields &&
        request_fields.visitors &&
        request_fields.visitors.document.number &&
        !request_fields.visitors.document.number.visibility
      )
    ) {
      this.DocInitState(visitor.document, index);
    }
  }

  DocInitState(document, index) {
    let request_fields = {};
    if (this.props.objects.objectById.result) {
      request_fields = this.props.objects.objectById.result.settings
        .request_fields;
    }
    if (!this.state.formErrors.docNumber[index]) {
      let formErrors = Object.assign({}, this.state.formErrors);
      formErrors.issueDate.push("init");
      formErrors.docNumber.push("init");

      this.setState({
        formErrors: formErrors
      });
    }

    let doc = { doc_type: document.doc_type };

    if (document.doc_type) {
      for (let field of DOCUMENTS[document.doc_type]) {
        document[field.id] &&
        !(
          request_fields &&
          request_fields.visitors &&
          request_fields.visitors.document[field.id] &&
          !request_fields.visitors.document[field.id].visibility
        )
          ? (doc[field.id] = document[field.id])
          : (doc[field.id] = "");
      }
    }

    this.setState({
      visitors: update(this.state.visitors, {
        [index]: {
          ["document"]: { $set: doc }
        }
      })
    });
  }

  TransportInitState(transport, index) {
    if (!this.state.formErrors.licensePlate[index]) {
      let formErrors = Object.assign({}, this.state.formErrors);
      formErrors.licensePlate.push("init");

      this.setState({
        formErrors: formErrors
      });
    }

    if (!this.state.vehicles[index]) {
      const emptyTransport = {
        transport_id: "",
        brand: "",
        model: "",
        color: "",
        category: "",
        license_plate: ""
      };
      const vehicles = update(this.state, {
        vehicles: { $push: [emptyTransport] }
      });

      this.setState(vehicles);
    }

    let request_fields = {};
    if (this.props.objects.objectById.result) {
      request_fields = this.props.objects.objectById.result.settings
        .request_fields;
    }

    this.setState({
      vehicles: update(this.state.vehicles, {
        [index]: {
          ["transport_id"]: {
            $set: transport.transport_id
              ? transport.transport_id
              : transport.license_plate
                ? "new"
                : ""
          },
          ["brand"]: {
            $set: !(
              request_fields &&
              request_fields.vehicles &&
              request_fields.vehicles.brand &&
              !request_fields.vehicles.brand.visibility
            )
              ? transport.brand
              : ""
          },
          ["color"]: {
            $set: !(
              request_fields &&
              request_fields.vehicles &&
              request_fields.vehicles.color &&
              !request_fields.vehicles.color.visibility
            )
              ? transport.color
              : ""
          },
          ["category"]: {
            $set: !(
              request_fields &&
              request_fields.vehicles &&
              request_fields.vehicles.category &&
              !request_fields.vehicles.category.visibility
            )
              ? transport.category
              : ""
          },
          ["model"]: {
            $set: !(
              request_fields &&
              request_fields.vehicles &&
              request_fields.vehicles.model &&
              !request_fields.vehicles.model.visibility
            )
              ? transport.model
              : ""
          },
          ["license_plate"]: { $set: transport.license_plate },
          ["driver"]: {
            $set:
              transport.driver &&
              transport.driver.surname &&
              !(
                request_fields &&
                request_fields.vehicles &&
                request_fields.vehicles.driver.surname &&
                !request_fields.vehicles.driver.surname.visibility
              ) &&
              !(
                request_fields &&
                request_fields.vehicles &&
                request_fields.vehicles.driver.name &&
                !request_fields.vehicles.driver.name.visibility
              )
                ? transport.driver
                : null
          }
        }
      })
    });
  }

  DateInitState(requestData) {
    if (requestData.start_date) {
      this.setState({
        start_date: requestData.start_date
      });
    }

    if (requestData.end_date) {
      this.setState({
        end_date: requestData.end_date
      });
    }
  }

  ObjectInitState(requestData) {
    const object = this.state;
    if (requestData.object && requestData.object.name) {
      object.name = requestData.object.name;
    }

    if (requestData.object && requestData.object.object_id) {
      object.object_id = requestData.object.object_id;
    }
  }

  RequestTypeInitState(requestData) {
    if (requestData.request_type) {
      this.setState({
        request_type: requestData.request_type
      });
    }
  }

  /**********************/
  clearRooms() {
    const { dispatch } = this.props;
    dispatch(clearRooms());
  }

  clearInviters() {
    const { dispatch } = this.props;
    dispatch(clearAddresseeEmployees());
  }

  clearAccompany() {
    const { dispatch } = this.props;
    dispatch(clearAddresseeAccompanyEmployees());
  }

  async getRooms(keywords, addressee_id) {
    const { dispatch } = this.props;
    const object_id = this.getObjectId();

    const data = {
      filter: {
        keywords: keywords,
        addressee_id: addressee_id,
        object_id: object_id
      },
      order: "+name",
      limit: 100,
      offset: 0
    };
    return await dispatch(fetchRooms(data));
  }

  getAddresseeEmployees(keywords, addressee_id) {
    const { dispatch } = this.props;
    const data = {
      filter: {
        keywords: keywords,
        addressee_id: addressee_id,
        roles: ["inviter"]
      },
      order: "+name",
      limit: 5,
      offset: 0
    };
    dispatch(fetchAddresseeEmployees(data));
  }

  getAddresseeAccompanyEmployees(keywords, addressee_id) {
    const { dispatch } = this.props;
    const data = {
      filter: {
        keywords: keywords,
        addressee_id: addressee_id,
        roles: ["accompany"]
      },
      order: "+name",
      limit: 5,
      offset: 0
    };
    dispatch(fetchAddresseeAccompanyEmployees(data));
  }

  getAddressees(keywords) {
    const { dispatch } = this.props;
    const object_id = this.getObjectId();

    const data = {
      filter: {
        keywords: keywords,
        object_id: object_id
      },
      order: "+name",
      limit: 100,
      offset: 0
    };
    dispatch(fetchAddressees(data));
  }

  /************ handlers *************/
  addUser(id) {
    let visitor = {};

    if (id === "current" && this.props.user.user.result) {
      const user = this.props.user.user.result;
      visitor = {
        user_id: user.user_id,
        name: user.name,
        surname: user.surname,
        patronymic: user.patronymic || "",
        company: user.company || "",
        job_title: user.job_title || "",
        email: "",
        phone_number: "",
        document: {
          doc_type: "",
          number: "",
          issue_date: "",
          issue_place: "",
          other_info: ""
        }
      };
    } else if (
      this.props.contacts &&
      this.props.contacts.allContacts.result &&
      this.props.contacts.allContacts.result.find(
        contact => contact.contact_id === id
      )
    ) {
      const contact = this.props.contacts.allContacts.result.find(
        contact => contact.contact_id === id
      );

      visitor = {
        user_id: "",
        contact_id: contact.contact_id,
        name: contact.name || "",
        surname: contact.surname || "",
        patronymic: contact.patronymic || "",
        company: contact.company || "",
        job_title: contact.job_title || "",
        email: contact.email || "",
        phone_number: contact.phone_number || "",
        document: {
          doc_type: "",
          number: "",
          issue_date: "",
          issue_place: "",
          other_info: ""
        }
      };
    } else {
      visitor = {
        user_id: "",
        name: "",
        surname: "",
        patronymic: "",
        company: "",
        job_title: "",
        email: "",
        phone_number: "",
        document: {
          doc_type: "",
          number: "",
          issue_date: "",
          issue_place: "",
          other_info: ""
        }
      };
    }

    let formErrors = Object.assign({}, this.state.formErrors);

    formErrors.name.push("init");
    formErrors.issueDate.push("init");
    formErrors.docNumber.push("init");
    formErrors.surname.push("init");

    this.setState({
      visitors: update(this.state.visitors, { $push: [visitor] }),
      formErrors: formErrors
    });
  }

  deleteDocument(index) {
    const emptyDocument = {
      doc_type: "",
      number: "",
      issue_date: "",
      issue_place: "",
      other_info: ""
    };

    let formErrors = Object.assign({}, this.state.formErrors);

    formErrors.issueDate[index] = "init";
    formErrors.docNumber[index] = "init";

    this.setState({
      formErrors: formErrors,
      visitors: update(this.state.visitors, {
        [index]: {
          ["document"]: { $set: emptyDocument }
        }
      })
    });
  }

  deleteDriver(transportIndex) {
    this.setState({
      vehicles: update(this.state.vehicles, {
        [transportIndex]: {
          ["driver"]: { $set: null }
        }
      })
    });
  }

  deleteTransport(index) {
    let vehicles = this.state.vehicles.slice(0);

    vehicles.splice(index, 1);

    let formErrors = Object.assign({}, this.state.formErrors);
    formErrors.licensePlate.splice(index, 1);

    this.setState({
      vehicles: vehicles,
      formErrors: formErrors
    });
  }

  deleteUser(index) {
    let visitors = this.state.visitors.slice(0);
    visitors.splice(index, 1);

    let formErrors = Object.assign({}, this.state.formErrors);

    formErrors.name.splice(index, 1);
    formErrors.issueDate.splice(index, 1);
    formErrors.docNumber.splice(index, 1);
    formErrors.surname.splice(index, 1);

    this.setState({
      visitors: visitors,
      formErrors: formErrors
    });
  }

  setTimeInput(id, value) {
    const date = new Date(this.state[id]);
    const newDate = new Date(
      date.getFullYear(),
      date.getMonth(),
      date.getDate(),
      value.getHours(),
      value.getMinutes()
    );
    this.setState(
      {
        [id]: newDate.toISOString()
      },
      () => {
        this.validateField(id, newDate.toISOString());
      }
    );

    let request_fields = {};
    if (this.props.objects.objectById.result) {
      request_fields = this.props.objects.objectById.result.settings
        .request_fields;
    }

    if (
      id === "start_date" &&
      !(
        request_fields &&
        request_fields.end_date &&
        !request_fields.end_date.visibility
      )
    ) {
      this.setState({
        end_date: this.getEndDate(newDate)
      });
    }
  }

  setDateInput(id, value) {
    const date = new Date(this.state[id]);
    const newDate = new Date(
      value.getFullYear(),
      value.getMonth(),
      value.getDate(),
      date.getHours(),
      date.getMinutes()
    );
    this.setState(
      {
        [id]: newDate.toISOString()
      },
      () => {
        this.validateField(id, newDate.toISOString());
      }
    );

    if (id === "start_date") {
      this.setState(
        {
          end_date: this.getEndDate(newDate)
        },
        () => {
          this.validateField("end_date", this.getEndDate(newDate));
        }
      );
    }
  }

  handleSelectChange(value, id) {
    this.setState({
      [id]: value
    });
  }

  handleInputChange(event) {
    let id = event.target.id;
    let value = event.target.value.replace(/\s+/g, " ");
    let setStateValue = [];
    let index = 0;
    let checkId = id;

    if (id.endsWith("license_plate")) {
      value = value.toUpperCase();
    }

    const split_id = id.split(".");

    switch (split_id.length) {
      case 1:
        setStateValue[split_id[0]] = value;
        break;
      case 2:
        setStateValue[split_id[0]] = update(this.state[split_id[0]], {
          [split_id[1]]: { $set: value }
        });
        break;
      case 3:
        setStateValue[split_id[0]] = update(this.state[split_id[0]], {
          [split_id[1]]: { [split_id[2]]: { $set: value } }
        });
        index = split_id[1];
        checkId = split_id[2];
        break;
      case 4:
        setStateValue[split_id[0]] = update(this.state[split_id[0]], {
          [split_id[1]]: { [split_id[2]]: { [split_id[3]]: { $set: value } } }
        });
        index = split_id[1];
        checkId = [split_id[2]] + "." + split_id[3];
        break;
      default:
        break;
    }

    this.setState(setStateValue, () => {
      this.validateField(checkId, value.trim(), index);

      if (
        (id === "visitors.0.surname" || id === "visitors.0.name") &&
        this.state.visitors[0].user_id
      ) {
        this.setState(
          {
            visitors: update(this.state.visitors, {
              [0]: { ["user_id"]: { $set: "" } }
            })
          },
          () => {
            const emptyDocument = {
              doc_type: ""
            };
            this.DocInitState(emptyDocument, 0);
          }
        );
      }

      if (
        (id.endsWith("driver.surname") || id.endsWith("driver.name")) &&
        this.state.vehicles[index].driver.user_id
      ) {
        this.setState({
          vehicles: update(this.state.vehicles, {
            [index]: { ["driver"]: { ["user_id"]: { $set: "" } } }
          })
        });
      }
    });
  }

  handleDocumentAdd(documentType, index, documentId) {
    const value = documentType;

    let doc;

    if (
      documentType !== "custom_document" &&
      this.props.user.user.result &&
      this.state.visitors[index].user_id &&
      this.state.visitors[index].user_id ===
        this.props.user.user.result.user_id &&
      this.props.documents.userDoc.result &&
      this.props.documents.userDoc.result.find(doc => doc.doc_type === value)
    ) {
      doc = this.props.documents.userDoc.result.find(
        doc => doc.doc_type === value
      );
    } else if (documentType === "custom_document" && documentId) {
      doc = this.props.documents.userDoc.result.find(
        doc => doc.doc_id === documentId
      );
    } else {
      doc = {
        doc_type: value
      };
    }

    this.DocInitState(doc, index);
  }

  handleDriverAdd(visitorIndex, transportIndex) {
    let driver = {};
    if (visitorIndex !== null) {
      driver = {
        user_id: this.state.visitors[visitorIndex].user_id,
        name: this.state.visitors[visitorIndex].name,
        surname: this.state.visitors[visitorIndex].surname,
        email: this.state.visitors[visitorIndex].email,
        phone_number: this.state.visitors[visitorIndex].phone_number
      };
    } else {
      driver = {
        user_id: "",
        name: "",
        surname: "",
        email: "",
        phone_number: ""
      };
    }

    this.setState({
      vehicles: update(this.state.vehicles, {
        [transportIndex]: {
          ["driver"]: { $set: driver }
        }
      })
    });
  }

  handleTransportAdd(transportId) {
    const emptyTransport = {
      transport_id: "",
      brand: "",
      model: "",
      color: "",
      category: "",
      license_plate: ""
    };

    let formErrors = Object.assign({}, this.state.formErrors);
    formErrors.licensePlate.push("init");

    this.setState(
      {
        vehicles: update(this.state.vehicles, { $push: [emptyTransport] }),
        formErrors: formErrors
      },
      function() {
        const value = transportId;
        const index = this.state.vehicles.length - 1;
        let transport;

        if (
          this.props.transport.userTransport.result &&
          this.props.transport.userTransport.result.find(
            transport => transport.transport_id === value
          )
        ) {
          transport = this.props.transport.userTransport.result.find(
            transport => transport.transport_id === value
          );
        } else {
          transport = {
            transport_id: value,
            brand: "",
            model: "",
            color: "",
            category: "",
            license_plate: ""
          };
        }

        this.TransportInitState(transport, index);
      }
    );
  }

  handleTypeAheadChange = id => value => {
    let setStateValue = [];

    const split_id = id.split(".");

    setStateValue[split_id[0]] = update(this.state[split_id[0]], {
      [split_id[1]]: { [split_id[2]]: { $set: value } }
    });

    this.setState(setStateValue);
  };

  handleAsyncTypeAheadChange(event) {
    let value = "";
    let addressee_id = "";
    if (event[0] && event[0].name) {
      value = event[0].name;
    }

    if (event[0] && event[0].addressee_id) {
      addressee_id = event[0].addressee_id;
      this.getRooms(null, addressee_id);
      this.getAddresseeEmployees(null, addressee_id);
      this.getAddresseeAccompanyEmployees(null, addressee_id);
    } else {
      this.clearRooms();
      this.clearInviters();
      this.clearAccompany();
      this.setState({
        room: {
          room_id: "",
          name: ""
        },

        inviter: {
          user_id: "",
          name: "",
          surname: "",
          patronymic: ""
        },

        accompany: {
          user_id: "",
          name: "",
          surname: "",
          patronymic: ""
        }
      });
      $(".md-form.room")
        .find("label")
        .removeClass("active");
      $(".md-form.inviter")
        .find("label")
        .removeClass("active");
    }

    const addresseeData = {
      addressee_id: addressee_id,
      name: value
    };

    this.setState({ addressee: addresseeData }, () => {
      this.validateField("addressee", value);
    });
  }

  handleSearch(keywords) {
    this.getAddressees(keywords);
  }

  handleInputContact(value, id) {
    let index = 0;
    let checkId = id;

    if (id.split(".").length === 3) {
      index = id.split(".")[1];
      checkId = id.split(".")[2];
    }

    this.validateField(checkId, value.trim(), index);
  }

  handleBlurContact(value, id) {
    let setStateValue = {};

    const split_id = id.split(".");

    switch (split_id.length) {
      case 1:
        setStateValue[split_id[0]] = value;
        break;
      case 3:
        if (this.state[split_id[0]][split_id[1]][split_id[2]] !== value) {
          setStateValue[split_id[0]] = update(this.state[split_id[0]], {
            [split_id[1]]: { [split_id[2]]: { $set: value } }
          });
        }
        break;
      default:
        break;
    }

    if (JSON.stringify(setStateValue) !== "{}") {
      this.setState(setStateValue);
    }

    if (id === "visitors.0.surname" || id === "visitors.0.name") {
      this.resetVisitorId();
    }
  }

  handleContactSearch(value, id) {
    let checkId = id;

    if (id.split(".").length === 3) {
      checkId = id.split(".")[2];
    }

    if (checkId === "invite_email") {
      checkId = "email";
    }

    this.getContacts(value, checkId, id);
  }

  getContacts(value, field, id) {
    const { dispatch } = this.props;

    const data = {
      filter: {
        [field]: value
      },
      order: "+name",
      limit: 100,
      offset: 0
    };
    dispatch(fetchContacts(data, id));
  }

  getAllContacts() {
    const { dispatch } = this.props;

    const data = {
      order: "+name",
      limit: 100,
      offset: 0
    };
    dispatch(fetchAllContacts(data));
  }

  resetVisitorId() {
    if (this.state.visitors[0].user_id) {
      this.setState(
        {
          visitors: update(this.state.visitors, {
            [0]: { ["user_id"]: { $set: "" } }
          })
        },
        () => {
          const emptyDocument = {
            doc_type: ""
          };
          this.DocInitState(emptyDocument, 0);
        }
      );
    }
  }

  handleContactTypeAheadChange(event, id) {
    let field_type = id.split(".").pop();
    let setStateValue = {};

    if (field_type === "invite_email") {
      if (!event[0]) {
        this.setState({
          invite_email: ""
        });
      }

      if (event[0] && event[0].email) {
        this.setState({
          invite_email: event[0].email
        });
      }
    }

    if (
      field_type === "surname" ||
      field_type === "name" ||
      field_type === "patronymic" ||
      field_type === "email" ||
      field_type === "company" ||
      field_type === "job_title" ||
      field_type === "phone_number"
    ) {
      let index = id.split(".")[1];

      if (!event[0]) {
        setStateValue["visitors"] = update(this.state.visitors, {
          [index]: {
            [field_type]: {
              $set: ""
            }
          }
        });
      }

      if (
        event[0] &&
        (this.state.visitors[index].surname !== event[0].surname ||
          this.state.visitors[index].name !== event[0].name ||
          this.state.visitors[index].patronymic !== event[0].patronymic ||
          this.state.visitors[index].email !== event[0].email ||
          this.state.visitors[index].phone_number !== event[0].phone_number ||
          this.state.visitors[index].job_title !== event[0].job_title ||
          this.state.visitors[index].company !== event[0].company)
      ) {
        setStateValue["visitors"] = update(this.state.visitors, {
          [index]: {
            surname: {
              $set: event[0].surname
                ? event[0].surname
                : this.state.visitors[index].surname
            },
            name: {
              $set: event[0].name
                ? event[0].name
                : this.state.visitors[index].name
            },
            patronymic: {
              $set: event[0].patronymic
                ? event[0].patronymic
                : this.state.visitors[index].patronymic
            },
            email: {
              $set: event[0].email
                ? event[0].email
                : this.state.visitors[index].email
            },
            phone_number: {
              $set: event[0].phone_number
                ? event[0].phone_number
                : this.state.visitors[index].phone_number
            },
            company: {
              $set: event[0].company
                ? event[0].company
                : this.state.visitors[index].company
            },
            job_title: {
              $set: event[0].job_title
                ? event[0].job_title
                : this.state.visitors[index].job_title
            }
          }
        });
      }

      if (JSON.stringify(setStateValue) !== "{}") {
        this.setState(setStateValue, () => {
          if (
            (event[0] && (event[0].surname || event[0].name)) ||
            id === "visitors.0.surname" ||
            id === "visitors.0.name"
          )
            this.resetVisitorId();
        });
      }
    }
  }

  handleRoomTypeAheadChange(event) {
    let room = "";
    let room_id = "";
    if (event[0] && event[0].name) {
      room = event[0].name;
    }

    if (event[0] && event[0].room_id) {
      room_id = event[0].room_id;
    }

    const roomData = {
      room_id: room_id,
      name: room
    };
    this.setState({
      room: roomData
    });
  }

  handleInviterTypeAheadChange(event) {
    let surname = "";
    let name = "";
    let patronymic = "";
    let user_id = "";
    let company = "";
    let job_title = "";
    if (event[0] && event[0].surname) {
      surname = event[0].surname;
    }
    if (event[0] && event[0].name) {
      name = event[0].name;
    }
    if (event[0] && event[0].patronymic) {
      patronymic = event[0].patronymic;
    }

    if (event[0] && event[0].user_id) {
      user_id = event[0].user_id;
    }

    if (event[0] && event[0].company) {
      company = event[0].company;
    }

    if (event[0] && event[0].job_title) {
      job_title = event[0].job_title;
    }

    const inviterData = {
      name: name,
      surname: surname,
      patronymic: patronymic,
      user_id: user_id,
      company: company,
      job_title: job_title
    };
    this.setState({
      inviter: inviterData
    });
  }

  handleAccompanyTypeAheadChange(event) {
    let surname = "";
    let name = "";
    let patronymic = "";
    let user_id = "";
    let company = "";
    let job_title = "";
    if (event[0] && event[0].surname) {
      surname = event[0].surname;
    }
    if (event[0] && event[0].name) {
      name = event[0].name;
    }
    if (event[0] && event[0].patronymic) {
      patronymic = event[0].patronymic;
    }

    if (event[0] && event[0].user_id) {
      user_id = event[0].user_id;
    }

    if (event[0] && event[0].company) {
      company = event[0].company;
    }

    if (event[0] && event[0].job_title) {
      job_title = event[0].job_title;
    }

    const accompanyData = {
      name: name,
      surname: surname,
      patronymic: patronymic,
      user_id: user_id,
      company: company,
      job_title: job_title
    };
    this.setState({
      accompany: accompanyData
    });
  }

  handleRoomSearch(keywords) {
    if (this.state.addressee.addressee_id) {
      this.getRooms(keywords, this.state.addressee.addressee_id);
    } else {
      this.validateAddressee(this.state.addressee.addressee);
    }
  }

  handleInviterSearch(keywords) {
    if (this.state.addressee.addressee_id) {
      this.getAddresseeEmployees(keywords, this.state.addressee.addressee_id);
    } else {
      this.validateAddressee(this.state.addressee.addressee_id);
    }
  }

  handleAccompanySearch(keywords) {
    if (this.state.addressee.addressee_id) {
      this.getAddresseeAccompanyEmployees(
        keywords,
        this.state.addressee.addressee_id
      );
    } else {
      this.validateAddressee(this.state.addressee.addressee_id);
    }
  }

  /****************************/

  prepareDataToSave() {
    const data = {
      request_id: this.state.request_id,
      start_date: this.state.start_date,
      end_date: this.state.end_date,
      visit_reason: this.state.visit_reason,
      visitors: this.state.visitors,
      addressee: this.state.addressee,
      room: this.state.room,
      inviter: this.state.inviter,
      object: this.state.object,
      vehicles: this.state.vehicles,
      request_type: this.state.request_type
    };

    return data;
  }

  prepareLogbookDataToSave() {
    const data = {
      object: this.state.object,
      visitor: {
        user_id: this.state.visitors[0].user_id,
        name: this.state.visitors[0].name,
        surname: this.state.visitors[0].surname,
        patronymic: this.state.visitors[0].patronymic,
        company: this.state.visitors[0].company,
        job_title: this.state.visitors[0].job_title
      },
      visit_reason: this.state.visit_reason,
      visit_date: new Date().toISOString(),
      addressee: this.state.addressee,
      room: this.state.room,
      inviter: this.state.inviter,
      pass_in: {
        date: new Date().toISOString(),
        punched_by: {
          user_id: this.props.user.user.result.user_id,
          name: this.props.user.user.result.name,
          surname: this.props.user.user.result.surname,
          patronymic: this.props.user.user.result.patronymic
        }
      },
      document: this.state.visitors[0].document
    };

    if (this.state.visitors[0].document.doc_type) {
      data.document = this.state.visitors[0].document;
    }

    return data;
  }

  prepareTransportLogbookDataToSave() {
    const data = {
      object: this.state.object,
      transport: this.state.vehicles[0],
      visit_reason: this.state.visit_reason,
      visit_date: new Date().toISOString(),
      addressee: this.state.addressee,
      room: this.state.room,
      inviter: this.state.inviter,
      pass_in: {
        date: new Date().toISOString(),
        punched_by: {
          user_id: this.props.user.user.result.user_id,
          name: this.props.user.user.result.name,
          surname: this.props.user.user.result.surname,
          patronymic: this.props.user.user.result.patronymic
        }
      },
      document: this.state.visitors[0].document
    };

    if (this.state.visitors[0].document.doc_type) {
      data.document = this.state.visitors[0].document;
    }

    return data;
  }

  addRequest(event) {
    event.preventDefault();
    const { dispatch } = this.props;

    const formValid = this.validateBeforeAddRequest();
    const completeness = this.validateCompletenessOfRequest();

    if (formValid && completeness) {
      const data = this.prepareDataToSave();
      // data.end_date = this.getEndDate();

      dispatch(saveRequestData(data));
      dispatch(toRequestConfirm());
    } else {
      if (!formValid) {
        let error = {
          code: -31001
        };
        ErrorToast(error);
      }

      if (!completeness) {
        let error = {
          code: -31002
        };
        ErrorToast(error);
      }
    }
  }

  addLogbookRecord(signature) {
    const { dispatch } = this.props;

    const formValid = this.validateBeforeAddLogbookRecord();
    if (formValid) {
      (async () => {
        try {
          const data = this.prepareLogbookDataToSave();
          await dispatch(fetchAddLogBookRecord(data));

          if (this.props.logbook.logbookOperationStatus.error) {
            ErrorToast(this.props.logbook.logbookOperationStatus.error);
          }

          if (this.props.logbook.logbookOperationStatus.result) {
            if (signature) {
              this.saveSignature(
                this.props.logbook.logbookOperationStatus.result,
                "logbook",
                signature
              );
            } else {
              this.toHistoryPath();
            }
          }
        } catch (e) {
          ErrorToast();
          console.log(e);
        } finally {
        }
      })();
    } else {
      const error = {
        code: -31001
      };
      ErrorToast(error);
    }
  }

  async saveSignature(recordId, entity_type, signature) {
    const { dispatch } = this.props;

    let res = await fetch(signature);
    let blob = await res.blob();
    let fd = new FormData();
    fd.append("file", blob, "file.png");
    fd.append("entity_type", entity_type);
    fd.append("entity_id", recordId);
    fd.append("suffix", "in");

    await dispatch(fetchSetImage(fd)).then(res => {
      if (res.payload && res.payload.error) {
        ErrorToast(res.payload.error);
      }

      if (res.payload && res.payload.result) {
        this.toHistoryPath();
      }
    });
  }

  addTransportLogbookRecord(signature) {
    const { dispatch } = this.props;

    const formValid = this.validateBeforeAddTransportLogbookRecord();
    if (formValid) {
      (async () => {
        try {
          const data = this.prepareTransportLogbookDataToSave();
          await dispatch(fetchAddTransportLogBookRecord(data));

          if (
            this.props.transportLogbook.transportLogbookOperationStatus.error
          ) {
            ErrorToast(
              this.props.transportLogbook.transportLogbookOperationStatus.error
            );
          }

          if (
            this.props.transportLogbook.transportLogbookOperationStatus.result
          ) {
            if (signature) {
              this.saveSignature(
                this.props.transportLogbook.transportLogbookOperationStatus
                  .result,
                "transport_logbook",
                signature
              );
            } else {
              this.toHistoryPath();
            }
          }
        } catch (e) {
          ErrorToast();
          console.log(e);
        } finally {
        }
      })();
    } else {
      const error = {
        code: -31001
      };
      ErrorToast(error);
    }
  }

  toHistoryPath() {
    const { dispatch } = this.props;
    const fromHistory = this.props.router.history.pop();
    const historyPath = fromHistory
      ? fromHistory
      : this.props.router.customHistoryPath;
    dispatch(toCustomPath(historyPath));
  }

  addInvite() {
    const { dispatch } = this.props;
    const formValid = this.validateBeforeAddInvite();

    if (formValid) {
      const data = {
        invite_type: "visit",
        to_identifier: this.state.invite_email,
        to_identifier_type: "email",
        entity_type: "addressee",
        entity_id: this.state.addressee.addressee_id,
        object_id: this.props.objects.currentObject.result.object_id,

        request_details: {
          start_date: this.state.start_date,
          end_date: this.state.end_date,
          visit_reason: this.state.visit_reason,
          object: this.state.object,
          addressee: this.state.addressee,
          room: this.state.room,
          inviter: this.state.inviter
        }
      };

      (async () => {
        try {
          await dispatch(fetchAddInvite(data));
          if (this.props.invites.inviteOperationStatus.result) {
            this.toHistoryPath();
          }

          if (this.props.invites.inviteOperationStatus.error) {
            ErrorToast(this.props.invites.inviteOperationStatus.error);
          }
        } catch (e) {
          console.log(e);
          ErrorToast();
        } finally {
        }
      })();
    }
  }

  editRequest(action) {
    const { dispatch } = this.props;
    const formValid = this.validateBeforeEditRequest();
    if (formValid) {
      (async () => {
        try {
          const data = this.prepareDataToSave();
          data.end_date = this.state.end_date;
          if (this.isEditRequestPage()) {
            data.accompany = this.state.accompany;
          }

          await dispatch(fetchSetRequest(data));

          if (this.props.requests.requestOperationStatus.error) {
            ErrorToast(this.props.requests.requestOperationStatus.error);
          }

          if (this.props.requests.requestOperationStatus.result) {
            if (this.isUserEditRequestPage()) {
              this.toHistoryPath();
            } else {
              switch (action) {
                case "save":
                  this.toHistoryPath();
                  break;

                case "save_and_approve":
                  let visitorsIndexes = [];
                  for (let i = 0; i < this.state.visitors.length; i++) {
                    visitorsIndexes.push(i);
                  }

                  let transportsIndexes = [];
                  for (let i = 0; i < this.state.vehicles.length; i++) {
                    transportsIndexes.push(i);
                  }

                  const approveData = {
                    request_id: this.props.params.request_id,
                    outcome: "approve",
                    visitor_indices: visitorsIndexes,
                    transport_indices: transportsIndexes
                  };

                  await dispatch(fetchApproveRequest(approveData));
                  if (this.props.requests.requestOperationStatus.result) {
                    this.toHistoryPath();
                  }

                  if (this.props.requests.requestOperationStatus.error) {
                    ErrorToast(
                      this.props.requests.requestOperationStatus.error
                    );
                  }

                  break;
                case "save_and_send_for_review":
                  const reviewData = {
                    request_id: this.props.params.request_id
                  };
                  await dispatch(fetchSendForReview(reviewData));
                  if (this.props.requests.requestOperationStatus.result) {
                    this.toHistoryPath();
                  }
                  if (this.props.requests.requestOperationStatus.error) {
                    ErrorToast(
                      this.props.requests.requestOperationStatus.error
                    );
                  }
                  break;

                default:
                  break;
              }
            }
          }
        } catch (e) {
          ErrorToast();
          console.log(e);
        } finally {
        }
      })();
    } else {
      const error = {
        code: -31001
      };
      ErrorToast(error);
    }
  }

  toRoot() {
    const { dispatch } = this.props;
    dispatch(toRoot());
  }

  toPrevPage() {
    const { dispatch } = this.props;
    if (this.isEditRequestPage() || this.isUserEditRequestPage()) {
      dispatch(toRequests());
    } else {
      dispatch(toRoot());
    }
  }

  render() {
    if (this.isEditRequestPage() || this.isUserEditRequestPage()) {
      return this.renderRequestEdit();
    } else if (this.isLogbookRecordAddPage()) {
      return this.renderLogbookRecordAdd();
    } else if (this.isTransportLogbookRecordAddPage()) {
      return this.renderTransportLogbookRecordAdd();
    } else if (this.isAddInvitePage()) {
      return this.renderAddInvite();
    } else {
      return this.renderRequestAdd();
    }
  }

  renderRequestAdd() {
    const { userTransport } = this.props.transport;
    const { addressees, addresseeEmployees } = this.props.addressee;
    const { rooms } = this.props.rooms;
    const { requestRecordByIdIsFetching } = this.props.requests;
    const { objectByIdIsFetching } = this.props.objects;
    const { objectPlanIsFetching } = this.props.plans;
    const { contacts, allContacts } = this.props.contacts;

    if (
      requestRecordByIdIsFetching ||
      objectByIdIsFetching ||
      objectPlanIsFetching
    ) {
      return (
        <RequestAddPreloader
          cancelPath={"/requests/" + this.state.request_id}
        />
      );
    } else {
      return (
        <RequestAdd
          {...this.state}
          contacts={contacts}
          allContacts={allContacts}
          params={this.props.params}
          userTransport={userTransport}
          currentUser={this.props.user.user.result}
          addressees={addressees}
          rooms={rooms}
          inviters={addresseeEmployees}
          errorClass={this.errorClass.bind(this)}
          addUser={this.addUser.bind(this)}
          deleteTransport={this.deleteTransport.bind(this)}
          deleteUser={this.deleteUser.bind(this)}
          deleteDocument={this.deleteDocument.bind(this)}
          deleteDriver={this.deleteDriver.bind(this)}
          handleInputChange={this.handleInputChange.bind(this)}
          handleTypeAheadChange={this.handleTypeAheadChange.bind(this)}
          handleSearch={this.handleSearch.bind(this)}
          handleInputTypeAheadChange={this.handleAsyncTypeAheadChange.bind(
            this
          )}
          handleSelectChange={this.handleSelectChange.bind(this)}
          handleContactTypeAheadChange={this.handleContactTypeAheadChange.bind(
            this
          )}
          handleContactSearch={this.handleContactSearch.bind(this)}
          handleInputContact={this.handleInputContact.bind(this)}
          handleBlurContact={this.handleBlurContact.bind(this)}
          handleRoomSearch={this.handleRoomSearch.bind(this)}
          handleRoomTypeAheadChange={this.handleRoomTypeAheadChange.bind(this)}
          handleInviterSearch={this.handleInviterSearch.bind(this)}
          handleInviterTypeAheadChange={this.handleInviterTypeAheadChange.bind(
            this
          )}
          handleDocumentAdd={this.handleDocumentAdd.bind(this)}
          handleDriverAdd={this.handleDriverAdd.bind(this)}
          handleTransportAdd={this.handleTransportAdd.bind(this)}
          setTimeInput={this.setTimeInput.bind(this)}
          setDateInput={this.setDateInput.bind(this)}
          Submit={this.addRequest.bind(this)}
          toRoot={this.toRoot.bind(this)}
        />
      );
    }
  }

  renderRequestEdit() {
    const { userTransport } = this.props.transport;
    const {
      addressees,
      addresseeEmployees,
      addresseeAccompanyEmployees
    } = this.props.addressee;
    const { rooms } = this.props.rooms;
    const { requestRecordByIdIsFetching } = this.props.requests;

    if (requestRecordByIdIsFetching) {
      return (
        <RequestEditPreloader
          cancelPath={"/requests/" + this.state.request_id}
        />
      );
    } else {
      return (
        <RequestEdit
          {...this.state}
          userTransport={userTransport}
          addressees={addressees}
          rooms={rooms}
          inviters={addresseeEmployees}
          accompanies={addresseeAccompanyEmployees}
          errorClass={this.errorClass.bind(this)}
          handleInputChange={this.handleInputChange.bind(this)}
          handleSelectChange={this.handleSelectChange.bind(this)}
          handleTypeAheadChange={this.handleTypeAheadChange.bind(this)}
          handleSearch={this.handleSearch.bind(this)}
          handleInputTypeAheadChange={this.handleAsyncTypeAheadChange.bind(
            this
          )}
          addUser={this.addUser.bind(this)}
          deleteTransport={this.deleteTransport.bind(this)}
          deleteUser={this.deleteUser.bind(this)}
          deleteDocument={this.deleteDocument.bind(this)}
          deleteDriver={this.deleteDriver.bind(this)}
          handleRoomSearch={this.handleRoomSearch.bind(this)}
          handleRoomTypeAheadChange={this.handleRoomTypeAheadChange.bind(this)}
          handleInviterSearch={this.handleInviterSearch.bind(this)}
          handleInviterTypeAheadChange={this.handleInviterTypeAheadChange.bind(
            this
          )}
          handleAccompanySearch={this.handleAccompanySearch.bind(this)}
          handleAccompanyTypeAheadChange={this.handleAccompanyTypeAheadChange.bind(
            this
          )}
          handleDocumentAdd={this.handleDocumentAdd.bind(this)}
          handleTransportAdd={this.handleTransportAdd.bind(this)}
          handleDriverAdd={this.handleDriverAdd.bind(this)}
          setTimeInput={this.setTimeInput.bind(this)}
          setDateInput={this.setDateInput.bind(this)}
          Submit={this.editRequest.bind(this)}
          CancelClick={this.toHistoryPath.bind(this)}
          cancelPath={"/requests/" + this.state.request_id}
          status={
            this.props.requests.requestRecordById.result
              ? this.props.requests.requestRecordById.result.status
              : null
          }
        />
      );
    }
  }

  renderAddInvite() {
    const { addressees, addresseeEmployees } = this.props.addressee;
    const { contacts } = this.props.contacts;
    const { rooms } = this.props.rooms;

    return (
      <AddInvite
        {...this.state}
        addressees={addressees}
        contacts={contacts}
        rooms={rooms}
        inviters={addresseeEmployees}
        errorClass={this.errorClass.bind(this)}
        handleInputChange={this.handleInputChange.bind(this)}
        handleSearch={this.handleSearch.bind(this)}
        handleContactSearch={this.handleContactSearch.bind(this)}
        handleInputTypeAheadChange={this.handleAsyncTypeAheadChange.bind(this)}
        handleContactTypeAheadChange={this.handleContactTypeAheadChange.bind(
          this
        )}
        handleInputContact={this.handleInputContact.bind(this)}
        handleBlurContact={this.handleBlurContact.bind(this)}
        handleRoomSearch={this.handleRoomSearch.bind(this)}
        handleRoomTypeAheadChange={this.handleRoomTypeAheadChange.bind(this)}
        handleInviterSearch={this.handleInviterSearch.bind(this)}
        handleInviterTypeAheadChange={this.handleInviterTypeAheadChange.bind(
          this
        )}
        setTimeInput={this.setTimeInput.bind(this)}
        setDateInput={this.setDateInput.bind(this)}
        Submit={this.addInvite.bind(this)}
        CancelClick={this.toHistoryPath.bind(this)}
        cancelPath={"/invites"}
        location={this.props.location}
      />
    );
  }

  renderLogbookRecordAdd() {
    const { userTransport } = this.props.transport;
    const { addressees, addresseeEmployees } = this.props.addressee;
    const { rooms } = this.props.rooms;
    const { requestRecordByIdIsFetching } = this.props.requests;

    if (requestRecordByIdIsFetching) {
      return <LogbookRecordAddPreloader cancelPath={"/logbooks/"} />;
    } else {
      return (
        <LogbookRecordAdd
          {...this.state}
          userTransport={userTransport}
          addressees={addressees}
          rooms={rooms}
          inviters={addresseeEmployees}
          errorClass={this.errorClass.bind(this)}
          deleteDocument={this.deleteDocument.bind(this)}
          handleInputChange={this.handleInputChange.bind(this)}
          handleTypeAheadChange={this.handleTypeAheadChange.bind(this)}
          handleSearch={this.handleSearch.bind(this)}
          handleInputTypeAheadChange={this.handleAsyncTypeAheadChange.bind(
            this
          )}
          handleRoomSearch={this.handleRoomSearch.bind(this)}
          handleRoomTypeAheadChange={this.handleRoomTypeAheadChange.bind(this)}
          handleInviterSearch={this.handleInviterSearch.bind(this)}
          handleInviterTypeAheadChange={this.handleInviterTypeAheadChange.bind(
            this
          )}
          handleDocumentAdd={this.handleDocumentAdd.bind(this)}
          handleTransportAdd={this.handleTransportAdd.bind(this)}
          setTimeInput={this.setTimeInput.bind(this)}
          setDateInput={this.setDateInput.bind(this)}
          Submit={this.addLogbookRecord.bind(this)}
          CancelClick={this.toHistoryPath.bind(this)}
          cancelPath={"/logbooks/visitors/"}
        />
      );
    }
  }

  renderTransportLogbookRecordAdd() {
    const { addressees, addresseeEmployees } = this.props.addressee;
    const { rooms } = this.props.rooms;

    return (
      <TransportLogbookRecordAdd
        {...this.state}
        addressees={addressees}
        rooms={rooms}
        inviters={addresseeEmployees}
        errorClass={this.errorClass.bind(this)}
        handleInputChange={this.handleInputChange.bind(this)}
        handleTypeAheadChange={this.handleTypeAheadChange.bind(this)}
        handleSearch={this.handleSearch.bind(this)}
        handleInputTypeAheadChange={this.handleAsyncTypeAheadChange.bind(this)}
        handleRoomSearch={this.handleRoomSearch.bind(this)}
        handleRoomTypeAheadChange={this.handleRoomTypeAheadChange.bind(this)}
        handleInviterSearch={this.handleInviterSearch.bind(this)}
        handleInviterTypeAheadChange={this.handleInviterTypeAheadChange.bind(
          this
        )}
        setTimeInput={this.setTimeInput.bind(this)}
        setDateInput={this.setDateInput.bind(this)}
        Submit={this.addTransportLogbookRecord.bind(this)}
        CancelClick={this.toHistoryPath.bind(this)}
        cancelPath={"/logbooks/transports/"}
      />
    );
  }

  componentWillUnmount() {
    const { dispatch } = this.props;
    dispatch(clearRooms());
    dispatch(clearAddresseeEmployees());
    dispatch(clearAddressees());
  }

  validateField(fieldId, value, index) {
    switch (fieldId) {
      case "addressee":
        this.validateAddressee(value);
        break;

      case "name":
        this.validateName(value, index);
        break;

      case "email":
        this.validateEmail(value, index);
        break;

      case "invite_email":
        this.validateInviteEmail(value, index);
        break;

      case "driver.name":
        this.validateDriverName(value, index);
        break;

      case "surname":
        this.validateSurname(value, index);
        break;

      case "driver.surname":
        this.validateDriverSurname(value, index);
        break;

      case "driver.email":
        this.validateDriverEmail(value, index);
        break;

      case "start_date":
        this.validateInputStartDate(value);
        this.validateEndDate(this.state.end_date);
        break;

      case "end_date":
        this.validateEndDate(value);
        break;

      case "document.issue_date":
        this.validateIssueDate(value, index);
        break;

      case "document.number":
        this.validateDocNumber(value, index);
        break;

      case "license_plate":
        this.validateLicensePlate(value, index);
        break;

      default:
        break;
    }
  }

  validateAddressee(value) {
    let fieldValidationErrors = this.state.formErrors;
    let addresseeValid;
    if (!value || value.length < 1) {
      addresseeValid = false;
      fieldValidationErrors.addressee = strings.hint_choose_addressee;
    } else {
      addresseeValid = true;
      fieldValidationErrors.addressee = "";
    }

    this.setState({
      formErrors: fieldValidationErrors
    });

    return addresseeValid;
  }

  validateName(value, index) {
    let fieldValidationErrors = Object.assign({}, this.state.formErrors);

    let nameValid = true;
    fieldValidationErrors.name[index] = "";

    if (value.length < 1) {
      nameValid = false;
      fieldValidationErrors.name[index] = strings.hint_name_too_short;
    }

    if (value.length > 50) {
      nameValid = false;
      fieldValidationErrors.name[index] = strings.hint_name_too_long;
    }
    this.setState({
      formErrors: fieldValidationErrors
    });

    return nameValid;
  }

  validateInviteEmail(value) {
    let fieldValidationErrors = Object.assign({}, this.state.formErrors);

    let inviteEmailValid = true;
    fieldValidationErrors.invite_email = "";

    if (value.length === 0 || !isValidEmail(value)) {
      inviteEmailValid = false;
      fieldValidationErrors.invite_email = strings.hint_invalid_email;
    }

    this.setState({
      formErrors: fieldValidationErrors
    });

    return inviteEmailValid;
  }

  validateEmail(value, index) {
    if (value) {
      let fieldValidationErrors = Object.assign({}, this.state.formErrors);

      let emailValid = true;
      fieldValidationErrors.email[index] = "";

      if (!isValidEmail(value)) {
        emailValid = false;
        fieldValidationErrors.email[index] = strings.hint_invalid_email;
      }

      this.setState({
        formErrors: fieldValidationErrors
      });

      return emailValid;
    }
  }

  validateDriverEmail(value, index) {
    let fieldValidationErrors = Object.assign({}, this.state.formErrors);

    let driverEmailValid = true;
    fieldValidationErrors.driver_email[index] = "";

    if (!isValidEmail(value)) {
      driverEmailValid = false;
      fieldValidationErrors.driver_email[index] = strings.hint_invalid_email;
    }

    this.setState({
      formErrors: fieldValidationErrors
    });

    return driverEmailValid;
  }

  validateDriverName(value, index) {
    let fieldValidationErrors = Object.assign({}, this.state.formErrors);

    let driverNameValid = true;
    fieldValidationErrors.driver_name[index] = "";

    if (value.length < 1) {
      driverNameValid = false;
      fieldValidationErrors.driver_name[index] = strings.hint_name_too_short;
    }

    if (value.length > 50) {
      driverNameValid = false;
      fieldValidationErrors.driver_name[index] = strings.hint_name_too_long;
    }
    this.setState({
      formErrors: fieldValidationErrors
    });

    return driverNameValid;
  }

  validateDriverSurname(value, index) {
    let fieldValidationErrors = Object.assign({}, this.state.formErrors);

    let driverSurnameValid = true;
    fieldValidationErrors.driver_surname[index] = "";

    if (value.length < 1) {
      driverSurnameValid = false;
      fieldValidationErrors.driver_surname[index] =
        strings.hint_surname_too_short;
    }

    if (value.length > 50) {
      driverSurnameValid = false;
      fieldValidationErrors.driver_surname[index] =
        strings.hint_surname_too_long;
    }
    this.setState({
      formErrors: fieldValidationErrors
    });

    return driverSurnameValid;
  }

  validateDocNumber(value, index) {
    let fieldValidationErrors = Object.assign({}, this.state.formErrors);
    let docType = this.state.visitors[index].document.doc_type;
    let docNumberValid;

    let fieldLength;
    let match;
    for (let field of DOCUMENTS[docType]) {
      if (field.id === "number" && field.mask) {
        fieldLength = field.mask.length;
      }
      if (field.id === "number" && field.match) {
        match = field.match;
      }
    }

    if (fieldLength) {
      docNumberValid = value.length === fieldLength;
    }

    if (match) {
      docNumberValid = value.match(match);
    }

    fieldValidationErrors.docNumber[index] = docNumberValid
      ? ""
      : strings.hint_invalid_document_number;

    this.setState({
      formErrors: fieldValidationErrors
    });
    return docNumberValid;
  }

  validateLicensePlate(value, index) {
    let fieldValidationErrors = Object.assign({}, this.state.formErrors);
    let licensePlateValid;

    if (value.length > 3 && value.length < 11) {
      licensePlateValid = true;
      fieldValidationErrors.licensePlate[index] = "";
    }

    if (value.length <= 3) {
      licensePlateValid = false;
      fieldValidationErrors.licensePlate[index] =
        strings.hint_license_plate_too_short;
    }

    if (value.length >= 11) {
      licensePlateValid = false;
      fieldValidationErrors.licensePlate[index] =
        strings.hint_license_plate_too_long;
    }

    this.setState({
      formErrors: fieldValidationErrors
    });

    return licensePlateValid;
  }

  validateSurname(value, index) {
    let fieldValidationErrors = Object.assign({}, this.state.formErrors);
    let surnameValid = true;
    fieldValidationErrors.surname[index] = "";

    if (value.length < 1) {
      surnameValid = false;
      fieldValidationErrors.surname[index] = strings.hint_surname_too_short;
    }

    if (value.length > 50) {
      surnameValid = false;
      fieldValidationErrors.surname[index] = strings.hint_surname_too_long;
    }
    this.setState({
      formErrors: fieldValidationErrors
    });

    return surnameValid;
  }

  validateStartDate(value) {
    let fieldValidationErrors = this.state.formErrors;
    let start_dateValid;

    let diff = new Date() - new Date(value);

    if (diff / 60000 > 30) {
      start_dateValid = false;
      fieldValidationErrors.start_date = strings.hint_visit_date_in_past;
    } else {
      start_dateValid = true;
      fieldValidationErrors.start_date = "";
    }

    this.setState({
      formErrors: fieldValidationErrors
    });

    return start_dateValid;
  }

  validateInputStartDate(value) {
    let fieldValidationErrors = this.state.formErrors;
    let start_dateValid;

    let diff = new Date() - new Date(value);

    if (diff > 0) {
      start_dateValid = false;
      fieldValidationErrors.start_date = strings.hint_visit_date_in_past;
    } else {
      start_dateValid = true;
      fieldValidationErrors.start_date = "";
    }

    this.setState({
      formErrors: fieldValidationErrors
    });

    return start_dateValid;
  }

  validateEndDate(value) {
    let fieldValidationErrors = this.state.formErrors;
    let end_dateValid;
    let start_date = this.state.start_date;
    if (value) {
      let diff = new Date(value) - new Date(start_date);
      if (diff < 0) {
        end_dateValid = false;
        fieldValidationErrors.end_date =
          strings.hint_start_date_greater_than_end_date;
      } else {
        end_dateValid = true;
        fieldValidationErrors.end_date = "";
      }
    } else {
      end_dateValid = true;
      fieldValidationErrors.end_date = "";
    }

    this.setState({
      formErrors: fieldValidationErrors
    });

    return end_dateValid;
  }

  validateIssueDate(value, index) {
    let fieldValidationErrors = Object.assign({}, this.state.formErrors);
    fieldValidationErrors.issueDate[index] = "";

    let issueDateValid = value !== "invalidDate";
    if (!issueDateValid) {
      fieldValidationErrors.issueDate[index] = strings.hint_invalid_date;
    }

    this.setState({
      formErrors: fieldValidationErrors
    });

    return issueDateValid;
  }

  validateCompletenessOfRequest() {
    return this.state.visitors.length > 0 || this.state.vehicles.length > 0;
  }

  validateBeforeAddRequest() {
    let addresseeValid = this.validateAddressee(this.state.addressee.name);
    let startDateValid = this.validateStartDate(this.state.start_date);
    let endDateValid = this.validateEndDate(this.state.end_date);

    let nameValid = true;
    let surnameValid = true;
    let emailValid = true;
    let issueDateValid = true;
    let docNumberValid = true;
    let licensePlateValid = true;
    let driverNameValid = true;
    let driverSurnameValid = true;
    let driverEmailValid = true;

    for (let i = 0; i < this.state.visitors.length; i++) {
      nameValid = this.validateName(this.state.visitors[i].name, i)
        ? nameValid
        : false;

      surnameValid = this.validateSurname(this.state.visitors[i].surname, i)
        ? surnameValid
        : false;

      issueDateValid = this.validateIssueDate(
        this.state.visitors[i].document.issue_date,
        i
      )
        ? issueDateValid
        : false;

      this.state.visitors[i].email
        ? (emailValid = this.validateEmail(this.state.visitors[i].email, i)
            ? emailValid
            : false)
        : null;

      this.state.visitors[i].document.doc_type
        ? (docNumberValid = this.validateDocNumber(
            this.state.visitors[i].document.number,
            i
          )
            ? docNumberValid
            : false)
        : null;
    }

    for (let i = 0; i < this.state.vehicles.length; i++) {
      licensePlateValid = this.validateLicensePlate(
        this.state.vehicles[i].license_plate,
        i
      )
        ? licensePlateValid
        : false;

      if (this.state.vehicles[i].driver) {
        this.state.vehicles[i].driver.email
          ? (driverEmailValid = this.validateDriverEmail(
              this.state.vehicles[i].driver.email,
              i
            )
              ? driverEmailValid
              : false)
          : null;

        driverNameValid = this.validateDriverName(
          this.state.vehicles[i].driver.name,
          i
        )
          ? driverNameValid
          : false;

        driverSurnameValid = this.validateDriverSurname(
          this.state.vehicles[i].driver.surname,
          i
        )
          ? driverSurnameValid
          : false;
      }
    }

    return (
      addresseeValid &&
      nameValid &&
      surnameValid &&
      emailValid &&
      startDateValid &&
      endDateValid &&
      issueDateValid &&
      docNumberValid &&
      licensePlateValid &&
      driverNameValid &&
      driverEmailValid &&
      driverSurnameValid
    );
  }

  validateBeforeAddLogbookRecord() {
    let addresseeValid = this.validateAddressee(this.state.addressee.name);

    let nameValid = true;
    let surnameValid = true;
    let issueDateValid = true;
    let docNumberValid = true;

    for (let i = 0; i < this.state.visitors.length; i++) {
      nameValid = this.validateName(this.state.visitors[i].name, i)
        ? nameValid
        : false;

      surnameValid = this.validateSurname(this.state.visitors[i].surname, i)
        ? surnameValid
        : false;
      issueDateValid = this.validateIssueDate(
        this.state.visitors[i].document.issue_date,
        i
      )
        ? nameValid
        : false;

      this.state.visitors[i].document.doc_type
        ? (docNumberValid = this.validateDocNumber(
            this.state.visitors[i].document.number,
            i
          )
            ? docNumberValid
            : false)
        : null;
    }

    return (
      addresseeValid &&
      nameValid &&
      surnameValid &&
      issueDateValid &&
      docNumberValid
    );
  }

  validateBeforeAddTransportLogbookRecord() {
    let addresseeValid = this.validateAddressee(this.state.addressee.name);

    let licensePlateValid = true;

    for (let i = 0; i < this.state.vehicles.length; i++) {
      licensePlateValid = this.validateLicensePlate(
        this.state.vehicles[i].license_plate,
        i
      )
        ? licensePlateValid
        : false;
    }

    return addresseeValid && licensePlateValid;
  }

  validateBeforeEditRequest() {
    let addresseeValid = this.validateAddressee(this.state.addressee.name);
    let startDateValid = this.validateStartDate(this.state.start_date);
    let endDateValid = this.validateEndDate(this.state.end_date);
    let nameValid = true;
    let surnameValid = true;
    let emailValid = true;
    let issueDateValid = true;
    let docNumberValid = true;
    let licensePlateValid = true;
    let driverNameValid = true;
    let driverSurnameValid = true;
    let driverEmailValid = true;

    for (let i = 0; i < this.state.visitors.length; i++) {
      nameValid = this.validateName(this.state.visitors[i].name, i)
        ? nameValid
        : false;

      surnameValid = this.validateSurname(this.state.visitors[i].surname, i)
        ? surnameValid
        : false;

      issueDateValid = this.validateIssueDate(
        this.state.visitors[i].document.issue_date,
        i
      )
        ? issueDateValid
        : false;

      this.state.visitors[i].email
        ? (emailValid = this.validateEmail(this.state.visitors[i].email, i)
            ? emailValid
            : false)
        : null;

      this.state.visitors[i].document.doc_type
        ? (docNumberValid = this.validateDocNumber(
            this.state.visitors[i].document.number,
            i
          )
            ? docNumberValid
            : false)
        : null;
    }

    for (let i = 0; i < this.state.vehicles.length; i++) {
      licensePlateValid = this.validateLicensePlate(
        this.state.vehicles[i].license_plate,
        i
      )
        ? licensePlateValid
        : false;

      if (this.state.vehicles[i].driver) {
        this.state.vehicles[i].driver.email
          ? (driverEmailValid = this.validateDriverEmail(
              this.state.vehicles[i].driver.email,
              i
            )
              ? driverEmailValid
              : false)
          : null;

        driverNameValid = this.validateDriverName(
          this.state.vehicles[i].driver.name,
          i
        )
          ? driverNameValid
          : false;

        driverSurnameValid = this.validateDriverSurname(
          this.state.vehicles[i].driver.surname,
          i
        )
          ? driverSurnameValid
          : false;
      }
    }

    return (
      addresseeValid &&
      nameValid &&
      surnameValid &&
      emailValid &&
      startDateValid &&
      endDateValid &&
      issueDateValid &&
      docNumberValid &&
      licensePlateValid &&
      driverNameValid &&
      driverEmailValid &&
      driverSurnameValid
    );
  }

  validateBeforeAddInvite() {
    let addresseeValid = this.validateAddressee(this.state.addressee.name);
    let startDateValid = this.validateStartDate(this.state.start_date);
    let endDateValid = this.validateEndDate(this.state.end_date);
    let inviteEmailValid = this.validateInviteEmail(this.state.invite_email);

    return addresseeValid && startDateValid && endDateValid && inviteEmailValid;
  }

  errorClass(error) {
    if (error) {
      if (error.length === 0) {
        return "success";
      } else if (error === "init") {
        return "";
      } else {
        return "wrong";
      }
    }
  }
}

const mapStateToProps = state => {
  return {
    requests: state.requests,
    objects: state.objects,
    user: state.user,
    documents: state.documents,
    transport: state.transport,
    addressee: state.addressee,
    rooms: state.rooms,
    add_request: state.add_request,
    logbook: state.logbook,
    transportLogbook: state.transportLogbook,
    router: state.router,
    plans: state.plans,
    invites: state.invites,
    contacts: state.contacts,
    activity: state.activity,
  };
};

export default connect(mapStateToProps)(RequestOperationContainer);
