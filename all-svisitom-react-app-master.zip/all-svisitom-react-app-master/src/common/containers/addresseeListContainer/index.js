import React, { Component } from "react";
import { connect } from "react-redux";

import {
  fetchAddressees,
  fetchMoreAddressees,
  clearAddressees
} from "../../../common/actions/addressee";
import { fetchObjectById } from "../../../common/actions/objects";

import SearchInput from "../../../common/components/SearchInput";
import CircleLoader from "../../../common/components/CircleLoader";
import {
  MaterialList,
  CircleLoaderOrButtonShowMore,
} from "../../../common/components/MaterialList";
import MaterialListItem from "../../../common/components/MaterialListItem/twoLineItem";

import { ErrorToast } from "../../../common/Toasts/error";

import strings from "../../localization/all";
import common_strings from "../../../common/localization/all";

class AddresseeListContainer extends Component {
  constructor(props) {
    super(props);
    this.state = {
      keywords: "",
      limit: 20,
      offset: 0,
      order: "-create_date",
      anyDataReceived: false,
      hasAnyData: false
    };
  }

  componentDidMount() {
    window.scrollTo(0, 0);

    const { dispatch } = this.props;

    const { objectById } = this.props.objects;
    const object_id = this.props.object_id;

    (async () => {
      try {
        if (
          objectById &&
          objectById.result &&
          objectById.result.object_id === object_id
        ) {
          this.showResult();
        } else {
          const data = {
            object_id: object_id
          };
          await dispatch(fetchObjectById(data));

          if (this.props.objects.objectById.result) {
            this.showResult();
          }

          if (this.props.objects.objectById.error) {
            ErrorToast(this.props.objects.objectById.error);
          }
        }
      } catch (e) {
        ErrorToast();
        console.log(e);
      }
    })();
  }

  componentWillUnmount() {
    const { dispatch } = this.props;
    dispatch(clearAddressees());
  }

  handleInputChange(event) {
    const id = event.target.id;
    const value = event.target.value;
    this.setState({ [id]: value });
  }

  Search(value) {
    const { dispatch } = this.props;
    dispatch(clearAddressees());

    this.setState(
      {
        keywords: value,
        offset: 0
      },
      function() {
        this.showResult();
      }
    );
  }

  showResult() {
    const { dispatch } = this.props;
    (async () => {
      try {
        if (this.props.objects.objectById.result) {
          const data = {
            filter: {
              keywords: this.state.keywords,
              object_id: this.props.objects.objectById.result.object_id
            },
            limit: this.state.limit + 1,
            offset: this.state.offset,
            order: this.state.order
          };
          await dispatch(fetchAddressees(data));

          const { addressees } = this.props.addressee;
          if (addressees.error) {
            ErrorToast(addressees.error);
          }

          if (addressees.result) {
            if (this.state.keywords==='' && addressees.result.length>0) {
              this.setState({
                hasAnyData: true
              });
            }
          }

          this.setState({
            anyDataReceived: true
          });
        }
      } catch (e) {
        ErrorToast();
        console.log(e);
      } finally {
      }
    })();
  }

  emptyText() {
    const { addressees } = this.props.addressee;
    if (addressees.error) {
      return string.empty_text_data_load_failure;
    } else if (this.state.hasAnyData) {
      return strings.nothing_found;
    } else {
      return strings.no_addressees;
    }
  }

  toAddressee(addressee_id) {
    this.props.onClickAddressee(addressee_id);
  }

  showMore() {
    const { dispatch } = this.props;

    (async () => {
      try {
        const data = {
          filter: {
            keywords: this.state.keywords,
            object_id: this.props.objects.objectById.result.object_id
          },
          limit: this.state.limit,
          offset: this.state.offset + this.state.limit + 1,
          order: this.state.order
        };
        await dispatch(fetchMoreAddressees(data));
        this.emptyText();

        if (!this.props.addressee.addressees.error) {
          const offset = this.state.offset + this.state.limit;
          this.setState({
            offset: offset
          });
        }
      } catch (e) {
        ErrorToast();
        console.log(e);
      } finally {
      }
    })();
  }

  render() {
    const { objectById, objectByIdIsFetching } = this.props.objects;
    let addressees = [];
    let fetching = !this.state.anyDataReceived;
    let hasMore = false;

    if (this.props.addressee) {
      fetching |= this.props.addressee.addresseesIsFetching;
    }

    if (
      this.props.addressee &&
      this.props.addressee.addressees &&
      this.props.addressee.addressees.result
    ) {
      addressees = this.props.addressee.addressees.result;
      if (addressees.length > this.state.offset + this.state.limit) {
        addressees = addressees.slice(0, this.state.offset + this.state.limit);
        hasMore = true;
      }
    }

    if (objectByIdIsFetching) {
      return (
        <div>
          <CircleLoader />
        </div>
      );
    }
    if (objectById.result) {
      return (
        <div>
          {
            this.state.hasAnyData &&
            <SearchInput
              id={`keywords`}
              query={this.state.keywords}
              placeholder={common_strings.search_placeholder}
              onChange={this.handleInputChange.bind(this)}
              onSearch={this.Search.bind(this)}
            />
          }

          <MaterialList emptyText={fetching ? null : this.emptyText()}>
            {addressees.map((addressee, index) => (
              <MaterialListItem
                key={index}
                item_id={addressee.addressee_id}
                firstLineContent={addressee.name}
                secondLineContent={addressee.description}
                icon={`business`}
                gotoItem={this.toAddressee.bind(this)}
              />
            ))}
          </MaterialList>

          <CircleLoaderOrButtonShowMore
            fetching={fetching}
            hasMore={hasMore}
            onShowMoreClick={this.showMore.bind(this)}
          />


        </div>
      );
    } else {
      return null;
    }
  }
}

const mapStateToProps = state => {
  return {
    objects: state.objects,
    addressee: state.addressee
  };
};

export default connect(mapStateToProps)(AddresseeListContainer);
