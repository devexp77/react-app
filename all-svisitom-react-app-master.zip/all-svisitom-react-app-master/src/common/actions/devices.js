import {jsonRPCRequest} from "./asyncActions";
import {checkAuth} from "./user";
import { HOST_NAME, PROTOCOL } from '../constants';

export const REQUEST_DEVICES = 'REQUEST_DEVICES';
export const RECEIVE_DEVICES = 'RECEIVE_DEVICES';
export const REQUEST_MORE_DEVICES = 'REQUEST_MORE_DEVICES';
export const RECEIVE_MORE_DEVICES = 'RECEIVE_MORE_DEVICES';
export const CLEAR_DEVICES = 'CLEAR_DEVICES';

export const REQUEST_ADD_DEVICE = 'REQUEST_ADD_DEVICE';
export const RECEIVE_ADD_DEVICE = 'RECEIVE_ADD_DEVICE';

export const REQUEST_SET_DEVICE = 'REQUEST_SET_DEVICE';
export const RECEIVE_SET_DEVICE = 'RECEIVE_SET_DEVICE';

export const REQUEST_OPEN_ACCESS_POINT = 'REQUEST_OPEN_ACCESS_POINT';
export const RECEIVE_OPEN_ACCESS_POINT = 'RECEIVE_OPEN_ACCESS_POINT';

export const REQUEST_OPEN_ACCESS_POINT_BY_SHARED_LINK = 'REQUEST_OPEN_ACCESS_POINT_BY_SHARED_LINK';
export const RECEIVE_OPEN_ACCESS_POINT_BY_SHARED_LINK = 'RECEIVE_OPEN_ACCESS_POINT_BY_SHARED_LINK';

export const REQUEST_OPEN_ACCESS_POINT_AND_REGISTER_PASS = 'REQUEST_OPEN_ACCESS_POINT_AND_REGISTER_PASS';
export const RECEIVE_OPEN_ACCESS_POINT_AND_REGISTER_PASS = 'RECEIVE_OPEN_ACCESS_POINT_AND_REGISTER_PASS';

export const REQUEST_GET_ACCESS_POINT_USERS = 'REQUEST_GET_ACCESS_POINT_USERS';
export const RECEIVE_GET_ACCESS_POINT_USERS = 'RECEIVE_GET_ACCESS_POINT_USERS';
export const CLEAR_ACCESS_POINT_USERS = 'CLEAR_ACCESS_POINT_USERS';

export const REQUEST_SET_ACCESS_POINT_PERMISSIONS = 'REQUEST_SET_ACCESS_POINT_PERMISSIONS';
export const RECEIVE_SET_ACCESS_POINT_PERMISSIONS = 'RECEIVE_SET_ACCESS_POINT_PERMISSIONS';

export const REQUEST_DELETE_ACCESS_POINT_PERMISSIONS = 'REQUEST_DELETE_ACCESS_POINT_PERMISSIONS';
export const RECEIVE_DELETE_ACCESS_POINT_PERMISSIONS = 'RECEIVE_DELETE_ACCESS_POINT_PERMISSIONS';

export const REQUEST_DELETE_DEVICE = 'REQUEST_DELETE_DEVICE';
export const RECEIVE_DELETE_DEVICE = 'RECEIVE_DELETE_DEVICE';

export const REQUEST_DEVICE_BY_ID = 'REQUEST_DEVICE_BY_ID';
export const RECEIVE_DEVICE_BY_ID = 'RECEIVE_DEVICE_BY_ID';
export const CLEAR_DEVICE_BY_ID = 'CLEAR_DEVICE_BY_ID';

export const REQUEST_DEVICE_EXECUTE_METHOD = 'REQUEST_DEVICE_EXECUTE_METHOD';
export const RECEIVE_DEVICE_EXECUTE_METHOD = 'RECEIVE_DEVICE_EXECUTE_METHOD';
export const CLEAR_DEVICE_EXECUTE_METHOD = 'CLEAR_DEVICE_EXECUTE_METHOD';

export const REQUEST_DEVICE_EXECUTE_METHOD_SET_CONFIG = 'REQUEST_DEVICE_EXECUTE_METHOD_SET_CONFIG';
export const RECEIVE_DEVICE_EXECUTE_METHOD_SET_CONFIG = 'RECEIVE_DEVICE_EXECUTE_METHOD_SET_CONFIG';
export const CLEAR_DEVICE_EXECUTE_METHOD_SET_CONFIG = 'CLEAR_DEVICE_EXECUTE_METHOD_SET_CONFIG';

export const REQUEST_DEVICE_EXECUTE_METHOD_GET_CONFIG = 'REQUEST_DEVICE_EXECUTE_METHOD_GET_CONFIG';
export const RECEIVE_DEVICE_EXECUTE_METHOD_GET_CONFIG = 'RECEIVE_DEVICE_EXECUTE_METHOD_GET_CONFIG';
export const CLEAR_DEVICE_EXECUTE_METHOD_GET_CONFIG = 'CLEAR_DEVICE_EXECUTE_METHOD_GET_CONFIG';

export const REQUEST_DEVICE_EXECUTE_METHOD_GET_DOORS = 'REQUEST_DEVICE_EXECUTE_METHOD_GET_DOORS';
export const RECEIVE_DEVICE_EXECUTE_METHOD_GET_DOORS = 'RECEIVE_DEVICE_EXECUTE_METHOD_GET_DOORS';
export const CLEAR_DEVICE_EXECUTE_METHOD_GET_DOORS = 'CLEAR_DEVICE_EXECUTE_METHOD_GET_DOORS';

export const REQUEST_USER_DOORS = 'REQUEST_GET_USER_DOORS';
export const RECEIVE_USER_DOORS = 'RECEIVE_GET_USER_DOORS';
export const CLEAR_USER_DOORS = 'CLEAR_USER_DOORS';

export const REQUEST_DOORS = 'REQUEST_GET_DOORS';
export const RECEIVE_DOORS = 'RECEIVE_GET_DOORS';
export const CLEAR_DOORS = 'CLEAR_DOORS';

export const REQUEST_DISTANCE_TO_ACCESS_POINTS = 'REQUEST_DISTANCE_TO_ACCESS_POINTS';
export const RECEIVE_DISTANCE_TO_ACCESS_POINTS = 'RECEIVE_DISTANCE_TO_ACCESS_POINTS';
export const CLEAR_DISTANCE_TO_ACCESS_POINTS = 'CLEAR_DISTANCE_TO_ACCESS_POINTS';


export const REQUEST_ATTACH_DEVICE_TO_OBJECT = 'REQUEST_ATTACH_DEVICE_TO_OBJECT';
export const RECEIVE_ATTACH_DEVICE_TO_OBJECT = 'RECEIVE_ATTACH_DEVICE_TO_OBJECT';

export const REQUEST_DETACH_DEVICE_FROM_OBJECT = 'REQUEST_DETACH_DEVICE_FROM_OBJECT';
export const RECEIVE_DETACH_DEVICE_FROM_OBJECT = 'RECEIVE_DETACH_DEVICE_FROM_OBJECT';

export const REQUEST_CHECK_DEVICES_ONLINE = 'REQUEST_CHECK_DEVICES_ONLINE';
export const RECEIVE_CHECK_DEVICES_ONLINE = 'RECEIVE_CHECK_DEVICES_ONLINE';

export const SELECT_DEVICE = 'SELECT_DEVICE';

export const REQUEST_TEMPORARY_DEVICES_IDS = 'REQUEST_TEMPORARY_DEVICES_IDS';
export const RECEIVE_TEMPORARY_DEVICES_IDS = 'RECEIVE_TEMPORARY_DEVICES_IDS';

export const REQUEST_REGISTER_TEMPORARY_DEVICE = 'REQUEST_REGISTER_TEMPORARY_DEVICE';
export const RECEIVE_REGISTER_TEMPORARY_DEVICE = 'RECEIVE_REGISTER_TEMPORARY_DEVICE';

export const REQUEST_TOUCH_TEMPORARY_DEVICE = 'REQUEST_TOUCH_TEMPORARY_DEVICE';
export const RECEIVE_TOUCH_TEMPORARY_DEVICE = 'RECEIVE_TOUCH_TEMPORARY_DEVICE';

export const REQUEST_DEVICE_BY_ACCESS_POINT_ID = 'REQUEST_DEVICE_BY_ACCESS_POINT_ID';
export const RECEIVE_DEVICE_BY_ACCESS_POINT_ID = 'RECEIVE_DEVICE_BY_ACCESS_POINT_ID';


const DEVICES_SERVICE_URL = `${PROTOCOL}//api.${HOST_NAME}/devices/`;
const DEVICE_MANAGER_SERVICE_URL = `${PROTOCOL}//api.${HOST_NAME}/device_manager/`;

/*
select device
 */

export const selectDevice = (kind, device) => ({
  type: SELECT_DEVICE,
  payload: {
    kind: kind,
    device: device
  }
});


/****************** get devices *******************/
export const requestDevices = () => ({
  type: REQUEST_DEVICES
});

export const requestMoreDevices = () => ({
  type: REQUEST_MORE_DEVICES
});

export const receiveDevices = (json) => ({
  type: RECEIVE_DEVICES,
  payload: json
});

export const receiveMoreDevices = (json) => ({
  type: RECEIVE_MORE_DEVICES,
  payload: json
});

export const clearDevices = () => ({
  type: CLEAR_DEVICES
});

export const fetchDevices = (data) => dispatch => {
  const method = 'get_devices';
  dispatch(requestDevices());
  return jsonRPCRequest(DEVICES_SERVICE_URL,method, data)
    .then(response => response.json())
    .then(json => dispatch(checkAuth(json)))
    .then(json => dispatch(receiveDevices(json), ))
};

export const fetchMoreDevices = (data) => dispatch => {
  const method = 'get_devices';
  dispatch(requestMoreDevices());
  return jsonRPCRequest(DEVICES_SERVICE_URL,method, data)
    .then(response => response.json())
    .then(json => dispatch(checkAuth(json)))
    .then(json => dispatch(receiveMoreDevices(json), ))
};


/****************** get device by id *******************/
export const requestDeviceById = () => ({
  type: REQUEST_DEVICE_BY_ID
});

export const receiveDeviceById = (json) => ({
  type: RECEIVE_DEVICE_BY_ID,
  payload: json
});

export const clearDeviceById = () => ({
  type: CLEAR_DEVICE_BY_ID
});

export const fetchDeviceById = (data) => dispatch => {
  const method = 'get_device';
  dispatch(requestDeviceById());
  return jsonRPCRequest(DEVICES_SERVICE_URL,method, data)
    .then(response => response.json())
    .then(json => dispatch(checkAuth(json)))
    .then(json => dispatch(receiveDeviceById(json), ))
};


/*
execute device method
 */

export const requestDeviceExecuteMethod = () => ({
  type: REQUEST_DEVICE_EXECUTE_METHOD
});

export const clearDeviceExecuteMethod = () => ({
  type: CLEAR_DEVICE_EXECUTE_METHOD
});

export const receiveDeviceExecuteMethod = (json) => ({
  type: RECEIVE_DEVICE_EXECUTE_METHOD,
  payload: json
});

export const fetchDeviceExecuteMethod = (data) => dispatch => {
  const method = 'execute_method';
  dispatch(requestDeviceExecuteMethod());
  return jsonRPCRequest(DEVICE_MANAGER_SERVICE_URL,method, data)
    .then(response => response.json())
    .then(json => dispatch(checkAuth(json)))
    .then(json => dispatch(receiveDeviceExecuteMethod(json), ))
};

/****************** execute device method set_config *******************/
export const requestDeviceExecuteMethodSetConfig = () => ({
  type: REQUEST_DEVICE_EXECUTE_METHOD_SET_CONFIG
});

export const clearDeviceExecuteMethodSetConfig = () => ({
  type: CLEAR_DEVICE_EXECUTE_METHOD_SET_CONFIG
});

export const receiveDeviceExecuteMethodSetConfig  = (json) => ({
  type: RECEIVE_DEVICE_EXECUTE_METHOD_SET_CONFIG,
  payload: json
});

export const fetchDeviceExecuteMethodSetConfig = (data) => dispatch => {
  const method = 'execute_method';
  dispatch(requestDeviceExecuteMethodSetConfig());
  return jsonRPCRequest(DEVICE_MANAGER_SERVICE_URL,method, data)
    .then(response => response.json())
    .then(json => dispatch(checkAuth(json)))
    .then(json => dispatch(receiveDeviceExecuteMethodSetConfig(json), ))
};

/****************** execute device method get_config *******************/
export const requestDeviceExecuteMethodGetConfig = () => ({
  type: REQUEST_DEVICE_EXECUTE_METHOD_GET_CONFIG
});

export const receiveDeviceExecuteMethodGetConfig  = (json) => ({
  type: RECEIVE_DEVICE_EXECUTE_METHOD_GET_CONFIG,
  payload: json
});

export const clearDeviceExecuteMethodGetConfig  = () => ({
  type: CLEAR_DEVICE_EXECUTE_METHOD_GET_CONFIG,
});

export const fetchDeviceExecuteMethodGetConfig = (data) => dispatch => {
  const method = 'execute_method';
  dispatch(requestDeviceExecuteMethodGetConfig());
  return jsonRPCRequest(DEVICE_MANAGER_SERVICE_URL,method, data)
    .then(response => response.json())
    .then(json => dispatch(checkAuth(json)))
    .then(json => dispatch(receiveDeviceExecuteMethodGetConfig(json), ))
};


/****************** execute device method get_doors *******************/
export const requestDeviceExecuteMethodGetDoors = () => ({
  type: REQUEST_DEVICE_EXECUTE_METHOD_GET_DOORS
});

export const receiveDeviceExecuteMethodGetDoors  = (json) => ({
  type: RECEIVE_DEVICE_EXECUTE_METHOD_GET_DOORS,
  payload: json
});

export const clearDeviceExecuteMethodGetDoors  = () => ({
  type: CLEAR_DEVICE_EXECUTE_METHOD_GET_DOORS,
});

export const fetchDeviceExecuteMethodGetDoors = (data) => dispatch => {
  const method = 'execute_method';
  dispatch(requestDeviceExecuteMethodGetDoors());
  return jsonRPCRequest(DEVICE_MANAGER_SERVICE_URL,method, data)
    .then(response => response.json())
    .then(json => dispatch(checkAuth(json)))
    .then(json => dispatch(receiveDeviceExecuteMethodGetDoors(json), ))
};


/*
add device
 */

export const requestAddDevice = () => ({
  type: REQUEST_ADD_DEVICE
});

export const receiveAddDevice  = (json) => ({
  type: RECEIVE_ADD_DEVICE,
  payload: json
});

export const fetchAddDevice = (data) => dispatch => {
  const method = 'add_device';
  dispatch(requestAddDevice());
  return jsonRPCRequest(DEVICES_SERVICE_URL, method, data)
    .then(response => response.json())
    .then(json => dispatch(checkAuth(json)))
    .then(json => dispatch(receiveAddDevice(json), ))
};

/*
set device
 */

export const requestSetDevice = () => ({
  type: REQUEST_ADD_DEVICE
});

export const receiveSetDevice  = (json) => ({
  type: RECEIVE_ADD_DEVICE,
  payload: json
});

export const fetchSetDevice = (data) => dispatch => {
  const method = 'set_device';
  dispatch(requestSetDevice());
  return jsonRPCRequest(DEVICES_SERVICE_URL, method, data)
    .then(response => response.json())
    .then(json => dispatch(checkAuth(json)))
    .then(json => dispatch(receiveSetDevice(json), ))
};


/*
delete device
 */

export const requestDeleteDevice = () => ({
  type: REQUEST_DELETE_DEVICE
});

export const receiveDeleteDevice  = (json) => ({
  type: RECEIVE_DELETE_DEVICE,
  payload: json
});

export const fetchDeleteDevice = (data) => dispatch => {
  const method = 'delete_devices';
  dispatch(requestDeleteDevice());
  return jsonRPCRequest(DEVICES_SERVICE_URL, method, data)
    .then(response => response.json())
    .then(json => dispatch(checkAuth(json)))
    .then(json => dispatch(receiveDeleteDevice(json), ))
};



/*
get_user_doors
 */

export const clearUserDoors = () => ({
  type: CLEAR_USER_DOORS
});

export const requestUserDoors = () => ({
  type: REQUEST_USER_DOORS
});

export const receiveUserDoors  = (json) => ({
  type: RECEIVE_USER_DOORS,
  payload: json
});

export const fetchUserDoors = (data) => dispatch => {
  const method = 'get_access_points';
  dispatch(requestUserDoors());
  return jsonRPCRequest(DEVICES_SERVICE_URL, method, data)
    .then(response => response.json())
    .then(json => dispatch(checkAuth(json)))
    .then(json => dispatch(receiveUserDoors(json), ))
};

/*
get_doors
 */

export const clearDoors = () => ({
  type: CLEAR_DOORS
});

export const requestDoors = () => ({
  type: REQUEST_DOORS
});

export const receiveDoors  = (json) => ({
  type: RECEIVE_DOORS,
  payload: json
});

export const fetchDoors = (data) => dispatch => {
  const method = 'get_access_points';
  dispatch(requestDoors());
  return jsonRPCRequest(DEVICES_SERVICE_URL, method, data)
    .then(response => response.json())
    .then(json => dispatch(checkAuth(json)))
    .then(json => dispatch(receiveDoors(json), ))
};


/*
attach device to object
 */

export const requestAttachDeviceToObject = () => ({
  type: REQUEST_ATTACH_DEVICE_TO_OBJECT
});

export const receiveAttachDeviceToObject  = (json) => ({
  type: RECEIVE_ATTACH_DEVICE_TO_OBJECT,
  payload: json
});

export const fetchAttachDeviceToObject = (data) => dispatch => {
  const method = 'attach_device_to_object';
  dispatch(requestAttachDeviceToObject());
  return jsonRPCRequest(DEVICES_SERVICE_URL, method, data)
    .then(response => response.json())
    .then(json => dispatch(checkAuth(json)))
    .then(json => dispatch(receiveAttachDeviceToObject(json), ))
};

/*
detach device from object
 */

export const requestDetachDeviceFromObject = () => ({
  type: REQUEST_DETACH_DEVICE_FROM_OBJECT
});

export const receiveDetachDeviceFromObject  = (json) => ({
  type: RECEIVE_DETACH_DEVICE_FROM_OBJECT,
  payload: json
});

export const fetchDetachDeviceFromObject = (data) => dispatch => {
  const method = 'detach_device_from_object';
  dispatch(requestDetachDeviceFromObject());
  return jsonRPCRequest(DEVICES_SERVICE_URL, method, data)
    .then(response => response.json())
    .then(json => dispatch(checkAuth(json)))
    .then(json => dispatch(receiveDetachDeviceFromObject(json), ))
};

/*
set_access_point_permissions
 */

export const requestSetAccessPointPermissions = () => ({
  type: REQUEST_SET_ACCESS_POINT_PERMISSIONS
});

export const receiveSetAccessPointPermissions  = (json) => ({
  type: RECEIVE_SET_ACCESS_POINT_PERMISSIONS,
  payload: json
});

export const fetchSetAccessPointPermissions = (data) => dispatch => {
  const method = 'set_access_point_permissions';
  dispatch(requestSetAccessPointPermissions());
  return jsonRPCRequest(DEVICES_SERVICE_URL, method, data)
    .then(response => response.json())
    .then(json => dispatch(checkAuth(json)))
    .then(json => dispatch(receiveSetAccessPointPermissions(json), ))
};


/*
delete_access_point_permissions
 */

export const requestDeleteAccessPointPermissions = () => ({
  type: REQUEST_DELETE_ACCESS_POINT_PERMISSIONS
});

export const receiveDeleteAccessPointPermissions  = (json) => ({
  type: RECEIVE_DELETE_ACCESS_POINT_PERMISSIONS,
  payload: json
});

export const fetchDeleteAccessPointPermissions = (data) => dispatch => {
  const method = 'delete_access_point_permissions';
  dispatch(requestDeleteAccessPointPermissions());
  return jsonRPCRequest(DEVICES_SERVICE_URL, method, data)
    .then(response => response.json())
    .then(json => dispatch(checkAuth(json)))
    .then(json => dispatch(receiveDeleteAccessPointPermissions(json), ))
};

/*
get_access_point_users
 */

export const requestGetAccessPointUsers = () => ({
  type: REQUEST_GET_ACCESS_POINT_USERS
});

export const receiveGetAccessPointUsers  = (json) => ({
  type: RECEIVE_GET_ACCESS_POINT_USERS,
  payload: json
});

export const clearAccessPointUsers  = (json) => ({
  type: CLEAR_ACCESS_POINT_USERS,
  payload: json
});

export const fetchGetAccessPointUsers = (data) => dispatch => {
  const method = 'get_access_point_users';
  dispatch(requestGetAccessPointUsers());
  return jsonRPCRequest(DEVICES_SERVICE_URL, method, data)
    .then(response => response.json())
    .then(json => dispatch(checkAuth(json)))
    .then(json => dispatch(receiveGetAccessPointUsers(json), ))
};

/*
get_distance_to_access_points
 */

export const requestDistanceToAccessPoints = () => ({
  type: REQUEST_DISTANCE_TO_ACCESS_POINTS
});

export const receiveDistanceToAccessPoints  = (json) => ({
  type: RECEIVE_DISTANCE_TO_ACCESS_POINTS,
  payload: json
});

export const clearDistanceToAccessPoints  = (json) => ({
  type: CLEAR_DISTANCE_TO_ACCESS_POINTS,
  payload: json
});

export const fetchDistanceToAccessPoints = (data) => dispatch => {
  const method = 'get_distance_to_access_points';
  dispatch(requestDistanceToAccessPoints());
  return jsonRPCRequest(DEVICES_SERVICE_URL, method, data)
    .then(response => response.json())
    .then(json => dispatch(checkAuth(json)))
    .then(json => dispatch(receiveDistanceToAccessPoints(json), ))
};


/****************** open door*******************/
export const requestOpenAccessPoint = () => ({
  type: REQUEST_OPEN_ACCESS_POINT
});

export const receiveOpenAccessPoint  = (json) => ({
  type: RECEIVE_OPEN_ACCESS_POINT,
  payload: json
});

export const fetchOpenAccessPoint = (data) => dispatch => {
  const method = 'open_access_point_by_id';
  dispatch(requestOpenAccessPoint());
  return jsonRPCRequest(DEVICE_MANAGER_SERVICE_URL, method, data)
    .then(response => response.json())
    .then(json => dispatch(checkAuth(json)))
    .then(json => dispatch(receiveOpenAccessPoint(json), ))
};

/****************** open door by shared link*******************/
export const requestOpenAccessPointBySharedLink = () => ({
  type: REQUEST_OPEN_ACCESS_POINT_BY_SHARED_LINK
});

export const receiveOpenAccessPointBySharedLink  = (json) => ({
  type: RECEIVE_OPEN_ACCESS_POINT_BY_SHARED_LINK,
  payload: json
});

export const fetchOpenAccessPointBySharedLink = (data) => dispatch => {
  const method = 'open_access_point_by_shared_link';
  dispatch(requestOpenAccessPointBySharedLink());
  return jsonRPCRequest(DEVICE_MANAGER_SERVICE_URL, method, data)
    .then(response => response.json())
    .then(json => dispatch(checkAuth(json)))
    .then(json => dispatch(receiveOpenAccessPointBySharedLink(json), ))
};


/****************** open door and register pass*******************/
export const requestOpenAccessPointAndRegisterPass = () => ({
  type: REQUEST_OPEN_ACCESS_POINT_AND_REGISTER_PASS
});

export const receiveOpenAccessPointAndRegisterPass  = (json) => ({
  type: RECEIVE_OPEN_ACCESS_POINT_AND_REGISTER_PASS,
  payload: json
});

export const fetchOpenAccessPointAndRegisterPass = (data) => dispatch => {
  const method = 'open_access_point_and_register_pass';
  dispatch(requestOpenAccessPointAndRegisterPass());
  return jsonRPCRequest(DEVICE_MANAGER_SERVICE_URL, method, data)
    .then(response => response.json())
    .then(json => dispatch(checkAuth(json)))
    .then(json => dispatch(receiveOpenAccessPointAndRegisterPass(json), ))
};


/****************** check_devices_online*******************/
export const requestCheckDevicesOnline = () => ({
  type: REQUEST_CHECK_DEVICES_ONLINE
});

export const receiveCheckDevicesOnline  = (json) => ({
  type: RECEIVE_CHECK_DEVICES_ONLINE,
  payload: json
});

export const fetchCheckDevicesOnline = (data) => dispatch => {
  const method = 'check_devices_online';
  dispatch(requestCheckDevicesOnline());
  return jsonRPCRequest(DEVICE_MANAGER_SERVICE_URL, method, data)
    .then(response => response.json())
    .then(json => dispatch(checkAuth(json)))
    .then(json => dispatch(receiveCheckDevicesOnline(json), ))
};


/*
get_temporary_devices_ids
 */
export const requestTemporaryDevicesIds = () => ({
  type: REQUEST_TEMPORARY_DEVICES_IDS
});

export const receiveTemporaryDevicesIds  = (json) => ({
  type: RECEIVE_TEMPORARY_DEVICES_IDS,
  payload: json
});

export const fetchTemporaryDevicesIds = (data) => dispatch => {
  const method = 'get_temporary_devices_ids';
  dispatch(requestTemporaryDevicesIds());
  return jsonRPCRequest(DEVICE_MANAGER_SERVICE_URL, method, data)
    .then(response => response.json())
    .then(json => dispatch(checkAuth(json)))
    .then(json => dispatch(receiveTemporaryDevicesIds(json), ))
};


/*
register_temporary_device
 */
export const requestRegisterTemporaryDevice = () => ({
  type: REQUEST_REGISTER_TEMPORARY_DEVICE
});

export const receiveRegisterTemporaryDevice  = (json) => ({
  type: RECEIVE_REGISTER_TEMPORARY_DEVICE,
  payload: json
});

export const fetchRegisterTemporaryDevice = (data) => dispatch => {
  const method = 'register_temporary_device';
  dispatch(requestRegisterTemporaryDevice());
  return jsonRPCRequest(DEVICE_MANAGER_SERVICE_URL, method, data)
    .then(response => response.json())
    .then(json => dispatch(checkAuth(json)))
    .then(json => dispatch(receiveRegisterTemporaryDevice(json), ))
};


/*
touch_temporary_device
 */
export const requestTouchTemporaryDevice = () => ({
  type: REQUEST_TOUCH_TEMPORARY_DEVICE
});

export const receiveTouchTemporaryDevice  = (json) => ({
  type: RECEIVE_TOUCH_TEMPORARY_DEVICE,
  payload: json
});

export const fetchTouchTemporaryDevice = (data) => dispatch => {
  const method = 'touch_temporary_device';
  dispatch(requestTouchTemporaryDevice());
  return jsonRPCRequest(DEVICE_MANAGER_SERVICE_URL, method, data)
    .then(response => response.json())
    .then(json => dispatch(checkAuth(json)))
    .then(json => dispatch(receiveTouchTemporaryDevice(json), ))
};


/*
request_device_by_access_point_id
 */
export const requestDeviceByAccessPointId = () => ({
  type: REQUEST_DEVICE_BY_ACCESS_POINT_ID
});

export const receiveDeviceByAccessPointId = (json) => ({
  type: RECEIVE_DEVICE_BY_ACCESS_POINT_ID,
  payload: json
});

export const fetchDeviceByAccessPointId = (data) => dispatch => {
  const method = 'get_device_by_access_point_id';
  dispatch(requestDeviceByAccessPointId());
  return jsonRPCRequest(DEVICES_SERVICE_URL, method, data)
    .then(response => response.json())
    .then(json => dispatch(checkAuth(json)))
    .then(json => dispatch(receiveDeviceByAccessPointId(json), ))
};

