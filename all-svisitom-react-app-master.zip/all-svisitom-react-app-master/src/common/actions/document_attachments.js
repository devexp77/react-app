import { jsonRPCRequest, postRequest } from "./asyncActions";
import { PROTOCOL, HOST_NAME } from "../constants";
import { checkAuth } from "./user";

const PORTAL_UPLOAD_URL = `${PROTOCOL}//upload-document.${HOST_NAME}/`;
const PORTAL_SERVICE_URL = `${PROTOCOL}//api.${HOST_NAME}/document_attachments/`;

export const REQUEST_ADD_DOCUMENT = "REQUEST_ADD_DOCUMENT";
export const RECEIVE_ADD_DOCUMENT = "RECEIVE_ADD_DOCUMENT";

export const REQUEST_FACILITY_PROBLEM_DOCUMENTS = "REQUEST_FACILITY_PROBLEM_DOCUMENTS";
export const RECEIVE_FACILITY_PROBLEM_DOCUMENTS = "RECEIVE_FACILITY_PROBLEM_DOCUMENTS";
export const CLEAR_FACILITY_PROBLEM_DOCUMENTS = "CLEAR_FACILITY_PROBLEM_DOCUMENTS";

export const REQUEST_OBJECT_DOCUMENTS = "REQUEST_OBJECT_DOCUMENTS";
export const RECEIVE_OBJECT_DOCUMENTS = "RECEIVE_OBJECT_DOCUMENTS";
export const CLEAR_OBJECT_DOCUMENTS = "CLEAR_OBJECT_DOCUMENTS";

export const REQUEST_DOCUMENT_BY_ID = "REQUEST_DOCUMENT_BY_ID";
export const RECEIVE_DOCUMENT_BY_ID = "RECEIVE_DOCUMENT_BY_ID";
export const CLEAR_DOCUMENT_BY_ID = "CLEAR_DOCUMENT_BY_ID";

/************ add document *************/
export const requestAddDocument = () => ({
  type: REQUEST_ADD_DOCUMENT
});

export const receiveAddDocument = json => ({
  type: RECEIVE_ADD_DOCUMENT,
  payload: json
});

export const fetchAddDocument = data => dispatch => {
  dispatch(requestAddDocument());
  return postRequest(PORTAL_UPLOAD_URL, data)
    .then(response => response.json())
    .then(json => dispatch(receiveAddDocument(json)));
};

/**********************************************/

/************  facility problem documents *************/
export const requestFmDocuments = () => ({
  type: REQUEST_FACILITY_PROBLEM_DOCUMENTS
});

export const receiveFmDocuments = json => ({
  type: RECEIVE_FACILITY_PROBLEM_DOCUMENTS,
  payload: json
});

export const fetchFmDocuments = data => dispatch => {
  const method = "get_document_attachments";
  dispatch(requestFmDocuments());
  return jsonRPCRequest(PORTAL_SERVICE_URL, method, data)
    .then(response => response.json())
    .then(json => dispatch(checkAuth(json)))
    .then(json => dispatch(receiveFmDocuments(json)));
};

export const clearFmDocuments = () => ({
  type: CLEAR_FACILITY_PROBLEM_DOCUMENTS
});

/**********************************************/

/************  object documents *************/
export const requestObjectDocuments = () => ({
  type: REQUEST_OBJECT_DOCUMENTS
});

export const receiveObjectDocuments = json => ({
  type: RECEIVE_OBJECT_DOCUMENTS,
  payload: json
});

export const fetchObjectDocuments = data => dispatch => {
  const method = "get_document_attachments";
  dispatch(requestObjectDocuments());
  return jsonRPCRequest(PORTAL_SERVICE_URL, method, data)
    .then(response => response.json())
    .then(json => dispatch(checkAuth(json)))
    .then(json => dispatch(receiveObjectDocuments(json)));
};

export const clearObjectDocuments = () => ({
  type: CLEAR_OBJECT_DOCUMENTS
});
/**********************************************/

/******************* document by id ***************************/
export const requestDocumentById = () => ({
  type: REQUEST_DOCUMENT_BY_ID
});

export const receiveDocumentById = json => ({
  type: RECEIVE_DOCUMENT_BY_ID,
  payload: json
});


export const fetchDocumentById = data => dispatch => {
  const method = "get_document_attachments";
  dispatch(requestDocumentById());
  return jsonRPCRequest(PORTAL_SERVICE_URL, method, data)
    .then(response => response.json())
    .then(json => dispatch(checkAuth(json)))
    .then(json => dispatch(receiveDocumentById(json)));
};


export const clearDocumentById = () => ({
  type: CLEAR_DOCUMENT_BY_ID
});
/**********************************************/


