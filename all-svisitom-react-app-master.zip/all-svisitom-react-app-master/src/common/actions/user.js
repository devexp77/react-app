import { jsonRPCRequest } from "./asyncActions";
import { push } from "react-router-redux";
import { FULL_HOST_NAME, PROTOCOL, HOST_NAME } from "../constants";
import strings from "../localization/all";

export const REQUEST_USER_GLOBAL = "REQUEST_USER_GLOBAL";
export const RECEIVE_USER_GLOBAL = "RECEIVE_USER_GLOBAL";

export const REQUEST_USER = "REQUEST_USER";
export const RECEIVE_USER = "RECEIVE_USER";

export const REQUEST_SET_USER = "REQUEST_SET_USER";
export const RECEIVE_SET_USER = "RECEIVE_SET_USER";

export const CLEAR_SET_USER_STATUS = "CLEAR_SET_USER_STATUS";

export const REQUEST_USER_BY_ID = "REQUEST_USER_BY_ID";
export const RECEIVE_USER_BY_ID = "RECEIVE_USER_BY_ID";
export const CLEAR_USER_BY_ID = "CLEAR_USER_BY_ID";

export const REQUEST_DELETE_CURRENT_USER = "REQUEST_DELETE_CURRENT_USER";
export const RECEIVE_DELETE_CURRENT_USER = "RECEIVE_DELETE_CURRENT_USER";

export const REQUEST_CHANGE_PASSWORD = "REQUEST_CHANGE_PASSWORD";
export const RECEIVE_CHANGE_PASSWORD = "RECEIVE_CHANGE_PASSWORD";

export const REQUEST_SET_IDENTIFIER = "REQUEST_SET_IDENTIFIER";
export const RECEIVE_SET_IDENTIFIER = "RECEIVE_SET_IDENTIFIER";

export const REQUEST_CONFIRM_IDENTIFIER = "REQUEST_CONFIRM_IDENTIFIER";
export const RECEIVE_CONFIRM_IDENTIFIER = "RECEIVE_CONFIRM_IDENTIFIER";

export const REQUEST_GENERATE_PERSONAL_CODE = "REQUEST_GENERATE_PERSONAL_CODE";
export const RECEIVE_GENERATE_PERSONAL_CODE = "RECEIVE_GENERATE_PERSONAL_CODE";

export const REQUEST_CHECK_USER_EXISTS = 'REQUEST_CHECK_USER_EXISTS';
export const RECEIVE_CHECK_USER_EXISTS = 'RECEIVE_CHECK_USER_EXISTS';

export const REQUEST_ADD_DEPENDENT_USER = 'REQUEST_ADD_DEPENDENT_USER';
export const RECEIVE_ADD_DEPENDENT_USER = 'RECEIVE_ADD_DEPENDENT_USER';

export const REQUEST_PROFILE_USER = "REQUEST_PROFILE_USER";
export const RECEIVE_PROFILE_USER = "RECEIVE_PROFILE_USER";

export const REQUEST_GLOBAL_PROFILE_USER = "REQUEST_GLOBAL_PROFILE_USER";
export const RECEIVE_GLOBAL_PROFILE_USER = "RECEIVE_GLOBAL_PROFILE_USER";
export const CLEAR_PROFILE_USER = "CLEAR_PROFILE_USER";

export const REQUEST_SET_DO_NOT_DISTURB_STATE = "REQUEST_SET_DO_NOT_DISTURB_STATE";
export const RECEIVE_SET_DO_NOT_DISTURB_STATE = "RECEIVE_SET_DO_NOT_DISTURB_STATE";

const PORTAL_SERVICE_URL = `${PROTOCOL}//api.${HOST_NAME}/users/`;

export const requestUserGlobal = () => ({
  type: REQUEST_USER_GLOBAL
});

export const receiveUserGlobal = json => ({
  type: RECEIVE_USER_GLOBAL,
  payload: json
});

export const fetchUserGlobal = () => dispatch => {
  const method = "get_current_user";
  const data = {
    local_time: moment().format("YYYY-MM-DD HH:mm:ss ZZ"),
    timezone_offset: new Date().getTimezoneOffset(),
    language: strings.getLanguage()
  };
  dispatch(requestUserGlobal());
  return jsonRPCRequest(PORTAL_SERVICE_URL, method, data)
    .then(response => response.json())
    .then(json => dispatch(receiveUserGlobal(json)));
};

export const requestUser = () => ({
  type: REQUEST_USER
});

export const receiveUser = json => ({
  type: RECEIVE_USER,
  payload: json
});

export const toRoot = () => dispatch => {
  dispatch(push("/"));
};

export const toMyData = () => dispatch => {
  dispatch(push("/me/mydata"));
};

export const toLogin = () => (dispatch, getState) => {
  const url = encodeURIComponent(
    `${PROTOCOL}//${FULL_HOST_NAME}/#${getState().router.routerPrevPath}`
  );
  window.location.href = `${PROTOCOL}//${HOST_NAME}/authorize/svisitom?next=${url}`;
};

export const fetchUser = () => dispatch => {
  const method = "get_current_user";
  dispatch(requestUser());
  return jsonRPCRequest(PORTAL_SERVICE_URL, method, [])
    .then(response => response.json())
    .then(json => dispatch(receiveUser(json)));
};

export const requestSetUser = json => ({
  type: REQUEST_SET_USER,
  payload: json
});

export const receiveSetUser = json => ({
  type: RECEIVE_SET_USER,
  payload: json
});

export const fetchSetUser = data => dispatch => {
  const method = "set_user";
  dispatch(requestSetUser());
  return jsonRPCRequest(PORTAL_SERVICE_URL, method, data)
    .then(response => response.json())
    .then(json => dispatch(checkAuth(json)))
    .then(json => dispatch(receiveSetUser(json)));
};

export const clearSetUserStatus = () => ({
  type: CLEAR_SET_USER_STATUS
});

export const checkAuth = json => dispatch => {
  // console.log('checkAuth working');
  if (json.error) {
    switch (json.error.code) {
      case -32010:
        dispatch(toLogin());
        break;

      default:
        break;
    }
  }

  return json;
};

export const requestUserById = () => ({
  type: REQUEST_USER_BY_ID
});

export const receiveUserById = json => ({
  type: RECEIVE_USER_BY_ID,
  payload: json
});

export const fetchUserById = data => dispatch => {
  const method = "get_user";
  dispatch(requestUserById());
  return jsonRPCRequest(PORTAL_SERVICE_URL, method, data)
    .then(response => response.json())
    .then(json => dispatch(checkAuth(json)))
    .then(json => dispatch(receiveUserById(json)));
};

export const clearUserById = () => ({
  type: CLEAR_USER_BY_ID
});

/************ delete current user *************/
export const requestDeleteCurrentUser = () => ({
  type: REQUEST_DELETE_CURRENT_USER
});

export const receiveDeleteCurrentUser = json => ({
  type: RECEIVE_DELETE_CURRENT_USER,
  payload: json
});

export const fetchDeleteCurrentUser = data => dispatch => {
  const method = "delete_current_user";
  dispatch(requestDeleteCurrentUser());
  return jsonRPCRequest(PORTAL_SERVICE_URL, method, data)
    .then(response => response.json())
    .then(json => dispatch(checkAuth(json)))
    .then(json => dispatch(receiveDeleteCurrentUser(json)));
};

/**********************************************/

/************ change password *************/
export const requestChangePassword = () => ({
  type: REQUEST_CHANGE_PASSWORD
});

export const receiveChangePassword = json => ({
  type: RECEIVE_CHANGE_PASSWORD,
  payload: json
});

export const fetchChangePassword = data => dispatch => {
  const method = "change_password";
  dispatch(requestChangePassword());
  return jsonRPCRequest(PORTAL_SERVICE_URL, method, data)
    .then(response => response.json())
    .then(json => dispatch(checkAuth(json)))
    .then(json => dispatch(receiveChangePassword(json)));
};
/**********************************************/

/************ set_identifier *************/
export const requestSetIdentifier = () => ({
  type: REQUEST_SET_IDENTIFIER
});

export const receiveSetIdentifier = json => ({
  type: RECEIVE_SET_IDENTIFIER,
  payload: json
});

export const fetchSetIdentifier = data => dispatch => {
  const method = "set_identifier";
  dispatch(requestSetIdentifier());
  return jsonRPCRequest(PORTAL_SERVICE_URL, method, data)
    .then(response => response.json())
    .then(json => dispatch(checkAuth(json)))
    .then(json => dispatch(receiveSetIdentifier(json)));
};
/**********************************************/

/************ confirm_identifier *************/
export const requestConfirmIdentifier = () => ({
  type: REQUEST_CONFIRM_IDENTIFIER
});

export const receiveConfirmIdentifier = json => ({
  type: RECEIVE_CONFIRM_IDENTIFIER,
  payload: json
});

export const fetchConfirmIdentifier = data => dispatch => {
  const method = "confirm_identifier";
  dispatch(requestConfirmIdentifier());
  return jsonRPCRequest(PORTAL_SERVICE_URL, method, data)
    .then(response => response.json())
    .then(json => dispatch(checkAuth(json)))
    .then(json => dispatch(receiveConfirmIdentifier(json)));
};
/**********************************************/

/************ confirm_identifier *************/
export const requestGeneratePersonalCode = () => ({
  type: REQUEST_GENERATE_PERSONAL_CODE
});

export const receiveGeneratePersonalCode = json => ({
  type: RECEIVE_GENERATE_PERSONAL_CODE,
  payload: json
});

export const fetchGeneratePersonalCode = data => dispatch => {
  const method = "generate_new_personal_code";
  dispatch(requestGeneratePersonalCode());
  return jsonRPCRequest(PORTAL_SERVICE_URL, method, data)
    .then(response => response.json())
    .then(json => dispatch(checkAuth(json)))
    .then(json => dispatch(receiveGeneratePersonalCode(json)));
};
/**********************************************/

/*********** profile user **********/

export const requestProfileUser = () => ({
  type: REQUEST_PROFILE_USER
});

export const receiveProfileUser = json => ({
  type: RECEIVE_PROFILE_USER,
  payload: json
});

export const fetchProfileUser = (data, current = false) => dispatch => {
  const method = current ? "get_current_user" : "get_user";
  dispatch(requestProfileUser());
  return jsonRPCRequest(PORTAL_SERVICE_URL, method, data)
    .then(response => response.json())
    .then(json => dispatch(checkAuth(json)))
    .then(json => dispatch(receiveProfileUser(json)));
};

export const requestGlobalProfileUser = () => ({
  type: REQUEST_GLOBAL_PROFILE_USER
});

export const receiveGlobalProfileUser = json => ({
  type: RECEIVE_GLOBAL_PROFILE_USER,
  payload: json
});

export const fetchGlobalProfileUser = (data, current = false) => dispatch => {
  const method = current ? "get_current_user" : "get_user";
  dispatch(requestGlobalProfileUser());
  return jsonRPCRequest(PORTAL_SERVICE_URL, method, data)
    .then(response => response.json())
    .then(json => dispatch(checkAuth(json)))
    .then(json => dispatch(receiveGlobalProfileUser(json)));
};

export const clearProfileUser = () => ({
  type: CLEAR_PROFILE_USER
});


/*
is_user_exists
 */
export const requestCheckUserExists = () => ({
  type: REQUEST_CHECK_USER_EXISTS
});

export const receiveCheckUserExists = json => ({
  type: RECEIVE_CHECK_USER_EXISTS,
  payload: json
});

export const fetchCheckUserExists = data => dispatch => {
  const method = "check_user_exists";
  dispatch(requestCheckUserExists());
  return jsonRPCRequest(PORTAL_SERVICE_URL, method, data)
    .then(response => response.json())
    .then(json => dispatch(checkAuth(json)))
    .then(json => dispatch(receiveCheckUserExists(json)));
};


/*
add_dependent_user
 */
export const requestAddDependentUser = () => ({
  type: REQUEST_ADD_DEPENDENT_USER
});

export const receiveAddDependentUser = json => ({
  type: RECEIVE_ADD_DEPENDENT_USER,
  payload: json
});

export const fetchAddDependentUser = data => dispatch => {
  const method = "add_dependent_user";
  dispatch(requestAddDependentUser());
  return jsonRPCRequest(PORTAL_SERVICE_URL, method, data)
    .then(response => response.json())
    .then(json => dispatch(checkAuth(json)))
    .then(json => dispatch(receiveAddDependentUser(json)));
};


/*
set_do_not_disturb_state
 */
export const requestSetDoNotDisturbState = () => ({
  type: REQUEST_SET_DO_NOT_DISTURB_STATE
});

export const receiveSetDoNotDisturbState = json => ({
  type: RECEIVE_SET_DO_NOT_DISTURB_STATE,
  payload: json
});

export const fetchSetDoNotDisturbState = data => dispatch => {
  const method = "set_do_not_disturb_state";
  dispatch(requestSetDoNotDisturbState());
  return jsonRPCRequest(PORTAL_SERVICE_URL, method, data)
    .then(response => response.json())
    .then(json => dispatch(checkAuth(json)))
    .then(json => dispatch(receiveSetDoNotDisturbState(json)));
};



