import { jsonRPCRequest } from "./asyncActions";
import { checkAuth } from "./user";
import { HOST_NAME, PROTOCOL } from "../constants";

const SERVICE_URL = `${PROTOCOL}//api.${HOST_NAME}/comments/`;

export const REQUEST_GET_COMMENTS = "REQUEST_GET_COMMENTS";
export const RECEIVE_GET_COMMENTS = "RECEIVE_GET_COMMENTS";
export const CLEAR_COMMENTS = "CLEAR_COMMENTS";

export const REQUEST_ADD_COMMENT = "REQUEST_ADD_COMMENT";
export const RECEIVE_ADD_COMMENT = "RECEIVE_ADD_COMMENT";

export const REQUEST_SET_COMMENT = "REQUEST_SET_COMMENT";
export const RECEIVE_SET_COMMENT = "RECEIVE_SET_COMMENT";

/****************** get comments *******************/
export const requestGetComments = () => ({
  type: REQUEST_GET_COMMENTS
});

export const receiveGetComments = json => ({
  type: RECEIVE_GET_COMMENTS,
  payload: json
});

export const clearComments = () => ({
  type: CLEAR_COMMENTS
});

export const fetchGetComments = data => dispatch => {
  const method = "get_comments";
  dispatch(requestGetComments());
  return jsonRPCRequest(SERVICE_URL, method, data)
    .then(response => response.json())
    .then(json => dispatch(checkAuth(json)))
    .then(json => dispatch(receiveGetComments(json)));
};

/****************** add comment *******************/
export const requestAddComments = () => ({
  type: REQUEST_ADD_COMMENT
});

export const receiveAddComments = json => ({
  type: RECEIVE_ADD_COMMENT,
  payload: json
});

export const fetchAddComment = data => dispatch => {
  const method = "add_comment";
  dispatch(requestAddComments());
  return jsonRPCRequest(SERVICE_URL, method, data)
    .then(response => response.json())
    .then(json => dispatch(checkAuth(json)))
    .then(json => dispatch(receiveAddComments(json)));
};

/****************** set comment *******************/
export const requestSetComments = () => ({
  type: REQUEST_SET_COMMENT
});

export const receiveSetComments = json => ({
  type: RECEIVE_SET_COMMENT,
  payload: json
});

export const fetchSetComment = data => dispatch => {
  const method = "set_comment";
  dispatch(requestSetComments());
  return jsonRPCRequest(SERVICE_URL, method, data)
    .then(response => response.json())
    .then(json => dispatch(checkAuth(json)))
    .then(json => dispatch(receiveSetComments(json)));
};
