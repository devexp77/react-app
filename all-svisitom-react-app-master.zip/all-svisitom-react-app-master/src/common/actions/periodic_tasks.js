import {jsonRPCRequest} from "./asyncActions";
import {checkAuth} from "./user";
import { HOST_NAME, PROTOCOL } from '../constants';

export const REQUEST_ADD_PERIODIC_TASK = 'REQUEST_ADD_PERIODIC_TASK';
export const RECEIVE_ADD_PERIODIC_TASK  = 'RECEIVE_ADD_PERIODIC_TASK';

export const REQUEST_SET_PERIODIC_TASK = 'REQUEST_SET_PERIODIC_TASK';
export const RECEIVE_SET_PERIODIC_TASK  = 'RECEIVE_SET_PERIODIC_TASK';

export const REQUEST_DELETE_PERIODIC_TASKS = 'REQUEST_DELETE_PERIODIC_TASKS';
export const RECEIVE_DELETE_PERIODIC_TASKS  = 'RECEIVE_DELETE_PERIODIC_TASKS';

export const REQUEST_PERIODIC_TASKS = 'REQUEST_PERIODIC_TASKS';
export const RECEIVE_PERIODIC_TASKS = 'RECEIVE_PERIODIC_TASKS';
export const CLEAR_PERIODIC_TASKS = 'CLEAR_PERIODIC_TASKS';

export const REQUEST_PERIODIC_TASK_BY_ID = 'REQUEST_PERIODIC_TASK_BY_ID';
export const RECEIVE_PERIODIC_TASK_BY_ID = 'RECEIVE_PERIODIC_TASK_BY_ID';
export const CLEAR_PERIODIC_TASK_BY_ID = 'CLEAR_PERIODIC_TASK_BY_ID';

const SERVICE_URL =`${PROTOCOL}//api.${HOST_NAME}/periodic_tasks/`;

/****************** add task *******************/
export const requestAddPeriodicTask = () => ({
  type: REQUEST_ADD_PERIODIC_TASK
});

export const receiveAddPeriodicTask = (json) => ({
  type: RECEIVE_ADD_PERIODIC_TASK,
  payload: json
});

export const fetchAddPeriodicTask = (data) => dispatch => {
  const method = 'add_task';
  dispatch(requestAddPeriodicTask());
  return jsonRPCRequest(SERVICE_URL,method, data)
  .then(response => response.json())
  .then(json => dispatch(checkAuth(json)))
  .then(json => dispatch(receiveAddPeriodicTask(json), ))
};

/****************** set task *******************/
export const requestSetPeriodicTask = () => ({
  type: REQUEST_SET_PERIODIC_TASK
});

export const receiveSetPeriodicTask = (json) => ({
  type: RECEIVE_SET_PERIODIC_TASK,
  payload: json
});

export const fetchSetPeriodicTask = (data) => dispatch => {
  const method = 'set_task';
  dispatch(requestSetPeriodicTask());
  return jsonRPCRequest(SERVICE_URL,method, data)
  .then(response => response.json())
  .then(json => dispatch(checkAuth(json)))
  .then(json => dispatch(receiveSetPeriodicTask(json), ))
};

/****************** delete task *******************/
export const requestDeletePeriodicTasks = () => ({
  type: REQUEST_DELETE_PERIODIC_TASKS
});

export const receiveDeletePeriodicTasks = (json) => ({
  type: RECEIVE_DELETE_PERIODIC_TASKS,
  payload: json
});

export const fetchADeletePeriodicTasks = (data) => dispatch => {
  const method = 'delete_tasks';
  dispatch(requestDeletePeriodicTasks());
  return jsonRPCRequest(SERVICE_URL,method, data)
  .then(response => response.json())
  .then(json => dispatch(checkAuth(json)))
  .then(json => dispatch(receiveDeletePeriodicTasks(json), ))
};


/****************** get tasks *******************/
export const requestPeriodicTasks = () => ({
  type: REQUEST_PERIODIC_TASKS
});

export const receivePeriodicTasks = (json) => ({
  type: RECEIVE_PERIODIC_TASKS,
  payload: json
});

export const clearPeriodicTasks = () => ({
  type: CLEAR_PERIODIC_TASKS
});

export const fetchPeriodicTasks = (data) => dispatch => {
  const method = 'get_tasks';
  dispatch(requestPeriodicTasks());
  return jsonRPCRequest(SERVICE_URL,method, data)
  .then(response => response.json())
  .then(json => dispatch(checkAuth(json)))
  .then(json => dispatch(receivePeriodicTasks(json), ))
};

/****************** get task *******************/
export const requestPeriodicTaskById = () => ({
  type: REQUEST_PERIODIC_TASK_BY_ID
});

export const receivePeriodicTaskById = (json) => ({
  type: RECEIVE_PERIODIC_TASK_BY_ID,
  payload: json
});

export const clearPeriodicTaskById = () => ({
  type: CLEAR_PERIODIC_TASK_BY_ID
});

export const fetchPeriodicTaskById = (data) => dispatch => {
  const method = 'get_task';
  dispatch(requestPeriodicTaskById());
  return jsonRPCRequest(SERVICE_URL,method, data)
  .then(response => response.json())
  .then(json => dispatch(checkAuth(json)))
  .then(json => dispatch(receivePeriodicTaskById(json), ))
};
