import { jsonRPCRequest } from "./asyncActions";
import { push } from "react-router-redux";
import { HOST_NAME, PROTOCOL } from "../constants";

export const REQUEST_PERMIT_RECORDS = "REQUEST_PERMIT_RECORDS";
export const RECEIVE_PERMIT_RECORDS = "RECEIVE_PERMIT_RECORDS";
export const CLEAR_PERMIT_RECORDS = "CLEAR_PERMIT_RECORDS";
export const RECEIVE_SCROLL_PERMIT_RECORDS = "RECEIVE_SCROLL_PERMIT_RECORDS";

export const REQUEST_PERMIT_RECORD_ID = "REQUEST_PERMIT_RECORD_ID";
export const RECEIVE_PERMIT_RECORD_ID = "RECEIVE_PERMIT_RECORD_ID";

export const REQUEST_SET_PERMIT_RECORD = "REQUEST_SET_PERMIT_RECORD";
export const RECEIVE_SET_PERMIT_RECORD = "RECEIVE_SET_PERMIT_RECORD";

export const REQUEST_PERMIT_RECORDS_IDS = "REQUEST_PERMIT_RECORDS_IDS";
export const RECEIVE_PERMIT_RECORDS_IDS = "RECEIVE_PERMIT_RECORDS_IDS";

export const CLEAR_PERMIT_RECORD_BY_ID = "CLEAR_PERMIT_RECORD_BY_ID";

export const REQUEST_REGISTER_PASS = "REQUEST_REGISTER_PASS";
export const RECEIVE_REGISTER_PASS = "RECEIVE_REGISTER_PASS";

export const REQUEST_PERMIT_ALLOWED_ACTIONS = "REQUEST_PERMIT_ALLOWED_ACTIONS";
export const RECEIVE_PERMIT_ALLOWED_ACTIONS = "RECEIVE_PERMIT_ALLOWED_ACTIONS";
export const CLEAR_PERMIT_ALLOWED_ACTIONS = "CLEAR_PERMIT_ALLOWED_ACTIONS";

export const REQUEST_CHANGE_PERMIT_STATUS = "REQUEST_CHANGE_PERMIT_STATUS";
export const RECEIVE_CHANGE_PERMIT_STATUS = "RECEIVE_CHANGE_PERMIT_STATUS";

export const REQUEST_NOTIFY_VISITOR_IS_WAITING = "REQUEST_NOTIFY_VISITOR_IS_WAITING";
export const RECEIVE_NOTIFY_VISITOR_IS_WAITING = "RECEIVE_NOTIFY_VISITOR_IS_WAITING";

export const RECEIVE_IS_PERMIT_IN_FILTER = "RECEIVE_IS_PERMIT_IN_FILTER";
export const REQUEST_IS_PERMIT_IN_FILTER = "REQUEST_IS_PERMIT_IN_FILTER";

export const REQUEST_PERMIT_COUNT = "REQUEST_PERMIT_COUNT";
export const RECEIVE_PERMIT_COUNT = "RECEIVE_PERMIT_COUNT";

export const REQUEST_CHANGE_PERMIT_SUSPEND_STATE = "REQUEST_CHANGE_PERMIT_SUSPEND_STATE";
export const RECEIVE_CHANGE_PERMIT_SUSPEND_STATE = "RECEIVE_CHANGE_PERMIT_SUSPEND_STATE";

export const SAVE_PERMITS_FILTER = "SAVE_PERMITS_FILTER";

export const SAVE_PERMITS_OFFSET = "SAVE_PERMITS_OFFSET";

export const toPermits = () => dispatch => {
  dispatch(push("/permits"));
};

const PORTAL_SERVICE_URL = `${PROTOCOL}//api.${HOST_NAME}/permits/`;

export const requestPermitRecords = () => ({
  type: REQUEST_PERMIT_RECORDS
});

export const receivePermitRecords = json => ({
  type: RECEIVE_PERMIT_RECORDS,
  permitRecords: json
});

export const clearPermitRecords = () => ({
  type: CLEAR_PERMIT_RECORDS
});

export const receiveScrollPermitRecords = json => ({
  type: RECEIVE_SCROLL_PERMIT_RECORDS,
  permitRecords: json
});

export const fetchPermitRecords = data => dispatch => {
  const method = "get_permits";
  dispatch(requestPermitRecords());
  return jsonRPCRequest(PORTAL_SERVICE_URL, method, data)
    .then(response => response.json())
    .then(json => dispatch(receivePermitRecords(json)));
};

export const fetchScrollPermitRecords = data => dispatch => {
  const method = "get_permits";
  dispatch(requestPermitRecords());
  return jsonRPCRequest(PORTAL_SERVICE_URL, method, data)
    .then(response => response.json())
    .then(json => dispatch(receiveScrollPermitRecords(json)));
};

export const requestPermitRecordById = () => ({
  type: REQUEST_PERMIT_RECORD_ID
});

export const receivePermitRecordById = json => ({
  type: RECEIVE_PERMIT_RECORD_ID,
  permitRecordById: json
});

export const clearPermitRecordById = () => ({
  type: CLEAR_PERMIT_RECORD_BY_ID
});

export const fetchPermitRecordById = data => dispatch => {
  const method = "get_permit";
  dispatch(requestPermitRecordById());
  return jsonRPCRequest(PORTAL_SERVICE_URL, method, data)
    .then(response => response.json())
    .then(json => dispatch(receivePermitRecordById(json)));
};


export const requestSetPermitRecord = () => ({
  type: REQUEST_SET_PERMIT_RECORD
});

export const receiveSetPermitRecord = json => ({
  type: RECEIVE_SET_PERMIT_RECORD,
  payload: json
});


export const fetchSetPermitRecord = data => dispatch => {
  const method = "set_permit";
  dispatch(requestSetPermitRecord());
  return jsonRPCRequest(PORTAL_SERVICE_URL, method, data)
    .then(response => response.json())
    .then(json => dispatch(receiveSetPermitRecord(json)));
};

export const requestRegisterPass = () => ({
  type: REQUEST_REGISTER_PASS
});

export const receiveRegisterPass = json => ({
  type: RECEIVE_REGISTER_PASS,
  registerPassStatus: json
});

export const fetchRegisterPass = data => dispatch => {
  const method = "register_pass";
  dispatch(requestRegisterPass());
  return jsonRPCRequest(PORTAL_SERVICE_URL, method, data)
    .then(response => response.json())
    .then(json => dispatch(receiveRegisterPass(json)));
};

export const toPermit = permit_id => dispatch => {
  dispatch(push("/permits/permit/" + permit_id));
};

export const requestPermitRecordByIds = () => ({
  type: REQUEST_PERMIT_RECORDS_IDS
});

export const receivePermitRecordByIds = json => ({
  type: RECEIVE_PERMIT_RECORDS_IDS,
  payload: json
});

export const fetchPermitRecordByIds = data => dispatch => {
  const method = "get_permits_by_ids";
  dispatch(requestPermitRecordByIds());
  return jsonRPCRequest(PORTAL_SERVICE_URL, method, data)
    .then(response => response.json())
    .then(json => dispatch(receivePermitRecordByIds(json)));
};

export const savePermitsFilter = json => ({
  type: SAVE_PERMITS_FILTER,
  payload: json
});

export const savePermitsOffset = json => ({
  type: SAVE_PERMITS_OFFSET,
  payload: json
});

export const requestPermitAllowedActions = () => ({
  type: REQUEST_PERMIT_ALLOWED_ACTIONS
});

export const receivePermitAllowedActions = json => ({
  type: RECEIVE_PERMIT_ALLOWED_ACTIONS,
  payload: json
});

export const clearPermitAllowedActions = json => ({
  type: CLEAR_PERMIT_ALLOWED_ACTIONS,
  payload: json
});

export const fetchPermitAllowedActions = data => dispatch => {
  const method = "get_allowed_actions";
  dispatch(requestPermitAllowedActions());
  return jsonRPCRequest(PORTAL_SERVICE_URL, method, data)
    .then(response => response.json())
    .then(json => dispatch(receivePermitAllowedActions(json)));
};

export const requestChangePermitStatus = () => ({
  type: REQUEST_CHANGE_PERMIT_STATUS
});

export const receiveChangePermitStatus = json => ({
  type: RECEIVE_CHANGE_PERMIT_STATUS,
  payload: json
});

export const fetchChangePermitStatus = data => dispatch => {
  const method = "change_permit_status";
  dispatch(requestChangePermitStatus());
  return jsonRPCRequest(PORTAL_SERVICE_URL, method, data)
    .then(response => response.json())
    .then(json => dispatch(receiveChangePermitStatus(json)));
};

export const requestNotifyVisitorIsWaiting = () => ({
  type: REQUEST_NOTIFY_VISITOR_IS_WAITING
});

export const receiveNotifyVisitorIsWaiting = json => ({
  type: RECEIVE_NOTIFY_VISITOR_IS_WAITING,
  payload: json
});

export const fetchNotifyVisitorIsWaiting = data => dispatch => {
  const method = "notify_visitor_is_waiting";
  dispatch(requestNotifyVisitorIsWaiting());
  return jsonRPCRequest(PORTAL_SERVICE_URL, method, data)
    .then(response => response.json())
    .then(json => dispatch(receiveNotifyVisitorIsWaiting(json)));
};

export const requestIsPermitInFilter = () => ({
  type: REQUEST_IS_PERMIT_IN_FILTER
});

export const receiveIsPermitInFilter = json => ({
  type: RECEIVE_IS_PERMIT_IN_FILTER,
  payload: json
});

export const fetchIsPermitInFilter = data => dispatch => {
  const method = "get_permits";
  dispatch(requestIsPermitInFilter());
  return jsonRPCRequest(PORTAL_SERVICE_URL, method, data)
    .then(response => response.json())
    .then(json => dispatch(receiveIsPermitInFilter(json)));
};

export const requestPermitCount = () => ({
  type: REQUEST_PERMIT_COUNT
});

export const receivePermitCount = (json, field) => ({
  type: RECEIVE_PERMIT_COUNT,
  payload: json,
  field: field
});

export const fetchPermitCount = (data, field) => dispatch => {
  const method = "get_permits_count";
  dispatch(requestPermitCount());
  return jsonRPCRequest(PORTAL_SERVICE_URL, method, data)
    .then(response => response.json())
    .then(json => dispatch(receivePermitCount(json, field)));
};


export const requestChangePermitSuspendState = () => ({
  type: REQUEST_CHANGE_PERMIT_SUSPEND_STATE
});

export const receiveChangePermitSuspendState = json => ({
  type: RECEIVE_CHANGE_PERMIT_SUSPEND_STATE,
  payload: json
});

export const fetchChangePermitSuspendState = data => dispatch => {
  const method = "change_permit_suspend_state";
  dispatch(requestChangePermitSuspendState());
  return jsonRPCRequest(PORTAL_SERVICE_URL, method, data)
    .then(response => response.json())
    .then(json => dispatch(receiveChangePermitSuspendState(json)));
};
