import {jsonRPCRequest} from "./asyncActions";
import {checkAuth} from "./user";
import { HOST_NAME, PROTOCOL } from '../constants';


export const REQUEST_ENTITY_ROLES = 'REQUEST_ENTITY_ROLES';
export const RECEIVE_ENTITY_ROLES = 'RECEIVE_ENTITY_ROLES';
export const CLEAR_ENTITY_ROLES = 'CLEAR_ENTITY_ROLES';

export const REQUEST_SET_ENTITY_ROLES = 'REQUEST_SET_ENTITY_ROLES';
export const RECEIVE_SET_ENTITY_ROLES = 'RECEIVE_SET_ENTITY_ROLES';

const PORTAL_SERVICE_URL =`${PROTOCOL}//api.${HOST_NAME}/roles/`;


/****************** get entity_ids_by_roles *******************/
export const requestEntityRoles = () => ({
  type: REQUEST_ENTITY_ROLES
});

export const receiveEntityRoles = (json) => ({
  type: RECEIVE_ENTITY_ROLES,
  payload: json
});

export const clearEntityRoles = () => ({
  type: CLEAR_ENTITY_ROLES
});

export const fetchEntityRoles = (data) => dispatch => {
  const method = 'get_roles';
  dispatch(requestEntityRoles());
  return jsonRPCRequest(PORTAL_SERVICE_URL,method, data)
  .then(response => response.json())
  .then(json => dispatch(checkAuth(json)))
  .then(json => dispatch(receiveEntityRoles(json), ))
};

/****************************************************/

/*
  set_roles
*/

export const requestSetEntityRoles = () => ({
  type: REQUEST_SET_ENTITY_ROLES
});

export const receiveSetEntityRoles = (json) => ({
  type: RECEIVE_SET_ENTITY_ROLES,
  payload: json
});

export const fetchSetEntityRoles = (data) => dispatch => {
  const method = 'set_roles';
  dispatch(requestSetEntityRoles());
  return jsonRPCRequest(PORTAL_SERVICE_URL,method, data)
  .then(response => response.json())
  .then(json => dispatch(checkAuth(json)))
  .then(json => dispatch(receiveSetEntityRoles(json), ))
};
