import {jsonRPCRequest} from "./asyncActions";
import {checkAuth} from "./user";
import { HOST_NAME, PROTOCOL } from '../constants';

export const REQUEST_ROOM_FACILITY_CONFIG_BY_ROOM_ID = 'REQUEST_ROOM_FACILITY_CONFIG_BY_ROOM_ID';
export const RECEIVE_ROOM_FACILITY_CONFIG_BY_ROOM_ID  = 'RECEIVE_ROOM_FACILITY_CONFIG_BY_ROOM_ID';
export const CLEAR_ROOM_FACILITY_CONFIG_BY_ROOM_ID  = 'CLEAR_ROOM_FACILITY_CONFIG_BY_ROOM_ID';

export const REQUEST_SET_ROOM_FACILITY_CONFIG = 'REQUEST_SET_ROOM_FACILITY_CONFIG';
export const RECEIVE_SET_ROOM_FACILITY_CONFIG  = 'RECEIVE_SET_ROOM_FACILITY_CONFIG';

export const REQUEST_DELETE_ROOM_FACILITY_CONFIG = 'REQUEST_DELETE_ROOM_FACILITY_CONFIG';
export const RECEIVE_DELETE_ROOM_FACILITY_CONFIG  = 'RECEIVE_DELETE_ROOM_FACILITY_CONFIG';

export const REQUEST_ADD_ROOM_FACILITY_CONFIG = 'REQUEST_ADD_ROOM_FACILITY_CONFIG';
export const RECEIVE_ADD_ROOM_FACILITY_CONFIG  = 'RECEIVE_ADD_ROOM_FACILITY_CONFIG';

export const REQUEST_FACILITY_AVAILABLE_MASTERS = 'REQUEST_FACILITY_AVAILABLE_MASTERS';
export const RECEIVE_FACILITY_AVAILABLE_MASTERS  = 'RECEIVE_FACILITY_AVAILABLE_MASTERS';
export const CLEAR_FACILITY_AVAILABLE_MASTERS  = 'CLEAR_FACILITY_AVAILABLE_MASTERS';

export const REQUEST_SET_FACILITY_PROBLEM = 'REQUEST_SET_FACILITY_PROBLEM';
export const RECEIVE_SET_FACILITY_PROBLEM = 'RECEIVE_SET_FACILITY_PROBLEM';

export const REQUEST_ADD_FACILITY_PROBLEM = 'REQUEST_ADD_FACILITY_PROBLEM';
export const RECEIVE_ADD_FACILITY_PROBLEM = 'RECEIVE_ADD_FACILITY_PROBLEM';

export const REQUEST_DELETE_FACILITY_PROBLEM = 'REQUEST_DELETE_FACILITY_PROBLEM';
export const RECEIVE_DELETE_FACILITY_PROBLEM = 'RECEIVE_DELETE_FACILITY_PROBLEM';

export const REQUEST_FACILITY_PROBLEM_BY_ID = 'REQUEST_FACILITY_PROBLEM_BY_ID';
export const RECEIVE_FACILITY_PROBLEM_BY_ID  = 'RECEIVE_FACILITY_PROBLEM_BY_ID';
export const CLEAR_FACILITY_PROBLEM_BY_ID  = 'CLEAR_FACILITY_PROBLEM_BY_ID';

export const REQUEST_FACILITY_PROBLEMS = 'REQUEST_FACILITY_PROBLEMS';
export const RECEIVE_FACILITY_PROBLEMS  = 'RECEIVE_FACILITY_PROBLEMS';
export const CLEAR_FACILITY_PROBLEMS  = 'CLEAR_FACILITY_PROBLEMS';

export const REQUEST_USER_SPECIALIZATION = 'REQUEST_USER_SPECIALIZATION';
export const RECEIVE_USER_SPECIALIZATION  = 'RECEIVE_USER_SPECIALIZATION';
export const CLEAR_USER_SPECIALIZATION  = 'CLEAR_USER_SPECIALIZATION';

const SERVICE_URL =`${PROTOCOL}//api.${HOST_NAME}/facility/`;

export const REQUEST_ATTACH_DOCUMENT_TO_PROBLEM = "REQUEST_ATTACH_DOCUMENT_TO_PROBLEM";
export const RECEIVE_ATTACH_DOCUMENT_TO_PROBLEM = "RECEIVE_ATTACH_DOCUMENT_TO_PROBLEM";

export const REQUEST_DETACH_DOCUMENT_TO_PROBLEM = "REQUEST_DETACH_DOCUMENT_TO_PROBLEM";
export const RECEIVE_DETACH_DOCUMENT_TO_PROBLEM = "RECEIVE_DETACH_DOCUMENT_TO_PROBLEM";

export const SET_FROM_OBJECT_FLAG = "SET_FROM_OBJECT_FLAG";


export const setFromObjectFlag = () => ({
  type: SET_FROM_OBJECT_FLAG
});



/****************** get room facility config *******************/
export const roomFacilityConfigByRoomIdRequest = () => ({
  type: REQUEST_ROOM_FACILITY_CONFIG_BY_ROOM_ID
});

export const clearRoomFacilityConfigByRoomId = () => ({
  type: CLEAR_ROOM_FACILITY_CONFIG_BY_ROOM_ID
});

export const roomFacilityConfigByRoomIdReceive = (json) => ({
  type: RECEIVE_ROOM_FACILITY_CONFIG_BY_ROOM_ID,
  payload: json
});

export const fetchRoomFacilityConfigByRoomId= (data) => dispatch => {
  const method = 'get_room_facility_config';
  dispatch(roomFacilityConfigByRoomIdRequest());
  return jsonRPCRequest(SERVICE_URL,method, data)
    .then(response => response.json())
    .then(json => dispatch(checkAuth(json)))
    .then(json => dispatch(roomFacilityConfigByRoomIdReceive(json), ))
};

/****************** set room facility config *******************/
export const requestSetRoomFacilityConfig = () => ({
  type: REQUEST_SET_ROOM_FACILITY_CONFIG
});

export const receiveSetRoomFacilityConfig = (json) => ({
  type: RECEIVE_SET_ROOM_FACILITY_CONFIG,
  payload: json
});

export const fetchSetRoomFacilityConfig= (data) => dispatch => {
  const method = 'set_room_facility_config';
  dispatch(requestSetRoomFacilityConfig());
  return jsonRPCRequest(SERVICE_URL,method, data)
    .then(response => response.json())
    .then(json => dispatch(checkAuth(json)))
    .then(json => dispatch(receiveSetRoomFacilityConfig(json), ))
};

/****************** delete room facility config *******************/
export const requestDeleteRoomFacilityConfig = () => ({
  type: REQUEST_DELETE_ROOM_FACILITY_CONFIG
});

export const receiveDeleteRoomFacilityConfig = (json) => ({
  type: RECEIVE_DELETE_ROOM_FACILITY_CONFIG,
  payload: json
});

export const fetchDeleteRoomFacilityConfig= (data) => dispatch => {
  const method = 'delete_room_facility_configs';
  dispatch(requestDeleteRoomFacilityConfig());
  return jsonRPCRequest(SERVICE_URL,method, data)
    .then(response => response.json())
    .then(json => dispatch(checkAuth(json)))
    .then(json => dispatch(receiveDeleteRoomFacilityConfig(json), ))
};

/****************** add room facility config *******************/
export const requestAddRoomFacilityConfig = () => ({
  type: REQUEST_ADD_ROOM_FACILITY_CONFIG
});

export const receiveAddRoomFacilityConfig = (json) => ({
  type: RECEIVE_ADD_ROOM_FACILITY_CONFIG,
  payload: json
});

export const fetchAddRoomFacilityConfig= (data) => dispatch => {
  const method = 'add_room_facility_config';
  dispatch(requestAddRoomFacilityConfig());
  return jsonRPCRequest(SERVICE_URL,method, data)
    .then(response => response.json())
    .then(json => dispatch(checkAuth(json)))
    .then(json => dispatch(receiveAddRoomFacilityConfig(json), ))
};


/****************** get facility problems by ids *******************/
export const facilityProblemsRequest = () => ({
  type: REQUEST_FACILITY_PROBLEMS
});

export const clearFacilityProblems = () => ({
  type: CLEAR_FACILITY_PROBLEMS
});

export const facilityProblemsReceive = (json) => ({
  type: RECEIVE_FACILITY_PROBLEMS,
  payload: json
});

export const fetchFacilityProblems= (data) => dispatch => {
  const method = 'get_problems';
  dispatch(facilityProblemsRequest());
  return jsonRPCRequest(SERVICE_URL,method, data)
    .then(response => response.json())
    .then(json => dispatch(checkAuth(json)))
    .then(json => dispatch(facilityProblemsReceive(json), ))
};

/****************** get facility problem by id *******************/
export const facilityProblemByIdRequest = () => ({
  type: REQUEST_FACILITY_PROBLEM_BY_ID
});

export const clearFacilityProblemById = () => ({
  type: CLEAR_FACILITY_PROBLEM_BY_ID
});

export const facilityProblemByIdReceive = (json) => ({
  type: RECEIVE_FACILITY_PROBLEM_BY_ID,
  payload: json
});

export const fetchFacilityProblemById= (data) => dispatch => {
  const method = 'get_problem';
  dispatch(facilityProblemByIdRequest());
  return jsonRPCRequest(SERVICE_URL,method, data)
    .then(response => response.json())
    .then(json => dispatch(checkAuth(json)))
    .then(json => dispatch(facilityProblemByIdReceive(json), ))
};

/****************** add *******************/
export const addFacilityProblemRequest = () => ({
  type: REQUEST_ADD_FACILITY_PROBLEM
});

export const addFacilityProblemReceive = (json) => ({
  type: RECEIVE_ADD_FACILITY_PROBLEM,
  payload: json
});

export const fetchAddFacilityProblem= (data) => dispatch => {
  const method = 'add_problem';
  dispatch(addFacilityProblemRequest());
  return jsonRPCRequest(SERVICE_URL,method, data)
    .then(response => response.json())
    .then(json => dispatch(checkAuth(json)))
    .then(json => dispatch(addFacilityProblemReceive(json), ))
};


/****************** set *******************/
export const setFacilityProblemRequest = () => ({
  type: REQUEST_SET_FACILITY_PROBLEM
});

export const setFacilityProblemReceive = (json) => ({
  type: RECEIVE_SET_FACILITY_PROBLEM,
  payload: json
});

export const fetchSetFacilityProblem= (data) => dispatch => {
  const method = 'set_problem';
  dispatch(setFacilityProblemRequest());
  return jsonRPCRequest(SERVICE_URL,method, data)
    .then(response => response.json())
    .then(json => dispatch(checkAuth(json)))
    .then(json => dispatch(setFacilityProblemReceive(json), ))
};


/****************** delete *******************/
export const deleteFacilityProblemRequest = () => ({
  type: REQUEST_DELETE_FACILITY_PROBLEM
});

export const deleteFacilityProblemReceive = (json) => ({
  type: RECEIVE_DELETE_FACILITY_PROBLEM,
  payload: json
});

export const fetchDeleteFacilityProblem= (data) => dispatch => {
  const method = 'delete_problems';
  dispatch(deleteFacilityProblemRequest());
  return jsonRPCRequest(SERVICE_URL,method, data)
    .then(response => response.json())
    .then(json => dispatch(checkAuth(json)))
    .then(json => dispatch(deleteFacilityProblemReceive(json), ))
};

/********************** get available masters ****************************/

export const facilityAvailableMastersRequest = () => ({
  type: REQUEST_FACILITY_AVAILABLE_MASTERS
});

export const clearFacilityAvailableMasters = () => ({
  type: CLEAR_FACILITY_AVAILABLE_MASTERS
});

export const facilityAvailableMastersReceive = (json) => ({
  type: RECEIVE_FACILITY_AVAILABLE_MASTERS,
  payload: json
});

export const fetchFacilityAvailableMasters= (data) => dispatch => {
  const method = 'get_available_masters';
  dispatch(facilityAvailableMastersRequest());
  return jsonRPCRequest(SERVICE_URL,method, data)
    .then(response => response.json())
    .then(json => dispatch(checkAuth(json)))
    .then(json => dispatch(facilityAvailableMastersReceive(json), ))
};

/********************** get user specialization****************************/

export const requestUserSpecialization = () => ({
  type: REQUEST_USER_SPECIALIZATION
});

export const clearUserSpecialization = () => ({
  type: CLEAR_USER_SPECIALIZATION
});

export const receiveUserSpecialization = (json) => ({
  type: RECEIVE_USER_SPECIALIZATION,
  payload: json
});

export const fetchUserSpecialization= (data) => dispatch => {
  const method = 'get_user_specialization';
  dispatch(requestUserSpecialization());
  return jsonRPCRequest(SERVICE_URL,method, data)
    .then(response => response.json())
    .then(json => dispatch(checkAuth(json)))
    .then(json => dispatch(receiveUserSpecialization(json), ))
};

/*************** attach document *******************************/
export const requestAttachDocumentToProblem = () => ({
  type: REQUEST_ATTACH_DOCUMENT_TO_PROBLEM
});

export const receiveAttachDocumentToProblem = json => ({
  type: RECEIVE_ATTACH_DOCUMENT_TO_PROBLEM,
  payload: json
});


export const fetchAttachDocumentToProblem = data => dispatch => {
  const method = "attach_document_to_problem";
  dispatch(requestAttachDocumentToProblem());
  return jsonRPCRequest(SERVICE_URL, method, data)
    .then(response => response.json())
    .then(json => dispatch(checkAuth(json)))
    .then(json => dispatch(receiveAttachDocumentToProblem(json)));
};

/**********************************************/

/*************** detach document *******************************/
export const requestDetachDocumentFromProblem = () => ({
  type: REQUEST_DETACH_DOCUMENT_TO_PROBLEM
});

export const receiveDetachDocumentFromProblem = json => ({
  type: RECEIVE_DETACH_DOCUMENT_TO_PROBLEM,
  payload: json
});


export const fetchDetachDocumentFromProblem = data => dispatch => {
  const method = "detach_document_from_problem";
  dispatch(requestDetachDocumentFromProblem());
  return jsonRPCRequest(SERVICE_URL, method, data)
    .then(response => response.json())
    .then(json => dispatch(checkAuth(json)))
    .then(json => dispatch(receiveDetachDocumentFromProblem(json)));
};

/**********************************************/
