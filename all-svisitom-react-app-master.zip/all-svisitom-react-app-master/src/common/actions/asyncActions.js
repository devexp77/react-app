import fetch from "isomorphic-fetch";

export function jsonRPCRequest(endpoint, method, params) {
  return fetch(endpoint, {
    credentials: "include",
    method: "POST",
    headers: {
      Accept: "application/json",
      "Content-Type": "application/json"
    },
    body: JSON.stringify({
      jsonrpc: "2.0",
      id: "1",
      method: method,
      params: params
    })
  }).then(checkStatus);
}

function checkStatus(response) {
  if (response.status === 401) {
  } else if (response.status >= 200 && response.status < 300) {
    return response;
  } else {
    let error = new Error(response.statusText);
    error.response = response;
    throw error;
  }
}

export function postRequest(endpoint, data) {
  return fetch(endpoint, {
    credentials: "include",
    method: "POST",
    body: data
  });
}

export function GETRequest(url) {
  return fetch(url, {
    method: "GET",
  });
}
