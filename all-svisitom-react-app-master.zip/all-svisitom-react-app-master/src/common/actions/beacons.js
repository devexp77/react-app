import {jsonRPCRequest} from "./asyncActions";
import {checkAuth} from "./user";
import { HOST_NAME, PROTOCOL } from '../constants';

export const REQUEST_ADD_BEACON = 'REQUEST_ADD_BEACON';
export const RECEIVE_ADD_BEACON = 'RECEIVE_ADD_BEACON';

export const REQUEST_ATTACH_BEACON = 'REQUEST_ATTACH_BEACON';
export const RECEIVE_ATTACH_BEACON = 'RECEIVE_ATTACH_BEACON';

export const REQUEST_DETACH_BEACON = 'REQUEST_DETACH_BEACON';
export const RECEIVE_DETACH_BEACON = 'RECEIVE_DETACH_BEACON';

export const REQUEST_SET_BEACON = 'REQUEST_SET_BEACON';
export const RECEIVE_SET_BEACON = 'RECEIVE_SET_BEACON';

export const REQUEST_DELETE_BEACONS = 'REQUEST_DELETE_BEACONS';
export const RECEIVE_DELETE_BEACONS = 'RECEIVE_DELETE_BEACONS';

export const REQUEST_BEACONS = 'REQUEST_BEACONS';
export const RECEIVE_MORE_BEACONS = 'RECEIVE_MORE_BEACONS';
export const RECEIVE_BEACONS = 'RECEIVE_BEACONS';
export const CLEAR_BEACONS = 'CLEAR_BEACONS';

export const REQUEST_ALL_BEACONS = 'REQUEST_ALL_BEACONS';
export const RECEIVE_ALL_BEACONS = 'RECEIVE_ALL_BEACONS';
export const CLEAR_ALL_BEACONS = 'CLEAR_ALL_BEACONS';

export const REQUEST_BEACON_BY_ID = 'REQUEST_BEACON_BY_ID';
export const RECEIVE_BEACON_BY_ID = 'RECEIVE_BEACON_BY_ID';
export const CLEAR_BEACON_BY_ID = 'CLEAR_BEACON_BY_ID';


const SERVICE_URL =`${PROTOCOL}//api.${HOST_NAME}/beacons/`;


/****************** attach beacon *******************/
export const requestAttachBeacon = () => ({
  type: REQUEST_ATTACH_BEACON
});

export const receiveAttachBeacon = (json) => ({
  type: RECEIVE_ATTACH_BEACON,
  payload: json
});

export const fetchAttachBeacon = (data) => dispatch => {
  const method = 'attach';
  dispatch(requestAttachBeacon());
  return jsonRPCRequest(SERVICE_URL,method, data)
    .then(response => response.json())
    .then(json => dispatch(checkAuth(json)))
    .then(json => dispatch(receiveAttachBeacon(json), ))
};


/****************** detach beacon *******************/
export const requestDetachBeacon = () => ({
  type: REQUEST_ATTACH_BEACON
});

export const receiveDetachBeacon = (json) => ({
  type: RECEIVE_ATTACH_BEACON,
  payload: json
});

export const fetchDetachBeacon = (data) => dispatch => {
  const method = 'detach';
  dispatch(requestDetachBeacon());
  return jsonRPCRequest(SERVICE_URL,method, data)
    .then(response => response.json())
    .then(json => dispatch(checkAuth(json)))
    .then(json => dispatch(receiveDetachBeacon(json), ))
};


/****************** add beacon *******************/
export const addBeaconRequest = () => ({
  type: REQUEST_ADD_BEACON
});

export const addBeaconResult = (json) => ({
  type: RECEIVE_ADD_BEACON,
  payload: json
});

export const fetchAddBeacon = (data) => dispatch => {
  const method = 'add_beacon';
  dispatch(addBeaconRequest());
  return jsonRPCRequest(SERVICE_URL,method, data)
    .then(response => response.json())
    .then(json => dispatch(checkAuth(json)))
    .then(json => dispatch(addBeaconResult(json), ))
};


/****************** set beacon *******************/
export const setBeaconRequest = () => ({
  type: REQUEST_SET_BEACON
});

export const setBeaconResult = (json) => ({
  type: RECEIVE_SET_BEACON,
  payload: json
});

export const fetchSetBeacon = (data) => dispatch => {
  const method = 'set_beacon';
  dispatch(setBeaconRequest());
  return jsonRPCRequest(SERVICE_URL,method, data)
    .then(response => response.json())
    .then(json => dispatch(checkAuth(json)))
    .then(json => dispatch(setBeaconResult(json), ))
};


/****************** delete beacons *******************/
export const deleteBeaconsRequest = () => ({
  type: REQUEST_DELETE_BEACONS
});

export const deleteBeaconsResult = (json) => ({
  type: RECEIVE_DELETE_BEACONS,
  payload: json
});

export const fetchDeleteBeacons = (data) => dispatch => {
  const method = 'delete_beacons';
  dispatch(deleteBeaconsRequest());
  return jsonRPCRequest(SERVICE_URL,method, data)
    .then(response => response.json())
    .then(json => dispatch(checkAuth(json)))
    .then(json => dispatch(deleteBeaconsResult(json), ))
};



/****************** get beacons *******************/
export const clearBeacons = () => ({
  type: CLEAR_BEACONS
});

export const getBeaconsRequest = () => ({
  type: REQUEST_BEACONS
});

export const getBeaconsResult = (json) => ({
  type: RECEIVE_BEACONS,
  payload: json
});

export const getMoreBeaconsResult = (json) => ({
  type: RECEIVE_MORE_BEACONS,
  payload: json
});

export const fetchBeacons = (data) => dispatch => {
  const method = 'get_beacons';
  dispatch(getBeaconsRequest());
  return jsonRPCRequest(SERVICE_URL,method, data)
    .then(response => response.json())
    .then(json => dispatch(checkAuth(json)))
    .then(json => dispatch(getBeaconsResult(json), ))
};

export const fetchMoreBeacons = (data) => dispatch => {
  const method = 'get_beacons';
  dispatch(getBeaconsRequest());
  return jsonRPCRequest(SERVICE_URL,method, data)
    .then(response => response.json())
    .then(json => dispatch(checkAuth(json)))
    .then(json => dispatch(getMoreBeaconsResult(json), ))
};


export const clearAllBeacons = () => ({
  type: CLEAR_ALL_BEACONS
});

export const getAllBeaconsRequest = () => ({
  type: REQUEST_ALL_BEACONS
});

export const getAllBeaconsResult = (json) => ({
  type: RECEIVE_ALL_BEACONS,
  payload: json
});

export const fetchAllBeacons = (data) => dispatch => {
  const method = 'get_beacons';
  dispatch(getAllBeaconsRequest());
  return jsonRPCRequest(SERVICE_URL,method, data)
    .then(response => response.json())
    .then(json => dispatch(checkAuth(json)))
    .then(json => dispatch(getAllBeaconsResult(json), ))
};


/****************** get beacon by id *******************/
export const clearBeaconById = () => ({
  type: CLEAR_BEACON_BY_ID
});

export const getBeaconByIdRequest = () => ({
  type: REQUEST_BEACON_BY_ID
});

export const getBeaconByIdResult = (json) => ({
  type: RECEIVE_BEACON_BY_ID,
  payload: json
});

export const fetchBeaconById = (data) => dispatch => {
  const method = 'get_beacon';
  dispatch(getBeaconByIdRequest());
  return jsonRPCRequest(SERVICE_URL,method, data)
    .then(response => response.json())
    .then(json => dispatch(checkAuth(json)))
    .then(json => dispatch(getBeaconByIdResult(json), ))
};




