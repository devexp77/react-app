import {jsonRPCRequest} from "./asyncActions";
import {checkAuth} from "./user";
import { HOST_NAME, PROTOCOL } from '../constants';

export const REQUEST_ADD_MAP_ROUTE = 'REQUEST_ADD_MAP_ROUTE';
export const RECEIVE_ADD_MAP_ROUTE = 'RECEIVE_ADD_MAP_ROUTE';

export const REQUEST_SET_MAP_ROUTE = 'REQUEST_SET_MAP_ROUTE';
export const RECEIVE_SET_MAP_ROUTE = 'RECEIVE_SET_MAP_ROUTE';

export const REQUEST_DELETE_MAP_ROUTE = 'REQUEST_DELETE_MAP_ROUTE';
export const RECEIVE_DELETE_MAP_ROUTE = 'RECEIVE_DELETE_MAP_ROUTE';

export const REQUEST_MAP_ROUTES = 'REQUEST_MAP_ROUTES';
export const RECEIVE_MAP_ROUTES = 'RECEIVE_MAP_ROUTES';
export const CLEAR_MAP_ROUTES = 'CLEAR_MAP_ROUTES';

export const REQUEST_MAP_ROUTE_BY_ID = 'REQUEST_MAP_ROUTE_BY_ID';
export const RECEIVE_MAP_ROUTE_BY_ID = 'RECEIVE_MAP_ROUTE_BY_ID';
export const CLEAR_MAP_ROUTE_BY_ID = 'CLEAR_MAP_ROUTE_BY_ID';


const SERVICE_URL =`${PROTOCOL}//api.${HOST_NAME}/map_routes/`;


/****************** add map route *******************/
export const addMapRouteRequest = () => ({
  type: REQUEST_ADD_MAP_ROUTE
});

export const addMapRouteResult = (json) => ({
  type: RECEIVE_ADD_MAP_ROUTE,
  payload: json
});

export const fetchAddMapRoute = (data) => dispatch => {
  const method = 'add_map_route';
  dispatch(addMapRouteRequest());
  return jsonRPCRequest(SERVICE_URL,method, data)
    .then(response => response.json())
    .then(json => dispatch(checkAuth(json)))
    .then(json => dispatch(addMapRouteResult(json), ))
};


/****************** set map route *******************/
export const setMapRouteRequest = () => ({
  type: REQUEST_SET_MAP_ROUTE
});

export const setMapRouteResult = (json) => ({
  type: RECEIVE_SET_MAP_ROUTE,
  payload: json
});

export const fetchSetMapRoute = (data) => dispatch => {
  const method = 'set_map_route';
  dispatch(setMapRouteRequest());
  return jsonRPCRequest(SERVICE_URL,method, data)
    .then(response => response.json())
    .then(json => dispatch(checkAuth(json)))
    .then(json => dispatch(setMapRouteResult(json), ))
};


/****************** delete map route *******************/
export const deleteMapRouteRequest = () => ({
  type: REQUEST_DELETE_MAP_ROUTE
});

export const deleteMapRouteResult = (json) => ({
  type: RECEIVE_DELETE_MAP_ROUTE,
  payload: json
});

export const fetchDeleteMapRoute = (data) => dispatch => {
  const method = 'delete_map_route';
  dispatch(deleteMapRouteRequest());
  return jsonRPCRequest(SERVICE_URL,method, data)
    .then(response => response.json())
    .then(json => dispatch(checkAuth(json)))
    .then(json => dispatch(deleteMapRouteResult(json), ))
};



/****************** get map routes *******************/
export const clearMapRoutes = () => ({
  type: CLEAR_MAP_ROUTES
});

export const getMapRoutesRequest = () => ({
  type: REQUEST_MAP_ROUTES
});

export const getMapRoutesResult = (json) => ({
  type: RECEIVE_MAP_ROUTES,
  payload: json
});

export const fetchMapRoutes = (data) => dispatch => {
  const method = 'get_map_routes';
  dispatch(getMapRoutesRequest());
  return jsonRPCRequest(SERVICE_URL,method, data)
    .then(response => response.json())
    .then(json => dispatch(checkAuth(json)))
    .then(json => dispatch(getMapRoutesResult(json), ))
};

/****************** get map route by id *******************/
export const clearMapRouteById = () => ({
  type: CLEAR_MAP_ROUTE_BY_ID
});

export const getMapRouteByIdRequest = () => ({
  type: REQUEST_MAP_ROUTE_BY_ID
});

export const getMapRouteByIdResult = (json) => ({
  type: RECEIVE_MAP_ROUTE_BY_ID,
  payload: json
});

export const fetchMapRouteById = (data) => dispatch => {
  const method = 'get_map_route';
  dispatch(getMapRouteByIdRequest());
  return jsonRPCRequest(SERVICE_URL,method, data)
    .then(response => response.json())
    .then(json => dispatch(checkAuth(json)))
    .then(json => dispatch(getMapRouteByIdResult(json), ))
};




