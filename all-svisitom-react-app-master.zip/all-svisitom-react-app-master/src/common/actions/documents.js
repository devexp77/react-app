import { jsonRPCRequest } from "./asyncActions";
import { push } from "react-router-redux";
import { HOST_NAME, PROTOCOL } from "../constants";
import { checkAuth } from "./user";

export const REQUEST_USER_DOC = "REQUEST_USER_DOC";
export const RECEIVE_USER_DOC = "RECEIVE_USER_DOC";

export const REQUEST_USER_DOC_BY_ID = "REQUEST_USER_DOC_BY_ID";
export const RECEIVE_USER_DOC_BY_ID = "RECEIVE_USER_DOC_BY_ID";

export const REQUEST_ADD_USER_DOC = "REQUEST_ADD_USER_DOC";
export const RECEIVE_ADD_USER_DOC = "RECEIVE_ADD_USER_DOC";

export const REQUEST_SET_USER_DOC = "REQUEST_SET_USER_DOC";
export const RECEIVE_SET_USER_DOC = "RECEIVE_SET_USER_DOC";

export const REQUEST_DELETE_USER_DOC = "REQUEST_DELETE_USER_DOC";
export const RECEIVE_DELETE_USER_DOC = "RECEIVE_DELETE_USER_DOC";

export const CLEAR_USER_DOC_OPERATION_STATUS =
  "CLEAR_USER_DOC_OPERATION_STATUS";
export const CLEAR_USER_DOC_BY_ID = "CLEAR_USER_DOC_BY_ID";

const PORTAL_SERVICE_URL = `${PROTOCOL}//api.${HOST_NAME}/documents/`;

/*************get user documents********************/
export const requestUserDoc = () => ({
  type: REQUEST_USER_DOC
});

export const receiveUserDoc = json => ({
  type: RECEIVE_USER_DOC,
  payload: json
});

export const fetchUserDoc = data => dispatch => {
  const method = "get_documents";
  dispatch(requestUserDoc());
  return jsonRPCRequest(PORTAL_SERVICE_URL, method, data)
    .then(response => response.json())
    .then(json => dispatch(checkAuth(json)))
    .then(json => dispatch(receiveUserDoc(json)));
};
/*************************************************/

/*************** add document *******************/
export const requestAddUserDoc = json => ({
  type: REQUEST_ADD_USER_DOC,
  payload: json
});

export const receiveAddUserDoc = json => ({
  type: RECEIVE_ADD_USER_DOC,
  payload: json
});

export const fetchAddUserDoc = data => dispatch => {
  const method = "add_document";
  dispatch(requestAddUserDoc());
  return jsonRPCRequest(PORTAL_SERVICE_URL, method, data)
    .then(response => response.json())
    .then(json => dispatch(checkAuth(json)))
    .then(json => dispatch(receiveAddUserDoc(json)));
};
/***************************************************/

/*************** set user doc ********************/
export const requestSetUserDoc = json => ({
  type: REQUEST_SET_USER_DOC,
  payload: json
});

export const receiveSetUserDoc = json => ({
  type: RECEIVE_SET_USER_DOC,
  payload: json
});

export const fetchSetUserDoc = data => dispatch => {
  const method = "set_document";
  dispatch(requestSetUserDoc());
  return jsonRPCRequest(PORTAL_SERVICE_URL, method, data)
    .then(response => response.json())
    .then(json => dispatch(checkAuth(json)))
    .then(json => dispatch(receiveSetUserDoc(json)));
};
/****************************************************/

/************** delete user doc ******************/
export const requestDeleteUserDoc = json => ({
  type: REQUEST_DELETE_USER_DOC,
  payload: json
});

export const receiveDeleteUserDoc = json => ({
  type: RECEIVE_DELETE_USER_DOC,
  payload: json
});

export const fetchDeleteUserDoc = data => dispatch => {
  const method = "delete_documents";
  dispatch(requestDeleteUserDoc());
  return jsonRPCRequest(PORTAL_SERVICE_URL, method, data)
    .then(response => response.json())
    .then(json => dispatch(checkAuth(json)))
    .then(json => dispatch(receiveDeleteUserDoc(json)));
};

/***********************************************/

/************* get document by id **************/
export const requestUserDocById = () => ({
  type: REQUEST_USER_DOC_BY_ID
});

export const receiveUserDocById = json => ({
  type: RECEIVE_USER_DOC_BY_ID,
  payload: json
});

export const fetchUserDocById = data => dispatch => {
  const method = "get_document";
  dispatch(requestUserDocById());
  return jsonRPCRequest(PORTAL_SERVICE_URL, method, data)
    .then(response => response.json())
    .then(json => dispatch(checkAuth(json)))
    .then(json => dispatch(receiveUserDocById(json)));
};
/***********************************************/

export const clearUserDocOperationStatus = () => ({
  type: CLEAR_USER_DOC_OPERATION_STATUS
});

export const clearUserDocById = () => ({
  type: CLEAR_USER_DOC_BY_ID
});
