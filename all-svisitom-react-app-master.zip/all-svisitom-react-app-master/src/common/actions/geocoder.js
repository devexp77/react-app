import { GETRequest } from "./asyncActions";

const SERVICE_URL = `https://maps.googleapis.com/maps/api/geocode/json?`;
const API_KEY = `AIzaSyAriseuZ90QqiVw_NihABttqK-hS0XkDM4`;

export const REQUEST_ADDRESS_BY_GEO_POINT = "REQUEST_ADDRESS_BY_GEO_POINT";
export const RECEIVE_ADDRESS_BY_GEO_POINT = "RECEIVE_ADDRESS_BY_GEO_POINT";
export const CLEAR_ADDRESS_BY_GEO_POINT = "CLEAR_ADDRESS_BY_GEO_POINT";

export const REQUEST_GEO_POINT_BY_ADDRESS = "REQUEST_GEO_POINT_BY_ADDRESS";
export const RECEIVE_GEO_POINT_BY_ADDRESS = "RECEIVE_GEO_POINT_BY_ADDRESS";
export const CLEAR_GEO_POINT_BY_ADDRESS = "CLEAR_GEO_POINT_BY_ADDRESS";

/*** service ***/
const buildURLQuery = obj =>
  Object.entries(obj)
    .map(pair => pair.map(encodeURIComponent).join("="))
    .join("&");
/**************/

/************** get address by geo point******************/
export const requestAddressByGeoPoint = () => ({
  type: REQUEST_ADDRESS_BY_GEO_POINT
});

export const receiveAddressByGeoPoint = json => ({
  type: RECEIVE_ADDRESS_BY_GEO_POINT,
  payload: json
});

export const clearAddressByGeoPoint = () => ({
  type: CLEAR_ADDRESS_BY_GEO_POINT
});

//latlng
export const fetchAddressByGeoPoint = data => dispatch => {
  data.key = `AIzaSyAriseuZ90QqiVw_NihABttqK-hS0XkDM4`;
  data = buildURLQuery(data);
  const url = SERVICE_URL + data;

  dispatch(requestAddressByGeoPoint());
  return GETRequest(url)
    .then(response => response.json())
    .then(json => dispatch(receiveAddressByGeoPoint(json)));
};

/************************************************/

/************** get geo point by address******************/
export const requestGeoPointByAddress = () => ({
  type: REQUEST_GEO_POINT_BY_ADDRESS
});

export const receiveGeoPointByAddress = json => ({
  type: RECEIVE_GEO_POINT_BY_ADDRESS,
  payload: json
});

export const clearGeoPointByAddress = () => ({
  type: CLEAR_GEO_POINT_BY_ADDRESS
});

// address = 'Москва Ленинский проспект 20'
export const fetchGeoPointByAddress = data => dispatch => {
  data.key = API_KEY;
  data = buildURLQuery(data);
  const url = SERVICE_URL + data;

  dispatch(requestGeoPointByAddress());
  return GETRequest(url)
    .then(response => response.json())
    .then(json => dispatch(receiveGeoPointByAddress(json)));
};
