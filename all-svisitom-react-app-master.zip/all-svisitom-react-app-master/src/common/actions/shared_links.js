import {jsonRPCRequest} from "./asyncActions";
import {checkAuth} from "./user";
import { HOST_NAME, PROTOCOL } from '../constants';

export const REQUEST_ADD_SHARED_LINK = 'REQUEST_ADD_SHARED_LINK';
export const RECEIVE_ADD_SHARED_LINK  = 'RECEIVE_ADD_SHARED_LINK';

export const REQUEST_DELETE_SHARED_LINKS = 'REQUEST_DELETE_SHARED_LINKS';
export const RECEIVE_DELETE_SHARED_LINKS  = 'RECEIVE_DELETE_SHARED_LINKS';

export const REQUEST_SHARED_LINKS = 'REQUEST_SHARED_LINKS';
export const RECEIVE_SHARED_LINKS = 'RECEIVE_SHARED_LINKS';
export const CLEAR_SHARED_LINKS = 'CLEAR_SHARED_LINKS';


const SERVICE_URL =`${PROTOCOL}//api.${HOST_NAME}/shared_links/`;

/****************** add_shared_link *******************/
export const requestAddSharedLink = () => ({
  type: REQUEST_ADD_SHARED_LINK
});

export const receiveAddSharedLink = (json) => ({
  type: RECEIVE_ADD_SHARED_LINK,
  payload: json
});

export const fetchAddSharedLink = (data) => dispatch => {
  const method = 'add_shared_link';
  dispatch(requestAddSharedLink());
  return jsonRPCRequest(SERVICE_URL,method, data)
  .then(response => response.json())
  .then(json => dispatch(checkAuth(json)))
  .then(json => dispatch(receiveAddSharedLink(json), ))
};

/****************** delete_shared_links *******************/
export const requestDeleteSharedLinks = () => ({
  type: REQUEST_DELETE_SHARED_LINKS
});

export const receiveDeleteSharedLinks = (json) => ({
  type: RECEIVE_DELETE_SHARED_LINKS,
  payload: json
});

export const fetchDeleteSharedLinks = (data) => dispatch => {
  const method = 'delete_shared_links';
  dispatch(requestDeleteSharedLinks());
  return jsonRPCRequest(SERVICE_URL,method, data)
  .then(response => response.json())
  .then(json => dispatch(checkAuth(json)))
  .then(json => dispatch(receiveDeleteSharedLinks(json), ))
};


/****************** get_shared_links *******************/
export const requestSharedLinks = () => ({
  type: REQUEST_SHARED_LINKS
});

export const receiveSharedLinks = (json) => ({
  type: RECEIVE_SHARED_LINKS,
  payload: json
});

export const clearSharedLinks = () => ({
  type: CLEAR_SHARED_LINKS
});

export const fetchSharedLinks = (data) => dispatch => {
  const method = 'get_shared_links';
  dispatch(requestSharedLinks());
  return jsonRPCRequest(SERVICE_URL,method, data)
  .then(response => response.json())
  .then(json => dispatch(checkAuth(json)))
  .then(json => dispatch(receiveSharedLinks(json), ))
};

