import { jsonRPCRequest } from "./asyncActions";
import { checkAuth } from "./user";
import { HOST_NAME, PROTOCOL } from "../constants";

export const REQUEST_KEYS = "REQUEST_KEYS";
export const RECEIVE_KEYS = "RECEIVE_KEYS";
export const REQUEST_MORE_KEYS = "REQUEST_MORE_KEYS";
export const RECEIVE_MORE_KEYS = "RECEIVE_MORE_KEYS";
export const CLEAR_KEYS = "CLEAR_KEYS";

export const REQUEST_KEY_BY_ID = 'REQUEST_KEY_BY_ID';
export const RECEIVE_KEY_BY_ID = 'RECEIVE_KEY_BY_ID';
export const CLEAR_KEY_BY_ID = 'CLEAR_KEY_BY_ID';

export const REQUEST_REGISTER_KEY_MOVE = "REQUEST_REGISTER_KEY_MOVE";
export const RECEIVE_REGISTER_KEY_MOVE = "RECEIVE_REGISTER_KEY_MOVE";

export const SAVE_KEY_MOVE_INFO = "SAVE_KEY_MOVE_INFO";
export const CLEAR_KEY_MOVE_INFO = "CLEAR_KEY_MOVE_INFO";

export const REQUEST_ADD_KEY = 'REQUEST_ADD_KEY';
export const RECEIVE_ADD_KEY = 'RECEIVE_ADD_KEY';

export const REQUEST_SET_KEY = 'REQUEST_SET_KEY';
export const RECEIVE_SET_KEY = 'RECEIVE_SET_KEY';

export const REQUEST_DELETE_KEYS = 'REQUEST_DELETE_KEYS';
export const RECEIVE_DELETE_KEYS = 'RECEIVE_DELETE_KEYS';

export const REQUEST_SET_KEY_PERMISSIONS = 'REQUEST_SET_KEY_PERMISSIONS';
export const RECEIVE_SET_KEY_PERMISSIONS = 'RECEIVE_SET_KEY_PERMISSIONS';

export const RECEIVE_DELETE_KEY_PERMISSIONS = 'RECEIVE_DELETE_KEY_PERMISSIONS';
export const REQUEST_DELETE_KEY_PERMISSIONS = 'REQUEST_DELETE_KEY_PERMISSIONS';

export const REQUEST_GET_USER_FAVORITE_KEYS = 'REQUEST_GET_USER_FAVORITE_KEYS';
export const RECEIVE_GET_USER_FAVORITE_KEYS = 'RECEIVE_GET_USER_FAVORITE_KEYS';

export const REQUEST_GET_USER_FAVORITE_KEYS_FULL = 'REQUEST_GET_USER_FAVORITE_KEYS_FULL';
export const RECEIVE_GET_USER_FAVORITE_KEYS_FULL = 'RECEIVE_GET_USER_FAVORITE_KEYS_FULL';

export const REQUEST_SET_USER_FAVORITE_KEYS = 'REQUEST_SET_USER_FAVORITE_KEYS';
export const RECEIVE_SET_USER_FAVORITE_KEYS = 'RECEIVE_SET_USER_FAVORITE_KEYS';

export const REQUEST_KEY_USERS = 'REQUEST_KEY_USERS';
export const RECEIVE_KEY_USERS = 'RECEIVE_KEY_USERS';
export const CLEAR_KEY_USERS = 'CLEAR_KEY_USERS';

const PORTAL_SERVICE_URL = `${PROTOCOL}//api.${HOST_NAME}/keys/`;

/****************** get keys *******************/
export const requestKeys = () => ({
  type: REQUEST_KEYS
});

export const receiveKeys = json => ({
  type: RECEIVE_KEYS,
  payload: json
});

export const requestMoreKeys = () => ({
  type: REQUEST_MORE_KEYS
});

export const receiveMoreKeys = json => ({
  type: RECEIVE_MORE_KEYS,
  payload: json
});

export const clearKeys = () => ({
  type: CLEAR_KEYS
});

export const fetchKeys = data => dispatch => {
  const method = "get_keys";
  dispatch(requestKeys());
  return jsonRPCRequest(PORTAL_SERVICE_URL, method, data)
    .then(response => response.json())
    .then(json => dispatch(checkAuth(json)))
    .then(json => dispatch(receiveKeys(json)));
};

export const fetchMoreKeys = data => dispatch => {
  const method = "get_keys";
  dispatch(requestKeys());
  return jsonRPCRequest(PORTAL_SERVICE_URL, method, data)
    .then(response => response.json())
    .then(json => dispatch(checkAuth(json)))
    .then(json => dispatch(receiveMoreKeys(json)));
};


/****************************************************/

/****************** register key move *******************/
export const requestRegisterKeyMove = () => ({
  type: REQUEST_REGISTER_KEY_MOVE
});

export const receiveRegisterKeyMove = json => ({
  type: RECEIVE_REGISTER_KEY_MOVE,
  payload: json
});

export const fetchRegisterKeyMove = data => dispatch => {
  const method = "register_key_move";
  dispatch(requestRegisterKeyMove());
  return jsonRPCRequest(PORTAL_SERVICE_URL, method, data)
    .then(response => response.json())
    .then(json => dispatch(checkAuth(json)))
    .then(json => dispatch(receiveRegisterKeyMove(json)));
};

/****************************************************/

export const saveKeyMoveInfo = json => ({
  type: SAVE_KEY_MOVE_INFO,
  payload: json
});

export const clearKeyMoveInfo = () => ({
  type: CLEAR_KEY_MOVE_INFO
});


/*
  get key by id
*/
export const requestKeyById = () => ({
  type: REQUEST_KEY_BY_ID
});

export const receiveKeyById = json => ({
  type: RECEIVE_KEY_BY_ID,
  payload: json
});

export const clearKeyById = () => ({
  type: CLEAR_KEY_BY_ID
});

export const fetchKeyById = data => dispatch => {
  const method = "get_key";
  dispatch(requestKeyById());
  return jsonRPCRequest(PORTAL_SERVICE_URL, method, data)
    .then(response => response.json())
    .then(json => dispatch(checkAuth(json)))
    .then(json => dispatch(receiveKeyById(json)));
};


/*
  add key
*/
export const requestAddKey = () => ({
  type: REQUEST_ADD_KEY
});

export const receiveAddKey = json => ({
  type: RECEIVE_ADD_KEY,
  payload: json
});

export const fetchAddKey = data => dispatch => {
  const method = "add_key";
  dispatch(requestAddKey());
  return jsonRPCRequest(PORTAL_SERVICE_URL, method, data)
    .then(response => response.json())
    .then(json => dispatch(checkAuth(json)))
    .then(json => dispatch(receiveAddKey(json)));
};


/*
  set key
*/
export const requestSetKey = () => ({
  type: REQUEST_SET_KEY
});

export const receiveSetKey = json => ({
  type: RECEIVE_SET_KEY,
  payload: json
});

export const fetchSetKey = data => dispatch => {
  const method = "set_key";
  dispatch(requestAddKey());
  return jsonRPCRequest(PORTAL_SERVICE_URL, method, data)
    .then(response => response.json())
    .then(json => dispatch(checkAuth(json)))
    .then(json => dispatch(receiveSetKey(json)));
};


/*
  delete key
*/
export const requestDeleteKeys = () => ({
  type: REQUEST_DELETE_KEYS
});

export const receiveDeleteKeys = json => ({
  type: RECEIVE_DELETE_KEYS,
  payload: json
});

export const fetchDeleteKeys = data => dispatch => {
  const method = "delete_keys";
  dispatch(requestDeleteKeys());
  return jsonRPCRequest(PORTAL_SERVICE_URL, method, data)
    .then(response => response.json())
    .then(json => dispatch(checkAuth(json)))
    .then(json => dispatch(receiveDeleteKeys(json)));
};


/*
  get key users
*/
export const clearKeyUsers = () => ({
  type: CLEAR_KEY_USERS
});

export const requestKeyUsers = () => ({
  type: REQUEST_KEY_USERS
});

export const receiveKeyUsers = json => ({
  type: RECEIVE_KEY_USERS,
  payload: json
});

export const fetchKeyUsers = data => dispatch => {
  const method = "get_key_users";
  dispatch(requestKeyUsers());
  return jsonRPCRequest(PORTAL_SERVICE_URL, method, data)
    .then(response => response.json())
    .then(json => dispatch(checkAuth(json)))
    .then(json => dispatch(receiveKeyUsers(json)));
};


/*
  set key-user permissions
*/

export const requestSetKeyPermissions = () => ({
  type: REQUEST_SET_KEY_PERMISSIONS
});

export const receiveSetKeyPermissions = json => ({
  type: RECEIVE_SET_KEY_PERMISSIONS,
  payload: json
});

export const fetchSetKeyPermissions = data => dispatch => {
  const method = "set_key_permissions";
  dispatch(requestSetKeyPermissions());
  return jsonRPCRequest(PORTAL_SERVICE_URL, method, data)
    .then(response => response.json())
    .then(json => dispatch(checkAuth(json)))
    .then(json => dispatch(receiveSetKeyPermissions(json)));
};

/*
  delete key-user permissions
*/

export const requestDeleteKeyPermissions = () => ({
  type: REQUEST_DELETE_KEY_PERMISSIONS
});

export const receiveDeleteKeyPermissions = json => ({
  type: RECEIVE_DELETE_KEY_PERMISSIONS,
  payload: json
});

export const fetchDeleteKeyPermissions = data => dispatch => {
  const method = "delete_key_permissions";
  dispatch(requestDeleteKeyPermissions());
  return jsonRPCRequest(PORTAL_SERVICE_URL, method, data)
    .then(response => response.json())
    .then(json => dispatch(checkAuth(json)))
    .then(json => dispatch(receiveDeleteKeyPermissions(json)));
};


/*
  get_user_favorite_keys
*/

export const requestGetUserFavoriteKeys = () => ({
  type: REQUEST_GET_USER_FAVORITE_KEYS
});

export const receiveGetUserFavoriteKeys = json => ({
  type: RECEIVE_GET_USER_FAVORITE_KEYS,
  payload: json
});

export const fetchGetUserFavoriteKeys = data => dispatch => {
  const method = "get_user_favorite_keys";
  dispatch(requestGetUserFavoriteKeys());
  return jsonRPCRequest(PORTAL_SERVICE_URL, method, data)
    .then(response => response.json())
    .then(json => dispatch(checkAuth(json)))
    .then(json => dispatch(receiveGetUserFavoriteKeys(json)));
};

/*
  get_user_favorite_keys_full
*/

export const requestGetUserFavoriteKeysFull = () => ({
  type: REQUEST_GET_USER_FAVORITE_KEYS_FULL
});

export const receiveGetUserFavoriteKeysFull = json => ({
  type: RECEIVE_GET_USER_FAVORITE_KEYS_FULL,
  payload: json
});

export const fetchGetUserFavoriteKeysFull = data => dispatch => {
  const method = "get_user_favorite_keys_full";
  dispatch(requestGetUserFavoriteKeysFull());
  return jsonRPCRequest(PORTAL_SERVICE_URL, method, data)
    .then(response => response.json())
    .then(json => dispatch(checkAuth(json)))
    .then(json => dispatch(receiveGetUserFavoriteKeysFull(json)));
};


/*
  set_user_favorite_keys
*/

export const requestSetUserFavoriteKeys = () => ({
  type: REQUEST_SET_USER_FAVORITE_KEYS
});

export const receiveSetUserFavoriteKeys = json => ({
  type: RECEIVE_SET_USER_FAVORITE_KEYS,
  payload: json
});

export const fetchSetUserFavoriteKeys = data => dispatch => {
  const method = "set_user_favorite_keys";
  dispatch(requestSetUserFavoriteKeys());
  return jsonRPCRequest(PORTAL_SERVICE_URL, method, data)
    .then(response => response.json())
    .then(json => dispatch(checkAuth(json)))
    .then(json => dispatch(receiveSetUserFavoriteKeys(json)));
};
