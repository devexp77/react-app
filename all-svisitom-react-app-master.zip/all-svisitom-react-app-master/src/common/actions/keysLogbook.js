import { jsonRPCRequest } from "./asyncActions";
import { HOST_NAME, PROTOCOL } from "../constants";

export const REQUEST_KEYS_LOGBOOK_RECORDS_COUNT = "REQUEST_KEYS_LOGBOOK_RECORDS_COUNT";
export const RECEIVE_KEYS_LOGBOOK_RECORDS_COUNT = "RECEIVE_KEYS_LOGBOOK_RECORDS_COUNT";
export const CLEAR_KEYS_LOGBOOK_RECORDS_COUNT = "CLEAR_KEYS_LOGBOOK_RECORDS_COUNT";

export const REQUEST_KEYS_LOGBOOK_RECORDS = "REQUEST_KEYS_LOGBOOK_RECORDS";
export const RECEIVE_KEYS_LOGBOOK_RECORDS = "RECEIVE_KEYS_LOGBOOK_RECORDS";
export const CLEAR_KEYS_LOGBOOK_RECORDS = "CLEAR_KEYS_LOGBOOK_RECORDS";
export const RECEIVE_SCROLL_KEYS_LOGBOOK_RECORDS = "RECEIVE_SCROLL_KEYS_LOGBOOK_RECORDS";

export const REQUEST_KEYS_LOGBOOK_RECORDS_ID = "REQUEST_KEYS_LOGBOOK_RECORDS_ID";
export const RECEIVE_KEYS_LOGBOOK_RECORDS_ID = "RECEIVE_KEYS_LOGBOOK_RECORDS_ID";
export const CLEAR_KEYS_LOGBOOK_RECORDS_ID = "CLEAR_KEYS_LOGBOOK_RECORDS_ID";

export const REQUEST_KEYS_LOGBOOK_RECORD_ID = "REQUEST_KEYS_LOGBOOK_RECORD_ID";
export const RECEIVE_KEYS_LOGBOOK_RECORD_ID = "RECEIVE_KEYS_LOGBOOK_RECORD_ID";
export const CLEAR_KEYS_LOGBOOK_RECORD_ID = "CLEAR_KEYS_LOGBOOK_RECORD_ID";

export const REQUEST_ADD_KEYS_LOGBOOK_RECORD = "REQUEST_ADD_KEYS_LOGBOOK_RECORD";
export const RECEIVE_ADD_KEYS_LOGBOOK_RECORD = "RECEIVE_ADD_KEYS_LOGBOOK_RECORD";

export const REQUEST_SET_KEYS_LOGBOOK_RECORD = "REQUEST_SET_KEYS_LOGBOOK_RECORD";
export const RECEIVE_SET_KEYS_LOGBOOK_RECORD = "RECEIVE_SET_KEYS_LOGBOOK_RECORD";

const SERVICE_URL = `${PROTOCOL}//api.${HOST_NAME}/keys_logbook/`;

/***************** get logbook records count *******************/
export const requestKeysLogBookRecordsCount = () => ({
  type: REQUEST_KEYS_LOGBOOK_RECORDS_COUNT
});

export const receiveKeysLogBookRecordsCount = json => ({
  type: RECEIVE_KEYS_LOGBOOK_RECORDS_COUNT,
  payload: json
});

export const clearKeysLogBookRecordsCount = () => ({
  type: CLEAR_KEYS_LOGBOOK_RECORDS_COUNT
});

export const fetchKeysLogBookRecordsCount = data => dispatch => {
  const method = "get_record_count";
  dispatch(requestKeysLogBookRecordsCount());
  return jsonRPCRequest(SERVICE_URL, method, data)
    .then(response => response.json())
    .then(json => dispatch(receiveKeysLogBookRecordsCount(json)));
};

/*******************************************************/


/***************** get logbook records *******************/
export const requestKeysLogBookRecords = () => ({
  type: REQUEST_KEYS_LOGBOOK_RECORDS
});

export const receiveKeysLogBookRecords = json => ({
  type: RECEIVE_KEYS_LOGBOOK_RECORDS,
  payload: json
});

export const clearKeysLogBookRecords = () => ({
  type: CLEAR_KEYS_LOGBOOK_RECORDS
});

export const receiveScrollKeysLogBookRecords = json => ({
  type: RECEIVE_SCROLL_KEYS_LOGBOOK_RECORDS,
  payload: json
});

export const fetchKeysLogBookRecords = data => dispatch => {
  const method = "get_records";
  dispatch(requestKeysLogBookRecords());
  return jsonRPCRequest(SERVICE_URL, method, data)
    .then(response => response.json())
    .then(json => dispatch(receiveKeysLogBookRecords(json)));
};

export const fetchScrollKeysLogBookRecords = data => dispatch => {
  const method = "get_records";
  dispatch(requestKeysLogBookRecords());
  return jsonRPCRequest(SERVICE_URL, method, data)
    .then(response => response.json())
    .then(json => dispatch(receiveScrollKeysLogBookRecords(json)));
};
/*******************************************************/

/******************* by records ids *******************/
export const requestKeysLogBookRecordsById = () => ({
  type: REQUEST_KEYS_LOGBOOK_RECORDS_ID
});

export const receiveKeysLogBookRecordsById = json => ({
  type: RECEIVE_KEYS_LOGBOOK_RECORDS_ID,
  payload: json
});

export const clearKeysLogBookRecordsById = () => ({
  type: CLEAR_KEYS_LOGBOOK_RECORDS_ID
});

export const fetchKeysLogBookRecordsById = data => dispatch => {
  const method = "get_records_by_ids";
  dispatch(requestKeysLogBookRecordsById());
  return jsonRPCRequest(SERVICE_URL, method, data)
    .then(response => response.json())
    .then(json => dispatch(receiveKeysLogBookRecordsById(json)));
};
/********************************************************/

/**************** transport logbook record by id *****************************/
export const requestKeysLogBookRecordById = () => ({
  type: REQUEST_KEYS_LOGBOOK_RECORD_ID
});

export const receiveKeysLogBookRecordById = json => ({
  type: RECEIVE_KEYS_LOGBOOK_RECORD_ID,
  payload: json
});

export const clearKeysLogBookRecordById = () => ({
  type: CLEAR_KEYS_LOGBOOK_RECORD_ID
});

export const fetchKeysLogBookRecordById = data => dispatch => {
  const method = "get_record";
  dispatch(requestKeysLogBookRecordById());
  return jsonRPCRequest(SERVICE_URL, method, data)
    .then(response => response.json())
    .then(json => dispatch(receiveKeysLogBookRecordById(json)));
};
/**************************************************************/

/*************** add logbook record ************************/
export const requestAddKeysLogBookRecord = () => ({
  type: REQUEST_ADD_KEYS_LOGBOOK_RECORD
});

export const receiveAddKeysLogBookRecord = json => ({
  type: RECEIVE_ADD_KEYS_LOGBOOK_RECORD,
  payload: json
});

export const fetchAddKeysLogBookRecord = data => dispatch => {
  const method = "add_record";
  dispatch(requestAddKeysLogBookRecord());
  return jsonRPCRequest(SERVICE_URL, method, data)
    .then(response => response.json())
    .then(json => dispatch(receiveAddKeysLogBookRecord(json)));
};
/**********************************************************/

/*************** set logbook record ************************/
export const requestSetKeysLogBookRecord = () => ({
  type: REQUEST_SET_KEYS_LOGBOOK_RECORD
});

export const receiveSetKeysLogBookRecord = json => ({
  type: RECEIVE_SET_KEYS_LOGBOOK_RECORD,
  payload: json
});

export const fetchSetKeyLogBookRecord = data => dispatch => {
  const method = "set_record";
  dispatch(requestSetKeysLogBookRecord());
  return jsonRPCRequest(SERVICE_URL, method, data)
    .then(response => response.json())
    .then(json => dispatch(receiveSetKeysLogBookRecord(json)));
};
/**********************************************************/
