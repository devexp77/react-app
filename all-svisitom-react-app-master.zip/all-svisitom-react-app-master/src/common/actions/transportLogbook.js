import { jsonRPCRequest } from "./asyncActions";
import { HOST_NAME, PROTOCOL } from "../constants";
/*
copy visitor logbook action
and edit it on need

*/

export const REQUEST_TRANSPORT_LOGBOOK_RECORDS_COUNT = "REQUEST_TRANSPORT_LOGBOOK_RECORDS_COUNT";
export const RECEIVE_TRANSPORT_LOGBOOK_RECORDS_COUNT = "RECEIVE_TRANSPORT_LOGBOOK_RECORDS_COUNT";
export const CLEAR_TRANSPORT_LOGBOOK_RECORDS_COUNT = "CLEAR_TRANSPORT_LOGBOOK_RECORDS_COUNT";

export const REQUEST_TRANSPORT_LOGBOOK_RECORDS = "REQUEST_TRANSPORT_LOGBOOK_RECORDS";
export const RECEIVE_TRANSPORT_LOGBOOK_RECORDS = "RECEIVE_TRANSPORT_LOGBOOK_RECORDS";
export const CLEAR_TRANSPORT_LOGBOOK_RECORDS = "CLEAR_TRANSPORT_LOGBOOK_RECORDS";
export const RECEIVE_SCROLL_TRANSPORT_LOGBOOK_RECORDS = "RECEIVE_SCROLL_TRANSPORT_LOGBOOK_RECORDS";

export const REQUEST_TRANSPORT_LOGBOOK_RECORDS_ID = "REQUEST_TRANSPORT_LOGBOOK_RECORDS_ID";
export const RECEIVE_TRANSPORT_LOGBOOK_RECORDS_ID = "RECEIVE_TRANSPORT_LOGBOOK_RECORDS_ID";
export const CLEAR_TRANSPORT_LOGBOOK_RECORDS_ID = "CLEAR_TRANSPORT_LOGBOOK_RECORDS_ID";

export const REQUEST_TRANSPORT_LOGBOOK_RECORD_ID =
  "REQUEST_TRANSPORT_LOGBOOK_RECORD_ID";
export const RECEIVE_TRANSPORT_LOGBOOK_RECORD_ID =
  "RECEIVE_TRANSPORT_LOGBOOK_RECORD_ID";
export const CLEAR_TRANSPORT_LOGBOOK_RECORD_ID =
  "CLEAR_TRANSPORT_LOGBOOK_RECORD_ID";

export const REQUEST_ADD_TRANSPORT_LOGBOOK_RECORD = "REQUEST_ADD_TRANSPORT_LOGBOOK_RECORD";
export const RECEIVE_ADD_TRANSPORT_LOGBOOK_RECORD = "RECEIVE_ADD_TRANSPORT_LOGBOOK_RECORD";

export const REQUEST_SET_TRANSPORT_LOGBOOK_RECORD = "REQUEST_SET_TRANSPORT_LOGBOOK_RECORD";
export const RECEIVE_SET_TRANSPORT_LOGBOOK_RECORD = "RECEIVE_SET_TRANSPORT_LOGBOOK_RECORD";

const PORTAL_SERVICE_URL = `${PROTOCOL}//api.${HOST_NAME}/transport_logbook/`;

/***************** get logbook records count *******************/
export const requestTransportLogBookRecordsCount = () => ({
  type: REQUEST_TRANSPORT_LOGBOOK_RECORDS_COUNT
});

export const receiveTransportLogBookRecordsCount = json => ({
  type: RECEIVE_TRANSPORT_LOGBOOK_RECORDS_COUNT,
  payload: json
});

export const clearTransportLogBookRecordsCount = () => ({
  type: CLEAR_TRANSPORT_LOGBOOK_RECORDS_COUNT
});

export const fetchTransportLogBookRecordsCount = data => dispatch => {
  const method = "get_record_count";
  dispatch(requestTransportLogBookRecordsCount());
  return jsonRPCRequest(PORTAL_SERVICE_URL, method, data)
    .then(response => response.json())
    .then(json => dispatch(receiveTransportLogBookRecordsCount(json)));
};

/*******************************************************/


/***************** get logbook records *******************/
export const requestTransportLogBookRecords = () => ({
  type: REQUEST_TRANSPORT_LOGBOOK_RECORDS
});

export const receiveTransportLogBookRecords = json => ({
  type: RECEIVE_TRANSPORT_LOGBOOK_RECORDS,
  payload: json
});

export const clearTransportLogBookRecords = () => ({
  type: CLEAR_TRANSPORT_LOGBOOK_RECORDS
});

export const receiveScrollTransportLogBookRecords = json => ({
  type: RECEIVE_SCROLL_TRANSPORT_LOGBOOK_RECORDS,
  payload: json
});

export const fetchTransportLogBookRecords = data => dispatch => {
  const method = "get_records";
  dispatch(requestTransportLogBookRecords());
  return jsonRPCRequest(PORTAL_SERVICE_URL, method, data)
    .then(response => response.json())
    .then(json => dispatch(receiveTransportLogBookRecords(json)));
};

export const fetchScrollTransportLogBookRecords = data => dispatch => {
  const method = "get_records";
  dispatch(requestTransportLogBookRecords());
  return jsonRPCRequest(PORTAL_SERVICE_URL, method, data)
    .then(response => response.json())
    .then(json => dispatch(receiveScrollTransportLogBookRecords(json)));
};
/*******************************************************/

/******************* by records ids *******************/
export const requestTransportLogBookRecordsById = () => ({
  type: REQUEST_TRANSPORT_LOGBOOK_RECORDS_ID
});

export const receiveTransportLogBookRecordsById = json => ({
  type: RECEIVE_TRANSPORT_LOGBOOK_RECORDS_ID,
  payload: json
});

export const clearTransportLogBookRecordsByIds = () => ({
  type: CLEAR_TRANSPORT_LOGBOOK_RECORDS_ID
});

export const fetchTransportLogBookRecordsByIds = data => dispatch => {
  const method = "get_records_by_ids";
  dispatch(requestTransportLogBookRecordsById());
  return jsonRPCRequest(PORTAL_SERVICE_URL, method, data)
    .then(response => response.json())
    .then(json => dispatch(receiveTransportLogBookRecordsById(json)));
};
/********************************************************/

/**************** transport logbook record by id *****************************/
export const requestTransportLogBookRecordById = () => ({
  type: REQUEST_TRANSPORT_LOGBOOK_RECORD_ID
});

export const receiveTransportLogBookRecordById = json => ({
  type: RECEIVE_TRANSPORT_LOGBOOK_RECORD_ID,
  payload: json
});

export const clearTransportLogBookRecordById = () => ({
  type: CLEAR_TRANSPORT_LOGBOOK_RECORD_ID
});

export const fetchTransportLogBookRecordById = data => dispatch => {
  const method = "get_record";
  dispatch(requestTransportLogBookRecordById());
  return jsonRPCRequest(PORTAL_SERVICE_URL, method, data)
    .then(response => response.json())
    .then(json => dispatch(receiveTransportLogBookRecordById(json)));
};
/**************************************************************/

/*************** add logbook record ************************/
export const requestAddTransportLogBookRecord = () => ({
  type: REQUEST_ADD_TRANSPORT_LOGBOOK_RECORD
});

export const receiveAddTransportLogBookRecord = json => ({
  type: RECEIVE_ADD_TRANSPORT_LOGBOOK_RECORD,
  payload: json
});

export const fetchAddTransportLogBookRecord = data => dispatch => {
  const method = "add_record";
  dispatch(requestAddTransportLogBookRecord());
  return jsonRPCRequest(PORTAL_SERVICE_URL, method, data)
    .then(response => response.json())
    .then(json => dispatch(receiveAddTransportLogBookRecord(json)));
};
/**********************************************************/

/*************** set logbook record ************************/
export const requestSetTransportLogBookRecord = () => ({
  type: REQUEST_SET_TRANSPORT_LOGBOOK_RECORD
});

export const receiveSetTransportLogBookRecord = json => ({
  type: RECEIVE_SET_TRANSPORT_LOGBOOK_RECORD,
  payload: json
});

export const fetchSetTransportLogBookRecord = data => dispatch => {
  const method = "set_record";
  dispatch(requestSetTransportLogBookRecord());
  return jsonRPCRequest(PORTAL_SERVICE_URL, method, data)
    .then(response => response.json())
    .then(json => dispatch(receiveSetTransportLogBookRecord(json)));
};
/**********************************************************/
