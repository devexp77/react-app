import {jsonRPCRequest} from "./asyncActions";
import {checkAuth} from "./user";
import { HOST_NAME, PROTOCOL } from '../constants';

export const REQUEST_ENTITY_ROLES_BENTO = 'REQUEST_ENTITY_ROLES_BENTO';
export const RECEIVE_ENTITY_ROLES_BENTO = 'RECEIVE_ENTITY_ROLES_BENTO';
export const CLEAR_ENTITY_ROLES_BENTO = 'CLEAR_ENTITY_ROLES_BENTO';

const ROLES_SERVICE_URL =`${PROTOCOL}//api.${HOST_NAME}/roles/`;


export const REQUEST_ACTIVITIES_BENTO = 'REQUEST_ACTIVITIES_BENTO';
export const RECEIVE_ACTIVITIES_BENTO = 'RECEIVE_ACTIVITIES_BENTO';
export const CLEAR_ACTIVITIES_BENTO = 'CLEAR_ACTIVITIES_BENTO';

const ACTIVITY_SERVICE_URL =`${PROTOCOL}//api.${HOST_NAME}/activity/`;

export const REQUEST_ADDRESSEES_BENTO = 'REQUEST_ADDRESSEES_BENTO';
export const RECEIVE_ADDRESSEES_BENTO = 'RECEIVE_ADDRESSEES_BENTO';
export const CLEAR_ADDRESSEES_BENTO = 'CLEAR_ADDRESSEES_BENTO';

const ADDRESSEE_SERVICE_URL =`${PROTOCOL}//api.${HOST_NAME}/addressee/`;

export const REQUEST_OBJECTS_BENTO = "REQUEST_OBJECTS_BENTO";
export const RECEIVE_OBJECTS_BENTO = "RECEIVE_OBJECTS_BENTO";
export const CLEAR_OBJECTS_BENTO = 'CLEAR_OBJECTS_BENTO';

const OBJECTS_SERVICE_URL = `${PROTOCOL}//api.${HOST_NAME}/objects/`;

export const REQUEST_OBJECTS_IMAGE_BENTO = "REQUEST_OBJECTS_IMAGE_BENTO";
export const RECEIVE_OBJECTS_IMAGE_BENTO = "RECEIVE_OBJECTS_IMAGE_BENTO";
export const CLEAR_OBJECTS_IMAGE_BENTO = "CLEAR_OBJECTS_IMAGE_BENTO";

const IMAGES_SERVICE_URL = `${PROTOCOL}//api.${HOST_NAME}/images/`;


/****************** ROLES *******************/
export const requestEntityRolesBento = () => ({
  type: REQUEST_ENTITY_ROLES_BENTO
});

export const receiveEntityRolesBento = (json) => ({
  type: RECEIVE_ENTITY_ROLES_BENTO,
  payload: json
});

export const clearEntityRolesBento = () => ({
  type: CLEAR_ENTITY_ROLES_BENTO
});

export const fetchEntityRolesBento = (data) => dispatch => {
  const method = 'get_roles';
  dispatch(requestEntityRolesBento());
  return jsonRPCRequest(ROLES_SERVICE_URL,method, data)
  .then(response => response.json())
  .then(json => dispatch(checkAuth(json)))
  .then(json => dispatch(receiveEntityRolesBento(json), ))
};

/****************** ACTIVITY *******************/

export const requestActivitiesBento = () => ({
  type: REQUEST_ACTIVITIES_BENTO
});

export const receiveActivitiesBento = (json) => ({
  type: RECEIVE_ACTIVITIES_BENTO,
  payload: json
});

export const fetchActivitiesBento = (data) => dispatch => {
  const method = 'get_activities';
  dispatch(requestActivitiesBento());
  return jsonRPCRequest(ACTIVITY_SERVICE_URL,method, data)
  .then(response => response.json())
  .then(json => dispatch(checkAuth(json)))
  .then(json => dispatch(receiveActivitiesBento(json), ))
};

export const clearActivitiesBento = () => ({
  type: CLEAR_ACTIVITIES_BENTO
});


/****************** OBJECTS *******************/
export const requestObjectsBento = () => ({
  type: REQUEST_OBJECTS_BENTO
});

export const receiveObjectsBento = json => ({
  type: RECEIVE_OBJECTS_BENTO,
  payload: json
});

export const fetchObjectsBento = data => dispatch => {
  const method = "get_objects_by_ids";
  dispatch(requestObjectsBento());
  return jsonRPCRequest(OBJECTS_SERVICE_URL, method, data)
    .then(response => response.json())
    .then(json => dispatch(checkAuth(json)))
    .then(json => dispatch(receiveObjectsBento(json)));
};

export const clearObjectsBento = () => ({
  type: CLEAR_OBJECTS_BENTO
});


/****************** IMAGES *******************/

export const requestObjectsImageBento = () => ({
  type: REQUEST_OBJECTS_IMAGE_BENTO
});

export const receiveObjectsImageBento = json => ({
  type: RECEIVE_OBJECTS_IMAGE_BENTO,
  payload: json
});

export const fetchObjectsImageBento = data => dispatch => {
  const method = "get_default_image_urls";
  dispatch(requestObjectsImageBento());
  if (data.entity_ids.length == 0) {
    dispatch(receiveObjectsImageBento({
      id: "1",
      jsonrpc: "2.0",
      result: []
    }));
  } else {
    return jsonRPCRequest(IMAGES_SERVICE_URL, method, data)
      .then(response => response.json())
      .then(json => dispatch(checkAuth(json)))
      .then(json => dispatch(receiveObjectsImageBento(json)));
  }
};

export const clearObjectsImageBento = () => ({
  type: CLEAR_OBJECTS_IMAGE_BENTO
});



/****************** ADDRESSEES *******************/
export const requestAddresseesBento = () => ({
  type: REQUEST_ADDRESSEES_BENTO
});

export const receiveAddresseesBento = (json) => ({
  type: RECEIVE_ADDRESSEES_BENTO,
  payload: json
});

export const fetchAddresseesBento = (data) => dispatch => {
  const method = 'get_addressees_by_ids';
  dispatch(requestAddresseesBento());
  return jsonRPCRequest(ADDRESSEE_SERVICE_URL,method, data)
  .then(response => response.json())
  .then(json => dispatch(checkAuth(json)))
  .then(json => dispatch(receiveAddresseesBento(json), ))
};

export const clearAddresseesBento = () => ({
  type: CLEAR_ADDRESSEES_BENTO
});
