import { jsonRPCRequest } from "./asyncActions";
import { HOST_NAME, PROTOCOL } from "../constants";

export const REQUEST_USER_NOTIFICATIONS = "REQUEST_USER_NOTIFICATIONS";
export const RECEIVE_USER_NOTIFICATIONS = "RECEIVE_USER_NOTIFICATIONS";
export const RECEIVE_USER_SCROLL_NOTIFICATIONS =
  "RECEIVE_USER_SCROLL_NOTIFICATIONS";

export const REQUEST_DELETE_NOTIFICATIONS_BY_ID =
  "REQUEST_DELETE_NOTIFICATIONS_BY_ID";
export const RECEIVE_DELETE_NOTIFICATIONS_BY_ID =
  "RECEIVE_DELETE_NOTIFICATIONS_BY_ID";

export const REQUEST_USER_NOTIFICATIONS_COUNT =
  "REQUEST_USER_NOTIFICATIONS_COUNT";
export const RECEIVE_USER_NOTIFICATIONS_COUNT =
  "RECEIVE_USER_NOTIFICATIONS_COUNT";

export const CLEAR_USER_NOTIFICATIONS = "CLEAR_USER_NOTIFICATIONS";
export const FIX_USER_NOTIFICATIONS_COUNT = "FIX_USER_NOTIFICATIONS_COUNT";


export const REQUEST_NOTIFICATION_SETTINGS = "REQUEST_NOTIFICATION_SETTINGS";
export const RECEIVE_NOTIFICATION_SETTINGS = "RECEIVE_NOTIFICATION_SETTINGS";
export const CLEAR_NOTIFICATION_SETTINGS = "CLEAR_NOTIFICATION_SETTINGS";


export const REQUEST_SET_NOTIFICATION_SETTINGS = "REQUEST_SET_NOTIFICATION_SETTINGS";
export const RECEIVE_SET_NOTIFICATION_SETTINGS = "RECEIVE_SET_NOTIFICATION_SETTINGS";

export const REQUEST_SET_SINGLE_NOTIFICATION_SETTINGS = "REQUEST_SET_SINGLE_NOTIFICATION_SETTINGS";
export const RECEIVE_SET_SINGLE_NOTIFICATION_SETTINGS = "RECEIVE_SET_SINGLE_NOTIFICATION_SETTINGS";

const PORTAL_SERVICE_URL = `${PROTOCOL}//api.${HOST_NAME}/notifications/`;

export const fixUserNotificationsCount = () => ({
  type: FIX_USER_NOTIFICATIONS_COUNT
});

export const requestUserNotifications = () => ({
  type: REQUEST_USER_NOTIFICATIONS
});

export const receiveUserNotifications = json => ({
  type: RECEIVE_USER_NOTIFICATIONS,
  payload: json
});

export const fetchUserNotifications = data => dispatch => {
  var method = "get_notifications";
  dispatch(requestUserNotifications());
  return jsonRPCRequest(PORTAL_SERVICE_URL, method, data)
    .then(response => response.json())
    .then(json => dispatch(receiveUserNotifications(json)));
};

export const receiveUserScrollNotifications = json => ({
  type: RECEIVE_USER_SCROLL_NOTIFICATIONS,
  payload: json
});

export const fetchUserScrollNotifications = data => dispatch => {
  var method = "get_notifications";
  dispatch(requestUserNotifications());
  return jsonRPCRequest(PORTAL_SERVICE_URL, method, data)
    .then(response => response.json())
    .then(json => dispatch(receiveUserScrollNotifications(json)));
};

export const requestUserNotificationsCount = json => ({
  type: REQUEST_USER_NOTIFICATIONS_COUNT,
  payload: json
});

export const receiveUserNotificationsCount = json => ({
  type: RECEIVE_USER_NOTIFICATIONS_COUNT,
  payload: json
});

export const fetchUserNotificationsCount = data => dispatch => {
  var method = "get_notification_count";
  dispatch(requestUserNotificationsCount());
  return jsonRPCRequest(PORTAL_SERVICE_URL, method, data)
    .then(response => response.json())
    .then(json => dispatch(receiveUserNotificationsCount(json)));
};

export const requestDeleteNotificationsById = json => ({
  type: REQUEST_DELETE_NOTIFICATIONS_BY_ID,
  payload: json
});

export const receiveDeleteNotificationsById = json => ({
  type: RECEIVE_DELETE_NOTIFICATIONS_BY_ID,
  payload: json
});

export const fetchDeleteNotificationsById = data => dispatch => {
  var method = "delete_notifications";
  dispatch(requestDeleteNotificationsById());
  return jsonRPCRequest(PORTAL_SERVICE_URL, method, data)
    .then(response => response.json())
    .then(json => dispatch(receiveDeleteNotificationsById(json)));
};

export const ClearUserNotifications = () => ({
  type: CLEAR_USER_NOTIFICATIONS
});


export const requestNotificationSettings = json => ({
  type: REQUEST_NOTIFICATION_SETTINGS,
  payload: json
});

export const receiveNotificationSettings = json => ({
  type: RECEIVE_NOTIFICATION_SETTINGS,
  payload: json
});

export const fetchNotificationSettings = data => dispatch => {
  const method = "get_notification_settings";
  dispatch(requestNotificationSettings());
  return jsonRPCRequest(PORTAL_SERVICE_URL, method, data)
    .then(response => response.json())
    .then(json => dispatch(receiveNotificationSettings(json)));
};

export const clearNotificationSettings = () => ({
  type: CLEAR_NOTIFICATION_SETTINGS
});


export const requestSetNotificationSettings = json => ({
  type: REQUEST_SET_NOTIFICATION_SETTINGS,
  payload: json
});

export const receiveSetNotificationSettings = json => ({
  type: RECEIVE_SET_NOTIFICATION_SETTINGS,
  payload: json
});

export const fetchSetNotificationSettings = data => dispatch => {
  const method = "set_notification_settings";
  dispatch(requestSetNotificationSettings());
  return jsonRPCRequest(PORTAL_SERVICE_URL, method, data)
    .then(response => response.json())
    .then(json => dispatch(receiveSetNotificationSettings(json)));
};

export const requestSetSingleNotificationSettings = json => ({
  type: REQUEST_SET_SINGLE_NOTIFICATION_SETTINGS,
  payload: json
});

export const receiveSetSingleNotificationSettings = json => ({
  type: RECEIVE_SET_SINGLE_NOTIFICATION_SETTINGS,
  payload: json
});

export const fetchSetSingleNotificationSettings = data => dispatch => {
  const method = "set_single_notification_setting";
  dispatch(requestSetSingleNotificationSettings());
  return jsonRPCRequest(PORTAL_SERVICE_URL, method, data)
    .then(response => response.json())
    .then(json => dispatch(receiveSetSingleNotificationSettings(json)));
};