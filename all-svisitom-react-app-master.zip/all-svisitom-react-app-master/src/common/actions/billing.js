import fetch from 'isomorphic-fetch';
import {jsonRPCRequest} from "./asyncActions";
import {checkAuth} from "./user";
import { PROTOCOL, HOST_NAME } from '../constants';

export const REQUEST_BILLING_ACCOUNT = 'REQUEST_BILLING_ACCOUNT'
export const RECEIVE_BILLING_ACCOUNT = 'RECEIVE_BILLING_ACCOUNT'
export const CLEAR_BILLING_ACCOUNT = 'CLEAR_BILLING_ACCOUNT'
export const UPDATE_BILLING_ACCOUNT_BALANCE = 'UPDATE_BILLING_ACCOUNT_BALANCE'

export const REQUEST_BILLING_TRANSACTIONS = 'REQUEST_BILLING_TRANSACTIONS'
export const RECEIVE_BILLING_TRANSACTIONS = 'RECEIVE_BILLING_TRANSACTIONS'
export const RECEIVE_MORE_BILLING_TRANSACTIONS = 'RECEIVE_MORE_BILLING_TRANSACTIONS'
export const CLEAR_BILLING_TRANSACTIONS = 'CLEAR_BILLING_TRANSACTIONS'

export const REQUEST_ADD_BILLING_TRANSACTION = 'REQUEST_ADD_BILLING_TRANSACTION'
export const RECEIVE_ADD_BILLING_TRANSACTION = 'RECEIVE_ADD_BILLING_TRANSACTION'

export const REQUEST_PAYMENT_URL = 'REQUEST_PAYMENT_URL'
export const RECEIVE_PAYMENT_URL = 'RECEIVE_PAYMENT_URL'
export const CLEAR_PAYMENT_URL = 'CLEAR_PAYMENT_URL'

export const REQUEST_BILLS = 'REQUEST_BILLS'
export const RECEIVE_BILLS = 'RECEIVE_BILLS'
export const RECEIVE_MORE_BILLS = 'RECEIVE_MORE_BILLS'
export const CLEAR_BILLS = 'CLEAR_BILLS'

export const REQUEST_BILL_BY_ID = 'REQUEST_BILL_BY_ID'
export const RECEIVE_BILL_BY_ID = 'RECEIVE_BILL_BY_ID'
export const CLEAR_BILL_BY_ID = 'CLEAR_BILL_BY_ID'

const SERVICE_URL = `${PROTOCOL}//api.${HOST_NAME}/billing/`

/*
 get_account
 */

export const updateBillingAccountBalance = (balance) => ({
  type: UPDATE_BILLING_ACCOUNT_BALANCE,
  payload: {
    balance: balance
  }
})

export const clearBillingAccount = ()  => ({
  type: CLEAR_BILLING_ACCOUNT
})

export const getBillingAccountRequest = () => ({
  type: REQUEST_BILLING_ACCOUNT
})

export const getBillingAccountResult = (json) => ({
  type: RECEIVE_BILLING_ACCOUNT,
  payload: json
})

export const fetchBillingAccount = (data) => dispatch => {
  var method = 'get_account'
  dispatch(getBillingAccountRequest())
  return jsonRPCRequest(SERVICE_URL,method, data)
  .then(response => response.json())
  .then(json => dispatch(checkAuth(json)))
  .then(json => dispatch(getBillingAccountResult(json), ))
}

/*
  get_transactions
*/

export const clearBillingTransactions = () => ({
  type: CLEAR_BILLING_TRANSACTIONS
})

export const getBillingTransactionsRequest = () => ({
  type: REQUEST_BILLING_TRANSACTIONS
})

export const getBillingTransactionsResult = (json) => ({
  type: RECEIVE_BILLING_TRANSACTIONS,
  payload: json
})

export const getMoreBillingTransactionsResult = (json) => ({
  type: RECEIVE_MORE_BILLING_TRANSACTIONS,
  payload: json
})

export const fetchBillingTransactions = (data) => dispatch => {
  var method = 'get_transactions'
  dispatch(getBillingTransactionsRequest())
  return jsonRPCRequest(SERVICE_URL,method, data)
  .then(response => response.json())
  .then(json => dispatch(checkAuth(json)))
  .then(json => dispatch(getBillingTransactionsResult(json), ))
}

export const fetchMoreBillingTransactions = (data) => dispatch => {
  var method = 'get_transactions'
  dispatch(getBillingTransactionsRequest())
  return jsonRPCRequest(SERVICE_URL,method, data)
  .then(response => response.json())
  .then(json => dispatch(checkAuth(json)))
  .then(json => dispatch(getMoreBillingTransactionsResult(json), ))
}

/*
add_transactions
*/

export const addBillingTransactionRequest = () => ({
  type: REQUEST_ADD_BILLING_TRANSACTION
})

export const addBillingTransactionResult = (json) => ({
  type: RECEIVE_ADD_BILLING_TRANSACTION,
  payload: json
})

export const fetchAddBillingTransaction = (data) => dispatch => {
  var method = 'add_transaction'
  dispatch(addBillingTransactionRequest())
  return jsonRPCRequest(SERVICE_URL,method, data)
  .then(response => response.json())
  .then(json => dispatch(checkAuth(json)))
  .then(json => dispatch(addBillingTransactionResult(json), ))
}

/*
get_product_url
*/

export const getPaymentUrlRequest = () => ({
  type: REQUEST_PAYMENT_URL
})

export const getPaymentUrlResult = (json) => ({
  type: RECEIVE_PAYMENT_URL,
  payload: json
})

export const clearPaymentUrl = () => ({
  type: CLEAR_PAYMENT_URL
})

export const fetchPaymentUrl = (data) => dispatch => {
  var method = 'get_product_url'
  dispatch(getPaymentUrlRequest())
  return jsonRPCRequest(SERVICE_URL,method, data)
  .then(response => response.json())
  .then(json => dispatch(checkAuth(json)))
  .then(json => dispatch(getPaymentUrlResult(json), ))
}


/*
bills
*/

export const clearBills = () => ({
  type: CLEAR_BILLS
})

export const getBillsRequest = () => ({
  type: REQUEST_BILLS
})

export const getBillsResult = (json) => ({
  type: RECEIVE_BILLS,
  payload: json
})

export const getMoreBillsResult = (json) => ({
  type: RECEIVE_MORE_BILLS,
  payload: json
})

export const fetchBills = (data) => dispatch => {
  var method = 'get_bills'
  dispatch(getBillsRequest())
  return jsonRPCRequest(SERVICE_URL,method, data)
  .then(response => response.json())
  .then(json => dispatch(checkAuth(json)))
  .then(json => dispatch(getBillsResult(json), ))
}

export const fetchMoreBills = (data) => dispatch => {
  var method = 'get_bills'
  dispatch(getBillsRequest())
  return jsonRPCRequest(SERVICE_URL,method, data)
  .then(response => response.json())
  .then(json => dispatch(checkAuth(json)))
  .then(json => dispatch(getMoreBillsResult(json), ))
}


/*
single bill
*/
export const clearBillById = () => ({
  type: CLEAR_BILL_BY_ID
})

export const getBillByIdRequest = () => ({
  type: REQUEST_BILL_BY_ID
})

export const getBillByIdResult = (json) => ({
  type: RECEIVE_BILL_BY_ID,
  payload: json
})

export const fetchBillById = (data) => dispatch => {
  var method = 'get_bill'
  dispatch(getBillByIdRequest())
  return jsonRPCRequest(SERVICE_URL,method, data)
  .then(response => response.json())
  .then(json => dispatch(checkAuth(json)))
  .then(json => dispatch(getBillByIdResult(json), ))
}
