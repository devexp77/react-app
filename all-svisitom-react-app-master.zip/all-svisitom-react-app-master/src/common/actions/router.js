import { push } from "react-router-redux";

export const SET_ROUTE_PATH = "SET_ROUTE_PATH";
export const SET_NAV_PANEL_CONTAINER = "SET_NAV_PANEL_CONTAINER";
export const SET_HISTORY = "SET_HISTORY";
export const CLEAR_HISTORY = "CLEAR_HISTORY";
export const SET_TITLE = "SET_TITLE";
export const SET_CUSTOM_HISTORY_PATH = "SET_CUSTOM_HISTORY_PATH";

export const SET_KIOSK_MODE = "SET_KIOSK_MODE";


export const setRoutePath = path => ({
  type: SET_ROUTE_PATH,
  payload: path
});

export const setNavPanelContainer = params => ({
  type: SET_NAV_PANEL_CONTAINER,
  payload: params
});

export const pushHistory = url => ({
  type: SET_HISTORY,
  payload: url
});

export const setKioskMode = urls => ({
  type: SET_KIOSK_MODE,
  payload: urls
});

export const setTitle = title => ({
  type: SET_TITLE,
  payload: title
});

export const setCustomHistoryPath = path => ({
  type: SET_CUSTOM_HISTORY_PATH,
  payload: path
});

export const clearHistory = () => ({
  type: CLEAR_HISTORY
});

export const toRoot = () => dispatch => {
  dispatch(push("/"));
};

export const toProfile = () => dispatch => {
  dispatch(push("/profile"));
};

export const toObject = object_id => dispatch => {
  dispatch(push("/" + object_id + "/info"));
};

export const toAddressees = object_id => dispatch => {
  dispatch(push("/" + object_id + "/addressees"));
};

export const toAddressee = (object_id, adressee_id) => dispatch => {
  dispatch(push("/" + object_id + "/addressees/" + adressee_id));
};

export const toAddresseeAdd = object_id => dispatch => {
  dispatch(push("/" + object_id + "/addressees/add"));
};

export const toAddresseeEdit = (object_id, addresse_id) => dispatch => {
  dispatch(push("/" + object_id + "/rooms/addressee/" + addresse_id));
};

export const toCustomPath = path => dispatch => {
  dispatch(push(path));
};

export const toRequestAdd = object_id => dispatch => {
  dispatch(push("/add/" + object_id));
}

export const toSuccessAdded = () => dispatch => {
  dispatch(push("/success"));
};

export const toFieldEdit = next_url => dispatch => {
  dispatch(push(next_url));
};

export const toRooms = object_id => dispatch => {
  dispatch(push("/" + object_id + "/rooms"));
};

export const toRoom = (object_id, room_id) => dispatch => {
  dispatch(push("/" + object_id + "/rooms/" + room_id));
};

export const toRoomAdd = object_id => dispatch => {
  dispatch(push("/" + object_id + "/rooms/add"));
};

export const toEmployees = object_id => dispatch => {
  dispatch(push("/" + object_id + "/employees"));
};

export const toEmployee = (object_id, employee_id) => dispatch => {
  dispatch(push("/" + object_id + "/employees/" + employee_id));
};

export const toEmployeeAdd = object_id => dispatch => {
  dispatch(push("/" + object_id + "/employees/add"));
};

export const toDevice = (object_id, device_id) => dispatch => {
  dispatch(push("/" + object_id + "/devices/" + device_id));
};

export const toDevices = (object_id) => dispatch => {
  dispatch(push("/" + object_id + "/devices/"));
};

export const toDeviceAdd = object_id => dispatch => {
  dispatch(push("/" + object_id + "/devices/add"));
};

export const toInvites = () => dispatch => {
  dispatch(push("/invites"));
};

export const toInvite = invite_id => dispatch => {
  dispatch(push("/invites/" + invite_id));
};

export const toRequest = request_id => dispatch => {
  dispatch(push("/requests/" + request_id));
};

export const toObjectRequestEdit = request_id => dispatch => {
  dispatch(push("/requests/" + request_id + "/edit"));
};

export const toRequestEdit = object_id => dispatch => {
  dispatch(push("/add/" + object_id));
};

export const toRequestConfirm = () => dispatch => {
  dispatch(push("/confirm"));
};

export const toRequests = () => dispatch => {
  dispatch(push("/requests/"));
};

export const toPermit = permit_id => dispatch => {
  dispatch(push("/permits/" + permit_id));
};

export const toPermits = () => dispatch => {
  dispatch(push("/permits/"));
};

export const toAddresseeEmployees = (object_id, addressee_id) => dispatch => {
  dispatch(
    push("/" + object_id + "/addressees/" + addressee_id + "/employees")
  );
};

export const toAddresseeRooms = (object_id, addressee_id) => dispatch => {
  dispatch(
    push("/" + object_id + "/addressees/" + addressee_id + "/rooms")
  );
};

export const toAddresseeEmployee = (
  object_id,
  addressee_id,
  employee_id
) => dispatch => {
  dispatch(
    push(
      "/" +
        object_id +
        "/addressees/" +
        addressee_id +
        "/employees/" +
        employee_id
    )
  );
};

export const toAddresseeEmployeeAdd = (object_id, addressee_id) => dispatch => {
  dispatch(
    push("/" + object_id + "/addressees/" + addressee_id + "/employees/add")
  );
};

export const toAddresseeRoomAdd = (object_id, addressee_id) => dispatch => {
  dispatch(
    push("/" + object_id + "/addressees/" + addressee_id + "/rooms/add")
  );
};

export const toAddresseeInvites = (object_id, addressee_id) => dispatch => {
  dispatch(push("/" + object_id + "/addressees/" + addressee_id + "/invites"));
};

export const toAddresseeInvite = (
  object_id,
  addressee_id,
  invite_id
) => dispatch => {
  dispatch(
    push(
      "/" + object_id + "/addressees/" + addressee_id + "/invites/" + invite_id
    )
  );
};

export const toObjectInvites = object_id => dispatch => {
  dispatch(push("/" + object_id + "/invites"));
};

export const toObjectInvite = (object_id, invite_id) => dispatch => {
  dispatch(push("/" + object_id + "/invites/" + invite_id));
};

export const toObjectAddressee = adressee_id => dispatch => {
  dispatch(push("/addressees/" + adressee_id));
};

export const toObjectAddresseeEmployees = addressee_id => dispatch => {
  dispatch(push("/addressees/" + addressee_id + "/employees"));
};

export const toObjectAddresseeEmployee = (
  addressee_id,
  employee_id
) => dispatch => {
  dispatch(push("/addressees/" + addressee_id + "/employees/" + employee_id));
};

export const toObjectAddresseeEmployeeAdd = addressee_id => dispatch => {
  dispatch(push("/addressees/" + addressee_id + "/employees/add"));
};

export const toObjectAddresseeInvites = addressee_id => dispatch => {
  dispatch(push("/addressees/" + addressee_id + "/invites"));
};

export const toObjectAddresseeRooms = addressee_id => dispatch => {
  dispatch(push("/addressees/" + addressee_id + "/rooms"));
};

export const toObjectAddresseeInvite = (
  addressee_id,
  invite_id
) => dispatch => {
  dispatch(push("/addressees/" + addressee_id + "/invites/" + invite_id));
};

export const toLogbookRecordAdd = () => dispatch => {
  dispatch(push("/logbooks/visitors/add"));
};

export const toTransportLogbookRecordAdd = () => dispatch => {
  dispatch(push("/logbooks/transports/add"));
};

export const toLogbook = () => dispatch => {
  dispatch(push("/logbooks/visitors"));
};

export const toTransportLogbook = () => dispatch => {
  dispatch(push("/logbooks/transports"));
};

export const toLogbookRecord = (record_id) => dispatch => {
  dispatch(push("/logbooks/visitors/"+record_id));
};

export const toTransportLogbookRecord = (record_id) => dispatch => {
  dispatch(push("/logbooks/transports/"+record_id));
};

export const toFMObjectRoomChoose = object_id => dispatch => {
  dispatch(push(object_id + "/rooms"));
};