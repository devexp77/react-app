import { jsonRPCRequest } from "./asyncActions";
import { HOST_NAME, PROTOCOL } from "../constants";

export const REQUEST_ADD_FM_REQUEST = "REQUEST_ADD_FM_REQUEST";
export const RECEIVE_ADD_FM_REQUEST = "RECEIVE_ADD_FM_REQUEST";

export const REQUEST_ADD_GROUP_FM_REQUEST = "REQUEST_ADD_GROUP_FM_REQUEST";
export const RECEIVE_ADD_GROUP_FM_REQUEST = "RECEIVE_ADD_GROUP_FM_REQUEST";

export const SAVE_FM_REQUEST_DATA = "SAVE_FM_REQUEST_DATA";
export const CLEAR_FM_REQUEST_DATA = "CLEAR_FM_REQUEST_DATA";

export const REQUEST_FM_REQUEST_RECORDS = "REQUEST_FM_REQUEST_RECORDS";
export const RECEIVE_FM_REQUEST_RECORDS = "RECEIVE_FM_REQUEST_RECORDS";
export const RECEIVE_SCROLL_FM_REQUEST_RECORDS = "RECEIVE_SCROLL_FM_REQUEST_RECORDS";
export const CLEAR_FM_REQUEST_RECORDS = "CLEAR_FM_REQUEST_RECORDS";

export const REQUEST_CHILD_FM_REQUEST_RECORDS = "REQUEST_CHILD_FM_REQUEST_RECORDS";
export const RECEIVE_CHILD_FM_REQUEST_RECORDS = "RECEIVE_CHILD_FM_REQUEST_RECORDS";
export const CLEAR_CHILD_FM_REQUEST_RECORDS = "CLEAR_CHILD_FM_REQUEST_RECORDS";

export const REQUEST_FM_REQUEST_RECORD_ID = "REQUEST_FM_REQUEST_RECORD_ID";
export const RECEIVE_FM_REQUEST_RECORD_ID = "RECEIVE_FM_REQUEST_RECORD_ID";
export const CLEAR_FM_REQUEST_RECORD_BY_ID = "CLEAR_FM_REQUEST_RECORD_BY_ID";

export const SAVE_FM_REQUESTS_FILTER = "SAVE_FM_REQUESTS_FILTER";

export const REQUEST_SET_FACILITY_REQUEST = "REQUEST_SET_FACILITY_REQUEST";
export const RECEIVE_SET_FACILITY_REQUEST = "RECEIVE_SET_FACILITY_REQUEST";

export const REQUEST_SET_FACILITY_REQUEST_STATUS = "REQUEST_SET_FACILITY_REQUEST_STATUS";
export const RECEIVE_SET_FACILITY_REQUEST_STATUS = "RECEIVE_SET_FACILITY_REQUEST_STATUS";

export const REQUEST_SET_FACILITY_REQUEST_PAID_STATUS = "REQUEST_SET_FACILITY_REQUEST_PAID_STATUS";
export const RECEIVE_SET_FACILITY_REQUEST_PAID_STATUS = "RECEIVE_SET_FACILITY_REQUEST_PAID_STATUS";

export const REQUEST_IS_FM_REQUEST_IN_FILTER = "REQUEST_IS_FM_REQUEST_IN_FILTER";
export const RECEIVE_IS_FM_REQUEST_IN_FILTER = "RECEIVE_IS_FM_REQUEST_IN_FILTER";

export const REQUEST_FM_REQUESTS_COUNT = "REQUEST_FM_REQUESTS_COUNT";
export const RECEIVE_FM_REQUESTS_COUNT = "RECEIVE_FM_REQUESTS_COUNT";

export const REQUEST_FM_REQUESTS_COUNT_BY_ROOMS_IDS = "REQUEST_FM_REQUESTS_COUNT_BY_ROOMS_IDS";
export const RECEIVE_FM_REQUESTS_COUNT_BY_ROOMS_IDS = "RECEIVE_FM_REQUESTS_COUNT_BY_ROOMS_IDS";

export const SAVE_FM_REQUESTS_OFFSET = "SAVE_FM_REQUESTS_OFFSET";

export const REQUEST_FM_ALLOWED_ACTIONS = "REQUEST_FM_ALLOWED_ACTIONS";
export const RECEIVE_FM_ALLOWED_ACTIONS = "RECEIVE_FM_ALLOWED_ACTIONS";
export const CLEAR_FM_ALLOWED_ACTIONS = "CLEAR_FM_ALLOWED_ACTIONS";

export const REQUEST_GET_FM_REQUEST_IN_WORK = "REQUEST_GET_FM_REQUEST_IN_WORK";
export const RECEIVE_GET_FM_REQUEST_IN_WORK = "RECEIVE_GET_FM_REQUEST_IN_WORK";

export const REQUEST_UPDATE_WORK_INTERVAL = "REQUEST_UPDATE_WORK_INTERVAL";
export const RECEIVE_UPDATE_WORK_INTERVAL = "RECEIVE_UPDATE_WORK_INTERVAL";

/*******************************************************************/
const PORTAL_SERVICE_URL = `${PROTOCOL}//api.${HOST_NAME}/facility_requests/`;
/*******************************************************************/

/*********************** add request **********************/
export const requestAddFmRequest = () => ({
  type: REQUEST_ADD_FM_REQUEST
});

export const receiveAddFmRequest = json => ({
  type: RECEIVE_ADD_FM_REQUEST,
  payload: json
});

export const fetchAddFmRequest = data => dispatch => {
  const method = "add_facility_request";
  dispatch(requestAddFmRequest());
  return jsonRPCRequest(PORTAL_SERVICE_URL, method, data)
    .then(response => response.json())
    .then(json => dispatch(receiveAddFmRequest(json)));
};
/*********************************************************/

/*********************** add group request **********************/
export const requestAddGroupFmRequest = () => ({
  type: REQUEST_ADD_GROUP_FM_REQUEST
});

export const receiveAddGroupFmRequest = json => ({
  type: RECEIVE_ADD_GROUP_FM_REQUEST,
  payload: json
});

export const fetchAddGroupFmRequest = data => dispatch => {
  const method = "add_group_facility_request";
  dispatch(requestAddGroupFmRequest());
  return jsonRPCRequest(PORTAL_SERVICE_URL, method, data)
    .then(response => response.json())
    .then(json => dispatch(receiveAddGroupFmRequest(json)));
};
/*********************************************************/

/*********** save request data on request page ***********/
export const saveFmRequestData = data => ({
  type: SAVE_FM_REQUEST_DATA,
  payload: data
});

export const clearFmRequestData = () => ({
  type: CLEAR_FM_REQUEST_DATA
});

/************************************************/

/****************** get fm requests **************/
export const requestFmRequestRecords = () => ({
  type: REQUEST_FM_REQUEST_RECORDS
});

export const receiveFmRequestRecords = json => ({
  type: RECEIVE_FM_REQUEST_RECORDS,
  payload: json
});

export const receiveScrollFmRequestRecords = json => ({
  type: RECEIVE_SCROLL_FM_REQUEST_RECORDS,
  payload: json
});

export const fetchFmRequestRecords = data => dispatch => {
  const method = "get_facility_requests";
  dispatch(requestFmRequestRecords());
  return jsonRPCRequest(PORTAL_SERVICE_URL, method, data)
    .then(response => response.json())
    .then(json => dispatch(receiveFmRequestRecords(json)));
};

export const fetchScrollFmRequestRecords = data => dispatch => {
  const method = "get_facility_requests";
  dispatch(requestFmRequestRecords());
  return jsonRPCRequest(PORTAL_SERVICE_URL, method, data)
    .then(response => response.json())
    .then(json => dispatch(receiveScrollFmRequestRecords(json)));
};

export const clearFmRequestRecords = () => ({
  type: CLEAR_FM_REQUEST_RECORDS
});
/*******************************************************/

/****************** get child fm requests **************/
export const requestChildFmRequestRecords = () => ({
  type: REQUEST_CHILD_FM_REQUEST_RECORDS
});

export const receiveChildFmRequestRecords = json => ({
  type: RECEIVE_CHILD_FM_REQUEST_RECORDS,
  payload: json
});

export const fetchChildFmRequestRecords = data => dispatch => {
  const method = "get_facility_requests";
  dispatch(requestChildFmRequestRecords());
  return jsonRPCRequest(PORTAL_SERVICE_URL, method, data)
    .then(response => response.json())
    .then(json => dispatch(receiveChildFmRequestRecords(json)));
};

export const clearChildFmRequestRecords = () => ({
  type: CLEAR_CHILD_FM_REQUEST_RECORDS
});
/*******************************************************/

/******************** get fm request by id **************/
export const requestFmRequestRecordById = () => ({
  type: REQUEST_FM_REQUEST_RECORD_ID
});

export const receiveFmRequestRecordById = json => ({
  type: RECEIVE_FM_REQUEST_RECORD_ID,
  payload: json
});

export const fetchFmRequestRecordById = data => dispatch => {
  const method = "get_facility_request";
  dispatch(requestFmRequestRecordById());
  return jsonRPCRequest(PORTAL_SERVICE_URL, method, data)
    .then(response => response.json())
    .then(json => dispatch(receiveFmRequestRecordById(json)));
};

export const clearFmRequestRecordById = () => ({
  type: CLEAR_FM_REQUEST_RECORD_BY_ID
});
/********************************************************/

/************** save request filter *****************/
export const saveFmRequestsFilter = data => ({
  type: SAVE_FM_REQUESTS_FILTER,
  payload: data
});
/*************************************************/

/******************* set request **********************/
export const requestSetFmRequest = () => ({
  type: REQUEST_SET_FACILITY_REQUEST
});

export const receiveSetFmRequest = json => ({
  type: RECEIVE_SET_FACILITY_REQUEST,
  payload: json
});

export const fetchSetFmRequest = data => dispatch => {
  const method = "set_facility_request";
  dispatch(requestSetFmRequest());
  return jsonRPCRequest(PORTAL_SERVICE_URL, method, data)
    .then(response => response.json())
    .then(json => dispatch(receiveSetFmRequest(json)));
};

/******************************************************/

export const saveFmRequestsOffset = json => ({
  type: SAVE_FM_REQUESTS_OFFSET,
  payload: json
});

/******************************************************/

export const requestIsFmRequestInFilter = () => ({
  type: REQUEST_IS_FM_REQUEST_IN_FILTER
});

export const receiveIsFmRequestInFilter = json => ({
  type: RECEIVE_IS_FM_REQUEST_IN_FILTER,
  payload: json
});

export const fetchIsFmRequestInFilter = data => dispatch => {
  const method = "get_facility_requests";
  dispatch(requestIsFmRequestInFilter());
  return jsonRPCRequest(PORTAL_SERVICE_URL, method, data)
    .then(response => response.json())
    .then(json => dispatch(receiveIsFmRequestInFilter(json)));
};

/******************* set request status**********************/
export const requestSetFmRequestStatus = () => ({
  type: REQUEST_SET_FACILITY_REQUEST_STATUS
});

export const receiveSetFmRequestStatus = json => ({
  type: RECEIVE_SET_FACILITY_REQUEST_STATUS,
  payload: json
});

export const fetchSetFmRequestStatus = data => dispatch => {
  const method = "set_facility_request_status";
  dispatch(requestSetFmRequestStatus());
  return jsonRPCRequest(PORTAL_SERVICE_URL, method, data)
    .then(response => response.json())
    .then(json => dispatch(receiveSetFmRequestStatus(json)));
};

/******************************************************/

/******************* set request paid status**********************/
export const requestSetFmRequestPaidStatus = () => ({
  type: REQUEST_SET_FACILITY_REQUEST_PAID_STATUS
});

export const receiveSetFmRequestPaidStatus = json => ({
  type: RECEIVE_SET_FACILITY_REQUEST_PAID_STATUS,
  payload: json
});

export const fetchSetFmRequestPaidStatus = data => dispatch => {
  const method = "set_facility_request_paid_status";
  dispatch(requestSetFmRequestPaidStatus());
  return jsonRPCRequest(PORTAL_SERVICE_URL, method, data)
    .then(response => response.json())
    .then(json => dispatch(receiveSetFmRequestPaidStatus(json)));
};

/******************************************************/

/******************* get allowed actions**********************/
export const clearFmAllowedActions = () => ({
  type: CLEAR_FM_ALLOWED_ACTIONS
});

export const requestFmAllowedActions = () => ({
  type: REQUEST_FM_ALLOWED_ACTIONS
});

export const receiveFmAllowedActions = json => ({
  type: RECEIVE_FM_ALLOWED_ACTIONS,
  payload: json
});

export const fetchFmAllowedActions = data => dispatch => {
  const method = "get_allowed_actions";
  dispatch(requestFmAllowedActions());
  return jsonRPCRequest(PORTAL_SERVICE_URL, method, data)
    .then(response => response.json())
    .then(json => dispatch(receiveFmAllowedActions(json)));
};

/******************************************************/

/******************* get facility requests count**********************/
export const requestFmRequestsCount = () => ({
  type: REQUEST_FM_REQUESTS_COUNT
});

export const receiveFmRequestsCount = (json, field) => ({
  type: RECEIVE_FM_REQUESTS_COUNT,
  payload: json,
  field: field
});

export const fetchFmRequestsCount = (data, field = "all") => dispatch => {
  const method = "get_facility_requests_count";
  dispatch(requestFmRequestsCount());
  return jsonRPCRequest(PORTAL_SERVICE_URL, method, data)
    .then(response => response.json())
    .then(json => dispatch(receiveFmRequestsCount(json, field)));
};

/******************************************************/

/******************* get facility requests count by rooms ids**********************/
export const requestFmRequestsCountByRoomsIds = () => ({
  type: REQUEST_FM_REQUESTS_COUNT_BY_ROOMS_IDS
});

export const receiveFmRequestsCountByRoomsIds = (json) => ({
  type: RECEIVE_FM_REQUESTS_COUNT_BY_ROOMS_IDS,
  payload: json,
});

export const fetchFmRequestsCountByRoomsIds = (data) => dispatch => {
  const method = "get_facility_requests_count_by_rooms_ids";
  dispatch(requestFmRequestsCountByRoomsIds());
  return jsonRPCRequest(PORTAL_SERVICE_URL, method, data)
    .then(response => response.json())
    .then(json => dispatch(receiveFmRequestsCountByRoomsIds(json)));
};

/******************************************************/

/******************* get request in work ***************/
export const requestGetFmRequestInWork = () => ({
  type: REQUEST_GET_FM_REQUEST_IN_WORK
});

export const receiveGetFmRequestInWork = (json) => ({
  type: RECEIVE_GET_FM_REQUEST_IN_WORK,
  payload: json,
});

export const fetchGetFmRequestInWork = (data) => dispatch => {
  const method = "get_in_work";
  dispatch(requestGetFmRequestInWork());
  return jsonRPCRequest(PORTAL_SERVICE_URL, method, data)
    .then(response => response.json())
    .then(json => dispatch(receiveGetFmRequestInWork(json)));
};

/******************************************************/


/******************* update work interval ***************/
export const requestUpdateWorkInterval = () => ({
  type: REQUEST_UPDATE_WORK_INTERVAL
});

export const receiveUpdateWorkInterval = (json) => ({
  type: RECEIVE_UPDATE_WORK_INTERVAL,
  payload: json,
});

export const fetchUpdateWorkInterval = (data) => dispatch => {
  const method = "update_work_interval";
  dispatch(requestUpdateWorkInterval());
  return jsonRPCRequest(PORTAL_SERVICE_URL, method, data)
    .then(response => response.json())
    .then(json => dispatch(receiveUpdateWorkInterval(json)));
};

/******************************************************/
