import { jsonRPCRequest } from "./asyncActions";
import { push } from "react-router-redux";
import { HOST_NAME, PROTOCOL } from "../constants";
import { checkAuth } from "./user";

export const REQUEST_USER_TRANSPORT = "REQUEST_USER_TRANSPORT";
export const RECEIVE_USER_TRANSPORT = "RECEIVE_USER_TRANSPORT";

export const REQUEST_USER_TRANSPORT_BY_ID = "REQUEST_USER_TRANSPORT_BY_ID";
export const RECEIVE_USER_TRANSPORT_BY_ID = "RECEIVE_USER_TRANSPORT_BY_ID";

export const REQUEST_ADD_USER_TRANSPORT = "REQUEST_ADD_USER_TRANSPORT";
export const RECEIVE_ADD_USER_TRANSPORT = "RECEIVE_ADD_USER_TRANSPORT";

export const REQUEST_SET_USER_TRANSPORT = "REQUEST_SET_USER_TRANSPORT";
export const RECEIVE_SET_USER_TRANSPORT = "RECEIVE_SET_USER_TRANSPORT";

export const REQUEST_DELETE_USER_TRANSPORT = "REQUEST_DELETE_USER_TRANSPORT";
export const RECEIVE_DELETE_USER_TRANSPORT = "RECEIVE_DELETE_USER_TRANSPORT";

export const CLEAR_USER_TRANSPORT_OPERATION_STATUS =
  "CLEAR_USER_TRANSPORT_OPERATION_STATUS";
export const CLEAR_USER_TRANSPORT_BY_ID = "CLEAR_USER_TRANSPORT_BY_ID";

const PORTAL_SERVICE_URL = `${PROTOCOL}//api.${HOST_NAME}/transport/`;

/************* get transports ****************/
export const requestUserTransport = () => ({
  type: REQUEST_USER_TRANSPORT
});

export const receiveUserTransport = json => ({
  type: RECEIVE_USER_TRANSPORT,
  payload: json
});

export const fetchUserTransport = data => dispatch => {
  const method = "get_transports";
  dispatch(requestUserTransport());
  return jsonRPCRequest(PORTAL_SERVICE_URL, method, data)
    .then(response => response.json())
    .then(json => dispatch(checkAuth(json)))
    .then(json => dispatch(receiveUserTransport(json)));
};
/***********************************************************/

/**************** add transport ******************/
export const requestAddUserTransport = () => ({
  type: REQUEST_ADD_USER_TRANSPORT
});

export const receiveAddUserTransport = json => ({
  type: RECEIVE_ADD_USER_TRANSPORT,
  payload: json
});

export const fetchAddUserTransport = data => dispatch => {
  const method = "add_transport";
  dispatch(requestAddUserTransport());
  return jsonRPCRequest(PORTAL_SERVICE_URL, method, data)
    .then(response => response.json())
    .then(json => dispatch(checkAuth(json)))
    .then(json => dispatch(receiveAddUserTransport(json)));
};
/**********************************************************/

/**************** set transport **********************/
export const requestSetUserTransport = () => ({
  type: REQUEST_SET_USER_TRANSPORT
});

export const receiveSetUserTransport = json => ({
  type: RECEIVE_SET_USER_TRANSPORT,
  payload: json
});

export const fetchSetUserTransport = data => dispatch => {
  const method = "set_transport";
  dispatch(requestAddUserTransport());
  return jsonRPCRequest(PORTAL_SERVICE_URL, method, data)
    .then(response => response.json())
    .then(json => dispatch(checkAuth(json)))
    .then(json => dispatch(receiveSetUserTransport(json)));
};
/**********************************************************/

/***************gey transport by id******************/
export const requestUserTransportById = () => ({
  type: REQUEST_USER_TRANSPORT_BY_ID
});

export const receiveUserTransportById = json => ({
  type: RECEIVE_USER_TRANSPORT_BY_ID,
  payload: json
});

export const fetchUserTransportById = data => dispatch => {
  const method = "get_transport";
  dispatch(requestUserTransportById());
  return jsonRPCRequest(PORTAL_SERVICE_URL, method, data)
    .then(response => response.json())
    .then(json => dispatch(checkAuth(json)))
    .then(json => dispatch(receiveUserTransportById(json)));
};
/**********************************************************/

/****************** delete transport *********************/
export const requestDeleteUserTransport = () => ({
  type: REQUEST_DELETE_USER_TRANSPORT
});

export const receiveDeleteUserTransport = json => ({
  type: RECEIVE_DELETE_USER_TRANSPORT,
  payload: json
});

export const fetchDeleteUserTransport = data => dispatch => {
  const method = "delete_transports";
  dispatch(requestDeleteUserTransport());
  return jsonRPCRequest(PORTAL_SERVICE_URL, method, data)
    .then(response => response.json())
    .then(json => dispatch(checkAuth(json)))
    .then(json => dispatch(receiveDeleteUserTransport(json)));
};
/**********************************************************/

/**********************************************************/

export const clearUserTransportOperationStatus = () => ({
  type: CLEAR_USER_TRANSPORT_OPERATION_STATUS
});

export const clearUserTransportById = () => ({
  type: CLEAR_USER_TRANSPORT_BY_ID
});
