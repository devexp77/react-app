import { jsonRPCRequest } from "./asyncActions";
import { HOST_NAME, PROTOCOL } from "../constants";

export const REQUEST_WEB_PUSH_SENDER_ID = "REQUEST_WEB_PUSH_SENDER_ID";
export const RECEIVE_WEB_PUSH_SENDER_ID = "RECEIVE_WEB_PUSH_SENDER_ID";

export const REQUEST_ADD_WEB_PUSH = 'REQUEST_ADD_WEB_PUSH';
export const RECEIVE_ADD_WEB_PUSH = 'RECEIVE_ADD_WEB_PUSH';

export const REQUEST_DELETE_WEB_PUSH = 'REQUEST_DELETE_WEB_PUSH';
export const RECEIVE_DELETE_WEB_PUSH = 'RECEIVE_DELETE_WEB_PUSH';


const PORTAL_SERVICE_URL = `${PROTOCOL}//api.${HOST_NAME}/web_push/`;

/***************** get web push sender id *******************/
export const requestWebPushSenderId = () => ({
  type: REQUEST_WEB_PUSH_SENDER_ID
});

export const receiveWebPushSenderId = json => ({
  type: RECEIVE_WEB_PUSH_SENDER_ID,
  payload: json
});

export const fetchWebPushSenderId = data => dispatch => {
  const method = "get_sender_id";
  dispatch(requestWebPushSenderId());
  return jsonRPCRequest(PORTAL_SERVICE_URL, method, data)
    .then(response => response.json())
    .then(json => dispatch(receiveWebPushSenderId(json)));
};

/*******************************************************/



/***************** add web push *******************/
export const requestAddWebPush = () => ({
  type: REQUEST_ADD_WEB_PUSH
});

export const receiveAddWebPush = json => ({
  type: RECEIVE_ADD_WEB_PUSH,
  payload: json
});

export const fetchAddWebPush = data => dispatch => {
  const method = "add_web_push";
  dispatch(requestAddWebPush());
  return jsonRPCRequest(PORTAL_SERVICE_URL, method, data)
    .then(response => response.json())
    .then(json => dispatch(receiveAddWebPush(json)));
};

/*******************************************************/


/***************** delete web push *******************/
export const requestDeleteWebPush = () => ({
  type: REQUEST_DELETE_WEB_PUSH
});

export const receiveDeleteWebPush = json => ({
  type: RECEIVE_DELETE_WEB_PUSH,
  payload: json
});

export const fetchDeleteWebPush = data => dispatch => {
  const method = "delete_web_push";
  dispatch(requestDeleteWebPush());
  return jsonRPCRequest(PORTAL_SERVICE_URL, method, data)
    .then(response => response.json())
    .then(json => dispatch(receiveDeleteWebPush(json)));
};

/*******************************************************/
