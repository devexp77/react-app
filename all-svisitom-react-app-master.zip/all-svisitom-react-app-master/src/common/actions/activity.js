import {jsonRPCRequest} from "./asyncActions";
import {checkAuth} from "./user";
import { HOST_NAME, PROTOCOL } from '../constants';

export const ADD_ACTIVITY_REQUEST = 'ADD_ACTIVITY_REQUEST';
export const ADD_ACTIVITY_RESULT  = 'ADD_ACTIVITY_RESULT';

export const REQUEST_ACTIVITIES = 'REQUEST_ACTIVITIES';
export const RECEIVE_ACTIVITIES = 'RECEIVE_ACTIVITIES';
export const CLEAR_ACTIVITIES = 'CLEAR_ACTIVITIES';

const SERVICE_URL =`${PROTOCOL}//api.${HOST_NAME}/activity/`;

/****************** add acitivity *******************/
export const addActivityRequest = () => ({
  type: ADD_ACTIVITY_REQUEST
});

export const addActivityResult = (json) => ({
  type: ADD_ACTIVITY_RESULT,
  payload: json
});

export const fetchAddActivity = (data) => dispatch => {
  const method = 'add_activity';
  dispatch(addActivityRequest());
  return jsonRPCRequest(SERVICE_URL,method, data)
  .then(response => response.json())
  .then(json => dispatch(checkAuth(json)))
  .then(json => dispatch(addActivityResult(json), ))
};


/****************** get activities *******************/
export const requestActivities = () => ({
  type: REQUEST_ACTIVITIES
});

export const receiveActivities = (json) => ({
  type: RECEIVE_ACTIVITIES,
  payload: json
});

export const clearActivities = () => ({
  type: CLEAR_ACTIVITIES
});

export const fetchActivities = (data) => dispatch => {
  const method = 'get_activities';
  dispatch(requestActivities());
  return jsonRPCRequest(SERVICE_URL,method, data)
  .then(response => response.json())
  .then(json => dispatch(checkAuth(json)))
  .then(json => dispatch(receiveActivities(json), ))
};
