import { jsonRPCRequest } from "./asyncActions";
import { HOST_NAME, PROTOCOL } from "../constants";

export const REQUEST_WORKTIME_LOGBOOK_RECORDS = "REQUEST_WORKTIME_LOGBOOK_RECORDS";
export const RECEIVE_WORKTIME_LOGBOOK_RECORDS = "RECEIVE_WORKTIME_LOGBOOK_RECORDS";
export const CLEAR_WORKTIME_LOGBOOK_RECORDS = "CLEAR_WORKTIME_LOGBOOK_RECORDS";

export const REQUEST_WORKTIME_LOGBOOK_RECORDS_COUNT = "REQUEST_WORKTIME_LOGBOOK_RECORDS_COUNT";
export const RECEIVE_WORKTIME_LOGBOOK_RECORDS_COUNT = "RECEIVE_WORKTIME_LOGBOOK_RECORDS_COUNT";
export const CLEAR_WORKTIME_LOGBOOK_RECORDS_COUNT = "CLEAR_WORKTIME_LOGBOOK_RECORDS_COUNT";

export const RECEIVE_SCROLL_WORKTIME_LOGBOOK_RECORDS = "RECEIVE_SCROLL_WORKTIME_LOGBOOK_RECORDS";

export const REQUEST_WORKTIME_LOGBOOK_RECORDS_ID = "REQUEST_WORKTIME_LOGBOOK_RECORDS_ID";
export const RECEIVE_WORKTIME_LOGBOOK_RECORDS_ID = "RECEIVE_WORKTIME_LOGBOOK_RECORDS_ID";
export const CLEAR_WORKTIME_LOGBOOK_RECORDS_ID = "CLEAR_WORKTIME_LOGBOOK_RECORDS_ID";

export const REQUEST_WORKTIME_LOGBOOK_RECORD_ID = "REQUEST_WORKTIME_LOGBOOK_RECORD_ID";
export const RECEIVE_WORKTIME_LOGBOOK_RECORD_ID = "RECEIVE_WORKTIME_LOGBOOK_RECORD_ID";
export const CLEAR_WORKTIME_LOGBOOK_RECORD_ID = "CLEAR_WORKTIME_LOGBOOK_RECORD_ID";

export const REQUEST_ADD_WORKTIME_LOGBOOK_RECORD = "REQUEST_ADD_WORKTIME_LOGBOOK_RECORD";
export const RECEIVE_ADD_WORKTIME_LOGBOOK_RECORD = "RECEIVE_ADD_WORKTIME_LOGBOOK_RECORD";

export const REQUEST_SET_WORKTIME_LOGBOOK_RECORD = "REQUEST_SET_WORKTIME_LOGBOOK_RECORD";
export const RECEIVE_SET_WORKTIME_LOGBOOK_RECORD = "RECEIVE_SET_WORKTIME_LOGBOOK_RECORD";

const PORTAL_SERVICE_URL = `${PROTOCOL}//api.${HOST_NAME}/worktime_logbook/`;

/***************** get logbook records *******************/
export const requestWorkTimeLogBookRecords = () => ({
  type: REQUEST_WORKTIME_LOGBOOK_RECORDS
});

export const receiveWorkTimeLogBookRecords = json => ({
  type: RECEIVE_WORKTIME_LOGBOOK_RECORDS,
  payload: json
});

export const clearWorkTimeLogBookRecords = () => ({
  type: CLEAR_WORKTIME_LOGBOOK_RECORDS
});

export const receiveScrollWorkTimeLogBookRecords = json => ({
  type: RECEIVE_SCROLL_WORKTIME_LOGBOOK_RECORDS,
  payload: json
});

export const fetchWorkTimeLogBookRecords = data => dispatch => {
  const method = "get_records";
  dispatch(requestWorkTimeLogBookRecords());
  return jsonRPCRequest(PORTAL_SERVICE_URL, method, data)
    .then(response => response.json())
    .then(json => dispatch(receiveWorkTimeLogBookRecords(json)));
};

export const fetchScrollWorkTimeLogBookRecords = data => dispatch => {
  const method = "get_records";
  dispatch(requestWorkTimeLogBookRecords());
  return jsonRPCRequest(PORTAL_SERVICE_URL, method, data)
    .then(response => response.json())
    .then(json => dispatch(receiveScrollWorkTimeLogBookRecords(json)));
};
/*******************************************************/

/***************** get logbook records count *******************/
export const requestWorkTimeLogBookRecordsCount = () => ({
  type: REQUEST_WORKTIME_LOGBOOK_RECORDS_COUNT
});

export const receiveWorkTimeLogBookRecordsCount = json => ({
  type: RECEIVE_WORKTIME_LOGBOOK_RECORDS_COUNT,
  payload: json
});

export const clearWorkTimeLogBookRecordsCount = () => ({
  type: CLEAR_WORKTIME_LOGBOOK_RECORDS_COUNT
});

export const fetchWorkTimeLogBookRecordsCount = data => dispatch => {
  const method = "get_record_count";
  dispatch(requestWorkTimeLogBookRecordsCount());
  return jsonRPCRequest(PORTAL_SERVICE_URL, method, data)
    .then(response => response.json())
    .then(json => dispatch(receiveWorkTimeLogBookRecordsCount(json)));
};

/*******************************************************/

/******************* by records ids *******************/
export const requestWorkTimeLogBookRecordsById = () => ({
  type: REQUEST_WORKTIME_LOGBOOK_RECORDS_ID
});

export const receiveWorkTimeLogBookRecordsById = json => ({
  type: RECEIVE_WORKTIME_LOGBOOK_RECORDS_ID,
  payload: json
});

export const clearWorkTimeLogBookRecordsByIds = () => ({
  type: CLEAR_WORKTIME_LOGBOOK_RECORDS_ID
});

export const fetchWorkTimeLogBookRecordsByIds = data => dispatch => {
  const method = "get_records_by_ids";
  dispatch(requestWorkTimeLogBookRecordsById());
  return jsonRPCRequest(PORTAL_SERVICE_URL, method, data)
    .then(response => response.json())
    .then(json => dispatch(receiveWorkTimeLogBookRecordsById(json)));
};
/********************************************************/

/**************** record by id *****************************/
export const requestWorkTimeLogBookRecordById = () => ({
  type: REQUEST_WORKTIME_LOGBOOK_RECORD_ID
});

export const receiveWorkTimeLogBookRecordById = json => ({
  type: RECEIVE_WORKTIME_LOGBOOK_RECORD_ID,
  payload: json
});

export const clearWorkTimeLogBookRecordById = () => ({
  type: CLEAR_WORKTIME_LOGBOOK_RECORD_ID
});

export const fetchWorkTimeLogBookRecordById = data => dispatch => {
  const method = "get_record";
  dispatch(requestWorkTimeLogBookRecordById());
  return jsonRPCRequest(PORTAL_SERVICE_URL, method, data)
    .then(response => response.json())
    .then(json => dispatch(receiveWorkTimeLogBookRecordById(json)));
};
/**************************************************************/

/*************** add logbook record ************************/
export const requestAddWorkTimeLogBookRecord = () => ({
  type: REQUEST_ADD_WORKTIME_LOGBOOK_RECORD
});

export const receiveAddWorkTimeLogBookRecord = json => ({
  type: RECEIVE_ADD_WORKTIME_LOGBOOK_RECORD,
  payload: json
});

export const fetchAddWorkTimeLogBookRecord = data => dispatch => {
  const method = "add_record";
  dispatch(requestAddWorkTimeLogBookRecord());
  return jsonRPCRequest(PORTAL_SERVICE_URL, method, data)
    .then(response => response.json())
    .then(json => dispatch(receiveAddWorkTimeLogBookRecord(json)));
};
/**********************************************************/

/*************** set logbook record ************************/
export const requestSetWorkTimeLogBookRecord = () => ({
  type: REQUEST_SET_WORKTIME_LOGBOOK_RECORD
});

export const receiveSetWorkTimeLogBookRecord = json => ({
  type: RECEIVE_SET_WORKTIME_LOGBOOK_RECORD,
  payload: json
});

export const fetchSetWorkTimeLogBookRecord = data => dispatch => {
  const method = "set_record";
  dispatch(requestSetWorkTimeLogBookRecord());
  return jsonRPCRequest(PORTAL_SERVICE_URL, method, data)
    .then(response => response.json())
    .then(json => dispatch(receiveSetWorkTimeLogBookRecord(json)));
};
/**********************************************************/
