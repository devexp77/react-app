import {jsonRPCRequest}      from "./asyncActions";
import {checkAuth}           from "./user";
import {HOST_NAME, PROTOCOL} from '../constants';

const SERVICE_URL = `${PROTOCOL}//api.${HOST_NAME}/promo/`;

export const REQUEST_ADD_PROMO = 'REQUEST_ADD_PROMO';
export const RECEIVE_ADD_PROMO = 'RECEIVE_ADD_PROMO';

export const REQUEST_ACTIVATE_PROMO = 'REQUEST_ACTIVATE_PROMO';
export const RECEIVE_ACTIVATE_PROMO = 'RECEIVE_ACTIVATE_PROMO';

export const REQUEST_PARTNER_PROMOS = 'REQUEST_PARTNER_PROMOS';
export const RECEIVE_PARTNER_PROMOS = 'RECEIVE_PARTNER_PROMOS';
export const RECEIVE_MORE_PARTNER_PROMOS = 'REQUEST_MORE_PARTNER_PROMOS';
export const CLEAR_PARTNER_PROMOS = 'CLEAR_PARTNER_PROMOS';

export const REQUEST_PROMO_ACTIVATION_CONDITIONS = 'REQUEST_PROMO_ACTIVATION_CONDITIONS';
export const RECEIVE_PROMO_ACTIVATION_CONDITIONS = 'RECEIVE_PROMO_ACTIVATION_CONDITIONS';

/*
  add_promo
*/
export const requestAddPromo = () => ({
  type: REQUEST_ADD_PROMO
});

export const receiveAddPromo = (json) => ({
  type: RECEIVE_ADD_PROMO,
  payload: json
});

export const fetchAddPromo = (data) => dispatch => {
    const method = 'add_promo';
    dispatch(requestAddPromo());
    return jsonRPCRequest(SERVICE_URL, method, data)
        .then(response => response.json())
        .then(json => dispatch(checkAuth(json)))
        .then(json => dispatch(receiveAddPromo(json),))
};


/*
  activate_promo
*/
export const requestActivatePromo = () => ({
  type: REQUEST_ACTIVATE_PROMO
});

export const receiveActivatePromo = (json) => ({
  type: RECEIVE_ACTIVATE_PROMO,
  payload: json
});

export const fetchActivatePromo = (data) => dispatch => {
    const method = 'activate_promo';
    dispatch(requestActivatePromo());
    return jsonRPCRequest(SERVICE_URL, method, data)
        .then(response => response.json())
        .then(json => dispatch(checkAuth(json)))
        .then(json => dispatch(receiveActivatePromo(json),))
};

/*
  get_promo_activation_conditions
*/
export const requestPromoActivationConditions = () => ({
  type: REQUEST_PROMO_ACTIVATION_CONDITIONS
});

export const receivePromoActivationConditions = (json) => ({
  type: RECEIVE_PROMO_ACTIVATION_CONDITIONS,
  payload: json
});

export const fetchPromoActivationConditions = (data) => dispatch => {
  const method = 'get_promo_activation_conditions';
  dispatch(requestPromoActivationConditions());
  return jsonRPCRequest(SERVICE_URL, method, data)
    .then(response => response.json())
    .then(json => dispatch(checkAuth(json)))
    .then(json => dispatch(receivePromoActivationConditions(json),))
};


/*
  get_partner_promos
*/
export const requestPartnerPromos = () => ({
  type: REQUEST_PARTNER_PROMOS
});

export const receivePartnerPromos = (json) => ({
  type: RECEIVE_PARTNER_PROMOS,
  payload: json
});

export const receiveMorePartnerPromos = (json) => ({
  type: RECEIVE_MORE_PARTNER_PROMOS,
  payload: json
});

export const clearPartnerPromos = () => ({
  type: CLEAR_PARTNER_PROMOS
});

export const fetchPartnerPromos = (data) => dispatch => {
    const method = 'get_promos';
    dispatch(requestPartnerPromos());
    return jsonRPCRequest(SERVICE_URL, method, data)
        .then(response => response.json())
        .then(json => dispatch(checkAuth(json)))
        .then(json => dispatch(receivePartnerPromos(json),))
};

export const fetchMorePartnerPromos = (data) => dispatch => {
    const method = 'get_promos';
    dispatch(requestPartnerPromos());
    return jsonRPCRequest(SERVICE_URL, method, data)
        .then(response => response.json())
        .then(json => dispatch(checkAuth(json)))
        .then(json => dispatch(receiveMorePartnerPromos(json),))
};
