import { jsonRPCRequest } from "./asyncActions";
import { HOST_NAME, PROTOCOL } from "../constants";

export const REQUEST_LOGBOOK_RECORDS = "REQUEST_LOGBOOK_RECORDS";
export const RECEIVE_LOGBOOK_RECORDS = "RECEIVE_LOGBOOK_RECORDS";
export const CLEAR_LOGBOOK_RECORDS = "CLEAR_LOGBOOK_RECORDS";

export const REQUEST_LOGBOOK_RECORDS_COUNT = "REQUEST_LOGBOOK_RECORDS_COUNT";
export const RECEIVE_LOGBOOK_RECORDS_COUNT = "RECEIVE_LOGBOOK_RECORDS_COUNT";
export const CLEAR_LOGBOOK_RECORDS_COUNT = "CLEAR_LOGBOOK_RECORDS_COUNT";

export const RECEIVE_SCROLL_LOGBOOK_RECORDS = "RECEIVE_SCROLL_LOGBOOK_RECORDS";

export const REQUEST_LOGBOOK_RECORDS_ID = "REQUEST_LOGBOOK_RECORDS_ID";
export const RECEIVE_LOGBOOK_RECORDS_ID = "RECEIVE_LOGBOOK_RECORDS_ID";
export const CLEAR_LOGBOOK_RECORDS_ID = "CLEAR_LOGBOOK_RECORDS_ID";

export const REQUEST_LOGBOOK_RECORD_ID = "REQUEST_LOGBOOK_RECORD_ID";
export const RECEIVE_LOGBOOK_RECORD_ID = "RECEIVE_LOGBOOK_RECORD_ID";
export const CLEAR_LOGBOOK_RECORD_ID = "CLEAR_LOGBOOK_RECORD_ID";

export const REQUEST_ADD_LOGBOOK_RECORD = "REQUEST_ADD_LOGBOOK_RECORD";
export const RECEIVE_ADD_LOGBOOK_RECORD = "RECEIVE_ADD_LOGBOOK_RECORD";

export const REQUEST_SET_LOGBOOK_RECORD = "REQUEST_SET_LOGBOOK_RECORD";
export const RECEIVE_SET_LOGBOOK_RECORD = "RECEIVE_SET_LOGBOOK_RECORD";

const PORTAL_SERVICE_URL = `${PROTOCOL}//api.${HOST_NAME}/logbook/`;

/***************** get logbook records *******************/
export const requestLogBookRecords = () => ({
  type: REQUEST_LOGBOOK_RECORDS
});

export const receiveLogBookRecords = json => ({
  type: RECEIVE_LOGBOOK_RECORDS,
  logBookRecords: json
});

export const clearLogBookRecords = () => ({
  type: CLEAR_LOGBOOK_RECORDS
});

export const receiveScrollLogBookRecords = json => ({
  type: RECEIVE_SCROLL_LOGBOOK_RECORDS,
  logBookRecords: json
});

export const fetchLogBookRecords = data => dispatch => {
  const method = "get_records";
  dispatch(requestLogBookRecords());
  return jsonRPCRequest(PORTAL_SERVICE_URL, method, data)
    .then(response => response.json())
    .then(json => dispatch(receiveLogBookRecords(json)));
};

export const fetchScrollLogBookRecords = data => dispatch => {
  const method = "get_records";
  dispatch(requestLogBookRecords());
  return jsonRPCRequest(PORTAL_SERVICE_URL, method, data)
    .then(response => response.json())
    .then(json => dispatch(receiveScrollLogBookRecords(json)));
};
/*******************************************************/

/***************** get logbook records count *******************/
export const requestLogBookRecordsCount = () => ({
  type: REQUEST_LOGBOOK_RECORDS_COUNT
});

export const receiveLogBookRecordsCount = json => ({
  type: RECEIVE_LOGBOOK_RECORDS_COUNT,
  logBookRecords: json
});

export const clearLogBookRecordsCount = () => ({
  type: CLEAR_LOGBOOK_RECORDS_COUNT
});

export const fetchLogBookRecordsCount = data => dispatch => {
  const method = "get_record_count";
  dispatch(requestLogBookRecordsCount());
  return jsonRPCRequest(PORTAL_SERVICE_URL, method, data)
    .then(response => response.json())
    .then(json => dispatch(receiveLogBookRecordsCount(json)));
};

/*******************************************************/

/******************* by records ids *******************/
export const requestLogBookRecordsById = () => ({
  type: REQUEST_LOGBOOK_RECORDS_ID
});

export const receiveLogBookRecordsById = json => ({
  type: RECEIVE_LOGBOOK_RECORDS_ID,
  payload: json
});

export const clearLogBookRecordsByIds = () => ({
  type: CLEAR_LOGBOOK_RECORDS_ID
});

export const fetchLogBookRecordsByIds = data => dispatch => {
  const method = "get_records_by_ids";
  dispatch(requestLogBookRecordsById());
  return jsonRPCRequest(PORTAL_SERVICE_URL, method, data)
    .then(response => response.json())
    .then(json => dispatch(receiveLogBookRecordsById(json)));
};
/********************************************************/

/**************** record by id *****************************/
export const requestLogBookRecordById = () => ({
  type: REQUEST_LOGBOOK_RECORD_ID
});

export const receiveLogBookRecordById = json => ({
  type: RECEIVE_LOGBOOK_RECORD_ID,
  logBookRecordById: json
});

export const clearLogBookRecordById = () => ({
  type: CLEAR_LOGBOOK_RECORD_ID
});

export const fetchLogBookRecordById = data => dispatch => {
  const method = "get_record";
  dispatch(requestLogBookRecordById());
  return jsonRPCRequest(PORTAL_SERVICE_URL, method, data)
    .then(response => response.json())
    .then(json => dispatch(receiveLogBookRecordById(json)));
};
/**************************************************************/

/*************** add logbook record ************************/
export const requestAddLogBookRecord = () => ({
  type: REQUEST_ADD_LOGBOOK_RECORD
});

export const receiveAddLogBookRecord = json => ({
  type: RECEIVE_ADD_LOGBOOK_RECORD,
  payload: json
});

export const fetchAddLogBookRecord = data => dispatch => {
  const method = "add_record";
  dispatch(requestAddLogBookRecord());
  return jsonRPCRequest(PORTAL_SERVICE_URL, method, data)
    .then(response => response.json())
    .then(json => dispatch(receiveAddLogBookRecord(json)));
};
/**********************************************************/

/*************** set logbook record ************************/
export const requestSetLogBookRecord = () => ({
  type: REQUEST_SET_LOGBOOK_RECORD
});

export const receiveSetLogBookRecord = json => ({
  type: RECEIVE_SET_LOGBOOK_RECORD,
  payload: json
});

export const fetchSetLogBookRecord = data => dispatch => {
  const method = "set_record";
  dispatch(requestSetLogBookRecord());
  return jsonRPCRequest(PORTAL_SERVICE_URL, method, data)
    .then(response => response.json())
    .then(json => dispatch(receiveSetLogBookRecord(json)));
};
/**********************************************************/
