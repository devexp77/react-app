import {jsonRPCRequest}      from "./asyncActions";
import {checkAuth}           from "./user";
import {HOST_NAME, PROTOCOL} from '../constants';

const SERVICE_URL = `${PROTOCOL}//api.${HOST_NAME}/plan/`;

export const REQUEST_PLANS = 'REQUEST_PLANS';
export const RECEIVE_PLANS = 'RECEIVE_PLANS';
export const CLEAR_PLANS = 'CLEAR_PLANS';

export const REQUEST_OBJECT_PLAN = 'REQUEST_OBJECT_PLAN';
export const RECEIVE_OBJECT_PLAN = 'RECEIVE_OBJECT_PLAN';
export const CLEAR_OBJECT_PLAN = 'CLEAR_OBJECT_PLAN';

export const REQUEST_SET_OBJECT_PLAN = 'REQUEST_SET_OBJECT_PLAN';
export const RECEIVE_SET_OBJECT_PLAN = 'RECEIVE_SET_OBJECT_PLAN';

/*
  fetchGetPlans
*/

export const requestPlans = () => ({
    type: REQUEST_PLANS
});

export const receivePlans = (json) => ({
    type   : RECEIVE_PLANS,
    payload: json
});

export const clearPlans = () => ({
    type: CLEAR_PLANS
});

export const fetchPlans = (data) => dispatch => {
    const method = 'get_plans';
    dispatch(requestPlans());
    return jsonRPCRequest(SERVICE_URL, method, data)
        .then(response => response.json())
        .then(json => dispatch(checkAuth(json)))
        .then(json => dispatch(receivePlans(json),))
};
/************************************************/

/*********** get object plan ************/
export const requestObjectPlan = () => ({
    type: REQUEST_OBJECT_PLAN
});

export const receiveObjectPlan = (json) => ({
    type   : RECEIVE_OBJECT_PLAN,
    payload: json
});

export const clearObjectPlan = () => ({
    type: CLEAR_OBJECT_PLAN
});

export const fetchObjectPlan = (data) => dispatch => {
    const method = 'get_plan';
    dispatch(requestObjectPlan());
    return jsonRPCRequest(SERVICE_URL, method, data)
        .then(response => response.json())
        .then(json => dispatch(checkAuth(json)))
        .then(json => dispatch(receiveObjectPlan(json),))
};
/************************************************/

/*********** set object plan ************/
export const requestSetObjectPlan = () => ({
    type: REQUEST_SET_OBJECT_PLAN
});

export const receiveSetObjectPlan = (json) => ({
    type   : RECEIVE_SET_OBJECT_PLAN,
    payload: json
});

export const fetchSetObjectPlan = (data) => dispatch => {
    const method = 'add_object_plan';
    dispatch(requestSetObjectPlan());
    return jsonRPCRequest(SERVICE_URL, method, data)
        .then(response => response.json())
        .then(json => dispatch(checkAuth(json)))
        .then(json => dispatch(receiveSetObjectPlan(json),))
};
/************************************************/