import {jsonRPCRequest} from "./asyncActions";
import {checkAuth} from "./user";
import { HOST_NAME, PROTOCOL } from '../constants';

export const ADD_INVITE_REQUEST = 'ADD_INVITE_REQUEST';
export const ADD_INVITE_RESULT  = 'ADD_INVITE_RESULT';

export const IMPORT_INVITE_REQUEST = 'IMPORT_INVITE_REQUEST';
export const IMPORT_INVITE_RESULT  = 'IMPORT_INVITE_RESULT';

export const REQUEST_INVITES = 'REQUEST_INVITES';
export const RECEIVE_INVITES = 'RECEIVE_INVITES';
export const RECEIVE_MORE_INVITES = 'RECEIVE_MORE_INVITES';
export const CLEAR_INVITES = 'CLEAR_INVITES';

export const REQUEST_CURRENT_USER_INVITES = 'REQUEST_CURRENT_USER_INVITES';
export const RECEIVE_CURRENT_USER_INVITES = 'RECEIVE_CURRENT_USER_INVITES';
export const CLEAR_CURRENT_USER_INVITES = 'CLEAR_CURRENT_USER_INVITES';

export const REQUEST_FROM_CURRENT_USER_INVITES = 'REQUEST_FROM_CURRENT_USER_INVITES';
export const RECEIVE_FROM_CURRENT_USER_INVITES = 'RECEIVE_FROM_CURRENT_USER_INVITES';
export const CLEAR_FROM_CURRENT_USER_INVITES = 'CLEAR_FROM_CURRENT_USER_INVITES';

export const REQUEST_INVITE_BY_ID = 'REQUEST_INVITE_BY_ID';
export const RECEIVE_INVITE_BY_ID = 'RECEIVE_INVITE_BY_ID';
export const CLEAR_INVITE_BY_ID = 'CLEAR_INVITE_BY_ID';

export const REQUEST_DELETE_INVITE = 'REQUEST_DELETE_INVITE';
export const RECEIVE_DELETE_INVITE = 'RECEIVE_DELETE_INVITE';

export const REQUEST_ACCEPT_INVITE = 'REQUEST_ACCEPT_INVITE';
export const RECEIVE_ACCEPT_INVITE = 'RECEIVE_ACCEPT_INVITE';

export const REQUEST_REJECT_INVITE = 'REQUEST_REJECT_INVITE';
export const RECEIVE_REJECT_INVITE = 'RECEIVE_REJECT_INVITE';

export const REQUEST_SEND_INVITE = 'REQUEST_SEND_INVITE';
export const RECEIVE_SEND_INVITE = 'RECEIVE_SEND_INVITE';


const PORTAL_SERVICE_URL =`${PROTOCOL}//api.${HOST_NAME}/invites/`;


/****************** add invites *******************/
export const addInviteRequest = () => ({
	type: ADD_INVITE_REQUEST
});

export const addInviteResult = (json) => ({
	type: ADD_INVITE_RESULT,
	payload: json
});

export const fetchAddInvite = (data) => dispatch => {
	var method = 'add_invite';
	dispatch(addInviteRequest());
	return jsonRPCRequest(PORTAL_SERVICE_URL,method, data)
	.then(response => response.json())
	.then(json => dispatch(checkAuth(json)))
	.then(json => dispatch(addInviteResult(json), ))
};
/****************************************************/

/****************** import invites *******************/
export const importInviteRequest = () => ({
  type: IMPORT_INVITE_REQUEST
});

export const importInviteResult = (json) => ({
  type: IMPORT_INVITE_RESULT,
  payload: json
});

export const fetchImportInvite = (data) => dispatch => {
  var method = 'add_invite';
  dispatch(importInviteRequest());
  return jsonRPCRequest(PORTAL_SERVICE_URL,method, data)
    .then(response => response.json())
    .then(json => dispatch(checkAuth(json)))
    .then(json => dispatch(importInviteResult(json), ))
};
/****************************************************/

/****************** get invites *******************/
export const requestInvites = () => ({
	type: REQUEST_INVITES
});

export const receiveInvites = (json) => ({
	type: RECEIVE_INVITES,
	payload: json
});

export const receiveMoreInvites = (json) => ({
	type: RECEIVE_MORE_INVITES,
	payload: json
});

export const clearInvites = () => ({
	type: CLEAR_INVITES
});

export const fetchInvites = (data) => dispatch => {
	var method = 'get_invites';
	dispatch(requestInvites());
	return jsonRPCRequest(PORTAL_SERVICE_URL,method, data)
	.then(response => response.json())
	.then(json => dispatch(checkAuth(json)))
	.then(json => dispatch(receiveInvites(json), ))
};

export const fetchMoreInvites = (data) => dispatch => {
	var method = 'get_invites';
	dispatch(requestInvites());
	return jsonRPCRequest(PORTAL_SERVICE_URL,method, data)
	.then(response => response.json())
	.then(json => dispatch(checkAuth(json)))
	.then(json => dispatch(receiveMoreInvites(json), ))
};

/****************************************************/

/****************** get current user invites *******************/
export const requestCurrentUserInvites = () => ({
	type: REQUEST_CURRENT_USER_INVITES
});

export const receiveCurrentUserInvites = (json) => ({
	type: RECEIVE_CURRENT_USER_INVITES,
	payload: json
});

export const fetchCurrentUserInvites = (data) => dispatch => {
	var method = 'get_current_user_invites';
	dispatch(requestCurrentUserInvites());
	return jsonRPCRequest(PORTAL_SERVICE_URL,method, data)
	.then(response => response.json())
	.then(json => dispatch(checkAuth(json)))
	.then(json => dispatch(receiveCurrentUserInvites(json), ))
};

export const clearCurrentUserInvites = (json) => ({
	type: CLEAR_CURRENT_USER_INVITES
});
/****************************************************/

/****************** get from current user invites *******************/
export const requestFromCurrentUserInvites = () => ({
	type: REQUEST_FROM_CURRENT_USER_INVITES
});

export const receiveFromCurrentUserInvites = (json) => ({
	type: RECEIVE_FROM_CURRENT_USER_INVITES,
	payload: json
});

export const fetchFromCurrentUserInvites = (data) => dispatch => {
	var method = 'get_current_user_invites';
	dispatch(requestFromCurrentUserInvites());
	return jsonRPCRequest(PORTAL_SERVICE_URL,method, data)
	.then(response => response.json())
	.then(json => dispatch(checkAuth(json)))
	.then(json => dispatch(receiveFromCurrentUserInvites(json), ))
};

export const clearFromCurrentUserInvites = (json) => ({
	type: CLEAR_FROM_CURRENT_USER_INVITES
});

/****************************************************/

/****************** get invite by id *******************/
export const requestInviteById = () => ({
	type: REQUEST_INVITE_BY_ID
});

export const receiveInviteById = (json) => ({
	type: RECEIVE_INVITE_BY_ID,
	payload: json
});

export const fetchInviteById = (data) => dispatch => {
	var method = 'get_invite';
	dispatch(requestInviteById());
	return jsonRPCRequest(PORTAL_SERVICE_URL,method, data)
	.then(response => response.json())
	.then(json => dispatch(checkAuth(json)))
	.then(json => dispatch(receiveInviteById(json), ))
};

export const clearInviteById = () => ({
	type: CLEAR_INVITE_BY_ID
});
/****************************************************/

/****************** delete invites*******************/
export const requestDeleteInvites = () => ({
	type: REQUEST_DELETE_INVITE
});

export const receiveDeleteInvites = (json) => ({
	type: RECEIVE_DELETE_INVITE,
	payload: json
});

export const fetchDeleteInvites = (data) => dispatch => {
	var method = 'delete_invites';
	dispatch(requestDeleteInvites());
	return jsonRPCRequest(PORTAL_SERVICE_URL,method, data)
	.then(response => response.json())
	.then(json => dispatch(checkAuth(json)))
	.then(json => dispatch(receiveDeleteInvites(json), ))
};
/****************************************************/

/****************** accept invites*******************/
export const requestAcceptInvite = () => ({
	type: REQUEST_ACCEPT_INVITE
});

export const receiveAcceptInvite = (json) => ({
	type: RECEIVE_ACCEPT_INVITE,
	payload: json
});

export const fetchAcceptInvite = (data) => dispatch => {
	var method = 'accept_invite';
	dispatch(requestAcceptInvite());
	return jsonRPCRequest(PORTAL_SERVICE_URL,method, data)
	.then(response => response.json())
	.then(json => dispatch(checkAuth(json)))
	.then(json => dispatch(receiveAcceptInvite(json), ))
};
/****************************************************/

/****************** reject invites*******************/
export const requestRejectInvite = () => ({
	type: REQUEST_REJECT_INVITE
});

export const receiveRejectInvite = (json) => ({
	type: RECEIVE_REJECT_INVITE,
	payload: json
});

export const fetchRejectInvite = (data) => dispatch => {
	var method = 'reject_invite';
	dispatch(requestRejectInvite());
	return jsonRPCRequest(PORTAL_SERVICE_URL,method, data)
	.then(response => response.json())
	.then(json => dispatch(checkAuth(json)))
	.then(json => dispatch(receiveRejectInvite(json), ))
};
/****************************************************/


/****************** send invite *******************/
export const requestSendInvite = () => ({
	type: REQUEST_SEND_INVITE
});

export const receiveSendInvite = (json) => ({
	type: RECEIVE_SEND_INVITE,
	payload: json
});

export const fetchSendInvite = (data) => dispatch => {
	var method = 'send_invite';
	dispatch(requestSendInvite());
	return jsonRPCRequest(PORTAL_SERVICE_URL,method, data)
		.then(response => response.json())
		.then(json => dispatch(checkAuth(json)))
		.then(json => dispatch(receiveSendInvite(json), ))
};
/****************************************************/
