import {jsonRPCRequest} from "./asyncActions";
import {checkAuth} from "./user";
import { HOST_NAME, PROTOCOL } from '../constants';


export const ADD_ADDRESSEE_REQUEST = 'ADD_ADDRESSEE_REQUEST';
export const ADD_ADDRESSEE_RESULT  = 'ADD_ADDRESSEE_RESULT';

export const SET_ADDRESSEE_REQUEST = 'SET_ADDRESSEE_REQUEST';
export const SET_ADDRESSEE_RESULT  = 'SET_ADDRESSEE_RESULT';

export const DELETE_ADDRESSEES_REQUEST = 'DELETE_ADDRESSEES_REQUEST';
export const DELETE_ADDRESSEES_RESULT  = 'DELETE_ADDRESSEES_RESULT';

export const IMPORT_ADDRESSEE_REQUEST = 'IMPORT_ADDRESSEE_REQUEST';
export const IMPORT_ADDRESSEE_RESULT  = 'IMPORT_ADDRESSEE_RESULT';

export const REQUEST_ADDRESSEES = 'REQUEST_ADDRESSEES';
export const RECEIVE_ADDRESSEES = 'RECEIVE_ADDRESSEES';
export const RECEIVE_MORE_ADDRESSES = 'RECEIVE_MORE_ADDRESSES';
export const RECEIVE_SIDEBAR_ADDRESSEES = 'RECEIVE_SIDEBAR_ADDRESSEES';
export const CLEAR_ADDRESSEES = 'CLEAR_ADDRESSEES';

export const REQUEST_ADDRESSEE_BY_ID = 'REQUEST_ADDRESSEE_BY_ID';
export const RECEIVE_ADDRESSEE_BY_ID = 'RECEIVE_ADDRESSEE_BY_ID';
export const CLEAR_ADDRESSEE_BY_ID = 'CLEAR_ADDRESSEE_BY_ID';

export const REQUEST_ADDRESSEES_BY_IDS = 'REQUEST_ADDRESSEES_BY_IDS';
export const RECEIVE_ADDRESSEES_BY_IDS = 'RECEIVE_ADDRESSEES_BY_IDS';
export const CLEAR_ADDRESSEES_BY_IDS = 'CLEAR_ADDRESSEES_BY_IDS';

export const REQUEST_ADDRESSEE_EMPLOYEES = 'REQUEST_ADDRESSEE_EMPLOYEES';
export const RECEIVE_ADDRESSEE_EMPLOYEES = 'RECEIVE_ADDRESSEE_EMPLOYEES';
export const RECEIVE_MORE_ADDRESSEE_EMPLOYEES = 'RECEIVE_MORE_ADDRESSEE_EMPLOYEES';
export const CLEAR_ADDRESSEE_EMPLOYEES = 'CLEAR_ADDRESSEE_EMPLOYEES';

export const RECEIVE_ADDRESSEE_ACCOMPANY_EMPLOYEES = 'RECEIVE_ADDRESSEE_ACCOMPANY_EMPLOYEES';
export const REQUEST_ADDRESSEE_ACCOMPANY_EMPLOYEES = 'REQUEST_ADDRESSEE_ACCOMPANY_EMPLOYEES';
export const CLEAR_ADDRESSEE_ACCOMPANY_EMPLOYEES = 'CLEAR_ADDRESSEE_ACCOMPANY_EMPLOYEES';


export const REQUEST_SET_ADDRESSEE_PERMISSIONS = 'REQUEST_SET_ADDRESSEE_PERMISSIONS';
export const RECEIVE_SET_ADDRESSEE_PERMISSIONS = 'RECEIVE_SET_ADDRESSEE_PERMISSIONS';

export const REQUEST_ADDRESSEE_PERMISSIONS = 'REQUEST_ADDRESSEE_PERMISSIONS';
export const RECEIVE_ADDRESSEE_PERMISSIONS = 'RECEIVE_ADDRESSEE_PERMISSIONS';
export const CLEAR_ADDRESSEE_PERMISSIONS = 'CLEAR_ADDRESSEE_PERMISSIONS';

export const REQUEST_DELETE_ADDRESSEE_PERMISSIONS = 'REQUEST_DELETE_ADDRESSEE_PERMISSIONS';
export const RECEIVE_DELETE_ADDRESSEE_PERMISSIONS = 'RECEIVE_DELETE_ADDRESSEE_PERMISSIONS';


const PORTAL_SERVICE_URL =`${PROTOCOL}//api.${HOST_NAME}/addressee/`;


/****************** add addressee *******************/
export const addAddresseeRequest = () => ({
  type: ADD_ADDRESSEE_REQUEST
});

export const addAddresseeResult = (json) => ({
  type: ADD_ADDRESSEE_RESULT,
  payload: json
});

export const fetchAddAddressee = (data) => dispatch => {
  const method = 'add_addressee';
  dispatch(addAddresseeRequest());
  return jsonRPCRequest(PORTAL_SERVICE_URL,method, data)
  .then(response => response.json())
  .then(json => dispatch(checkAuth(json)))
  .then(json => dispatch(addAddresseeResult(json), ))
};
/****************************************************/

/****************** import addressee *******************/
export const importAddresseeRequest = () => ({
  type: IMPORT_ADDRESSEE_REQUEST
});

export const importAddresseeResult = (json) => ({
  type: IMPORT_ADDRESSEE_RESULT,
  payload: json
});

export const fetchImportAddressee = (data) => dispatch => {
  const method = 'add_addressee';
  dispatch(importAddresseeRequest());
  return jsonRPCRequest(PORTAL_SERVICE_URL,method, data)
    .then(response => response.json())
    .then(json => dispatch(checkAuth(json)))
    .then(json => dispatch(importAddresseeResult(json), ))
};
/****************************************************/

/****************** set addressee *******************/
export const setAddresseeRequest = () => ({
  type: SET_ADDRESSEE_REQUEST
});

export const setAddresseeResult = (json) => ({
  type: SET_ADDRESSEE_RESULT,
  payload: json
});

export const fetchSetAddressee = (data) => dispatch => {
  const method = 'set_addressee';
  dispatch(setAddresseeRequest());
  return jsonRPCRequest(PORTAL_SERVICE_URL,method, data)
  .then(response => response.json())
  .then(json => dispatch(checkAuth(json)))
  .then(json => dispatch(setAddresseeResult(json), ))
};
/****************************************************/

/**************** delete addressee *****************/
export const deleteAddresseesRequest = () => ({
  type: DELETE_ADDRESSEES_REQUEST
});

export const deleteAddresseesResult = (json) => ({
  type: DELETE_ADDRESSEES_RESULT,
  payload: json
});

export const fetchDeleteAddressees = (data) => dispatch => {
  const method = 'delete_addressees';
  dispatch(deleteAddresseesRequest());
  return jsonRPCRequest(PORTAL_SERVICE_URL,method, data)
  .then(response => response.json())
  .then(json => dispatch(checkAuth(json)))
  .then(json => dispatch(deleteAddresseesResult(json), ))
};
/****************************************************/

/****************** get addressees *******************/
export const requestAddressees = () => ({
  type: REQUEST_ADDRESSEES
});

export const receiveAddressees = (json) => ({
  type: RECEIVE_ADDRESSEES,
  payload: json
});

export const receiveSidebarAddressees = (json) => ({
  type: RECEIVE_SIDEBAR_ADDRESSEES,
  payload: json
});

export const receiveMoreAddressees = (json) => ({
  type: RECEIVE_MORE_ADDRESSES,
  payload: json
});

export const clearAddressees = () => ({
  type: CLEAR_ADDRESSEES
});

export const fetchAddressees = (data) => dispatch => {
  const method = 'get_addressees';
  dispatch(requestAddressees());
  return jsonRPCRequest(PORTAL_SERVICE_URL,method, data)
  .then(response => response.json())
  .then(json => dispatch(checkAuth(json)))
  .then(json => dispatch(receiveAddressees(json), ))
};

export const fetchMoreAddressees = (data) => dispatch => {
  const method = 'get_addressees';
  dispatch(requestAddressees());
  return jsonRPCRequest(PORTAL_SERVICE_URL,method, data)
  .then(response => response.json())
  .then(json => dispatch(checkAuth(json)))
  .then(json => dispatch(receiveMoreAddressees(json), ))
};

export const fetchSidebarAddressees = (data) => dispatch => {
  const method = 'get_addressees';
  dispatch(requestAddressees());
  return jsonRPCRequest(PORTAL_SERVICE_URL,method, data)
  .then(response => response.json())
  .then(json => dispatch(checkAuth(json)))
  .then(json => dispatch(receiveSidebarAddressees(json), ))
};

/****************************************************/

/**************** get addressee by id *****************/
export const requestAddresseeById = () => ({
  type: REQUEST_ADDRESSEE_BY_ID
});

export const receiveAddresseeById = (json) => ({
  type: RECEIVE_ADDRESSEE_BY_ID,
  payload: json
});

export const fetchAddresseeById = (data) => dispatch => {
  const method = 'get_addressee';
  dispatch(requestAddresseeById());
  return jsonRPCRequest(PORTAL_SERVICE_URL,method, data)
  .then(response => response.json())
  .then(json => dispatch(checkAuth(json)))
  .then(json => dispatch(receiveAddresseeById(json), ))
};

export const clearAddresseeById = () => ({
  type: CLEAR_ADDRESSEE_BY_ID
});

/****************************************************/

/**************** get addressee by id *****************/
export const requestAddresseesByIds = () => ({
  type: REQUEST_ADDRESSEES_BY_IDS
});

export const receiveAddresseesByIds = (json) => ({
  type: RECEIVE_ADDRESSEES_BY_IDS,
  payload: json
});

export const fetchAddresseesByIds = (data) => dispatch => {
  const method = 'get_addressees_by_ids';
  dispatch(requestAddresseesByIds());
  return jsonRPCRequest(PORTAL_SERVICE_URL,method, data)
  .then(response => response.json())
  .then(json => dispatch(checkAuth(json)))
  .then(json => dispatch(receiveAddresseesByIds(json), ))
};

export const clearAddresseesByIds = () => ({
  type: CLEAR_ADDRESSEES_BY_IDS
});

/****************************************************/


/**************** get addressee users *****************/
export const requestAddresseeEmployees = () => ({
  type: REQUEST_ADDRESSEE_EMPLOYEES
});

export const receiveAddresseeEmployees = (json) => ({
  type: RECEIVE_ADDRESSEE_EMPLOYEES,
  payload: json
});

export const receiveMoreAddresseeEmployees = (json) => ({
  type: RECEIVE_MORE_ADDRESSEE_EMPLOYEES,
  payload: json
});

export const fetchAddresseeEmployees = (data) => dispatch => {
  const method = 'get_addressee_users';
  dispatch(requestAddresseeEmployees());
  return jsonRPCRequest(PORTAL_SERVICE_URL,method, data)
  .then(response => response.json())
  .then(json => dispatch(checkAuth(json)))
  .then(json => dispatch(receiveAddresseeEmployees(json), ))
};

export const fetchMoreAddresseeEmployees = (data) => dispatch => {
  const method = 'get_addressee_users';
  dispatch(requestAddresseeEmployees());
  return jsonRPCRequest(PORTAL_SERVICE_URL,method, data)
  .then(response => response.json())
  .then(json => dispatch(checkAuth(json)))
  .then(json => dispatch(receiveMoreAddresseeEmployees(json), ))
};

export const clearAddresseeEmployees = () => ({
  type: CLEAR_ADDRESSEE_EMPLOYEES
});

export const requestAddresseeAccompanyEmployees = () => ({
  type: REQUEST_ADDRESSEE_ACCOMPANY_EMPLOYEES
});

export const receiveAddresseeAccompanyEmployees = (json) => ({
  type: RECEIVE_ADDRESSEE_ACCOMPANY_EMPLOYEES,
  payload: json
});

export const fetchAddresseeAccompanyEmployees = (data) => dispatch => {
  const method = 'get_addressee_users';
  dispatch(requestAddresseeAccompanyEmployees());
  return jsonRPCRequest(PORTAL_SERVICE_URL,method, data)
    .then(response => response.json())
    .then(json => dispatch(checkAuth(json)))
    .then(json => dispatch(receiveAddresseeAccompanyEmployees(json), ))
};

export const clearAddresseeAccompanyEmployees = () => ({
  type: CLEAR_ADDRESSEE_ACCOMPANY_EMPLOYEES
});
/****************************************************/


/**************** set addressee permitions *****************/
export const requestSetAddresseePermissions = () => ({
  type: REQUEST_SET_ADDRESSEE_PERMISSIONS
});

export const receiveSetAddresseePermissions  = (json) => ({
  type: RECEIVE_SET_ADDRESSEE_PERMISSIONS,
  payload: json
});

export const fetchSetAddresseePermissions = (data) => dispatch => {
  const method = 'set_addressee_permissions';
  dispatch(requestSetAddresseePermissions());
  return jsonRPCRequest(PORTAL_SERVICE_URL,method, data)
  .then(response => response.json())
  .then(json => dispatch(receiveSetAddresseePermissions(json), ))
};

/****************************************************/

/**************** get addressee permitions *****************/
export const requestAddresseePermissions = () => ({
  type: REQUEST_ADDRESSEE_PERMISSIONS
});

export const receiveAddresseePermissions  = (json) => ({
  type: RECEIVE_ADDRESSEE_PERMISSIONS,
  payload: json
});

export const fetchAddresseePermissions = (data) => dispatch => {
  const method = 'get_addressee_permissions';
  dispatch(requestAddresseePermissions());
  return jsonRPCRequest(PORTAL_SERVICE_URL,method, data)
  .then(response => response.json())
  .then(json => dispatch(receiveAddresseePermissions(json), ))
};

export const clearAddresseePermissions = () => ({
  type: CLEAR_ADDRESSEE_PERMISSIONS
});

/****************************************************/

/**************** delete addressee permitions *****************/
export const requestDeleteAddresseePermissions = () => ({
  type: REQUEST_DELETE_ADDRESSEE_PERMISSIONS
});

export const receiveDeleteAddresseePermissions  = (json) => ({
  type: RECEIVE_DELETE_ADDRESSEE_PERMISSIONS,
  payload: json
});

export const fetchDeleteAddresseePermissions = (data) => dispatch => {
  const method = 'delete_addressee_permissions';
  dispatch(requestDeleteAddresseePermissions());
  return jsonRPCRequest(PORTAL_SERVICE_URL,method, data)
  .then(response => response.json())
  .then(json => dispatch(receiveDeleteAddresseePermissions(json), ))
};

/****************************************************/

/****************** import addressee *******************/

export const fetchAddresseesByRoles = (data) => dispatch => {
  console.log('fetchAddresseesByRoles');
  const method = 'fetch_addressees_by_roles';
  dispatch(requestAddressees());
  return jsonRPCRequest(PORTAL_SERVICE_URL, method, data)
    .then(response => response.json())
    .then(json => dispatch(checkAuth(json)))
    .then(json => dispatch(receiveAddressees(json), ))
};
/****************************************************/


