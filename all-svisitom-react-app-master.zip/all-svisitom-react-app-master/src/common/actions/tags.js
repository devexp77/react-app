import { jsonRPCRequest } from "./asyncActions";
import { checkAuth } from "./user";

import { HOST_NAME, PROTOCOL } from "../constants";
const SERVICE_URL = `${PROTOCOL}//api.${HOST_NAME}/tags/`;

export const REQUEST_ADD_TAG = "REQUEST_ADD_TAG";
export const RECEIVE_ADD_TAG = "RECEIVE_ADD_TAG";

export const REQUEST_TAGS = "REQUEST_TAGS";
export const RECEIVE_TAGS = "RECEIVE_TAGS";
export const CLEAR_TAGS = "CLEAR_TAGS";

/*** add tag ***/

export const requestAddTag = () => ({
  type: REQUEST_ADD_TAG
});

export const receiveAddTag = json => ({
  type: RECEIVE_ADD_TAG,
  payload: json
});

export const fetchAddTag = data => dispatch => {
  const method = "add_tag";
  dispatch(requestAddTag());
  return jsonRPCRequest(SERVICE_URL, method, data)
    .then(response => response.json())
    .then(json => dispatch(checkAuth(json)))
    .then(json => dispatch(receiveAddTag(json)));
};

/*** get tags ***/
export const requestTags = () => ({
  type: REQUEST_TAGS
});

export const receiveTags = json => ({
  type: RECEIVE_TAGS,
  payload: json
});

export const clearTags = () => ({
  type: CLEAR_TAGS
});

export const fetchTags = data => dispatch => {
  const method = "get_tags";
  dispatch(requestTags());
  return jsonRPCRequest(SERVICE_URL, method, data)
    .then(response => response.json())
    .then(json => dispatch(checkAuth(json)))
    .then(json => dispatch(receiveTags(json)));
};
