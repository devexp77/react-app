import {jsonRPCRequest} from "./asyncActions";
import {checkAuth} from "./user";
import { HOST_NAME, PROTOCOL } from '../constants';

export const REQUEST_ADD_ADVERT = 'REQUEST_ADD_ADVERT';
export const RECEIVE_ADD_ADVERT = 'RECEIVE_ADD_ADVERT';

export const REQUEST_SET_ADVERT = 'REQUEST_SET_ADVERT';
export const RECEIVE_SET_ADVERT = 'RECEIVE_SET_ADVERT';

export const REQUEST_DELETE_ADVERT = 'REQUEST_DELETE_ADVERT';
export const RECEIVE_DELETE_ADVERT = 'RECEIVE_DELETE_ADVERT';

export const REQUEST_ADVERTS = 'REQUEST_ADVERTS';
export const RECEIVE_MORE_ADVERTS = 'RECEIVE_MORE_ADVERTS';
export const RECEIVE_ADVERTS = 'RECEIVE_ADVERTS';
export const CLEAR_ADVERTS = 'CLEAR_ADVERTS';

export const REQUEST_ADVERT_BY_ID = 'REQUEST_ADVERT_BY_ID';
export const RECEIVE_ADVERT_BY_ID = 'RECEIVE_ADVERT_BY_ID';
export const CLEAR_ADVERT_BY_ID = 'CLEAR_ADVERT_BY_ID';


const SERVICE_URL =`${PROTOCOL}//api.${HOST_NAME}/adverts/`;



/****************** add advert *******************/
export const addAdvertRequest = () => ({
  type: REQUEST_ADD_ADVERT
});

export const addAdvertResult = (json) => ({
  type: RECEIVE_ADD_ADVERT,
  payload: json
});

export const fetchAddAdvert = (data) => dispatch => {
  const method = 'add_advert';
  dispatch(addAdvertRequest());
  return jsonRPCRequest(SERVICE_URL,method, data)
    .then(response => response.json())
    .then(json => dispatch(checkAuth(json)))
    .then(json => dispatch(addAdvertResult(json), ))
};


/****************** set advert *******************/
export const setAdvertRequest = () => ({
  type: REQUEST_SET_ADVERT
});

export const setAdvertResult = (json) => ({
  type: RECEIVE_SET_ADVERT,
  payload: json
});

export const fetchSetAdvert = (data) => dispatch => {
  const method = 'set_advert';
  dispatch(setAdvertRequest());
  return jsonRPCRequest(SERVICE_URL,method, data)
    .then(response => response.json())
    .then(json => dispatch(checkAuth(json)))
    .then(json => dispatch(setAdvertResult(json), ))
};


/****************** delete adverts *******************/
export const deleteAdvertRequest = () => ({
  type: REQUEST_DELETE_ADVERT
});

export const deleteAdvertResult = (json) => ({
  type: RECEIVE_DELETE_ADVERT,
  payload: json
});

export const fetchDeleteAdvert = (data) => dispatch => {
  const method = 'delete_advert';
  dispatch(deleteAdvertRequest());
  return jsonRPCRequest(SERVICE_URL,method, data)
    .then(response => response.json())
    .then(json => dispatch(checkAuth(json)))
    .then(json => dispatch(deleteAdvertResult(json), ))
};



/****************** get adverts *******************/
export const clearAdverts = () => ({
  type: CLEAR_ADVERTS
});

export const getAdvertsRequest = () => ({
  type: REQUEST_ADVERTS
});

export const getAdvertsResult = (json) => ({
  type: RECEIVE_ADVERTS,
  payload: json
});

export const getMoreAdvertsResult = (json) => ({
  type: RECEIVE_MORE_ADVERTS,
  payload: json
});

export const fetchAdverts = (data) => dispatch => {
  const method = 'get_adverts';
  dispatch(getAdvertsRequest());
  return jsonRPCRequest(SERVICE_URL,method, data)
    .then(response => response.json())
    .then(json => dispatch(checkAuth(json)))
    .then(json => dispatch(getAdvertsResult(json), ))
};

export const fetchMoreAdverts = (data) => dispatch => {
  const method = 'get_adverts';
  dispatch(getAdvertsRequest());
  return jsonRPCRequest(SERVICE_URL,method, data)
    .then(response => response.json())
    .then(json => dispatch(checkAuth(json)))
    .then(json => dispatch(getMoreAdvertsResult(json), ))
};


/****************** get advert by id *******************/
export const clearAdvertById = () => ({
  type: CLEAR_ADVERT_BY_ID
});

export const getAdvertByIdRequest = () => ({
  type: REQUEST_ADVERT_BY_ID
});

export const getAdvertByIdResult = (json) => ({
  type: RECEIVE_ADVERT_BY_ID,
  payload: json
});

export const fetchAdvertById = (data) => dispatch => {
  const method = 'get_advert';
  dispatch(getAdvertByIdRequest());
  return jsonRPCRequest(SERVICE_URL,method, data)
    .then(response => response.json())
    .then(json => dispatch(checkAuth(json)))
    .then(json => dispatch(getAdvertByIdResult(json), ))
};




