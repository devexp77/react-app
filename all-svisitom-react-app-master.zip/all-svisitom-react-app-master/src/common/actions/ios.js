import { GETRequest, jsonRPCRequest, postRequest } from "./asyncActions";
import { HOST_NAME, PROTOCOL } from "../constants";

export const REQUEST_ALL_IOS_IDS = "REQUEST_ALL_IOS_IDS";
export const RECEIVE_ALL_IOS_IDS = "RECEIVE_ALL_IOS_IDS";

export const REQUEST_IOS_BY_ID = "REQUEST_IOS_BY_ID";
export const RECEIVE_IOS_BY_ID = "RECEIVE_IOS_BY_ID";
export const CLEAR_IOS_BY_ID = "CLEAR_IOS_BY_ID";
export const DELETE_IOS = "DELETE_IOS";

export const REQUEST_IOS_META_BY_ID = "REQUEST_IOS_META_BY_ID";
export const RECEIVE_IOS_META_BY_ID = "RECEIVE_IOS_META_BY_ID";
export const CLEAR_IOS_META_BY_ID = "CLEAR_IOS_META_BY_ID";

export const REQUEST_SET_IOS = "REQUEST_SET_IOS";
export const RECEIVE_SET_IOS = "RECEIVE_SET_IOS";

export const REQUEST_IOS_URL = "REQUEST_IOS_URL";
export const RECEIVE_IOS_URL = "RECEIVE_IOS_URL";
export const CLEAR_IOS_URL = "CLEAR_IOS_URL";

export const REQUEST_IOS_META_URL = "REQUEST_IOS_META_URL";
export const RECEIVE_IOS_META_URL = "RECEIVE_IOS_META_URL";
export const CLEAR_IOS_META_URL = "CLEAR_IOS_META_URL";

export const REQUEST_CREATE_META_DATA = "REQUEST_CREATE_META_DATA";
export const RECEIVE_CREATE_META_DATA = "RECEIVE_CREATE_META_DATA";

const PORTAL_UPLOAD_URL = `${PROTOCOL}//ios.${HOST_NAME}/`;
const PORTAL_SERVICE_URL = `${PROTOCOL}//api.${HOST_NAME}/ios/`;
/************ *************/
export const requestSetIos = () => ({
  type: REQUEST_SET_IOS
});

export const receiveSetIos = json => ({
  type: RECEIVE_SET_IOS,
  payload: json
});

export const fetchSetIos = data => dispatch => {
  dispatch(requestSetIos());
  return postRequest(PORTAL_UPLOAD_URL, data)
    .then(response => response.json())
    .then(json => dispatch(receiveSetIos(json)));
};

/**********************************************/

/************   *************/
export const requestIosById = () => ({
  type: REQUEST_IOS_BY_ID
});

export const receiveIosById = json => ({
  type: RECEIVE_IOS_BY_ID,
  payload: json
});

export const clearIosById = () => ({
  type: CLEAR_IOS_BY_ID
});

export const fetchIosById = url => dispatch => {
  dispatch(requestIosById());
  return GETRequest(url)
    .then(response => response.text())
    .then(text => dispatch(receiveIosById(text)));
};

/**********************************************/

/************   *************/
export const requestIosMetaById = () => ({
  type: REQUEST_IOS_META_BY_ID
});

export const receiveIosMetaById = json => ({
  type: RECEIVE_IOS_META_BY_ID,
  payload: json
});

export const clearIosMetaById = () => ({
  type: CLEAR_IOS_META_BY_ID
});

export const fetchIosMetaById = url => dispatch => {
  dispatch(requestIosMetaById());
  return GETRequest(url)
    .then(response => response.text())
    .then(text => dispatch(receiveIosMetaById(text)));
};

/**********************************************/

/************  *************/
export const requestIosUrl = () => ({
  type: REQUEST_IOS_URL
});

export const receiveIosUrl = json => ({
  type: RECEIVE_IOS_URL,
  payload: json
});

export const clearIosUrl = () => ({
  type: CLEAR_IOS_URL,
});

export const fetchIosUrl = data => dispatch => {
  const method = "get_ios_url";
  dispatch(requestIosUrl());
  return jsonRPCRequest(PORTAL_SERVICE_URL, method, data)
    .then(response => response.json())
    .then(json => dispatch(receiveIosUrl(json)));
};

/************  *************/

/************  *************/
export const requestIosMetaUrl = () => ({
  type: REQUEST_IOS_META_URL
});

export const receiveIosMetaUrl = json => ({
  type: RECEIVE_IOS_META_URL,
  payload: json
});

export const clearIosMetaUrl = () => ({
  type: CLEAR_IOS_META_URL,
});

export const fetchIosMetaUrl = data => dispatch => {
  const method = "get_ios_url";
  dispatch(requestIosMetaUrl());
  return jsonRPCRequest(PORTAL_SERVICE_URL, method, data)
    .then(response => response.json())
    .then(json => dispatch(receiveIosMetaUrl(json)));
};

/************  *************/

/************  *************/
export const requestAllIosIds = () => ({
  type: REQUEST_ALL_IOS_IDS
});

export const receiveAllIosIds = json => ({
  type: RECEIVE_ALL_IOS_IDS,
  payload: json
});

export const fetchAllIosIds = data => dispatch => {
  const method = "get_all_ios";
  dispatch(requestAllIosIds());
  return jsonRPCRequest(PORTAL_SERVICE_URL, method, data)
    .then(response => response.json())
    .then(json => dispatch(receiveAllIosIds(json)));
};

/************  *************/

export const deleteIos = json => ({
  type: DELETE_IOS,
  payload: json
});

export const fetchDeleteIos = data => dispatch => {
  const method = "delete_ios";
  return jsonRPCRequest(PORTAL_SERVICE_URL, method, data)
    .then(response => response.json())
    .then(json => dispatch(deleteIos(json)));
};



export const requestCreateMetaData = () => ({
  type: REQUEST_CREATE_META_DATA
});

export const receiveCreateMetaData = json => ({
  type: RECEIVE_CREATE_META_DATA,
  payload: json
});

export const fetchCreateMetaData = data => dispatch => {
  const method = "create_meta_data";
  dispatch(requestCreateMetaData());
  return jsonRPCRequest(PORTAL_SERVICE_URL, method, data)
    .then(response => response.json())
    .then(json => dispatch(receiveCreateMetaData(json)));
};
