import { jsonRPCRequest } from "./asyncActions";
import { checkAuth } from "./user";
import { HOST_NAME, PROTOCOL } from "../constants";

const SERVICE_URL = `${PROTOCOL}//api.${HOST_NAME}/contacts/`;

export const REQUEST_CONTACTS = "REQUEST_CONTACTS";
export const RECEIVE_CONTACTS = "RECEIVE_CONTACTS";
export const CLEAR_CONTACTS = "CLEAR_CONTACTS";

export const REQUEST_ALL_CONTACTS = "REQUEST_ALL_CONTACTS";
export const RECEIVE_ALL_CONTACTS = "RECEIVE_ALL_CONTACTS";
export const CLEAR_ALL_CONTACTS = "CLEAR_ALL_CONTACTS";

/*
  fetchGetContacts
*/

export const requestContacts = () => ({
  type: REQUEST_CONTACTS
});

export const receiveContacts = (json, id) => ({
  type: RECEIVE_CONTACTS,
  payload: json,
  id: id
});

export const clearContacts = () => ({
  type: CLEAR_CONTACTS
});

export const fetchContacts = (data, id) => dispatch => {
  const method = "get_current_user_contacts";
  dispatch(requestContacts());
  return jsonRPCRequest(SERVICE_URL, method, data)
    .then(response => response.json())
    .then(json => dispatch(checkAuth(json)))
    .then(json => dispatch(receiveContacts(json, id)));
};

export const requestAllContacts = () => ({
  type: REQUEST_ALL_CONTACTS
});

export const receiveAllContacts = (json) => ({
  type: RECEIVE_ALL_CONTACTS,
  payload: json
});

export const clearAllContacts = () => ({
  type: CLEAR_ALL_CONTACTS
});

export const fetchAllContacts = (data) => dispatch => {
  const method = "get_current_user_contacts";
  dispatch(requestAllContacts());
  return jsonRPCRequest(SERVICE_URL, method, data)
    .then(response => response.json())
    .then(json => dispatch(checkAuth(json)))
    .then(json => dispatch(receiveAllContacts(json)));
};
/************************************************/
