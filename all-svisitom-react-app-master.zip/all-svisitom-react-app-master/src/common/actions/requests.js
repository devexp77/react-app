import { jsonRPCRequest } from "./asyncActions";
import { HOST_NAME, PROTOCOL } from "../constants";

export const REQUEST_REQUEST_RECORDS = "REQUEST_REQUEST_RECORDS";
export const RECEIVE_REQUEST_RECORDS = "RECEIVE_REQUEST_RECORDS";
export const RECEIVE_SCROLL_REQUEST_RECORDS = "RECEIVE_SCROLL_REQUEST_RECORDS";
export const CLEAR_REQUEST_RECORDS = "CLEAR_REQUEST_RECORDS";

export const REQUEST_SET_REQUEST = "REQUEST_SET_REQUEST";
export const RECEIVE_SET_REQUEST = "RECEIVE_SET_REQUEST";

export const REQUEST_REQUEST_RECORD_ID = "REQUEST_REQUEST_RECORD_ID";
export const RECEIVE_REQUEST_RECORD_ID = "RECEIVE_REQUEST_RECORD_ID";
export const CLEAR_REQUEST_RECORD_BY_ID = "CLEAR_REQUEST_RECORD_BY_ID";

export const REQUEST_APPROVE_REQUEST = "REQUEST_REGISTER_REQUEST";
export const RECEIVE_REGISTER_REQUEST = "RECEIVE_REGISTER_REQUEST";

export const REQUEST_REGISTER_REQUEST = "REQUEST_APPROVE_REQUEST";
export const RECEIVE_APPROVE_REQUEST = "RECEIVE_APPROVE_REQUEST";

export const REQUEST_REQUEST_HISTORY = "REQUEST_REQUEST_HISTORY";
export const RECEIVE_REQUEST_HISTORY = "RECEIVE_REQUEST_HISTORY";
export const CLEAR_REQUEST_HISTORY = "CLEAR_REQUEST_HISTORY";

export const CAN_APPROVE_REQUEST = "CAN_APPROVE_REQUEST";
export const CAN_REGISTER_REQUEST = "CAN_REGISTER_REQUEST";
export const CAN_SEND_REQUEST_FOR_APPROVAL = "CAN_SEND_REQUEST_FOR_APPROVAL";

export const REQUEST_ADD_REQUEST = "REQUEST_ADD_REQUEST";
export const RECEIVE_ADD_REQUEST = "RECEIVE_ADD_REQUEST";

export const SAVE_REQUEST_DATA = "SAVE_REQUEST_DATA";
export const CLEAR_REQUEST_DATA = "CLEAR_REQUEST_DATA";

export const REQUEST_SEND_FOR_REVIEW = "REQUEST_SEND_FOR_REVIEW";
export const RECEIVE_SEND_FOR_REVIEW = "RECEIVE_SEND_FOR_REVIEW";

export const RECEIVE_SEND_FOR_APPROVAL = "RECEIVE_SEND_FOR_APPROVAL";
export const REQUEST_SEND_FOR_APPROVAL = "REQUEST_SEND_FOR_APPROVAL";

export const RECEIVE_CANCEL_REQUEST = "RECEIVE_CANCEL_REQUEST";
export const REQUEST_CANCEL_REQUEST = "REQUEST_CANCEL_REQUEST";


export const SAVE_REQUESTS_FILTER = "SAVE_REQUESTS_FILTER";

/*******************************************************************/
const PORTAL_SERVICE_URL = `${PROTOCOL}//api.${HOST_NAME}/requests/`;
/*******************************************************************/

/****************** get requests **************/
export const requestRequestRecords = () => ({
  type: REQUEST_REQUEST_RECORDS
});

export const receiveRequestRecords = json => ({
  type: RECEIVE_REQUEST_RECORDS,
  requestRecords: json
});

export const receiveScrollRequestRecords = json => ({
  type: RECEIVE_SCROLL_REQUEST_RECORDS,
  requestRecords: json
});

export const fetchRequestRecords = data => dispatch => {
  const method = "get_requests";
  dispatch(requestRequestRecords());
  return jsonRPCRequest(PORTAL_SERVICE_URL, method, data)
    .then(response => response.json())
    .then(json => dispatch(receiveRequestRecords(json)));
};

export const fetchScrollRequestRecords = data => dispatch => {
  const method = "get_requests";
  dispatch(requestRequestRecords());
  return jsonRPCRequest(PORTAL_SERVICE_URL, method, data)
    .then(response => response.json())
    .then(json => dispatch(receiveScrollRequestRecords(json)));
};

export const clearRequestRecords = () => ({
  type: CLEAR_REQUEST_RECORDS
});
/*******************************************************/

/******************* set request **********************/
export const requestSetRequest = () => ({
  type: REQUEST_SET_REQUEST
});

export const receiveSetRequest = json => ({
  type: RECEIVE_SET_REQUEST,
  payload: json
});

export const fetchSetRequest = data => dispatch => {
  const method = "set_request";
  dispatch(requestSetRequest());
  return jsonRPCRequest(PORTAL_SERVICE_URL, method, data)
    .then(response => response.json())
    .then(json => dispatch(receiveSetRequest(json)));
};

/******************************************************/

/******************** get request by id **************/
export const requestRequestRecordById = () => ({
  type: REQUEST_REQUEST_RECORD_ID
});

export const receiveRequestRecordById = json => ({
  type: RECEIVE_REQUEST_RECORD_ID,
  requestRecordById: json
});

export const fetchRequestRecordById = data => dispatch => {
  const method = "get_request";
  dispatch(requestRequestRecordById());
  return jsonRPCRequest(PORTAL_SERVICE_URL, method, data)
    .then(response => response.json())
    .then(json => dispatch(receiveRequestRecordById(json)));
};

export const clearRequestRecordById = () => ({
  type: CLEAR_REQUEST_RECORD_BY_ID
});
/********************************************************/

/*************** register request **********************/
export const requestRegisterRequest = () => ({
  type: REQUEST_REGISTER_REQUEST
});

export const receiveRegisterRequest = json => ({
  type: RECEIVE_REGISTER_REQUEST,
  payload: json
});

export const fetchRegisterRequest = data => dispatch => {
  const method = "register_request";
  dispatch(requestRegisterRequest());
  return jsonRPCRequest(PORTAL_SERVICE_URL, method, data)
    .then(response => response.json())
    .then(json => dispatch(receiveRegisterRequest(json)));
};
/*********************************************************/

/*************** approve request **********************/
export const requestApproveRequest = () => ({
  type: REQUEST_APPROVE_REQUEST
});

export const receiveApproveRequest = json => ({
  type: RECEIVE_APPROVE_REQUEST,
  payload: json
});

export const fetchApproveRequest = data => dispatch => {
  const method = "approve_request";
  dispatch(requestApproveRequest());
  return jsonRPCRequest(PORTAL_SERVICE_URL, method, data)
    .then(response => response.json())
    .then(json => dispatch(receiveApproveRequest(json)));
};
/*********************************************************/

/*************** get request history **********************/
export const requestRequestHistory = () => ({
  type: REQUEST_REQUEST_HISTORY
});

export const receiveRequestHistory = json => ({
  type: RECEIVE_REQUEST_HISTORY,
  payload: json
});

export const fetchRequestHistory = data => dispatch => {
  const method = "get_request_history";
  dispatch(requestRequestHistory());
  return jsonRPCRequest(PORTAL_SERVICE_URL, method, data)
    .then(response => response.json())
    .then(json => dispatch(receiveRequestHistory(json)));
};

export const clearRequestHistory = () => ({
  type: CLEAR_REQUEST_HISTORY
});

/*********************************************************/

/************** check can approve request ***************/
export const canApproveRequest = json => ({
  type: CAN_APPROVE_REQUEST,
  payload: json
});

export const fetchCanApproveRequest = data => dispatch => {
  const method = "can_approve";
  return jsonRPCRequest(PORTAL_SERVICE_URL, method, data)
    .then(response => response.json())
    .then(json => dispatch(canApproveRequest(json)));
};
/*********************************************************/

/************** check can register request ***************/
export const canRegisterRequest = json => ({
  type: CAN_REGISTER_REQUEST,
  payload: json
});

export const fetchCanRegisterRequest = data => dispatch => {
  const method = "can_register";
  return jsonRPCRequest(PORTAL_SERVICE_URL, method, data)
    .then(response => response.json())
    .then(json => dispatch(canRegisterRequest(json)));
};
/*********************************************************/

/*********************** add request **********************/
export const requestAddRequest = () => ({
  type: REQUEST_ADD_REQUEST
});

export const receiveAddRequest = json => ({
  type: RECEIVE_ADD_REQUEST,
  payload: json
});

export const fetchAddRequest = data => dispatch => {
  const method = "add_request";
  dispatch(requestAddRequest());
  return jsonRPCRequest(PORTAL_SERVICE_URL, method, data)
    .then(response => response.json())
    .then(json => dispatch(receiveAddRequest(json)));
};
/*********************************************************/

/*********************** send_for_review**********************/
export const requestSendForReview = () => ({
  type: REQUEST_SEND_FOR_REVIEW
});

export const receiveSendForReview = json => ({
  type: RECEIVE_SEND_FOR_REVIEW,
  payload: json
});

export const fetchSendForReview = data => dispatch => {
  const method = "send_for_review";
  dispatch(requestSendForReview());
  return jsonRPCRequest(PORTAL_SERVICE_URL, method, data)
    .then(response => response.json())
    .then(json => dispatch(receiveSendForReview(json)));
};
/*********************************************************/

/*********************** send_for_approval**********************/
export const requestSendForApproval = () => ({
  type: REQUEST_SEND_FOR_APPROVAL
});

export const receiveSendForApproval = json => ({
  type: RECEIVE_SEND_FOR_APPROVAL,
  payload: json
});

export const fetchSendForApproval = data => dispatch => {
  const method = "send_for_approval";
  dispatch(requestSendForApproval());
  return jsonRPCRequest(PORTAL_SERVICE_URL, method, data)
    .then(response => response.json())
    .then(json => dispatch(receiveSendForApproval(json)));
};
/*********************************************************/

/*********************** cancel request**********************/
export const requestCancelRequest = () => ({
  type: REQUEST_CANCEL_REQUEST
});

export const receiveCancelRequest= json => ({
  type: RECEIVE_CANCEL_REQUEST,
  payload: json
});

export const fetchCancelRequest = data => dispatch => {
  const method = "cancel_request";
  dispatch(requestCancelRequest());
  return jsonRPCRequest(PORTAL_SERVICE_URL, method, data)
    .then(response => response.json())
    .then(json => dispatch(receiveCancelRequest(json)));
};
/*********************************************************/

/************** check can send for approval ***************/
export const canSendRequestForApproval = json => ({
  type: CAN_SEND_REQUEST_FOR_APPROVAL,
  payload: json
});

export const fetchCanSendRequestForApproval = data => dispatch => {
  const method = "can_send_for_approval";
  return jsonRPCRequest(PORTAL_SERVICE_URL, method, data)
    .then(response => response.json())
    .then(json => dispatch(canSendRequestForApproval(json)));
};
/*********************************************************/

/*********** save request data on request page ***********/
export const saveRequestData = data => ({
  type: SAVE_REQUEST_DATA,
  payload: data
});

export const clearRequestData = () => ({
  type: CLEAR_REQUEST_DATA
});

/************************************************/

/************** save request filter *****************/
export const saveRequestsFilter = data => ({
  type: SAVE_REQUESTS_FILTER,
  payload: data
});
/**************************************************/
