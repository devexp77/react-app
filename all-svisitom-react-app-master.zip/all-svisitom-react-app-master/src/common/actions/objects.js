import { jsonRPCRequest } from "./asyncActions";
import { checkAuth } from "./user";
import { HOST_NAME, PROTOCOL } from "../constants";
import { push } from "react-router-redux";

export const REQUEST_USER_OBJECTS = "REQUEST_USER_OBJECTS";
export const RECEIVE_USER_OBJECTS = "RECEIVE_USER_OBJECTS";

export const REQUEST_OBJECT_BY_ID = "REQUEST_OBJECT_BY_ID";
export const RECEIVE_OBJECT_BY_ID = "RECEIVE_OBJECT_BY_ID";
export const CLEAR_OBJECT_BY_ID = "CLEAR_OBJECT_BY_ID";

export const REQUEST_ADD_USER_OBJECT = "REQUEST_ADD_USER_OBJECT";
export const RECEIVE_ADD_USER_OBJECT = "RECEIVE_ADD_USER_OBJECT";

export const REQUEST_SET_OBJECT = "REQUEST_SET_OBJECT";
export const RECEIVE_SET_OBJECT = "RECEIVE_SET_OBJECT";

export const REQUEST_DELETE_USER_OBJECT = "REQUEST_DELETE_USER_OBJECT";
export const DELETE_USER_OBJECT = "DELETE_USER_OBJECT";

export const REQUEST_RESTORE_USER_OBJECT = "REQUEST_RESTORE_USER_OBJECT";
export const RECEIVE_RESTORE_USER_OBJECT = "RECEIVE_RESTORE_USER_OBJECT";

export const CHECK_OBJECT_DOMAIN = "CHECK_OBJECT_DOMAIN";
export const REQUEST_CHECK_OBJECT_DOMAIN = "REQUEST_CHECK_OBJECT_DOMAIN";

export const REQUEST_OBJECTS = "REQUEST_OBJECTS";
export const RECEIVE_OBJECTS = "RECEIVE_OBJECTS";
export const RECEIVE_MORE_OBJECTS = "RECEIVE_MORE_OBJECTS";
export const CLEAR_OBJECTS = "CLEAR_OBJECTS";
export const REQUEST_OBJECTS_COUNT = "REQUEST_OBJECTS_COUNT";
export const RECEIVE_OBJECTS_COUNT = "RECEIVE_OBJECTS_COUNT";


export const REQUEST_OBJECTS_BY_ROLES = "REQUEST_OBJECTS_BY_ROLES";
export const RECEIVE_OBJECTS_BY_ROLES = "RECEIVE_OBJECTS_BY_ROLES";
export const CLEAR_OBJECTS_BY_ROLES = "CLEAR_OBJECTS_BY_ROLES";

export const REQUEST_CURRENT_OBJECT = "REQUEST_CURRENT_OBJECT";
export const RECEIVE_CURRENT_OBJECT = "RECEIVE_CURRENT_OBJECT";

export const REQUEST_OBJECT_EMPLOYEES = "REQUEST_OBJECT_EMPLOYEES";
export const RECEIVE_OBJECT_EMPLOYEES = "RECEIVE_OBJECT_EMPLOYEES";
export const RECEIVE_MORE_OBJECT_EMPLOYEES = "RECEIVE_MORE_OBJECT_EMPLOYEES";
export const CLEAR_OBJECT_EMPLOYEES = "CLEAR_OBJECT_EMPLOYEES";

export const REQUEST_SET_OBJECT_PERMISSIONS = "REQUEST_SET_OBJECT_PERMISSIONS";
export const RECEIVE_SET_OBJECT_PERMISSIONS = "RECEIVE_SET_OBJECT_PERMISSIONS";

export const REQUEST_OBJECT_PERMISSIONS = "REQUEST_OBJECT_PERMISSIONS";
export const RECEIVE_OBJECT_PERMISSIONS = "RECEIVE_OBJECT_PERMISSIONS";

export const REQUEST_DELETE_OBJECT_PERMISSIONS =
  "REQUEST_DELETE_OBJECT_PERMISSIONS";
export const RECEIVE_DELETE_OBJECT_PERMISSIONS =
  "RECEIVE_DELETE_OBJECT_PERMISSIONS";

export const REQUEST_OBJECTS_BY_IDS = "REQUEST_OBJECTS_BY_IDS";
export const RECEIVE_OBJECTS_BY_IDS = "RECEIVE_OBJECTS_BY_IDS";
export const CLEAR_OBJECTS_BY_IDS = "CLEAR_OBJECTS_BY_IDS";

const PORTAL_SERVICE_URL = `${PROTOCOL}//api.${HOST_NAME}/objects/`;

export const toSuccessPage = () => dispatch => {
  dispatch(push("/success"));
};

/*************get objects by owner*****************/
export const requestUserObjects = () => ({
  type: REQUEST_USER_OBJECTS
});

export const receiveUserObjects = json => ({
  type: RECEIVE_USER_OBJECTS,
  payload: json
});

export const fetchUserObjects = () => dispatch => {
  const method = "get_objects_by_owner";
  dispatch(requestUserObjects());
  return jsonRPCRequest(PORTAL_SERVICE_URL, method, [])
    .then(response => response.json())
    .then(json => dispatch(checkAuth(json)))
    .then(json => dispatch(receiveUserObjects(json)));
};
/******************************************************/

/***************get object by id*********************/
export const requestObjectById = () => ({
  type: REQUEST_OBJECT_BY_ID
});

export const receiveObjectById = json => ({
  type: RECEIVE_OBJECT_BY_ID,
  payload: json
});

export const clearObjectById = () => ({
  type: CLEAR_OBJECT_BY_ID
});

export const fetchObjectById = data => dispatch => {
  const method = "get_object";
  dispatch(requestObjectById());
  return jsonRPCRequest(PORTAL_SERVICE_URL, method, data)
    .then(response => response.json())
    .then(json => dispatch(checkAuth(json)))
    .then(json => dispatch(receiveObjectById(json)));
};
/****************************************************/

/************** add user object*************************/
export const requestAddUserObject = () => ({
  type: REQUEST_ADD_USER_OBJECT
});

export const receiveAddUserObject = json => ({
  type: RECEIVE_ADD_USER_OBJECT,
  addObjectStatus: json
});

export const addUserObjectsRequest = data => dispatch => {
  const method = "add_object";
  dispatch(requestAddUserObject());
  return jsonRPCRequest(PORTAL_SERVICE_URL, method, data)
    .then(response => response.json())
    .then(json => dispatch(checkAuth(json)))
    .then(json => dispatch(receiveAddUserObject(json)));
};
/******************************************************/

/**************** delete object ******************/
export const requestDeleteUserObject = () => ({
  type: REQUEST_DELETE_USER_OBJECT
});

export const deleteUserObject = json => ({
  type: DELETE_USER_OBJECT,
  deleteObjectStatus: json
});

export const deleteUserObjectsRequest = data => dispatch => {
  const method = "delete_object";
  dispatch(requestDeleteUserObject());
  return jsonRPCRequest(PORTAL_SERVICE_URL, method, data)
    .then(response => response.json())
    .then(json => dispatch(checkAuth(json)))
    .then(json => dispatch(deleteUserObject(json)));
};
/***********************************************/

/**************** delete object ******************/
export const requestRestoreUserObject = () => ({
  type: REQUEST_RESTORE_USER_OBJECT
});

export const receiveRestoreUserObject = json => ({
  type: RECEIVE_RESTORE_USER_OBJECT,
  restoreObjectStatus: json
});

export const restoreUserObjects = data => dispatch => {
  const method = "restore_object";
  dispatch(requestRestoreUserObject());
  return jsonRPCRequest(PORTAL_SERVICE_URL, method, data)
    .then(response => response.json())
    .then(json => dispatch(checkAuth(json)))
    .then(json => dispatch(receiveRestoreUserObject(json)));
};
/***********************************************/

/**************** check domain ******************/
export const requestCheckObjectDomainName = () => ({
  type: REQUEST_CHECK_OBJECT_DOMAIN
});

export const checkObjectDomainName = json => ({
  type: CHECK_OBJECT_DOMAIN,
  domainStatus: json
});

export const checkObjectDomainNameRequest = data => dispatch => {
  const method = "validate_domain_name";
  dispatch(requestCheckObjectDomainName());
  return jsonRPCRequest(PORTAL_SERVICE_URL, method, data)
    .then(response => response.json())
    .then(json => dispatch(checkAuth(json)))
    .then(json => dispatch(checkObjectDomainName(json)));
};

/********************************************************/

export const clearObjects = () => ({
  type: CLEAR_OBJECTS
});

/********************* get object **********************/
export const requestObjects = () => ({
  type: REQUEST_OBJECTS
});

export const receiveObjects = json => ({
  type: RECEIVE_OBJECTS,
  payload: json
});

export const receiveMoreObjects = json => ({
  type: RECEIVE_MORE_OBJECTS,
  payload: json
});

export const fetchObjects = data => dispatch => {
  const method = "get_objects";
  dispatch(requestObjects());
  return jsonRPCRequest(PORTAL_SERVICE_URL, method, data)
    .then(response => response.json())
    .then(json => dispatch(checkAuth(json)))
    .then(json => dispatch(receiveObjects(json)));
};

export const fetchMoreObjects = data => dispatch => {
  const method = "get_objects";
  dispatch(requestObjects());
  return jsonRPCRequest(PORTAL_SERVICE_URL, method, data)
    .then(response => response.json())
    .then(json => dispatch(checkAuth(json)))
    .then(json => dispatch(receiveMoreObjects(json)));
};

export const requestObjectsCount = () => ({
  type: REQUEST_OBJECTS_COUNT
});

export const receiveObjectsCount = json => ({
  type: RECEIVE_OBJECTS_COUNT,
  payload: json
});


export const fetchObjectsCount = data => dispatch => {
  const method = "get_object_count";
  dispatch(requestObjectsCount());
  return jsonRPCRequest(PORTAL_SERVICE_URL, method, data)
    .then(response => response.json())
    .then(json => dispatch(checkAuth(json)))
    .then(json => dispatch(receiveObjectsCount(json)));
};
/**********************************************************/

/**************** get objects by roles *****************/
export const requestObjectsByRoles = () => ({
  type: REQUEST_OBJECTS_BY_ROLES
});

export const receiveObjectsByRoles = json => ({
  type: RECEIVE_OBJECTS_BY_ROLES,
  payload: json
});

export const fetchObjectsByRoles = data => dispatch => {
  const method = "get_objects_by_roles";
  dispatch(requestObjectsByRoles());
  return jsonRPCRequest(PORTAL_SERVICE_URL, method, data)
    .then(response => response.json())
    .then(json => dispatch(checkAuth(json)))
    .then(json => dispatch(receiveObjectsByRoles(json)));
};

export const clearObjectsByRoles = () => ({
  type: CLEAR_OBJECTS_BY_ROLES
});
/*******************************************************/

/****************get current object*********/
export const requestCurrentObject = () => ({
  type: REQUEST_CURRENT_OBJECT
});

export const receiveCurrentObject = json => ({
  type: RECEIVE_CURRENT_OBJECT,
  payload: json
});

export const fetchCurrentObject = () => dispatch => {
  const method = "get_current_object";
  dispatch(requestCurrentObject());
  return jsonRPCRequest(PORTAL_SERVICE_URL, method, [])
    .then(response => response.json())
    .then(json => dispatch(receiveCurrentObject(json)));
};
/*******************************************************/

/******************************************************/
export const requestSetObject = json => ({
  type: REQUEST_SET_OBJECT,
  payload: json
});

export const receiveSetObject = json => ({
  type: RECEIVE_SET_OBJECT,
  payload: json
});

export const fetchSetObject = data => dispatch => {
  const method = "set_object";
  dispatch(requestSetObject());
  return jsonRPCRequest(PORTAL_SERVICE_URL, method, data)
    .then(response => response.json())
    .then(json => dispatch(checkAuth(json)))
    .then(json => dispatch(receiveSetObject(json)));
};

export const fetchSetObjectVisibility = data => dispatch => {
  const method = "set_visible";
  dispatch(requestSetObject());
  return jsonRPCRequest(PORTAL_SERVICE_URL, method, data)
    .then(response => response.json())
    .then(json => dispatch(checkAuth(json)))
    .then(json => dispatch(receiveSetObject(json)));
};
/*****************************************************/

/***************get_object_users*****************/
export const requestObjectEmployees = () => ({
  type: REQUEST_OBJECT_EMPLOYEES
});

export const receiveObjectEmployees = json => ({
  type: RECEIVE_OBJECT_EMPLOYEES,
  payload: json
});

export const receiveMoreObjectEmployees = json => ({
  type: RECEIVE_MORE_OBJECT_EMPLOYEES,
  payload: json
});

export const clearObjectEmployees = () => ({
  type: CLEAR_OBJECT_EMPLOYEES
});

export const fetchObjectEmployees = data => dispatch => {
  const method = "get_object_users";
  dispatch(requestObjectEmployees());
  return jsonRPCRequest(PORTAL_SERVICE_URL, method, data)
    .then(response => response.json())
    .then(json => dispatch(receiveObjectEmployees(json)));
};

export const fetchMoreObjectEmployees = data => dispatch => {
  const method = "get_object_users";
  dispatch(requestObjectEmployees());
  return jsonRPCRequest(PORTAL_SERVICE_URL, method, data)
    .then(response => response.json())
    .then(json => dispatch(receiveMoreObjectEmployees(json)));
};
/*****************************************************/

/*************set_object_permissions*****************/
export const requestSetObjectPermissions = () => ({
  type: REQUEST_SET_OBJECT_PERMISSIONS
});

export const receiveSetObjectPermissions = json => ({
  type: RECEIVE_SET_OBJECT_PERMISSIONS,
  payload: json
});

export const fetchSetObjectPermissions = data => dispatch => {
  const method = "set_object_permissions";
  dispatch(requestSetObjectPermissions());
  return jsonRPCRequest(PORTAL_SERVICE_URL, method, data)
    .then(response => response.json())
    .then(json => dispatch(receiveSetObjectPermissions(json)));
};
/*********************************************************/

/************get_object_permissions********************/
export const requestObjectPermissions = () => ({
  type: REQUEST_OBJECT_PERMISSIONS
});

export const receiveObjectPermissions = json => ({
  type: RECEIVE_OBJECT_PERMISSIONS,
  payload: json
});

export const fetchObjectPermissions = data => dispatch => {
  const method = "get_object_permissions";
  dispatch(requestObjectPermissions());
  return jsonRPCRequest(PORTAL_SERVICE_URL, method, data)
    .then(response => response.json())
    .then(json => dispatch(receiveObjectPermissions(json)));
};
/***********************************************************/

/*****************delete_object_permissions***************/
export const requestDeleteObjectPermissions = () => ({
  type: REQUEST_DELETE_OBJECT_PERMISSIONS
});

export const receiveDeleteObjectPermissions = json => ({
  type: RECEIVE_DELETE_OBJECT_PERMISSIONS,
  payload: json
});

export const fetchDeleteObjectPermissions = data => dispatch => {
  const method = "delete_object_permissions";
  dispatch(requestDeleteObjectPermissions());
  return jsonRPCRequest(PORTAL_SERVICE_URL, method, data)
    .then(response => response.json())
    .then(json => dispatch(receiveDeleteObjectPermissions(json)));
};
/********************************************************/
/*
  fetchObjectsByIds
*/

export const requestObjectsByIds = () => ({
  type: REQUEST_OBJECTS_BY_IDS
});

export const receiveObjectsByIds = json => ({
  type: RECEIVE_OBJECTS_BY_IDS,
  payload: json
});

export const clearObjectsByIds = () => ({
  type: CLEAR_OBJECTS_BY_IDS
});

export const fetchObjectsByIds = data => dispatch => {
  const method = "get_objects_by_ids";
  dispatch(requestObjectsByIds());
  return jsonRPCRequest(PORTAL_SERVICE_URL, method, data)
    .then(response => response.json())
    .then(json => dispatch(checkAuth(json)))
    .then(json => dispatch(receiveObjectsByIds(json)));
};
