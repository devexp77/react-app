import { jsonRPCRequest, postRequest } from "./asyncActions";
import { PROTOCOL, HOST_NAME } from "../constants";
import { checkAuth } from "./user";

export const REQUEST_SET_IMAGE = "REQUEST_SET_IMAGE";
export const RECEIVE_SET_IMAGE = "RECEIVE_SET_IMAGE";

export const REQUEST_DELETE_IMAGE = "REQUEST_DELETE_IMAGE";
export const RECEIVE_DELETE_IMAGE = "RECEIVE_DELETE_IMAGE";

export const REQUEST_CURRENT_USER_IMAGE = "REQUEST_CURRENT_USER_IMAGE";
export const RECEIVE_CURRENT_USER_IMAGE = "RECEIVE_CURRENT_USER_IMAGE";
export const CLEAR_CURRENT_USER_IMAGE = "CLEAR_CURRENT_USER_IMAGE";
export const SET_CURRENT_USER_IMG_SUFFIX = "SET_CURRENT_USER_IMG_SUFFIX";

export const REQUEST_CURRENT_OBJECT_MAIN_IMAGE =
  "REQUEST_CURRENT_OBJECT_MAIN_IMAGE";
export const RECEIVE_CURRENT_OBJECT_MAIN_IMAGE =
  "RECEIVE_CURRENT_OBJECT_MAIN_IMAGE";

export const REQUEST_CURRENT_OBJECT_IMAGE = "REQUEST_CURRENT_OBJECT_IMAGE";
export const RECEIVE_CURRENT_OBJECT_IMAGE = "RECEIVE_CURRENT_OBJECT_IMAGE";

export const REQUEST_ADDRESSEES_IMAGES = "REQUEST_ADDRESSEES_IMAGES";
export const RECEIVE_MORE_ADDRESSEES_IMAGES = "RECEIVE_MORE_ADDRESSEES_IMAGES";
export const RECEIVE_ADDRESSEES_IMAGES = "RECEIVE_ADDRESSEES_IMAGES";
export const CLEAR_ADDRESSEES_IMAGES = "CLEAR_ADDRESSEES_IMAGES";

export const REQUEST_ADDRESSEE_IMAGE = "REQUEST_ADDRESSEE_IMAGE";
export const RECEIVE_ADDRESSEE_IMAGE = "RECEIVE_ADDRESSEE_IMAGE";
export const SET_ADDRESSEE_IMG_SUFFIX = "SET_ADDRESSEE_IMG_SUFFIX";
export const CLEAR_ADDRESSEE_IMAGE = "CLEAR_ADDRESSEE_IMAGE";

export const REQUEST_ROOMS_IMAGES = "REQUEST_ROOMS_IMAGES";
export const RECEIVE_MORE_ROOMS_IMAGES = "RECEIVE_MORE_ROOMS_IMAGES";
export const RECEIVE_ROOMS_IMAGES = "RECEIVE_ROOMS_IMAGES";
export const CLEAR_ROOMS_IMAGES = "CLEAR_ROOMS_IMAGES";

export const REQUEST_ROOM_IMAGE = "REQUEST_ROOM_IMAGE";
export const RECEIVE_ROOM_IMAGE = "RECEIVE_ROOM_IMAGE";
export const SET_ROOM_IMG_SUFFIX = "SET_ROOM_IMG_SUFFIX";
export const CLEAR_ROOM_IMAGE = "CLEAR_ROOM_IMAGE";

export const CLEAR_CURRENT_OBJECT_IMAGE = "CLEAR_CURRENT_OBJECT_IMAGE";
export const SET_CURRENT_OBJECT_IMG_SUFFIX = "SET_CURRENT_OBJECT_IMG_SUFFIX";

const PORTAL_UPLOAD_URL = `${PROTOCOL}//upload.${HOST_NAME}/`;
const PORTAL_SERVICE_URL = `${PROTOCOL}//api.${HOST_NAME}/images/`;

export const REQUEST_OBJECTS_IMAGE = "REQUEST_OBJECTS_IMAGE";
export const RECEIVE_OBJECTS_IMAGE = "RECEIVE_OBJECTS_IMAGE";
export const RECEIVE_MORE_OBJECTS_IMAGE = "RECEIVE_MORE_OBJECTS_IMAGE";
export const CLEAR_OBJECTS_IMAGE = "CLEAR_OBJECTS_IMAGE";

export const REQUEST_USERS_IMAGE = "REQUEST_USERS_IMAGE";
export const RECEIVE_USERS_IMAGE = "RECEIVE_USERS_IMAGE";
export const RECEIVE_MORE_USERS_IMAGE = "RECEIVE_MORE_USERS_IMAGE";
export const CLEAR_USERS_IMAGE = "CLEAR_USERS_IMAGE";

export const RECEIVE_LOGBOOK_IMAGES = "RECEIVE_LOGBOOK_IMAGES";
export const REQUEST_LOGBOOK_IMAGES = "REQUEST_LOGBOOK_IMAGES";
export const CLEAR_LOGBOOK_IMAGES = "CLEAR_LOGBOOK_IMAGES";

export const RECEIVE_FM_REQUEST_IMAGES = "RECEIVE_FM_REQUEST_IMAGES";
export const REQUEST_FM_REQUEST_IMAGES = "REQUEST_FM_REQUEST_IMAGES";
export const CLEAR_FM_REQUEST_IMAGES = "CLEAR_FM_REQUEST_IMAGES";

export const REQUEST_COMMENTS_IMAGES = "REQUEST_COMMENTS_IMAGES";
export const RECEIVE_COMMENTS_IMAGES = "RECEIVE_COMMENTS_IMAGES";
export const CLEAR_COMMENTS_IMAGES = "CLEAR_COMMENTS_IMAGES";

export const REQUEST_FM_SIGNATURES = "REQUEST_FM_SIGNATURES";
export const RECEIVE_FM_SIGNATURES = "RECEIVE_FM_SIGNATURES";
export const CLEAR_FM_SIGNATURES = "CLEAR_FM_SIGNATURES";

/************ add image *************/
export const requestSetImage = () => ({
  type: REQUEST_SET_IMAGE
});

export const receiveSetImage = json => ({
  type: RECEIVE_SET_IMAGE,
  payload: json
});

export const fetchSetImage = data => dispatch => {
  dispatch(requestSetImage());
  return postRequest(PORTAL_UPLOAD_URL, data)
    .then(response => response.json())
    .then(json => dispatch(receiveSetImage(json)));
};

/**********************************************/

/************  user image *************/
export const requestCurrentUserImage = () => ({
  type: REQUEST_CURRENT_USER_IMAGE
});

export const receiveCurrentUserImage = json => ({
  type: RECEIVE_CURRENT_USER_IMAGE,
  payload: json
});

export const fetchCurrentUserImage = data => dispatch => {
  const method = "get_default_image_urls";
  dispatch(requestCurrentUserImage());
  return jsonRPCRequest(PORTAL_SERVICE_URL, method, data)
    .then(response => response.json())
    .then(json => dispatch(checkAuth(json)))
    .then(json => dispatch(receiveCurrentUserImage(json)));
};

export const clearCurrentUserImage = () => ({
  type: CLEAR_CURRENT_USER_IMAGE
});

export const setCurrentUserImageSuffix = () => ({
  type: SET_CURRENT_USER_IMG_SUFFIX,
  payload: `${new Date().getDate()}${new Date().getHours()}${new Date().getMinutes()}${new Date().getSeconds()}${new Date().getMilliseconds()}`
});

/**********************************************/

/************  object image *************/
export const requestCurrentObjectImage = () => ({
  type: REQUEST_CURRENT_OBJECT_IMAGE
});

export const receiveCurrentObjectImage = json => ({
  type: RECEIVE_CURRENT_OBJECT_IMAGE,
  payload: json
});

export const fetchCurrentObjectImage = data => dispatch => {
  const method = "get_default_image_urls";
  dispatch(requestCurrentObjectImage());
  return jsonRPCRequest(PORTAL_SERVICE_URL, method, data)
    .then(response => response.json())
    .then(json => dispatch(checkAuth(json)))
    .then(json => dispatch(receiveCurrentObjectImage(json)));
};

export const clearCurrentObjectImage = () => ({
  type: CLEAR_CURRENT_OBJECT_IMAGE
});

export const setCurrentObjectImageSuffix = () => ({
  type: SET_CURRENT_OBJECT_IMG_SUFFIX,
  payload: `${new Date().getDate()}${new Date().getHours()}${new Date().getMinutes()}${new Date().getSeconds()}${new Date().getMilliseconds()}`
});

export const requestCurrentObjectMainImage = () => ({
  type: REQUEST_CURRENT_OBJECT_MAIN_IMAGE
});

export const receiveCurrentObjectMainImage = json => ({
  type: RECEIVE_CURRENT_OBJECT_MAIN_IMAGE,
  payload: json
});

export const fetchCurrentObjectMainImage = data => dispatch => {
  const method = "get_object_main_image_url";
  dispatch(requestCurrentObjectMainImage());
  return jsonRPCRequest(PORTAL_SERVICE_URL, method, data)
    .then(response => response.json())
    .then(json => dispatch(checkAuth(json)))
    .then(json => dispatch(receiveCurrentObjectMainImage(json)));
};
/**********************************************/
/**********************************************/
export const requestObjectsImage = () => ({
  type: REQUEST_OBJECTS_IMAGE
});

export const receiveObjectsImage = json => ({
  type: RECEIVE_OBJECTS_IMAGE,
  payload: json
});

export const receiveMoreObjectsImage = json => ({
  type: RECEIVE_MORE_OBJECTS_IMAGE,
  payload: json
});

export const fetchObjectsImage = data => dispatch => {
  const method = "get_default_image_urls";
  dispatch(requestObjectsImage());
  if (data.entity_ids.length == 0) {
    dispatch(receiveObjectsImage({
      id: "1",
      jsonrpc: "2.0",
      result: []
    }));
  } else {
    return jsonRPCRequest(PORTAL_SERVICE_URL, method, data)
      .then(response => response.json())
      .then(json => dispatch(checkAuth(json)))
      .then(json => dispatch(receiveObjectsImage(json)));
  }
};

export const fetchMoreObjectsImage = data => dispatch => {
  const method = "get_default_image_urls";
  dispatch(requestObjectsImage());
  if (data.entity_ids.length == 0) {
    dispatch(receiveMoreObjectsImage({
      id: "1",
      jsonrpc: "2.0",
      result: []
    }));
  } else {
    return jsonRPCRequest(PORTAL_SERVICE_URL, method, data)
      .then(response => response.json())
      .then(json => dispatch(checkAuth(json)))
      .then(json => dispatch(receiveMoreObjectsImage(json)));
  }
};

export const clearObjectsImage = () => ({
  type: CLEAR_OBJECTS_IMAGE
});
/**********************************************/

/**********************************************/
export const requestUsersImage = () => ({
  type: REQUEST_USERS_IMAGE
});

export const receiveUsersImage = json => ({
  type: RECEIVE_USERS_IMAGE,
  payload: json
});

export const receiveMoreUsersImage = json => ({
  type: RECEIVE_MORE_USERS_IMAGE,
  payload: json
});

export const fetchUsersImage = data => dispatch => {
  const method = "get_default_image_urls";
  dispatch(requestUsersImage());
  if (data.entity_ids.length == 0) {
    dispatch(receiveUsersImage({
      id: "1",
      jsonrpc: "2.0",
      result: []
    }));
  } else {
    return jsonRPCRequest(PORTAL_SERVICE_URL, method, data)
      .then(response => response.json())
      .then(json => dispatch(checkAuth(json)))
      .then(json => dispatch(receiveUsersImage(json)));
  }
};

export const fetchMoreUsersImage = data => dispatch => {
  const method = "get_default_image_urls";
  dispatch(requestUsersImage());
  if (data.entity_ids.length == 0) {
    dispatch(receiveMoreUsersImage({
      id: "1",
      jsonrpc: "2.0",
      result: []
    }));
  } else {
    return jsonRPCRequest(PORTAL_SERVICE_URL, method, data)
      .then(response => response.json())
      .then(json => dispatch(checkAuth(json)))
      .then(json => dispatch(receiveMoreUsersImage(json)));
  }
};

export const clearUsersImage = () => ({
  type: CLEAR_USERS_IMAGE
});
/**********************************************/


/**********fetch addressee image ********/

export const requestAddresseeImage = () => ({
  type: REQUEST_ADDRESSEE_IMAGE
});

export const receiveAddresseeImage = json => ({
  type: RECEIVE_ADDRESSEE_IMAGE,
  payload: json
});

export const fetchAddresseeImage = data => dispatch => {
  const method = "get_default_image_urls";
  dispatch(requestAddresseeImage());
  return jsonRPCRequest(PORTAL_SERVICE_URL, method, data)
    .then(response => response.json())
    .then(json => dispatch(checkAuth(json)))
    .then(json => dispatch(receiveAddresseeImage(json)));
};

export const clearAddresseeImage = () => ({
  type: CLEAR_ADDRESSEE_IMAGE
});

export const setAddresseeImageSuffix = () => ({
  type: SET_ADDRESSEE_IMG_SUFFIX,
  payload: `${new Date().getDate()}${new Date().getHours()}${new Date().getMinutes()}${new Date().getSeconds()}${new Date().getMilliseconds()}`
});

/**********fetch addressee image ********/


/**********fetch room image ********/

export const requestRoomImage = () => ({
  type: REQUEST_ROOM_IMAGE
});

export const receiveRoomImage = json => ({
  type: RECEIVE_ROOM_IMAGE,
  payload: json
});

export const fetchRoomImage = data => dispatch => {
  const method = "get_default_image_urls";
  dispatch(requestRoomImage());
  return jsonRPCRequest(PORTAL_SERVICE_URL, method, data)
    .then(response => response.json())
    .then(json => dispatch(checkAuth(json)))
    .then(json => dispatch(receiveRoomImage(json)));
};

export const clearRoomImage = () => ({
  type: CLEAR_ROOM_IMAGE
});

export const setRoomImageSuffix = () => ({
  type: SET_ROOM_IMG_SUFFIX,
  payload: `${new Date().getDate()}${new Date().getHours()}${new Date().getMinutes()}${new Date().getSeconds()}${new Date().getMilliseconds()}`
});

/**********fetch addressee image ********/


export const requestLogbookImages = () => ({
  type: REQUEST_LOGBOOK_IMAGES
});

export const receiveLogbookImages = json => ({
  type: RECEIVE_LOGBOOK_IMAGES,
  payload: json
});

export const fetchLogbookImages = data => dispatch => {
  const method = "get_images";
  dispatch(requestLogbookImages());
  return jsonRPCRequest(PORTAL_SERVICE_URL, method, data)
    .then(response => response.json())
    .then(json => dispatch(checkAuth(json)))
    .then(json => dispatch(receiveLogbookImages(json)));
};

export const clearLogbookImages = () => ({
  type: CLEAR_LOGBOOK_IMAGES
});

/**********fetch fm signatures ********/


export const requestFmSignatures = () => ({
  type: REQUEST_FM_SIGNATURES
});

export const receiveFmSignatures = json => ({
  type: RECEIVE_FM_SIGNATURES,
  payload: json
});

export const fetchFmSignatures = data => dispatch => {
  const method = "get_images";
  dispatch(requestFmSignatures());
  return jsonRPCRequest(PORTAL_SERVICE_URL, method, data)
    .then(response => response.json())
    .then(json => dispatch(checkAuth(json)))
    .then(json => dispatch(receiveFmSignatures(json)));
};

export const clearFmSignatures = () => ({
  type: CLEAR_FM_SIGNATURES
});


/*** get fm requests images ***/

export const requestFmRequestImages = () => ({
  type: REQUEST_FM_REQUEST_IMAGES
});

export const receiveFmRequestImages = json => ({
  type: RECEIVE_FM_REQUEST_IMAGES,
  payload: json
});

export const fetchFmRequestImages = data => dispatch => {
  const method = "get_images";
  dispatch(requestFmRequestImages());
  return jsonRPCRequest(PORTAL_SERVICE_URL, method, data)
    .then(response => response.json())
    .then(json => dispatch(checkAuth(json)))
    .then(json => dispatch(receiveFmRequestImages(json)));
};

export const clearFmRequestImages = () => ({
  type: CLEAR_FM_REQUEST_IMAGES
});



/** fetch addressees images */

export const requestAddresseesImages = () => ({
  type: REQUEST_ADDRESSEES_IMAGES
});

export const receiveAddresseesImages = json => ({
  type: RECEIVE_ADDRESSEES_IMAGES,
  payload: json
});

export const receiveMoreAddresseesImages = json => ({
  type: RECEIVE_MORE_ADDRESSEES_IMAGES,
  payload: json
});

export const fetchAddresseesImages = data => dispatch => {
  const method = "get_default_image_urls";
  dispatch(requestAddresseesImages());
  if (data.entity_ids.length === 0) {
    dispatch(receiveAddresseesImages({
      id: "1",
      jsonrpc: "2.0",
      result: []
    }));
  } else {
    return jsonRPCRequest(PORTAL_SERVICE_URL, method, data)
      .then(response => response.json())
      .then(json => dispatch(checkAuth(json)))
      .then(json => dispatch(receiveAddresseesImages(json)));
  }
};

export const fetchMoreAddresseesImages = data => dispatch => {
  const method = "get_default_image_urls";
  dispatch(requestAddresseesImages());
  if (data.entity_ids.length === 0) {
    dispatch(receiveMoreAddresseesImages({
      id: "1",
      jsonrpc: "2.0",
      result: []
    }));
  } else {
    return jsonRPCRequest(PORTAL_SERVICE_URL, method, data)
      .then(response => response.json())
      .then(json => dispatch(checkAuth(json)))
      .then(json => dispatch(receiveMoreAddresseesImages(json)));
  }
};

export const clearAddresseesImages = () => ({
  type: CLEAR_ADDRESSEES_IMAGES
});



/** fetch rooms images */

export const requestRoomsImages = () => ({
  type: REQUEST_ROOMS_IMAGES
});

export const receiveRoomsImages = json => ({
  type: RECEIVE_ROOMS_IMAGES,
  payload: json
});

export const receiveMoreRoomsImages = json => ({
  type: RECEIVE_MORE_ROOMS_IMAGES,
  payload: json
});

export const fetchRoomsImages = data => dispatch => {
  const method = "get_default_image_urls";
  dispatch(requestRoomsImages());
  if (data.entity_ids.length === 0) {
    dispatch(receiveRoomsImages({
      id: "1",
      jsonrpc: "2.0",
      result: []
    }));
  } else {
    return jsonRPCRequest(PORTAL_SERVICE_URL, method, data)
      .then(response => response.json())
      .then(json => dispatch(checkAuth(json)))
      .then(json => dispatch(receiveRoomsImages(json)));
  }
};

export const fetchMoreRoomsImages = data => dispatch => {
  const method = "get_default_image_urls";
  dispatch(requestRoomsImages());
  if (data.entity_ids.length === 0) {
    dispatch(receiveMoreRoomsImages({
      id: "1",
      jsonrpc: "2.0",
      result: []
    }));
  } else {
    return jsonRPCRequest(PORTAL_SERVICE_URL, method, data)
      .then(response => response.json())
      .then(json => dispatch(checkAuth(json)))
      .then(json => dispatch(receiveMoreRoomsImages(json)));
  }
};

export const clearRoomsImages = () => ({
  type: CLEAR_ROOMS_IMAGES
});


/*** get comments images ***/

export const requestCommentsImages = () => ({
  type: REQUEST_COMMENTS_IMAGES
});

export const receiveCommentsImages = json => ({
  type: RECEIVE_COMMENTS_IMAGES,
  payload: json
});

export const fetchCommentsImages = data => dispatch => {
  const method = "get_images";
  dispatch(requestCommentsImages());
  return jsonRPCRequest(PORTAL_SERVICE_URL, method, data)
    .then(response => response.json())
    .then(json => dispatch(checkAuth(json)))
    .then(json => dispatch(receiveCommentsImages(json)));
};

export const clearCommentsImages = () => ({
  type: CLEAR_COMMENTS_IMAGES
});
