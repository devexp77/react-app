import { jsonRPCRequest } from "./asyncActions";
import { checkAuth } from "./user";
import { HOST_NAME, PROTOCOL } from "../constants";

export const ADD_ROOM_REQUEST = "ADD_ROOM_REQUEST";
export const ADD_ROOM_RESULT = "ADD_ROOM_RESULT";

export const SET_ROOM_REQUEST = "SET_ROOM_REQUEST";
export const SET_ROOM_RESULT = "SET_ROOM_RESULT";

export const ATTACH_IOS_ZONE_TO_ROOM_REQUEST =
  "ATTACH_IOS_ZONE_TO_ROOM_REQUEST";
export const ATTACH_IOS_ZONE_TO_ROOM_RESULT = "ATTACH_IOS_ZONE_TO_ROOM_RESULT";

export const DETACH_IOS_ZONE_TO_ROOM_REQUEST =
  "DETACH_IOS_ZONE_TO_ROOM_REQUEST";
export const DETACH_IOS_ZONE_TO_ROOM_RESULT = "DETACH_IOS_ZONE_TO_ROOM_RESULT";

export const DELETE_ROOMS_REQUEST = "DELETE_ROOMS_REQUEST";
export const DELETE_ROOMS_RESULT = "DELETE_ROOMS_RESULT";

export const IMPORT_ROOM_REQUEST = "IMPORT_ROOM_REQUEST";
export const IMPORT_ROOM_RESULT = "IMPORT_ROOM_RESULT";

export const REQUEST_ROOMS = "REQUEST_ROOMS";
export const RECEIVE_ROOMS = "RECEIVE_ROOMS";
export const RECEIVE_MORE_ROOMS = "RECEIVE_MORE_ROOMS";
export const CLEAR_ROOMS = "CLEAR_ROOMS";

export const REQUEST_ROOM_BY_ID = "REQUEST_ROOM_BY_ID";
export const RECEIVE_ROOM_BY_ID = "RECEIVE_ROOM_BY_ID";
export const CLEAR_ROOM_BY_ID = "CLEAR_ROOM_BY_ID";

const PORTAL_SERVICE_URL = `${PROTOCOL}//api.${HOST_NAME}/rooms/`;

/****************** add room *******************/
export const addRoomRequest = () => ({
  type: ADD_ROOM_REQUEST
});

export const addRoomResult = json => ({
  type: ADD_ROOM_RESULT,
  payload: json
});

export const fetchAddRoom = data => dispatch => {
  const method = "add_room";
  dispatch(addRoomRequest());
  return jsonRPCRequest(PORTAL_SERVICE_URL, method, data)
    .then(response => response.json())
    .then(json => dispatch(checkAuth(json)))
    .then(json => dispatch(addRoomResult(json)));
};
/****************************************************/

/****************** add room *******************/
export const importRoomRequest = () => ({
  type: IMPORT_ROOM_REQUEST
});

export const importRoomResult = json => ({
  type: IMPORT_ROOM_RESULT,
  payload: json
});

export const fetchImportRoom = data => dispatch => {
  const method = "add_room";
  dispatch(importRoomRequest());
  return jsonRPCRequest(PORTAL_SERVICE_URL, method, data)
    .then(response => response.json())
    .then(json => dispatch(checkAuth(json)))
    .then(json => dispatch(importRoomResult(json)));
};
/****************************************************/

/****************** set room *******************/
export const setRoomRequest = () => ({
  type: SET_ROOM_REQUEST
});

export const setRoomResult = json => ({
  type: SET_ROOM_RESULT,
  payload: json
});

export const fetchSetRoom = data => dispatch => {
  const method = "set_room";
  dispatch(setRoomRequest());
  return jsonRPCRequest(PORTAL_SERVICE_URL, method, data)
    .then(response => response.json())
    .then(json => dispatch(checkAuth(json)))
    .then(json => dispatch(setRoomResult(json)));
};
/****************************************************/

/****************** attach ios zone *******************/
export const attachIosZoneIdToRoomRequest = () => ({
  type: ATTACH_IOS_ZONE_TO_ROOM_REQUEST
});

export const attachIosZoneIdToRoomResult = json => ({
  type: ATTACH_IOS_ZONE_TO_ROOM_RESULT,
  payload: json
});

export const fetchAttachIosZoneIdToRoom = data => dispatch => {
  const method = "attach_ios_zone_id";
  dispatch(attachIosZoneIdToRoomRequest());
  return jsonRPCRequest(PORTAL_SERVICE_URL, method, data)
    .then(response => response.json())
    .then(json => dispatch(checkAuth(json)))
    .then(json => dispatch(attachIosZoneIdToRoomResult(json)));
};
/****************************************************/

/****************** detach ios zone *******************/
export const detachIosZoneIdToRoomRequest = () => ({
  type: DETACH_IOS_ZONE_TO_ROOM_REQUEST
});

export const detachIosZoneIdToRoomResult = json => ({
  type: DETACH_IOS_ZONE_TO_ROOM_RESULT,
  payload: json
});

export const fetchDetachIosZoneIdToRoom = data => dispatch => {
  const method = "detach_ios_zone_id";
  dispatch(detachIosZoneIdToRoomRequest());
  return jsonRPCRequest(PORTAL_SERVICE_URL, method, data)
    .then(response => response.json())
    .then(json => dispatch(checkAuth(json)))
    .then(json => dispatch(detachIosZoneIdToRoomResult(json)));
};
/****************************************************/

/**************** delete rooms *****************/
export const deleteRoomsRequest = () => ({
  type: DELETE_ROOMS_REQUEST
});

export const deleteRoomsResult = json => ({
  type: DELETE_ROOMS_RESULT,
  payload: json
});

export const fetchDeleteRooms = data => dispatch => {
  const method = "delete_rooms";
  dispatch(deleteRoomsRequest());
  return jsonRPCRequest(PORTAL_SERVICE_URL, method, data)
    .then(response => response.json())
    .then(json => dispatch(checkAuth(json)))
    .then(json => dispatch(deleteRoomsResult(json)));
};
/****************************************************/

/****************** get rooms *******************/
export const requestRooms = () => ({
  type: REQUEST_ROOMS
});

export const receiveRooms = json => ({
  type: RECEIVE_ROOMS,
  payload: json
});

export const receiveMoreRooms = json => ({
  type: RECEIVE_MORE_ROOMS,
  payload: json
});

export const clearRooms = () => ({
  type: CLEAR_ROOMS
});

export const fetchRooms = data => dispatch => {
  const method = "get_rooms";
  dispatch(requestRooms());
  return jsonRPCRequest(PORTAL_SERVICE_URL, method, data)
    .then(response => response.json())
    .then(json => dispatch(checkAuth(json)))
    .then(json => dispatch(receiveRooms(json)));
};

export const fetchMoreRooms = data => dispatch => {
  const method = "get_rooms";
  dispatch(requestRooms());
  return jsonRPCRequest(PORTAL_SERVICE_URL, method, data)
    .then(response => response.json())
    .then(json => dispatch(checkAuth(json)))
    .then(json => dispatch(receiveMoreRooms(json)));
};

/****************************************************/

/**************** get room by id *****************/
export const requestRoomById = () => ({
  type: REQUEST_ROOM_BY_ID
});

export const receiveRoomById = json => ({
  type: RECEIVE_ROOM_BY_ID,
  payload: json
});

export const clearRoomById = () => ({
  type: CLEAR_ROOM_BY_ID
});

export const fetchRoomById = data => dispatch => {
  const method = "get_room";
  dispatch(requestRoomById());
  return jsonRPCRequest(PORTAL_SERVICE_URL, method, data)
    .then(response => response.json())
    .then(json => dispatch(checkAuth(json)))
    .then(json => dispatch(receiveRoomById(json)));
};
/****************************************************/
