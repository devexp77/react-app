import {fetchUserNotifications, fetchUserNotificationsCount} from './actions/notifications'

import { NOTIFICATION_LIMIT, NOTIFICATION_ORDER } from './constants';

export const notificationsUpdate = (dispatch, user) => {

 var user_id = '';
 if (user.user.result) {
  user_id = user.user.result.user_id; 
  // var data = {
  //   filter: {
  //     user_id: user_id               
  //   },      
  //   limit: NOTIFICATION_LIMIT,
  //   offset: 0,
  //   order: NOTIFICATION_ORDER
  // };    

  var dataForCount = {
    user_id: user_id               
  };     


  dispatch(fetchUserNotificationsCount(dataForCount));
  // dispatch(fetchUserNotifications(data));
}

}
