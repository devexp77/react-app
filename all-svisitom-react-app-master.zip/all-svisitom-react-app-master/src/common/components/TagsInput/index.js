import React, { Component } from "react";

import "./style.css";

import strings from "../../localization/all";

import { WithContext as ReactTags } from "react-tag-input";

const KeyCodes = {
  enter: 13
};
const delimiters = [KeyCodes.enter];

class TagsInput extends Component {
  constructor() {
    super();
    this.state = {
      tagInput: ""
    };
    this.handleDelete = this.handleDelete.bind(this);
    this.handleDrag = this.handleDrag.bind(this);
    this.handleTagClick = this.handleTagClick.bind(this);
    this.tagInputChange = this.tagInputChange.bind(this);
    this.handleAddition = this.handleAddition.bind(this);
  }

  handleDelete(i) {
    const { tags } = this.props;
    this.setState({ tagInput: "" });
    this.props.setTagsForState(tags.filter((tag, index) => index !== i));
  }

  handleDrag(tag, currPos, newPos) {
    const tags = [...this.props.tags];
    const newTags = tags.slice();

    newTags.splice(currPos, 1);
    newTags.splice(newPos, 0, tag);

    // re-render
    this.setState({ tagInput: "" });
    this.props.setTagsForState(newTags);
  }

  handleAddition(tag) {
    this.setState({ tagInput: "" });
    this.props.handleAddition(tag);
  }

  handleTagClick(index) {
    this.setState({ tagInput: "" });
    // console.log("The tag at index " + index + " was clicked");
  }

  tagInputChange(event) {
    this.setState({ tagInput: event });
    if (this.props.onInput) {
      this.props.onInput(event);
    }
  }

  render() {
    const { tagInput } = this.state;

    return (
      <ReactTags
        tags={this.props.tags}
        inline={false}
        inputFieldPosition="bottom"
        suggestions={this.props.suggestions}
        delimiters={delimiters}
        handleDelete={this.handleDelete}
        handleAddition={this.handleAddition}
        handleDrag={this.handleDrag}
        handleTagClick={this.handleTagClick}
        labelField={"tag_text"}
        minQueryLength={0}
        autocomplete={false}
        autofocus={false}
        handleInputChange={this.tagInputChange}
        placeholder={strings.placeholder_tags_input}
        classNames={{
          selected: "ReactTags__selected clearfix",
          suggestions: !tagInput
            ? "ReactTags__suggestions collapse-suggestion"
            : "ReactTags__suggestions"
        }}
      />
    );
  }
}

export default TagsInput;
