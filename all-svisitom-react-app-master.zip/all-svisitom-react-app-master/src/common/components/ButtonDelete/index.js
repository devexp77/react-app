import React from "react";

import "./style.css";

class ButtonDelete extends React.Component {
  render() {
    return (
      <button
        className={`btn btn-flat button-delete ${this.props.customClass || ""}`}
        data-toggle="modal"
        data-target="#deletePopUp"
      >
        {this.props.buttonTitle}
      </button>
    );
  }
}

export default ButtonDelete;
