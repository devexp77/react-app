import React, { Component } from "react";
import common_strings from "../../localization/all";

import "./style.css";
import Icon from "../Icon";
import {Link} from "react-router";

/*
  props:
    id
    query
    placeholder
    onChange - function(event)
    onSearch - function(query)
*/
class SearchInput extends Component {
  constructor(props) {
    super(props);

    this.state = {
      query_string: ""
    };

    this.handleInputChange = this.handleInputChange.bind(this);
    this.handleKeyPress = this.handleKeyPress.bind(this);
    this.handleClearButtonClick = this.handleClearButtonClick.bind(this);
    this.handleSearchButtonClick = this.handleSearchButtonClick.bind(this);
  }

  componentDidMount(){
    $(document).off("click touch", "#more-vert");
    $(document).on("click touch", "#more-vert", function(e) {
      var dropdown = $("#dropdown-more-vert");
      var li = $("#more-vert");

      if (li.is(e.target) || !li.has(e.target).length == 0) {
        if (dropdown.hasClass("show")) {
          dropdown.removeClass("show");
        } else {
          dropdown.addClass("show");
        }
      }
    });
  }

  componentWillReceiveProps(newProps) {
    this.setState({
      query_string: newProps.query
    });
  }

  render() {
    return (
      <div
        className={`sv-search-input sv-search-input-wprapped ${
          this.props.searchButton ? "with-button" : ""
        } ${this.props.moreVert ? "with-more-vert" : ""} ${
          this.props.photoFindIcon ? "with-photo-button" : ""
        }`}
      >
        <div className="lens-icon" onClick={this.handleSearchButtonClick}>
          <i className="material-icons">search</i>
        </div>
        <input
          name={this.props.id}
          id={this.props.id}
          type="text"
          value={this.state.query_string}
          onChange={this.handleInputChange}
          onKeyPress={this.handleKeyPress}
          placeholder={this.props.placeholder}
          ref={input => (this.search_input = input)}
        />

        <div className="icon-row">
          <div className="clear-icon" onClick={this.handleClearButtonClick}>
            <i className="material-icons">clear</i>
          </div>

          {this.props.photoFindIcon ? (
            <div
              className={`filter-icon`}
              onClick={this.props.handlePhotoFindButtonClick}
            >
              <i className="material-icons">photo_camera</i>
            </div>
          ) : null}

          {this.props.filterIcon ? (
            <div
              className={`filter-icon ${this.props.filterIconClass}`}
              onClick={this.props.handleFilterButtonClick}
            >
              <i className="material-icons">filter_list</i>
            </div>
          ) : null}
        </div>

        {this.props.searchButton ? (
          <button
            className="btn btn-primary sv-button"
            onClick={this.handleSearchButtonClick}
          >
            {common_strings.button_search}
          </button>
        ) : null}

        {this.props.moreVert ? (
          <div>
            <a className="nav-link dropdown float-left more-vert" id="more-vert">
              <i className="material-icons more-vert">more_vert</i>
            </a>
            <div
              className="dropdown-menu dropdown-menu-right dropdown-primary"
              aria-labelledby="more-vert"
              id={`dropdown-more-vert`}
              style={{ right: "-25px", left: "auto" }}
            >
              <Link className="dropdown-item" to={this.props.printLink}>{common_strings.button_print}</Link>
            </div>
          </div>
        ) : null}
      </div>
    );
  }

  handleInputChange(event) {
    this.state.query_string = event.target.value;
    if (this.props.onChange) {
      this.props.onChange(event);
    }
  }

  handleKeyPress(event) {
    if (event.key == "Enter") {
      this.handleSearchButtonClick();
    }
  }

  handleSearchButtonClick() {
    this.props.onSearch(this.state.query_string);
  }

  handleClearButtonClick() {
    var e = document.createEvent("HTMLEvents");
    e.initEvent("change", false, true);

    this.setState(
      {
        query_string: ""
      },
      () => {
        if (this.props.onChange) {
           //, {bubbles: true})
          this.search_input.dispatchEvent(e);
        }
        this.handleSearchButtonClick();
      }
    );
  }
}

export default SearchInput;
