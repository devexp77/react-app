import React, { Fragment, useState } from "react";
import withStyles from "react-jss";
import Moment from "react-moment";
import TextareaField from "../../../common/components/Inputs/textarea";
import { RaisedButton } from "../../../common/components/Button";

import strings from "./localization";
import format from "string-format";
format.extend(String.prototype, {
  bold: s => s.bold()
});
import {
  commentStyles,
  commentsContainerStyles,
  attachedPhotosStyles
} from "./style";
import Icon from "../Icon";
import { ErrorClass } from "../../validation/errorClass";
import Dropzone from "react-dropzone";
import getBlobByImgSrc from "../../util/getBlobByImgSrc";
import { PhotoSwipeGallery } from "react-photoswipe";
import CheckerField from "../Inputs/checkerField";
import ProfileInfo from "../ProfileInfo";

export const DropZoneForCommentImages = withStyles(commentStyles)(
  ({ classes, onDrop, style = {} }) => (
    <Dropzone
      onDrop={onDrop}
      multiple={true}
      className={`dropzone`}
      activeClassName={`dropzone-active`}
    >
      <div className={`${classes.add_photo_button} clearfix`} style={style}>
        <i className="material-icons">add_a_photo</i>
        <span>{strings.title_add_photo}</span>
      </div>
    </Dropzone>
  )
);

const HideForCreatorChecker = withStyles(commentStyles)(
  ({ classes, onChange, value }) => (
    <CheckerField
      id={`hideForCreator`}
      onChange={onChange}
      checked={value}
      label={strings.title_hide_comment_for_creator}
    />
  )
);

const CommentInputField = withStyles(commentStyles)(
  ({ classes, submit, error, hideForCreatorOption = false }) => {
    const [comment, setComment] = useState("");
    const [hideForCreator, setHideForCreator] = useState(true);
    const [imagesBlob, setImagesBlob] = useState([]);
    const [imageGallery, setImageGallery] = useState([]);

    async function handleDrop(dropped) {
      for (let file of dropped) {
        let result = await getBlobByImgSrc(file.preview);
        setImagesBlob(imagesBlob => imagesBlob.concat(result.blob));
        setImageGallery(imageGallery =>
          imageGallery.concat(result.galleryImage)
        );
      }
    }

    return (
      <div className={classes.inputArea}>
        <TextareaField
          label={strings.label_comment_textarea}
          id={`comment`}
          value={comment}
          handleInputChange={e => setComment(e.target.value)}
          errorClass={error ? ErrorClass : null}
          error={error}
        />

        {hideForCreatorOption && (
          <HideForCreatorChecker
            onChange={e => setHideForCreator(e.target.checked)}
            value={hideForCreator}
          />
        )}

        <DropZoneForCommentImages onDrop={handleDrop} />

        <CommentImgGallery imageGallery={imageGallery} />

        <RaisedButton
          position={"left"}
          onClick={() =>
            submit(comment, imagesBlob, hideForCreator).then(res => {
              if (res) {
                setComment("");
                setImagesBlob([]);
                setImageGallery([]);
              }
            })
          }
        >
          {strings.button_send_comment}
        </RaisedButton>
      </div>
    );
  }
);

const CommentImgGallery = ({ imageGallery }) => {
  if (imageGallery.length > 0) {
    return (
      <div className={`clearfix`}>
        <PhotoSwipeGallery
          items={imageGallery}
          thumbnailContent={item => <AttachedPhotos src={item.src} />}
          options={{
            closeOnScroll: false,
            shareEl: false,
            captionEl: false,
            clickToCloseNonZoomable: false
          }}
        />
      </div>
    );
  } else return null;
};

class CommentImgGalleryComponent extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      imageGallery: []
    };
  }

  componentDidUpdate(prevProps) {
    if (
      this.props.comment.has_images &&
      prevProps.commentsImages !== this.props.commentsImages
    ) {
      this.getImageGallery();
    }
  }

  async getImageGallery() {
    let data = await getCommentImages(
      this.props.comment.comment_id,
      this.props.commentsImages
    );
    this.setState({ imageGallery: data });
  }

  render() {
    if (
      this.props.comment.has_images &&
      this.state.imageGallery &&
      this.state.imageGallery.length > 0
    ) {
      return <CommentImgGallery imageGallery={this.state.imageGallery} />;
    }

    return null;
  }
}

const AttachedPhotos = withStyles(attachedPhotosStyles)(({ classes, src }) => (
  <div className={classes.img_wrap}>
    <img className={classes.img_preview} src={src} />
  </div>
));

const CommentsContainer = withStyles(commentsContainerStyles)(
  ({ classes, children }) => <div className={classes.wrapper}>{children}</div>
);

const CommentsTitle = () => (
  <ProfileInfo.Title title={strings.title_comment_container} />
);

const Comment = ({ comment, userImages, commentsImages, problemType }) => {
  if (comment.comment_type === "comment") {
    return (
      <UserComment
        comment={comment}
        userImages={userImages}
        commentsImages={commentsImages}
      />
    );
  } else
    return (
      <AutoComment
        comment={comment}
        userImages={userImages}
        commentsImages={commentsImages}
        problemType={problemType}
      />
    );
};

const UserFio = withStyles(commentStyles)(({ classes, created_by }) => (
  <span className={classes.UserFio}>
    {created_by
      ? `${created_by.name} ${created_by.surname}`
      : strings.title_system_message}
  </span>
));

const ActionDate = withStyles(commentStyles)(({ classes, date }) => (
  <div className={classes.actionDate}>
    <Moment format="L LT" locale={strings.getLanguage()}>
      {new Date(date)}
    </Moment>
  </div>
));

const UserIcon = withStyles(commentStyles)(
  ({ classes, userImages, created_by }) => (
    <div className={classes.userImg}>
      {created_by ? (
        userImages && userImages[created_by.user_id] ? (
          <img src={userImages[created_by.user_id]} />
        ) : (
          <Icon name={`sv-icon-sv-account`} />
        )
      ) : (
        <Icon name={`sv-icon-fm-other`} />
      )}
    </div>
  )
);

const UserComment = withStyles(commentStyles)(
  ({ classes, comment, userImages, commentsImages }) => {
    return (
      <div className={classes.comment}>
        <UserIcon userImages={userImages} created_by={comment.created_by} />
        <div className={classes.commentFirstLine}>
          <UserFio created_by={comment.created_by} />
        </div>
        <div className={classes.commentText}>{comment.comment_text}</div>

        <CommentImgGalleryComponent
          comment={comment}
          commentsImages={commentsImages}
        />

        <div className={classes.commentLastLine}>
          <ActionDate date={comment.create_date} />
        </div>
      </div>
    );
  }
);

async function getMeta(url) {
  return new Promise((resolve, reject) => {
    let img = new Image();
    img.onload = () => resolve(img);
    img.onerror = reject;
    img.src = url;
  });
}

async function getCommentImages(comment_id, commentsImages) {
  let imageGallery = [];
  if (commentsImages && commentsImages.length > 0) {
    for (let commentImage of commentsImages) {
      if (commentImage.entity_id === comment_id) {
        let img = await getMeta(commentImage.image_url);
        imageGallery.push({
          src: commentImage.image_url,
          w: img.width,
          h: img.height
        });
      }
    }
  }
  return imageGallery;
}

const AutoComment = withStyles(commentStyles)(
  ({ classes, comment, userImages, commentsImages, problemType }) => (
    <div className={classes.comment}>
      <UserIcon
        userImages={userImages}
        created_by={comment.autocomment_attributes.emitted_by}
      />
      <div className={classes.commentFirstLine}>
        <UserFio created_by={comment.autocomment_attributes.emitted_by} />
      </div>
      <AutoCommentText comment={comment} problemType={problemType} />

      <CommentImgGalleryComponent
        comment={comment}
        commentsImages={commentsImages}
      />

      <div className={classes.commentLastLine}>
        <ActionDate date={comment.create_date} />
      </div>
    </div>
  )
);

const AutoCommentText = withStyles(commentStyles)(
  ({ classes, comment, problemType }) => {
    switch (comment.autocomment_attributes.type) {
      case "facility_request_assigned":
        return (
          <div
            className={classes.autoCommentText}
            dangerouslySetInnerHTML={{
              __html: strings.autocomment_facility_request_assigned.format(
                comment.autocomment_attributes.assigned_to.name,
                comment.autocomment_attributes.assigned_to.surname,
                problemType ? problemType : ""
              )
            }}
          />
        );

      case "facility_request_expiration_date_set":
        return (
          <div
            className={classes.autoCommentText}
            dangerouslySetInnerHTML={{
              __html: strings.autocomment_facility_request_expiration_date_set.format(
                problemType ? problemType : "",
                moment(new Date(comment.autocomment_attributes.expiration_date)).format("L")
              )
            }}
          >
          </div>
        );

      case "facility_request_done":
      case "facility_request_closed":
      case "facility_request_rejected":
      case "facility_request_reopened":
      case "facility_request_expired":
        return (
          <div
            className={classes.autoCommentText}
            dangerouslySetInnerHTML={{
              __html: strings[
                "autocomment_" + comment.autocomment_attributes.type
              ].format(problemType ? problemType : "")
            }}
          />
        );

      default:
        return;
    }
  }
);

export default {
  CommentsContainer,
  Comment,
  CommentInputField,
  CommentsTitle
};
