import LocalizedStrings from "react-localization";

const strings = new LocalizedStrings({
  "en": {
    "button_send_comment": "Send",
    "label_comment_textarea": "Comment",
    "title_comment_container": "Activity and comments",
    "text_comment_leave": "leave a comment",
    "autocomment_facility_request_assigned": "assign {!bold} {!bold} to request {!bold}",
    "autocomment_facility_request_expiration_date_set": "set expiration date of request {!bold} to {!bold}",
    "autocomment_facility_request_done": "done work on request {!bold}",
    "autocomment_facility_request_closed": "close request {!bold}",
    "autocomment_facility_request_rejected": "reject request {!bold}",
    "autocomment_facility_request_reopened": "reopen request {!bold}",
    "autocomment_facility_request_expired": "The deadline of request {!bold} has expired",
    "title_system_message": "System message",
    "title_add_photo": "Add photo",
    "title_hide_comment_for_creator": "Hide comment for creator",
  },
  "ru": {
    "button_send_comment": "Отправить",
    "label_comment_textarea": "Добавление комментария",
    "title_comment_container": "Активность и комментарии",
    "text_comment_leave": "оставил(а) сообщение",
    "autocomment_facility_request_assigned": "назначил {!bold} {!bold} на выполнение работ по обращению {!bold}",
    "autocomment_facility_request_expiration_date_set": "установил дату выполнения обращения {!bold} на {!bold}",
    "autocomment_facility_request_done": "выполнил работу по обращению {!bold}",
    "autocomment_facility_request_closed": "закрыл обращение {!bold}",
    "autocomment_facility_request_rejected": "отклонил обращение {!bold}",
    "autocomment_facility_request_reopened": "вернул обращение {!bold} в работу",
    "autocomment_facility_request_expired": "Срок выполнения работ по обращению {!bold} истек",
    "title_system_message": "Системное сообщение",
    "title_add_photo": "Добавить фотографию",
    "title_hide_comment_for_creator": "Скрыть комментарий для заявителя",
  },
  "de": {
    "button_send_comment": "Send",
    "label_comment_textarea": "Comment",
    "title_comment_container": "Activity and comments",
    "text_comment_leave": "leave a comment",
    "autocomment_facility_request_assigned": "assign {!bold} {!bold} to request {!bold}",
    "autocomment_facility_request_expiration_date_set": "set expiration date of request {!bold} to {!bold}",
    "autocomment_facility_request_done": "done work on request {!bold}",
    "autocomment_facility_request_closed": "close request {!bold}",
    "autocomment_facility_request_rejected": "reject request {!bold}",
    "autocomment_facility_request_reopened": "reopen request {!bold}",
    "autocomment_facility_request_expired": "The deadline of request {!bold} has expired",
    "title_system_message": "System message",
    "title_add_photo": "Add photo",
    "title_hide_comment_for_creator": "Hide comment for creator",
  }
});

export default strings;
