export const attachedPhotosStyles = {
  img_wrap: {
    float: "left",
    width: 60,
    height: 60,
    border: "2px solid",
    marginRight: 5,
    marginBottom: 5
  },

  img_preview: {
    width: "100%",
    height: "100%",
    objectFit: "cover",
    objectPosition: "0 0"
  }
};

export const commentsContainerStyles = {
  wrapper: {
    padding: 40
  },

  title: {
    fontSize: "1.5rem",
    margin: {
      bottom: "10px"
    }
  }
};

export const commentStyles = {
  comment: {
    padding: "10px 5px 10px 65px",

    position: "relative",

    "&:nth-child(odd)" : {
      backgroundColor: "rgba(0, 0, 0, 0.05)",
    }
  },

  add_photo_button: {
    marginBottom: "35px",
    color: "grey",
    cursor: "pointer",
    position: "relative",

    "& i": {
      display: "block",
      position: "absolute",
      left: "5px",
      top: "0",
      bottom: 0,
      margin: "auto",
      height: "24px",
      color: "#207ea9"
    },

    "& span": {
      display: "block",
      marginLeft: "40px"
    }
  },

  userImg: {
    height: 50,
    width: 50,
    borderRadius: 50,
    position: "absolute",
    left: 5,
    overflow: "hidden",

    "& img": {
      width: "100%"
    },

    "& i": {
      fontSize: 50,
      color: "grey"
    }
  },

  commentFirstLine: {
    fontStyle: "italic",
    textOverflow: "ellipsis",
    overflow: "hidden"
  },

  UserFio: {
    fontWeight: "bold",
    fontStyle: "normal"
  },

  commentText: {
    whiteSpace: "pre-line",
    minHeight: 24
  },

  autoCommentText: {
    fontSize: "0.8rem",
    minHeight: 24,
    overflow: "hidden",
    textOverflow: "ellipsis"
  },

  autoCommentTextBold: {
    fontWeight: "bolder"
  },

  commentLastLine: {
    position: "relative",
    minHeight: 20
  },

  actionDate: {
    fontSize: "0.8rem",
    position: "absolute",
    right: 0
  },

  inputArea: {
    overflow: "hidden",
    marginTop: "25px"
  }
};
