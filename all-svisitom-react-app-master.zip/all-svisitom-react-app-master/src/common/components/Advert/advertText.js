import React from 'react'
import MaterialSurface from "../PageContainers/materialSurface";

export const AdvertText = ({advert}) => (
  <MaterialSurface marginBottom>
    <div style={{ whiteSpace: "pre-line" }}>
      {advert.text}
    </div>
  </MaterialSurface>
);

