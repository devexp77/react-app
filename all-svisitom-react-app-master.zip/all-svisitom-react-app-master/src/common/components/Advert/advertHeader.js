import React from 'react';
import ProfileInfo from "../ProfileInfo";
import strings from "../../localization/all";
import {ObjectAvatar} from "../Avatar";

export const AdvertHeader = ({advert, object, objectImageUrl}) => (
  <div>
    <ProfileInfo.Table title={null}>
      <ProfileInfo.Row
        trClassName={`non-cursor`}
        mIconClass={`d-none`}
        title={strings.label_sent_date}
        data={moment(advert.create_date).format("L LT")}
      />

      <ProfileInfo.Row
        trClassName={`non-cursor`}
        mIconClass={`d-none`}
        title={strings.label_where}
        data={
          <div className="clearfix">
            <ObjectAvatar
              imageUrl={objectImageUrl}
              size={40}
              className="invite-card-object-avatar"
            />
            <div className="invite-card-avatar-text">
              {object ? object.name : ''}
            </div>
          </div>
        }
      />


      <ProfileInfo.Row
        trClassName={`non-cursor`}
        mIconClass={`d-none`}
        title={strings.label_theme}
        data={
          <div className="clearfix">
            {advert.title}
          </div>
        }
      />
    </ProfileInfo.Table>
  </div>
);

