import {AdvertText} from './advertText';
import {AdvertHeader} from './advertHeader';

export {
  AdvertHeader,
  AdvertText
}