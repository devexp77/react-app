import React from 'react';

import './style.css'

const Slider = ({id, min, max, value, onChange, label}) => (
  <div className="range-field">
    {label &&
      <label for={id}>{label}</label>
    }
    <input type="range" id={id} min={min} max={max} value={value} onChange={onChange} className={"custom-range"}/>
    <div className={"range-labels clearfix"}>
      <div className={"max"}>{max}</div>
      <div className={"min"}>{min}</div>
    </div>
  </div>
);

export default Slider;