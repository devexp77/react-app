import React from "react";
import Icon from "../Icon";
import "./style.css";
import CheckboxTree from "react-checkbox-tree";
import "react-checkbox-tree/lib/react-checkbox-tree.css";

const CheckBoxTree = ({
  nodes,
  checked,
  expanded,
  onCheck,
  onExpand,
  onClick,
  className,
  clickOnlyOnChildren
}) => {
  let checkBoxProps = {
    nodes: nodes,
    checked: checked,
    expanded: expanded,
    onCheck: onChecked => onCheck(onChecked),
    onExpand: onExpanded => onExpand(onExpanded)
  };

  if (onClick) {
    checkBoxProps.onClick = onClicked => onClick(onClicked);
  }

  return (
    <div
      className={`${className || ""} ${
        clickOnlyOnChildren ? "click-only-on-children" : ""
      }`}
    >
      <CheckboxTree
        {...checkBoxProps}
        icons={{
          check: <Icon name={`check_box`} />,
          uncheck: <Icon name={`check_box_outline_blank`} />,
          halfCheck: <Icon name={`indeterminate_check_box`} />,
          expandClose: <Icon name={`keyboard_arrow_right`} />,
          expandOpen: <Icon name={`keyboard_arrow_down`} />,
          expandAll: <Icon name={`keyboard_arrow_down`} />,
          collapseAll: <Icon name={`keyboard_arrow_up`} />,
          parentClose: <Icon name={`folder`} />,
          parentOpen: <Icon name={`folder_open`} />,
          leaf: <Icon name={`insert_drive_file`} />
        }}
      />
    </div>
  );
};

export default CheckBoxTree;
