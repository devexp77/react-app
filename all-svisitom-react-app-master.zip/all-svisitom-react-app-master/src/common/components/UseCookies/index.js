import React from "react";
import "./style.css";
import { RaisedButton } from "../Button";
import cookie from "react-cookies";
import { Link } from "react-router";
import strings from "../../localization/all";
import {HOST_NAME} from "../../constants";

class UseCookies extends React.Component {
  constructor() {
    super();
    this.state = {
      cookie: null
    };
  }

  componentWillMount() {
    this.setState({ cookie: cookie.load("svisitom_cookies_agree") });
  }

  agreeUseCookies = () => {
    const expires = new Date(Date.now() + 1000 * 60 * 60 * 24 * 365 * 10);
    cookie.save("svisitom_cookies_agree", new Date().toISOString(), {
      path: "/",
      expires,
      domain: `.${HOST_NAME}`
    });
    this.setState({ cookie: cookie.load("svisitom_cookies_agree") });
  };
  render() {
    if (!this.state.cookie) {
      return (
        <div className={`use-cookies-container shadow`}>
          <div className="pull-right">
            <RaisedButton onClick={this.agreeUseCookies}>
              {strings.button_next}
            </RaisedButton>
          </div>
          <p>{strings.title_cookies_use} <Link to={`/privacyPolicy`}>{strings.button_read_more}</Link></p>
        </div>
      );
    } else {
      return null;
    }
  }
}

export default UseCookies;
