import React from "react";

import DataSelectPicker from "../DataSelectPicker";
import InputMask from "../Inputs/inputMask";
import AutoScroll from "../AutoScroll";

import strings from "../../localization/all";
import InputField from "../Inputs/inputField";

class Document extends React.Component {
  getId(id) {
    return this.props.startOfId ? this.props.startOfId + id : id;
  }

  getLabel(field) {
    return strings["label_document_" + field.id] + (field.required ? " *" : "");
  }

  render() {
    let errors = {};
    if (this.props.formErrors) {
      if (!this.props.indexIgnore && this.props.index.toString()) {
        errors.number = this.props.formErrors.docNumber[this.props.index];
        errors.issue_date = this.props.formErrors.issueDate[this.props.index];
      } else {
        errors.number = this.props.formErrors.docNumber;
        errors.issue_date = this.props.formErrors.issueDate;
      }
    }

    const { request_fields } = this.props;

    return (
      <div className="document-component">
        {this.props.fields && this.props.fields.length > 0
          ? this.props.fields.map(
              (field, index) =>
                !(
                  request_fields &&
                  request_fields.visitors.document[field.id] &&
                  !request_fields.visitors.document[field.id].visibility
                ) && (
                  <AutoScroll enabled={this.props.autoScroll} key={index}>
                    {field.type === "input" &&
                      (field.mask ? (
                        <InputMask
                          id={this.getId(field.id)}
                          mask={field.mask}
                          value={this.props[field.id]}
                          handleInputChange={this.props.handleInputChange}
                          label={this.getLabel(field)}
                          error={errors[field.id]}
                          errorClass={this.props.errorClass}
                        />
                      ) : (
                        <InputField
                          id={this.getId(field.id)}
                          value={this.props[field.id]}
                          handleInputChange={this.props.handleInputChange}
                          label={this.getLabel(field)}
                        />
                      ))}

                    {field.type === "date" && (
                      <DataSelectPicker
                        id={this.getId(field.id)}
                        value={this.props[field.id]}
                        handleInputChange={this.props.handleInputChange}
                        label={this.getLabel(field)}
                        error={errors[field.id]}
                        errorClass={this.props.errorClass}
                      />
                    )}
                  </AutoScroll>
                )
            )
          : null}
      </div>
    );
  }
}

export default Document;
