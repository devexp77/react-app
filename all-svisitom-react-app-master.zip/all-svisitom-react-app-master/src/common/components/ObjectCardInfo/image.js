import React from "react";

class ObjectInfoImage extends React.Component {
  render() {
    return (
      <div className={`object-icon ${this.props.detailsTop && 'details-top'}`}>
        {this.props.imgPath ? (
          <div
            className={`img`}
            style={{ backgroundImage: `url(${this.props.imgPath})` }}
          />
        ) : (
          <div className={`i-back`}>
            <i className="material-icons">business</i>
          </div>
        )}
      </div>
    );
  }
}

export default ObjectInfoImage;
