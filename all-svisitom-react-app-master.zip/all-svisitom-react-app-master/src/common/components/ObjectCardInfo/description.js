import React from "react";
import AddressWithMap from "../AddressWithMap";
import Icon from "../Icon";
import KebabMenu from "../KebabMenu";

class ObjectInfoDescription extends React.Component {

  componentDidMount(){
    $(document).off("click touch", "#object-more-actions");
    $(document).on("click touch", "#object-more-actions", function(e) {
      var dropdown = $("#dropdown-object-more-actions");
      var li = $("#object-more-actions");

      if (li.is(e.target) || !li.has(e.target).length == 0) {
        if (dropdown.hasClass("show")) {
          dropdown.removeClass("show");
        } else {
          dropdown.addClass("show");
        }
      }
    });
  }

  render() {
    const object = this.props.object;
    return (
      <div className={`object-details`}>
        <span className={`object-title`}>{object.result && object.result.name}</span>
        <span className={`object-description`}>
          {this.props.address
            ?  <AddressWithMap
                  geo_point={object.result ? object.result.geo_point: null}
                  address={object.result && `${object.result.city}, ${object.result.address}`}
                />
            : object.result && object.result.description}
        </span>

        {this.props.settings && (
          <div onClick={this.props.settingsAction}>
            <Icon name="sv-icon-settings" className={`settings ${this.props.moreActions ? "with-kebab" : ""}`}/>
          </div>
        )}

        {
          this.props.moreActions &&
            <div className={"object-more-actions-wrapper"}>
              <KebabMenu id="object-more-actions">
                {this.props.moreActions}
              </KebabMenu>
            </div>
        }
      </div>
    );
  }
}

export default ObjectInfoDescription;
