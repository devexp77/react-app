import Container from "./container";
import Image from "./image";
import Details from "./description";

import "./style.css";

export default {
  Container,
  Image,
  Details
};
