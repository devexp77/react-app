import React, { Component } from "react";

import {
  withScriptjs,
  withGoogleMap,
  GoogleMap,
  Marker,
} from "react-google-maps";
const {
  SearchBox
} = require("react-google-maps/lib/components/places/SearchBox");
import { compose, withProps, lifecycle } from "recompose";

import "./style.css";

import common_strings from "../../../common/localization/all";
import isTouchDevice from "../../util/isTouchDevice";

const GOOGLE_MAP_URL =
  "https://maps.googleapis.com/maps/api/js?key=AIzaSyAriseuZ90QqiVw_NihABttqK-hS0XkDM4&libraries=geometry,drawing,places";

export const MapWithDragMarker = props => (
  <div className={`map-container no-box-sizing`}>
    <MapWithDragMarkerBox
      onClick={props.onClick}
      onDragEnd={props.onDragEnd}
      onSearch={props.onSearch}
      lat={props.lat}
      lng={props.lng}
      mapLat={props.mapLat}
      mapLng={props.mapLng}
      zoom={props.zoom}
    />
  </div>
);

export const MapStaticSingleMarker = props => (
  <div
    className={`map-container no-box-sizing
  ${props.entityClassName ? "map-" + props.entityClassName : ""} `}
  >
    <MapStaticSingleMarkerBox
      containerElement={
        <div
          className={
            props.entityClassName ? "map-" + props.entityClassName : ""
          }
        />
      }
      lat={props.lat ? props.lat : 0}
      lng={props.lng ? props.lng : 0}
      mapLat={props.lat ? props.lat : 0}
      mapLng={props.lng ? props.lng : 0}
      zoom={props.zoom}
    />
  </div>
);

const MapWithDragMarkerBox = compose(
  withProps({
    googleMapURL: GOOGLE_MAP_URL,
    loadingElement: <div style={{ height: `100%` }} />,
    containerElement: <div style={{ height: `400px` }} />,
    mapElement: <div style={{ height: `100%` }} />
  }),
  lifecycle({
    componentWillMount() {
      const refs = {};
      this.setState({
        onSearchBoxMounted: ref => {
          refs.searchBox = ref;
        },
        onPlacesChanged: () => {
          const places = refs.searchBox.getPlaces();
          this.props.onSearch(places);
        }
      });
    }
  }),
  withScriptjs,
  withGoogleMap
)(props => (
  <GoogleMap
    defaultZoom={props.zoom}
    defaultCenter={{ lat: props.mapLat, lng: props.mapLng }}
    onClick={props.onClick}
    defaultOptions={{
      gestureHandling: isTouchDevice() ? "cooperative" : "greedy",
      mapTypeControlOptions: {
        position: google.maps.ControlPosition.LEFT_BOTTOM
      }
    }}
  >
    <SearchBox
      ref={props.onSearchBoxMounted}
      bounds={props.bounds}
      onPlacesChanged={props.onPlacesChanged}
      controlPosition={google.maps.ControlPosition.TOP_LEFT}
    >
      <div className={`map-search-container`}>
        <div className="lens-icon">
          <i className="material-icons">search</i>
        </div>
        <input
          className={`map-search`}
          type="text"
          placeholder={common_strings.label_search_on_map}
        />
      </div>
    </SearchBox>

    {props.lat &&
      props.lng && (
        <Marker
          position={{ lat: props.lat, lng: props.lng }}
          draggable={true}
          onDragEnd={props.onDragEnd}
        />
      )}
  </GoogleMap>
));

const MapStaticSingleMarkerBox = compose(
  withProps({
    googleMapURL: GOOGLE_MAP_URL,
    loadingElement: <div style={{ height: `100%` }} />,

    mapElement: <div style={{ height: `100%` }} />
  }),
  withScriptjs,
  withGoogleMap
)(props => (
  <GoogleMap
    defaultZoom={props.zoom}
    defaultCenter={{ lat: props.mapLat, lng: props.mapLng }}
    defaultOptions={{
      fullscreenControl: false,
      gestureHandling: "greedy",
      mapTypeControlOptions: {
        position: google.maps.ControlPosition.LEFT_BOTTOM
      }
    }}
  >
    {props.lat &&
      props.lng && (
        <Marker
          position={{ lat: props.lat, lng: props.lng }}
          draggable={false}
        />
      )}
  </GoogleMap>
));


export const ObjectMarker = ({object, onClick}) => {
  if (object.geo_point && (object.geo_point.length == 2)) {
    return (
      <Marker
        position={{ lat: object.geo_point[0], lng: object.geo_point[1] }}
        title={object.name}
        draggable={false}
        onClick={onClick}
      />
    )
  } else {
    return null;
  }
}

const MapWithMarkersBox = compose(
  withProps({
    googleMapURL: GOOGLE_MAP_URL,
    loadingElement: <div style={{ height: `100%` }} />,

    mapElement: <div style={{ height: `100%` }} />
  }),
  withScriptjs,
  withGoogleMap
)(props => (
  <GoogleMap
    defaultZoom={12}
    center={props.center}
    defaultOptions={{
      fullscreenControl: false,
      gestureHandling: "greedy",
      mapTypeControlOptions: {
        position: google.maps.ControlPosition.LEFT_BOTTOM
      }
    }}
  >
    {props.children}
  </GoogleMap>
));

export const MapWithMarkers = props => {
  const calculateCenter = (children) => {
    var minLatitude = 180;
    var maxLatitude = -180;
    var minLongitude = 180;
    var maxLongitude = -180;
    for (var i=0; i<children.length; i++) {
      var object = children[i].props.object;
      if (object.geo_point && object.geo_point.length==2) {
        var latitude = object.geo_point[0];
        var longitude = object.geo_point[1];
        if (latitude > maxLatitude) {
          maxLatitude = latitude;
        }
        if (latitude < minLatitude) {
          minLatitude = latitude;
        }
        if (longitude > maxLongitude) {
          maxLongitude = longitude;
        }
        if (longitude < minLongitude) {
          minLongitude = longitude
        }
      }
    }

    var centerLatitude = (maxLatitude + minLatitude) / 2;
    var centerLongitude = (maxLongitude + minLongitude) /2;
    return {
      lat: centerLatitude,
      lng: centerLongitude
    }
  }

  var mapCenter = calculateCenter(props.children)

  return (
    <div
      className={`map-container no-box-sizing
    ${props.entityClassName ? "map-" + props.entityClassName : ""} `}
    >
      <MapWithMarkersBox
        containerElement={
          <div
            className={
              props.entityClassName ? "map-" + props.entityClassName : ""
            }
          />
        }
        center={mapCenter}
        zoom={props.zoom}
      >
        {props.children}
      </MapWithMarkersBox>
    </div>
  )
}
