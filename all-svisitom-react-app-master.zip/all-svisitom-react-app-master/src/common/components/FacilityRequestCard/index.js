import React, { Fragment } from "react";
import Moment from "react-moment";

import "./style.css";
import { connect } from "react-redux";
import strings from "../../localization/all";
import Tooltip from "../Tooltip";
import Icon from "../Icon";
import CheckerField from "../Inputs/checkerField";

class FacilityRequestCard extends React.Component {
  constructor() {
    super();
    this.statusClasses = {
      accepted: "sv-color-primary",
      rejected: "sv-color-grey",
      in_work: "sv-color-yellow",
      done: "sv-color-green",
      closed: "sv-color-grey",
      expired: "sv-color-red"
    };
  }

  getProblemIcon(record) {
    const { problem } = record;
    let reverseProblems = [];

    Object.assign(reverseProblems, problem);

    reverseProblems.reverse();

    let icon = "sv-icon-fm-other";

    for (let i in reverseProblems) {
      if (reverseProblems[i].icon_name) {
        icon = reverseProblems[i].icon_name.trim();
        return icon;
      }
    }

    return icon;
  }

  renderProblemType(record) {
    return (
      <div className={`row problem-block clearfix`}>
        <div className={"problem-icon"}>
          <Icon
            name={this.getProblemIcon(record)}
            className={this.statusClasses[record.status]}
          />
        </div>
        <div className="col-12 no-padding">
          {record.problem &&
            record.problem.length > 0 &&
            record.problem.length < 4 &&
            record.problem.map((problem, index) => (
              <div className={`problem-name`} key={index}>
                {problem.name}
              </div>
            ))}

          {record.problem && record.problem.length > 3 ? (
            <React.Fragment>
              <div className={`problem-name`}>{record.problem[0].name}</div>
              <div className={`problem-name`}>...</div>
              <div className={`problem-name`}>
                {record.problem[record.problem.length - 1].name}
              </div>
            </React.Fragment>
          ) : null}
        </div>
      </div>
    );
  }

  renderChildProblemType(record) {
    const problemTypeStartIndex = this.props.problemTypeStartIndex || 0;
    return (
      <div className={`row problem-block clearfix`}>
        <div className={"problem-icon"}>
          <Icon
            name={this.getProblemIcon(record)}
            className={this.statusClasses[record.status]}
          />
        </div>
        <div className="col-12 no-padding">
          {record.problem &&
            record.problem.length - problemTypeStartIndex > 0 &&
            record.problem.length - problemTypeStartIndex < 4 &&
            record.problem.map(
              (problem, index) =>
                index >= this.props.problemTypeStartIndex && (
                  <div className={`problem-name`} key={index}>
                    {problem.name}
                  </div>
                )
            )}

          {record.problem &&
          record.problem.length - problemTypeStartIndex > 3 ? (
            <React.Fragment>
              <div className={`problem-name`}>
                {record.problem[problemTypeStartIndex].name}
              </div>
              <div className={`problem-name`}>...</div>
              <div className={`problem-name`}>
                {record.problem[record.problem.length - 1].name}
              </div>
            </React.Fragment>
          ) : null}
        </div>
      </div>
    );
  }

  renderCreatedBy(record) {
    if (record.is_scheduled) {
      return (
        <div className={`row person-block clearfix`}>
          <div className="person-name">{strings.title_request_by_schedule}</div>
        </div>
      );
    } else if (
      record.created_by &&
      !record.created_by.name &&
      !record.created_by.surname
    ) {
      return (
        <div className={`row person-block clearfix`}>
          <div className="person-name">
            {strings.title_request_by_anonymous}
          </div>
        </div>
      );
    } else
      return (
        <div className={`row person-block clearfix`}>
          <div className="person-name">
            {record.created_by && record.created_by.surname ? (
              <span>{record.created_by.surname} </span>
            ) : null}
            {record.created_by && record.created_by.name ? (
              <span>{record.created_by.name} </span>
            ) : null}
          </div>
        </div>
      );
  }

  renderRoom(record) {
    return (
      <div className={`row room-block clearfix`}>
        <div className="room-name">{record.room.name}</div>
      </div>
    );
  }

  renderAssignedTo(record) {
    return (
      <div className={`row assigned-to-block clearfix`}>
        <div
          onClick={
            this.props.masterClick
              ? e => {
                  e.stopPropagation();
                  this.props.masterClick();
                }
              : null
          }
          className={`assigned-to-name ${
            this.props.masterClick ? "click-area-background" : ""
          } `}
        >
          {record.assigned_to && record.assigned_to.surname ? (
            <span>{record.assigned_to.surname} </span>
          ) : null}
          {record.assigned_to && record.assigned_to.name ? (
            <span>{record.assigned_to.name}</span>
          ) : null}
          <br />
          {record.assigned_to && record.assigned_to.job_title ? (
            <span>{record.assigned_to.job_title}</span>
          ) : null}
        </div>
      </div>
    );
  }

  renderProgressBar(record) {
    const { children_status } = record;
    let allCount = 0;
    let finishedCount = 0;
    if (children_status) {
      for (let children in children_status) {
        if (children_status.hasOwnProperty(children)) {
          allCount++;
          if (
            children_status[children] === "done" ||
            children_status[children] === "closed"
          ) {
            finishedCount++;
          }
        }
      }
    }

    return (
      <div className={`request-progress`}>
        <Icon name={`check`} />
        {finishedCount} / {allCount}
      </div>
    );
  }

  renderHead(record) {
    const create_date = record.create_date ? new Date(record.create_date) : "";
    return (
      <div className="row head">
        {!this.props.renderChildRequest ? (
          <Fragment>
            {record.is_group && this.renderProgressBar(record)}
            {record.is_payable && (
              <div>
                <div
                  className={`card-paid-icon ${
                    record.is_paid ? "sv-color-green" : "sv-color-red"
                  }`}
                >
                  <Icon name={`sv-icon-ruble`} />
                </div>
              </div>
            )}
          </Fragment>
        ) : this.props.finishWork ? (
          <div
            onClick={e => {
              e.stopPropagation();
              if (!(record.status === "done" || record.status === "closed")) {
                this.props.finishWork(record);
              }
            }}
          >
            <div className={`card-paid-icon`}>
              <CheckerField
                checked={record.status === "done" || record.status === "closed"}
              />
            </div>
          </div>
        ) : null}
        <div className="col-12 no-padding">
          <div className="request-number">
            №{record.number ? <span>{record.number} </span> : ""}
          </div>

          <div className="requests-time col-6 float-left">
            <p>
              <Moment format="L" locale={strings.getLanguage()}>
                {create_date}
              </Moment>
            </p>
          </div>

          {this.renderStatus(record)}
        </div>
      </div>
    );
  }

  renderStatus(record) {
    return (
      <div className="status">
        <span>{strings["status_facility_request_" + record.status]}</span>
      </div>
    );
  }

  renderExpirationDate(record) {
    const expiration_date = record.expiration_date
      ? new Date(record.expiration_date)
      : "";
    return (
      <div className={`row expiration-date-block`} style={{ marginTop: "5px" }}>
        <div
          onClick={
            this.props.dateClick
              ? e => {
                  e.stopPropagation();
                  this.props.dateClick();
                }
              : null
          }
          className={`${this.props.dateClick ? "click-area-background" : ""}`}
        >
          {expiration_date && (
            <Moment
              format={this.isToday(expiration_date) ? "LT" : "L"}
              locale={strings.getLanguage()}
            >
              {expiration_date}
            </Moment>
          )}
        </div>
      </div>
    );
  }

  isToday(date) {
    return (
      new Date(
        date.getFullYear(),
        date.getMonth(),
        date.getDate()
      ).toISOString() ===
      new Date(
        new Date().getFullYear(),
        new Date().getMonth(),
        new Date().getDate()
      ).toISOString()
    );
  }

  renderPlannedDate(record) {
    const planned_date = record.planned_date
      ? new Date(record.planned_date)
      : "";
    return (
      <div className={`row expiration-date-block`}>
        <div
          onClick={
            this.props.plannedDateClick
              ? e => {
                  e.stopPropagation();
                  this.props.plannedDateClick();
                }
              : null
          }
          className={`${
            this.props.plannedDateClick ? "click-area-background" : ""
          }`}
        >
          {planned_date && (
            <Moment
              format={this.isToday(planned_date) ? "LT" : "L"}
              locale={strings.getLanguage()}
            >
              {planned_date}
            </Moment>
          )}
        </div>
      </div>
    );
  }

  renderExecutionDate(record) {
    const execution_date = record.execution_date
      ? new Date(record.execution_date)
      : "";
    return (
      <div className={`row execution-date-block`}>
        {execution_date && (
          <p>
            <Moment
              format={this.isToday(execution_date) ? "LT" : "L"}
              locale={strings.getLanguage()}
            >
              {execution_date}
            </Moment>
          </p>
        )}
      </div>
    );
  }

  renderStartExecutionDate(record) {
    const start_execution_date = record.start_execution_date
      ? new Date(record.start_execution_date)
      : "";
    return (
      <div className={`row execution-date-block`} style={{ marginTop: "15px" }}>
        {start_execution_date && (
          <p>
            <Moment
              format={this.isToday(start_execution_date) ? "LT" : "L"}
              locale={strings.getLanguage()}
            >
              {start_execution_date}
            </Moment>
          </p>
        )}
      </div>
    );
  }

  render() {
    let record = this.props.record;

    if (this.props.renderChildRequest) {
      return (
        <div className="fm-request-card col-12 col-sm-12 col-md-12 col-lg-6 col-xl-6 clearfix">
          <div
            className="request-info"
            onClick={() => this.props.action(record.facility_request_id)}
          >
            {this.renderHead(record)}
            <div className={`children-kebab-menu`}>{this.props.children}</div>
            <hr />

            <div>{this.renderChildProblemType(record)}</div>

            <div>{this.renderAssignedTo(record)}</div>
            <div>{this.renderPlannedDate(record)}</div>
            <div>{this.renderExpirationDate(record)}</div>
            <div>{this.renderStartExecutionDate(record)}</div>
            <div>{this.renderExecutionDate(record)}</div>
          </div>
        </div>
      );
    } else {
      return (
        <div className="fm-request-card col-12 col-sm-12 col-md-12 col-lg-6 col-xl-4 clearfix">
          <div
            className="request-info"
            onClick={() => this.props.action(record.facility_request_id)}
          >
            {this.renderHead(record)}
            <div className={`children-kebab-menu`}>{this.props.children}</div>
            <hr />

            <div>{this.renderProblemType(record)}</div>

            <div>{this.renderRoom(record)}</div>
            <div>{this.renderCreatedBy(record)}</div>
            <div>{this.renderAssignedTo(record)}</div>
            <div>{this.renderPlannedDate(record)}</div>
            <div>{this.renderExpirationDate(record)}</div>
            <div>{this.renderStartExecutionDate(record)}</div>
            <div>{this.renderExecutionDate(record)}</div>
          </div>
        </div>
      );
    }
  }
}

const mapStateToProps = state => {
  return {
    image: state.image
  };
};

export default connect(mapStateToProps)(FacilityRequestCard);
