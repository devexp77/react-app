import React, { Component } from "react";
import { connect } from "react-redux";

import { toCustomPath } from "../../../common/actions/router";

import "./style.css";

/*
props
title
prevPath
addFunction()
actionIcon
actionFunction()
*/

class NavigationTitle extends Component {
  goBack() {
    const { dispatch } = this.props;
    dispatch(toCustomPath(this.props.prevPath));
  }

	render() {
		return (
			<div className="row navigation-title">
			{this.props.prevPath
				? <i className="material-icons" onClick={this.goBack.bind(this)}>navigate_before</i>
				: null
			}

			{this.props.onBackClick &&
				<i className="material-icons" onClick={this.props.onBackClick}>navigate_before</i>
			}

				<h5>{this.props.title}</h5>
				{this.props.addFunction
					? <i className="material-icons add" onClick={this.props.addFunction}>add</i>
					: null

				}

				{this.props.actionFunction
					? <i className="material-icons action" onClick={this.props.actionFunction}>{this.props.actionIcon}</i>
					: null
				}
			</div>
			)
	}
}

const mapStateToProps = () => {
  return {};
};

export default connect(mapStateToProps)(NavigationTitle);
