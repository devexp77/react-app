import React from "react";

import "./style.css";
import { Document, Page } from "react-pdf";
import { pdfjs } from "react-pdf";
import { RaisedButton } from "../Button";
import Icon from "../Icon";
import format from "string-format";
import strings from "../../localization/all";
import {HOST_NAME, PROTOCOL} from "../../constants";

pdfjs.GlobalWorkerOptions.workerSrc = `${PROTOCOL}//cdn.${HOST_NAME}/external/pdfJS/pdf.worker.js`;

class PdfViewer extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      numPages: null,
      pageNumber: 1,
      scale: 1
    };
  }

  onDocumentLoadSuccess = ({ numPages }) => {
    this.setState({ numPages });
  };

  onScaleChange(direction) {
    const delta = direction === "inc" ? 0.25 : -0.25;

    this.setState(prevState => {
      return {
        scale: prevState.scale + delta
      };
    });
  }

  onPageChange(direction) {
    const delta = direction === "inc" ? 1 : -1;
    this.setState(prevState => {
      return {
        pageNumber: prevState.pageNumber + delta
      };
    });
  }

  openPdfInNewTab(url) {
    const win = window.open(url, "_blank");
    win.focus();
  }

  render() {
    const { pageNumber, numPages } = this.state;
    return (
      <div className={`PdfViewer-container`}>
        <Document
          file={this.props.file}
          onLoadSuccess={this.onDocumentLoadSuccess}
        >
          <Page scale={this.state.scale} pageNumber={this.state.pageNumber} />
        </Document>

        <div className={`scale-buttons`}>
          <RaisedButton
            className={`share-button`}
            onClick={() => this.openPdfInNewTab(this.props.file)}
          >
            <Icon name={`sv-icon-hyperlink`} />
          </RaisedButton>
          <RaisedButton onClick={() => this.onScaleChange("inc")}>
            +
          </RaisedButton>
          <RaisedButton
            disabled={this.state.scale === 0.5}
            onClick={() => this.onScaleChange("dec")}
          >
            &minus;
          </RaisedButton>
        </div>

        <div className={`page-buttons`}>

          <RaisedButton
            disabled={this.state.pageNumber === 1}
            onClick={() => this.onPageChange("dec")}
          >
            <Icon name={`navigate_before`} />
          </RaisedButton>
          <div className={`pages`}>
            {format(strings.title_page_number, pageNumber, numPages)}
          </div>
          <RaisedButton
            disabled={this.state.pageNumber === this.state.numPages}
            onClick={() => this.onPageChange("inc")}
          >
            <Icon name={`navigate_next`} />
          </RaisedButton>

        </div>
      </div>
    );
  }
}

export default PdfViewer;
