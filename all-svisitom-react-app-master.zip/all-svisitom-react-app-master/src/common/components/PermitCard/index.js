import React from "react";
import Moment from "react-moment";
// import "moment-timezone";

import common_strings from "../../localization/all";

import "./style.css";
import { connect } from "react-redux";
import strings from "../../../object/localization/all";
import Tooltip from "../Tooltip";
import Icon from "../Icon";

class RequestCard extends React.Component {
  getImagePath(user_id) {
    let imgSrc = "";
    if (
      this.props.image.usersImage.result &&
      this.props.image.usersImage.result[user_id]
    ) {
      imgSrc = this.props.image.usersImage.result[user_id];
    }

    return imgSrc;
  }

  getEnterTime(permit) {
    const logbookRecordsByIds =
      this.props.logbookRecordsByIds && this.props.logbookRecordsByIds.result
        ? this.props.logbookRecordsByIds.result.slice().reverse()
        : null;
    const transportLogbookRecordsByIds =
      this.props.transportLogbookRecordsByIds &&
      this.props.transportLogbookRecordsByIds.result
        ? this.props.transportLogbookRecordsByIds.result.slice().reverse()
        : null;

    if (permit.entity_type === "visitor" && logbookRecordsByIds) {
      if (
        logbookRecordsByIds.find(
          record => record.record_id === permit.last_record_id
        ) &&
        logbookRecordsByIds.find(
          record => record.record_id === permit.last_record_id
        ).pass_in
      ) {
        return logbookRecordsByIds.find(
          record => record.record_id === permit.last_record_id
        ).pass_in.date;
      }
      return null;
    }

    if (permit.entity_type === "transport" && transportLogbookRecordsByIds) {
      if (
        transportLogbookRecordsByIds.find(
          record => record.record_id === permit.last_record_id
        ) &&
        transportLogbookRecordsByIds.find(
          record => record.record_id === permit.last_record_id
        ).pass_in
      ) {
        return transportLogbookRecordsByIds.find(
          record => record.record_id === permit.last_record_id
        ).pass_in.date;
      }
      return null;
    }

    return null;
  }

  getExitTime(permit) {
    const logbookRecordsByIds =
      this.props.logbookRecordsByIds && this.props.logbookRecordsByIds.result
        ? this.props.logbookRecordsByIds.result.slice().reverse()
        : null;
    const transportLogbookRecordsByIds =
      this.props.transportLogbookRecordsByIds &&
      this.props.transportLogbookRecordsByIds.result
        ? this.props.transportLogbookRecordsByIds.result.slice().reverse()
        : null;

    if (permit.entity_type === "visitor" && logbookRecordsByIds) {
      if (
        logbookRecordsByIds.find(
          record => record.record_id === permit.last_record_id
        ) &&
        logbookRecordsByIds.find(
          record => record.record_id === permit.last_record_id
        ).pass_out
      ) {
        return logbookRecordsByIds.find(
          record => record.record_id === permit.last_record_id
        ).pass_out.date;
      }
      return null;
    }

    if (permit.entity_type === "transport" && transportLogbookRecordsByIds) {
      if (
        transportLogbookRecordsByIds.find(
          record => record.record_id === permit.last_record_id
        ) &&
        transportLogbookRecordsByIds.find(
          record => record.record_id === permit.last_record_id
        ).pass_out
      ) {
        return transportLogbookRecordsByIds.find(
          record => record.record_id === permit.last_record_id
        ).pass_out.date;
      }
      return null;
    }

    return null;
  }

  renderIconStatus(record) {
    return (
      <div
        className={`icon ${
          this.props.statusClick ? "click-area-background" : ""
        }`}
        onClick={
          this.props.statusClick
            ? e => {
                e.stopPropagation();
                this.props.statusClick();
              }
            : null
        }
      >
        <div className={`status ${record.status} `}>
          <div className={record.is_suspended ? "suspended" : ""} />
        </div>
      </div>
    );
  }

  renderStatus(record) {
    return (
      <div className="pass-info">
        <span>
          {common_strings["status_permit_" + record.status]}
          {record.is_suspended ? ` (${common_strings.permit_suspended})` : ""}
        </span>
      </div>
    );
  }

  renderHead(record) {
    const start_date = new Date(record.start_date);
    const end_date = new Date(record.end_date);
    return (
      <div className="row head">
        {this.renderIconStatus(record)}
        <div className="col-12 no-padding">
          <div className="request-number">
            №{record.number ? <span>{record.number} </span> : ""}
            {record.permit_type === "multiple_use" && (
              <div className={`multiple-use-permit`}>
                <Tooltip
                  title={common_strings.permit_type_multiple_use}
                  id={`${record.permit_type}-${record.permit_id}`}
                >
                  <Icon name={`sv-icon-${record.permit_type}`} />
                </Tooltip>
              </div>
            )}
          </div>

          <div className="requests-time col-6 float-left">
            <p>
              <Moment format="L" locale={strings.getLanguage()}>
                {record.start_date}
              </Moment>
            </p>
            {new Date(
              start_date.getFullYear(),
              start_date.getMonth(),
              start_date.getDate()
            ).toISOString() !==
              new Date(
                end_date.getFullYear(),
                end_date.getMonth(),
                end_date.getDate()
              ).toISOString() && (
              <p>
                <Moment format="L" locale={strings.getLanguage()}>
                  {record.end_date}
                </Moment>
              </p>
            )}
          </div>

          {this.renderStatus(record)}
        </div>
      </div>
    );
  }

  renderPerson(record) {
    let imgPath = "";
    if (
      record.visitor &&
      record.visitor.user_id &&
      this.getImagePath(record.visitor.user_id)
    ) {
      imgPath = this.getImagePath(record.visitor.user_id);
    }
    return (
      <div className="row person">
        {imgPath ? (
          <div className="icon">
            <img src={imgPath} />
          </div>
        ) : (
          <div className="icon">
            <i className="material-icons">account_circle</i>
          </div>
        )}

        <div className="col-12 no-padding">
          <div className="person-name">
            {record.visitor && record.visitor.surname ? (
              <span>{record.visitor.surname} </span>
            ) : null}
            {record.visitor && record.visitor.name ? (
              <span>{record.visitor.name} </span>
            ) : null}
            <br />
            {record.visitor && record.visitor.patronymic ? (
              <span>{record.visitor.patronymic} </span>
            ) : null}
          </div>

          <div className="person-company">
            {record.visitor && record.visitor.company ? (
              <span>{record.visitor.company} </span>
            ) : null}
          </div>

          <div className="person-jobtitle">
            {record.visitor && record.visitor.job_title ? (
              <span>{record.visitor.job_title} </span>
            ) : null}
          </div>
        </div>
      </div>
    );
  }

  renderReceivingSide(record) {
    return (
      <div
        className={`row receiving-side`}
        onClick={
          this.props.roomClick
            ? e => {
                e.stopPropagation();
                this.props.roomClick();
              }
            : null
        }
      >
        <div className={`col-12 no-padding`}>
          <div className="addressee">
            {record.addressee && record.addressee.name ? (
              <span>{record.addressee.name} </span>
            ) : null}
          </div>
          <div
            className={`room ${
              this.props.roomClick ? "click-area-background" : ""
            }`}
          >
            {record.room && record.room.name ? (
              <span>{record.room.name} </span>
            ) : (
              <a>Назначить помещение</a>
            )}
          </div>
          <div className="inviter">
            {record.inviter && record.inviter.surname ? (
              <span>{record.inviter.surname} </span>
            ) : null}
            {record.inviter && record.inviter.name ? (
              <span>{record.inviter.name.substring(0, 1)}. </span>
            ) : null}
            {record.inviter && record.inviter.patronymic ? (
              <span>{record.inviter.patronymic.substring(0, 1)}.</span>
            ) : null}
          </div>
        </div>
      </div>
    );
  }

  renderAccompany(record) {
    if (record.accompany && record.accompany.surname) {
      return (
        <div className={`row accompany clearfix`}>
          <div className={`col-12 no-padding`}>
            <Icon name={`supervised_user_circle`} />

            <div className="accompany-name">
              {record.accompany && record.accompany.surname ? (
                <span>{record.accompany.surname} </span>
              ) : null}
              {record.accompany && record.accompany.name ? (
                <span>{record.accompany.name.substring(0, 1)}. </span>
              ) : null}
              {record.accompany && record.accompany.patronymic ? (
                <span>{record.accompany.patronymic.substring(0, 1)}.</span>
              ) : null}
            </div>
          </div>
        </div>
      );
    } else return <div className={`row accompany`} />;
  }

  renderPassInfo(record) {
    return (
      <div className={`row pass-info`}>
        <div className={`col-12 no-padding`}>
          {this.getEnterTime(record) && (
            <div className={`pass-in`}>
              <Icon name={`sv-icon-in`} />
              <div className={`time`}>
                <Moment format="L" locale={strings.getLanguage()}>
                  {this.getEnterTime(record)}
                </Moment>

                <Moment format="LT" locale={strings.getLanguage()}>
                  {this.getEnterTime(record)}
                </Moment>
              </div>
            </div>
          )}

          {this.getExitTime(record) && (
            <div className={`pass-out`}>
              <Icon name={`sv-icon-out`} />
              <div className={`time`}>
                <Moment format="L" locale={strings.getLanguage()}>
                  {this.getExitTime(record)}
                </Moment>

                <Moment format="LT" locale={strings.getLanguage()}>
                  {this.getExitTime(record)}
                </Moment>
              </div>
            </div>
          )}
        </div>
      </div>
    );
  }

  renderTransport(record) {
    return (
      <div className="row person">
        <div className="icon">
          <i className="material-icons">directions_car</i>
        </div>

        <div className="col-12 no-padding">
          <div className="person-name">
            {record.transport && record.transport.brand ? (
              <span>{record.transport.brand} </span>
            ) : null}

            {record.transport && record.transport.model ? (
              <span>{record.transport.model} </span>
            ) : null}
          </div>

          <div className="person-jobtitle">
            {record.transport && record.transport.license_plate ? (
              <span>{record.transport.license_plate} </span>
            ) : null}
          </div>

          <div className="person-jobtitle">
            {record.transport && record.transport.category ? (
              <span>{record.transport.category} </span>
            ) : null}
          </div>

          <div className="person-company">
            {record.transport &&
            record.transport.driver &&
            record.transport.driver.surname ? (
              <span>{record.transport.driver.surname} </span>
            ) : null}
            {record.transport &&
            record.transport.driver &&
            record.transport.driver.name ? (
              <span>{record.transport.driver.name.substring(0, 1)}. </span>
            ) : null}
            {record.transport &&
            record.transport.driver &&
            record.transport.driver.patronymic ? (
              <span>{record.transport.driver.patronymic.substring(0, 1)}.</span>
            ) : null}
          </div>
        </div>
      </div>
    );
  }

  render() {
    let record = this.props.record;
    return (
      <div className="permits-item col-12 col-sm-12 col-md-12 col-lg-6 col-xl-4 clearfix">
        <div
          className="visitor-info "
          onClick={() => this.props.action(record.permit_id)}
        >
          {this.renderHead(record)}
          <div className={`children-kebab-menu`}>{this.props.children}</div>
          <hr />
          {record.entity_type === "visitor" && this.renderPerson(record)}
          {record.entity_type === "transport" && this.renderTransport(record)}
          {this.renderReceivingSide(record)}
          {this.renderAccompany(record)}
          {this.renderPassInfo(record)}

          {record.visitor_is_waiting ? (
            <div
              className={`permit-status-icon ${
                this.props.visitorClick ? "click-area-background" : ""
              }`}
              onClick={
                this.props.visitorClick
                  ? e => {
                      e.stopPropagation();
                      this.props.visitorClick();
                    }
                  : null
              }
            >
              <Icon name={`sv-icon-arrives`} style={{ color: "#ffcc00" }} />
            </div>
          ) : (
            <div
              className={`permit-status-icon ${
                this.props.visitorClick ? "click-area-background" : ""
              }`}
              onClick={
                this.props.visitorClick
                  ? e => {
                      e.stopPropagation();
                      this.props.visitorClick();
                    }
                  : null
              }
            >
              <Icon name={`sv-icon-` + record.entity_status} />
            </div>
          )}
        </div>
      </div>
    );
  }
}

const mapStateToProps = state => {
  return {
    image: state.image
  };
};

export default connect(mapStateToProps)(RequestCard);
