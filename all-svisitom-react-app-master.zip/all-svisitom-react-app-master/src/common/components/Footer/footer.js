import React from "react";
import "./style.css";
import { SVISITOM_URL } from "../../constants";
import strings from "../../localization/all";

class Footer extends React.Component {
  render() {
    return (
      <footer className="small-footer">
        <div className={`footer-copyright white-text ${this.props.marginClass ? this.props.marginClass : null}`}>
          <div
            className={`${
              this.props.containerClass
                ? this.props.containerClass
                : "container"
            } copytext`}
          >
            <a href={`${SVISITOM_URL}/#/`} className="white-text">
              {strings.footer_link}
            </a>

            <div className="terms">
              <a href={`${SVISITOM_URL}/#/privacyPolicy`} className="white-text">{strings.footer_privacy}</a>
              <a href={`${SVISITOM_URL}/#/termsOfService`} className="white-text">{strings.footer_terms}</a>
            </div>
          </div>
        </div>
      </footer>
    );
  }
}
export default Footer;
