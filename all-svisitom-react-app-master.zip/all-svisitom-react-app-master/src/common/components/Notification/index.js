import React from "react";
import BasicNotification from "./BasicNotification";
import strings from "../../localization/notification";
import common_strings from "../../localization/all";
import { PROTOCOL, HOST_NAME } from "../../../common/constants";
import format from "string-format";
import numeral from "numeral";

const formatUserName = user => {
  if (user) {
    let result = user.name;
    if (user.surname) {
      result += " " + user.surname;
    }
    return result;
  } else {
    return null;
  }
};

/*
Unknown notification
*/

const NotificationUnknown = ({ notification, onClick, onDelete }) => {
  return (
    <BasicNotification
      appIcon="error"
      appName={strings.header_unknown}
      time={notification.create_date}
      contentTitle={notification.message_id}
      onClick={onClick}
      onDelete={onDelete}
    />
  );
};

const ActionUnknown = notification => {
  return null;
};

const ActionDefault = notification => {
  return notification.other.click_action;
};

/*
Request created
*/

const NotificationRequestCreated = ({ notification, onClick, onDelete }) => {
  return (
    <BasicNotification
      appIcon="content_paste"
      appName={strings.header_requests}
      time={notification.create_date}
      contentTitle={format(
        strings.title_request_created,
        notification.other.number
      )}
      contentText={format(
        strings.text_request_details,
        notification.object.name
      )}
      onClick={onClick}
      onDelete={onDelete}
    />
  );
};

const ActionRequestCreated = notification => {
  return `${PROTOCOL}//profile.${HOST_NAME}/#/requests/${
    notification.entity_id
  }`;
};

/*
Request created
*/

const NotificationRequestReview = ({ notification, onClick, onDelete }) => {
  return (
    <BasicNotification
      appIcon="content_paste"
      appName={strings.header_requests}
      time={notification.create_date}
      contentTitle={format(
        strings.title_request_review,
        notification.other.number
      )}
      contentText={format(
        strings.text_request_details,
        notification.object.name
      )}
      onClick={onClick}
      onDelete={onDelete}
    />
  );
};

const ActionRequestReview = notification => {
  return `${PROTOCOL}//profile.${HOST_NAME}/#/requests/${
    notification.entity_id
  }`;
};

/*
Request approved
*/

const NotificationRequestApproved = ({ notification, onClick, onDelete }) => {
  return (
    <BasicNotification
      appIcon="content_paste"
      appName={strings.header_requests}
      time={notification.create_date}
      contentTitle={format(
        strings.title_request_approved,
        notification.other.number
      )}
      contentText={format(
        strings.text_request_details,
        notification.object.name
      )}
      onClick={onClick}
      onDelete={onDelete}
    />
  );
};

const ActionRequestApproved = notification => {
  return `${PROTOCOL}//profile.${HOST_NAME}/#/requests/${
    notification.entity_id
  }`;
};

/*
Request rejected
*/

const NotificationRequestRejected = ({ notification, onClick, onDelete }) => {
  return (
    <BasicNotification
      appIcon="content_paste"
      appName={strings.header_requests}
      time={notification.create_date}
      contentTitle={format(
        strings.title_request_rejected,
        notification.other.number
      )}
      contentText={format(
        strings.text_request_details,
        notification.object.name
      )}
      onClick={onClick}
      onDelete={onDelete}
    />
  );
};

const ActionRequestRejected = notification => {
  return `${PROTOCOL}//profile.${HOST_NAME}/#/requests/${
    notification.entity_id
  }`;
};

/*
Request approval
*/

const NotificationRequestApproval = ({ notification, onClick, onDelete }) => {
  return (
    <BasicNotification
      appIcon="content_paste"
      appName={strings.header_requests}
      time={notification.create_date}
      contentTitle={format(
        strings.title_request_approval,
        notification.other.number
      )}
      contentText={format(
        strings.text_request_details2,
        notification.other.addressee.name,
        notification.object.name
      )}
      onClick={onClick}
      onDelete={onDelete}
    />
  );
};

const ActionRequestApproval = notification => {
  return `${PROTOCOL}//${
    notification.object.domain_name
  }.${HOST_NAME}/#/requests/${notification.entity_id}`;
};

/*
Request approval
*/

const NotificationNeedRegisterRequest = ({
  notification,
  onClick,
  onDelete
}) => {
  return (
    <BasicNotification
      appIcon="content_paste"
      appName={strings.header_requests}
      time={notification.create_date}
      contentTitle={format(
        strings.title_need_register_request,
        notification.other.number
      )}
      contentText={format(
        strings.text_request_details2,
        notification.other.addressee.name,
        notification.object.name
      )}
      onClick={onClick}
      onDelete={onDelete}
    />
  );
};

const ActionNeedRegisterRequest = notification => {
  return `${PROTOCOL}//${
    notification.object.domain_name
  }.${HOST_NAME}/#/requests/${notification.entity_id}`;
};

/*
Permit created
*/

const NotificationPermitCreated = ({ notification, onClick, onDelete }) => {
  return (
    <BasicNotification
      appIcon="content_paste"
      appName={strings.header_requests}
      time={notification.create_date}
      contentTitle={format(
        strings.title_permit_created,
        notification.other.number
      )}
      contentText={format(
        strings.text_request_details,
        notification.object.name
      )}
      onClick={onClick}
      onDelete={onDelete}
    />
  );
};

const ActionPermitCreated = notification => {
  return `${PROTOCOL}//profile.${HOST_NAME}/#/requests/${
    notification.entity_id
  }`;
};

/*
Permit not created
*/

const NotificationPermitNotCreated = ({ notification, onClick, onDelete }) => {
  return (
    <BasicNotification
      appIcon="content_paste"
      appName={strings.header_requests}
      time={notification.create_date}
      contentTitle={format(
        strings.title_permit_not_created,
        notification.other.number
      )}
      contentText={format(
        strings.text_request_details,
        notification.object.name
      )}
      onClick={onClick}
      onDelete={onDelete}
    />
  );
};

const ActionPermitNotCreated = notification => {
  return `${PROTOCOL}//profile.${HOST_NAME}/#/requests/${
    notification.entity_id
  }`;
};

/*
Permit active
 */

const NotificationPermitActive = ({ notification, onClick, onDelete }) => {
  return (
    <BasicNotification
      appIcon="content_paste"
      appName={strings.header_requests}
      time={notification.create_date}
      contentTitle={format(
        strings.title_permit_active,
        notification.other.number
      )}
      contentText={format(
        strings.text_permit_details,
        notification.other.object.name
      )}
      onClick={onClick}
      onDelete={onDelete}
    />
  );
};

/*
Permit temporarily_blocked
 */

const NotificationPermitTemporarilyBlocked = ({
  notification,
  onClick,
  onDelete
}) => {
  return (
    <BasicNotification
      appIcon="content_paste"
      appName={strings.header_requests}
      time={notification.create_date}
      contentTitle={format(
        strings.title_permit_temporarily_blocked,
        notification.other.number
      )}
      contentText={format(
        strings.text_permit_details,
        notification.other.object.name
      )}
      onClick={onClick}
      onDelete={onDelete}
    />
  );
};

/*
visitor is waiting
 */

const NotificationVisitorIsWaiting = ({ notification, onClick, onDelete }) => {
  return (
    <BasicNotification
      appIcon="content_paste"
      appName={strings.header_requests}
      time={notification.create_date}
      contentTitle={strings.title_visitor_is_waiting}
      contentText={
        <span>
          {format(strings.title_permit_number, notification.other.number)}
          <br />
          {getPersonDetail(notification)}
        </span>
      }
      onClick={onClick}
      onDelete={onDelete}
    />
  );
};

const ActionVisitorIsWaiting = notification => {
  if (notification.other.click_action) {
    return notification.other.click_action;
  }
  return null;
};

/*
accompany finished
 */

function getPersonDetail(notification) {
  if (
    notification.other &&
    notification.other.visitor &&
    notification.other.visitor.surname
  ) {
    let visitor = notification.other.visitor;
    return `${visitor.surname} ${
      visitor.name ? visitor.name.substring(0, 1) + "." : ""
    } ${visitor.patronymic ? visitor.patronymic.substring(0, 1) + "." : ""}`;
  } else if (
    notification.other &&
    notification.other.transport &&
    notification.other.transport.license_plate
  ) {
    const transport = notification.other.transport;
    return `${transport.brand ? transport.brand : strings.title_vehicle} ${
      transport.license_plate
    }`;
  } else return "";
}

const NotificationAccompanyFinished = ({ notification, onClick, onDelete }) => {
  return (
    <BasicNotification
      appIcon="content_paste"
      appName={strings.header_requests}
      time={notification.create_date}
      contentTitle={strings.title_permit_accompany_finished}
      contentText={
        <span>
          {format(strings.title_permit_number, notification.other.number)}
          <br />
          {getPersonDetail(notification)}
        </span>
      }
      onClick={onClick}
      onDelete={onDelete}
    />
  );
};

const ActionAccompanyFinished = notification => {
  if (notification.other.click_action) {
    return notification.other.click_action;
  }
  return null;
};

/*
accompany started
 */

const NotificationAccompanyStarted = ({ notification, onClick, onDelete }) => {
  return (
    <BasicNotification
      appIcon="content_paste"
      appName={strings.header_requests}
      time={notification.create_date}
      contentTitle={strings.title_permit_accompany_started}
      contentText={
        <span>
          {format(strings.title_permit_number, notification.other.number)}
          <br />
          {getPersonDetail(notification)}
        </span>
      }
      onClick={onClick}
      onDelete={onDelete}
    />
  );
};

const ActionAccompanyStarted = notification => {
  if (notification.other.click_action) {
    return notification.other.click_action;
  }
  return null;
};

/*
New invite
*/

const NotificationNewInvite = ({ notification, onClick, onDelete }) => {
  let targetName = notification.object.name;
  if (notification.other.addressee) {
    targetName = notification.other.addressee.name;
  }

  let messageText = strings.text_new_invite;
  if (notification.other.invite_type == "visit") {
    messageText = strings.text_new_invite_visit;
  } else if (notification.other.invite_type == "take_object") {
    messageText = strings.text_new_invite_take_object;
  }

  return (
    <BasicNotification
      appIcon="chat"
      appName={strings.header_messages}
      time={notification.create_date}
      contentTitle={formatUserName(notification.other.from)}
      contentText={format(messageText, targetName)}
      onClick={onClick}
      onDelete={onDelete}
    />
  );
};

const ActionNewInvite = notification => {
  return `${PROTOCOL}//profile.${HOST_NAME}/#/invites/${
    notification.entity_id
  }`;
};

/*
Accept invite
*/

const NotificationAcceptInvite = ({ notification, onClick, onDelete }) => {
  return (
    <BasicNotification
      appIcon="chat"
      appName={strings.header_messages}
      time={notification.create_date}
      contentTitle={formatUserName(notification.other.to)}
      contentText={strings.text_accept_invite}
      onClick={onClick}
      onDelete={onDelete}
    />
  );
};

const ActionAcceptInvite = notification => {
  return `${PROTOCOL}//profile.${HOST_NAME}/#/invites/${
    notification.entity_id
  }`;
};

/*
Reject invite
*/

const NotificationRejectInvite = ({ notification, onClick, onDelete }) => {
  return (
    <BasicNotification
      appIcon="chat"
      appName={strings.header_messages}
      time={notification.create_date}
      contentTitle={formatUserName(notification.other.to)}
      contentText={strings.text_reject_invite}
      onClick={onClick}
      onDelete={onDelete}
    />
  );
};

const ActionRejectInvite = notification => {
  return `${PROTOCOL}//profile.${HOST_NAME}/#/invites/${
    notification.entity_id
  }`;
};

/*
Change roles
*/

const NotificationChangeRoles = ({ notification, onClick, onDelete }) => {
  let targetName = "";
  if (notification.object) {
    targetName = notification.object.name;
  }
  if (notification.other.addressee) {
    targetName = notification.other.addressee.name;
  }

  return (
    <BasicNotification
      appIcon="chat"
      appName={strings.header_messages}
      time={notification.create_date}
      contentTitle={formatUserName(notification.other.from)}
      contentText={format(strings.text_change_roles, targetName)}
      onClick={onClick}
      onDelete={onDelete}
    />
  );
};

const ActionChangeRoles = notification => {
  return `${PROTOCOL}//profile.${HOST_NAME}/`;
};

/*
New payment
*/

const NotificationNewPayment = ({ notification, onClick, onDelete }) => {
  return (
    <BasicNotification
      appIcon="monetization_on"
      appName={strings.header_finance}
      time={notification.create_date}
      contentTitle={strings.title_new_payment}
      contentText={format(
        strings.text_new_payment,
        numeral(notification.other.amount).format("0[.]00")
      )}
      onClick={onClick}
      onDelete={onDelete}
    />
  );
};

const ActionNewPayment = notification => {
  return `${PROTOCOL}//profile.${HOST_NAME}/#/finance`;
};

/*
Next peyment soon
*/

const NotificationPaymentSoon = ({ notification, onClick, onDelete }) => {
  moment.locale(strings.getLanguage());
  return (
    <BasicNotification
      appIcon="monetization_on"
      appName={strings.header_finance}
      time={notification.create_date}
      contentTitle={format(
        strings.title_payment_soon,
        notification.other.number
      )}
      contentText={format(
        strings.text_bill_created,
        notification.other.amount,
        moment(notification.other.due_date).format("L")
      )}
      onClick={onClick}
      onDelete={onDelete}
    />
  );
};

const ActionPaymentSoon = notification => {
  return `${PROTOCOL}//profile.${HOST_NAME}/#/finance`;
};

/*
Billing issue
*/

const NotificationBillingIssue = ({ notification, onClick, onDelete }) => {
  return (
    <BasicNotification
      appIcon="monetization_on"
      appName={strings.header_finance}
      time={notification.create_date}
      contentTitle={format(
        strings.title_billing_issue,
        notification.other.account_id
      )}
      contentText={""}
      onClick={onClick}
      onDelete={onDelete}
    />
  );
};

const ActionBillingIssue = notification => {
  return `${PROTOCOL}//admin.${HOST_NAME}`;
};

/*
Bill created
*/

const NotificationBillCreated = ({ notification, onClick, onDelete }) => {
  return (
    <BasicNotification
      appIcon="monetization_on"
      appName={strings.header_finance}
      time={notification.create_date}
      contentTitle={format(
        strings.title_bill_created,
        notification.other.number
      )}
      contentText={format(
        strings.text_bill_created,
        notification.other.amount,
        moment(notification.other.due_date).format("L")
      )}
      onClick={onClick}
      onDelete={onDelete}
    />
  );
};

const ActionBillCreated = notification => {
  return `${PROTOCOL}//profile.${HOST_NAME}/#/finance`;
};

/*
Promo period end
*/

const NotificationPromoPeriodEnd = ({ notification, onClick, onDelete }) => {
  return (
    <BasicNotification
      appIcon="monetization_on"
      appName={strings.header_finance}
      time={notification.create_date}
      contentTitle={strings.title_promo_period_end}
      contentText={
        notification.other.plan_set_to_default
          ? strings.text_promo_period_end_default
          : strings.text_promo_period_end_charge
      }
      onClick={onClick}
      onDelete={onDelete}
    />
  );
};

const ActionPromoPeriodEnd = notification => {
  return `${PROTOCOL}//profile.${HOST_NAME}/#/`;
};

/*
Promo period end soon
*/

const NotificationPromoPeriodEndSoon = ({
  notification,
  onClick,
  onDelete
}) => {
  return (
    <BasicNotification
      appIcon="monetization_on"
      appName={strings.header_finance}
      time={notification.create_date}
      contentTitle={strings.title_promo_period_end_soon}
      contentText={format(
        strings.text_promo_period_end_soon,
        moment(notification.other.promo_period_deadline).fromNow()
      )}
      onClick={onClick}
      onDelete={onDelete}
    />
  );
};

/*
permit change room
*/

const NotificationPermitChangeRoom = ({ notification, onClick, onDelete }) => {
  return (
    <BasicNotification
      appIcon="content_paste"
      appName={strings.header_requests}
      time={notification.create_date}
      contentTitle={format(
        strings.title_permit_change_room,
        notification.other.number
      )}
      contentText={notification.other.room.name}
      onClick={onClick}
      onDelete={onDelete}
    />
  );
};

/* facility request accepted*/

const NotificationFacilityRequestAccepted = ({
  notification,
  onClick,
  onDelete
}) => {
  return (
    <BasicNotification
      appIcon="content_paste"
      appName={strings.header_fm_requests}
      time={notification.create_date}
      contentTitle={format(
        strings.title_facility_request_accepted,
        notification.other.number
      )}
      contentText={`${notification.other.room.name} - ${
        notification.other.problem[notification.other.problem.length - 1].name
      }`}
      onClick={onClick}
      onDelete={onDelete}
    />
  );
};

/* facility request created*/

const NotificationFacilityRequestCreated = ({
  notification,
  onClick,
  onDelete
}) => {
  return (
    <BasicNotification
      appIcon="content_paste"
      appName={strings.header_fm_requests}
      time={notification.create_date}
      contentTitle={format(
        strings.title_facility_request_created,
        notification.other.number
      )}
      contentText={`${notification.other.room.name} - ${
        notification.other.problem[notification.other.problem.length - 1].name
      }`}
      onClick={onClick}
      onDelete={onDelete}
    />
  );
};

/* facility request assigned*/

const NotificationFacilityRequestAssigned = ({
  notification,
  onClick,
  onDelete
}) => {
  return (
    <BasicNotification
      appIcon="content_paste"
      appName={strings.header_fm_requests}
      time={notification.create_date}
      contentTitle={format(
        strings.title_facility_request_assigned,
        notification.other.number
      )}
      contentText={`${notification.other.room.name} - ${
        notification.other.problem[notification.other.problem.length - 1].name
      }`}
      onClick={onClick}
      onDelete={onDelete}
    />
  );
};

/* facility request done*/

const NotificationFacilityRequestDone = ({
  notification,
  onClick,
  onDelete
}) => {
  return (
    <BasicNotification
      appIcon="content_paste"
      appName={strings.header_fm_requests}
      time={notification.create_date}
      contentTitle={format(
        strings.title_facility_request_done,
        notification.other.number
      )}
      contentText={`${notification.other.room.name} - ${
        notification.other.problem[notification.other.problem.length - 1].name
      }`}
      onClick={onClick}
      onDelete={onDelete}
    />
  );
};

/* facility request closed*/

const NotificationFacilityRequestClosed = ({
  notification,
  onClick,
  onDelete
}) => {
  return (
    <BasicNotification
      appIcon="content_paste"
      appName={strings.header_fm_requests}
      time={notification.create_date}
      contentTitle={format(
        strings.title_facility_request_closed,
        notification.other.number
      )}
      contentText={`${notification.other.room.name} - ${
        notification.other.problem[notification.other.problem.length - 1].name
      }`}
      onClick={onClick}
      onDelete={onDelete}
    />
  );
};

/* facility request rejected*/

const NotificationFacilityRequestRejected = ({
  notification,
  onClick,
  onDelete
}) => {
  return (
    <BasicNotification
      appIcon="content_paste"
      appName={strings.header_fm_requests}
      time={notification.create_date}
      contentTitle={format(
        strings.title_facility_request_rejected,
        notification.other.number
      )}
      contentText={`${notification.other.room.name} - ${
        notification.other.problem[notification.other.problem.length - 1].name
      }`}
      onClick={onClick}
      onDelete={onDelete}
    />
  );
};

/* facility request rejected*/

const NotificationFacilityRequestReopenedForCreator = ({
  notification,
  onClick,
  onDelete
}) => {
  return (
    <BasicNotification
      appIcon="content_paste"
      appName={strings.header_fm_requests}
      time={notification.create_date}
      contentTitle={format(
        strings.title_facility_request_reopened_for_creator,
        notification.other.number
      )}
      contentText={`${notification.other.room.name} - ${
        notification.other.problem[notification.other.problem.length - 1].name
      }`}
      onClick={onClick}
      onDelete={onDelete}
    />
  );
};

/* facility request rejected*/

const NotificationFacilityRequestReopenedForMaster = ({
  notification,
  onClick,
  onDelete
}) => {
  return (
    <BasicNotification
      appIcon="content_paste"
      appName={strings.header_fm_requests}
      time={notification.create_date}
      contentTitle={format(
        strings.title_facility_request_reopened_for_master,
        notification.other.number
      )}
      contentText={`${notification.other.room.name} - ${
        notification.other.problem[notification.other.problem.length - 1].name
      }`}
      onClick={onClick}
      onDelete={onDelete}
    />
  );
};

const NotificationFacilityRequestExpired = ({
  notification,
  onClick,
  onDelete
}) => {
  return (
    <BasicNotification
      appIcon="content_paste"
      appName={strings.header_fm_requests}
      time={notification.create_date}
      contentTitle={format(
        strings.title_facility_request_expired,
        notification.other.number
      )}
      contentText={`${notification.other.room.name} - ${
        notification.other.problem[notification.other.problem.length - 1].name
      }`}
      onClick={onClick}
      onDelete={onDelete}
    />
  );
};

const NotificationFacilityRequestExpirationDateSet = ({
  notification,
  onClick,
  onDelete
}) => {
  return (
    <BasicNotification
      appIcon="content_paste"
      appName={strings.header_fm_requests}
      time={notification.create_date}
      contentTitle={format(
        strings.title_facility_request_expiration_date_set,
        notification.other.number
      )}
      contentText={`${notification.other.room.name} - ${
        notification.other.problem[notification.other.problem.length - 1].name
      }`}
      onClick={onClick}
      onDelete={onDelete}
    />
  );
};

const NotificationFacilityCommentAddedForEmployee = ({
  notification,
  onClick,
  onDelete
}) => {
  return (
    <BasicNotification
      appIcon="content_paste"
      appName={strings.header_fm_requests}
      time={notification.create_date}
      contentTitle={format(
        strings.title_facility_comment_added_for_employee,
        notification.other.number
      )}
      contentText={`${notification.other.room.name} - ${
        notification.other.problem[notification.other.problem.length - 1].name
      }`}
      onClick={onClick}
      onDelete={onDelete}
    />
  );
};

const NotificationFacilityCommentAddedForCreator = ({
  notification,
  onClick,
  onDelete
}) => {
  return (
    <BasicNotification
      appIcon="content_paste"
      appName={strings.header_fm_requests}
      time={notification.create_date}
      contentTitle={format(
        strings.title_facility_comment_added_for_creator,
        notification.other.number
      )}
      contentText={`${notification.other.room.name} - ${
        notification.other.problem[notification.other.problem.length - 1].name
      }`}
      onClick={onClick}
      onDelete={onDelete}
    />
  );
};

const NotificationNewAdvertAdded = ({ notification, onClick, onDelete }) => {
  return (
    <BasicNotification
      appIcon="event_note"
      appName={strings.header_adverts}
      time={notification.create_date}
      contentTitle={strings.title_new_advert_added}
      contentText={`${notification.other.title}`}
      onClick={onClick}
      onDelete={onDelete}
    />
  );
};

const ActionPromoPeriodEndSoon = notification => {
  return `${PROTOCOL}//profile.${HOST_NAME}/#/`;
};

const notificationComponentMap = {
  request_created: NotificationRequestCreated,
  request_review: NotificationRequestReview,
  request_approved: NotificationRequestApproved,
  request_rejected: NotificationRequestRejected,
  request_approval: NotificationRequestApproval,
  need_register_request: NotificationNeedRegisterRequest,
  permit_created: NotificationPermitCreated,
  permit_not_created: NotificationPermitNotCreated,
  new_invite: NotificationNewInvite,
  accept_invite: NotificationAcceptInvite,
  reject_invite: NotificationRejectInvite,
  new_payment: NotificationNewPayment,
  billing_issue: NotificationBillingIssue,
  payment_soon: NotificationPaymentSoon,
  bill_created: NotificationBillCreated,
  promo_period_end: NotificationPromoPeriodEnd,
  promo_period_end_soon: NotificationPromoPeriodEndSoon,
  change_roles: NotificationChangeRoles,
  accompany_started: NotificationAccompanyStarted,
  accompany_finished: NotificationAccompanyFinished,
  visitor_is_waiting: NotificationVisitorIsWaiting,
  permit_active: NotificationPermitActive,
  permit_temporarily_blocked: NotificationPermitTemporarilyBlocked,
  permit_change_room: NotificationPermitChangeRoom,
  facility_request_accepted: NotificationFacilityRequestAccepted,
  facility_request_created: NotificationFacilityRequestCreated,
  facility_request_assigned: NotificationFacilityRequestAssigned,
  facility_request_done: NotificationFacilityRequestDone,
  facility_request_closed: NotificationFacilityRequestClosed,
  facility_request_rejected: NotificationFacilityRequestRejected,
  facility_request_reopened_for_creator: NotificationFacilityRequestReopenedForCreator,
  facility_request_reopened_for_master: NotificationFacilityRequestReopenedForMaster,
  facility_request_expired: NotificationFacilityRequestExpired,
  facility_request_expiration_date_set: NotificationFacilityRequestExpirationDateSet,
  facility_comment_added_for_employee: NotificationFacilityCommentAddedForEmployee,
  facility_comment_added_for_creator: NotificationFacilityCommentAddedForCreator,
  new_advert_added: NotificationNewAdvertAdded
};

const actionsMap = {
  // request_created: ActionRequestCreated,
  // request_review: ActionRequestReview,
  // request_approved: ActionRequestApproved,
  // request_rejected: ActionRequestRejected,
  // request_approval: ActionRequestApproval,
  // need_register_request: ActionNeedRegisterRequest,
  // permit_created: ActionPermitCreated,
  // permit_not_created: ActionPermitNotCreated,
  // new_invite: ActionNewInvite,
  // accept_invite: ActionAcceptInvite,
  // reject_invite: ActionRejectInvite,
  // new_payment: ActionNewPayment,
  // billing_issue: ActionBillingIssue,
  // payment_soon: ActionPaymentSoon,
  // bill_created: ActionBillCreated,
  // promo_period_end: ActionPromoPeriodEnd,
  // promo_period_end_soon: ActionPromoPeriodEndSoon,
  // change_roles: ActionChangeRoles,
  // accompany_started: ActionAccompanyStarted,
  // accompany_finished: ActionAccompanyFinished,
  // visitor_is_waiting: ActionVisitorIsWaiting,
};

export const Notification = ({ notification, onClick, onDelete }) => {
  let message_id = notification.message_id;
  let MappedComponent = notificationComponentMap[message_id];
  if (MappedComponent) {
    return (
      <MappedComponent
        notification={notification}
        onClick={onClick}
        onDelete={onDelete}
      />
    );
  } else {
    return (
      <NotificationUnknown
        notification={notification}
        onClick={onClick}
        onDelete={onDelete}
      />
    );
  }
};

export const notificationAction = notification => {
  let message_id = notification.message_id;
  let mappedAction = actionsMap[message_id];
  if (mappedAction) {
    return mappedAction(notification);
  } else if (notification.other.click_action) {
    return ActionDefault(notification);
  } else {
    return ActionUnknown(notification);
  }
};
