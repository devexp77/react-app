import React from 'react'
import Moment from 'react-moment'

import './style.css'
import strings from '../../localization/notification'
import Icon from "../Icon";

/*
  Properties:
    appIcon
    appName
    time
    contentTitle
    contentText
    onDelete - delete handler
    onClick - click handler
*/
class BasicNotification extends React.Component {
  render() {
    return (
      <div className="notification">
        <DeleteButton onClick={this.props.onDelete} />
        <NotificationHeader>
          <AppIcon name={this.props.appIcon} />
          <AppName name={this.props.appName} />
          <HeaderDelimiter />
          <Timestamp time={this.props.time} />
        </NotificationHeader>
        <NotificationContent onClick={this.props.onClick}>
          <ContentTitle title={this.props.contentTitle} />
          <ContentText text={this.props.contentText} />
        </NotificationContent>
      </div>
    )
  }
}

const NotificationHeader = (props) => {
  return (
    <div className="notification-header">
      {props.children}
    </div>
  )
}

const NotificationContent = ({children, onClick}) => {
  return (
    <div className="notification-content" onClick={onClick}>
      {children}
    </div>
  )
}

const DeleteButton = ({onClick}) => {
  if (onClick) {
    return (
      <div className="notification-delete-button" onClick={onClick}>
        <Icon name="sv-icon-close"/>
      </div>
    )
  } else {
    return null
  }
}

const AppIcon = ({name}) => {
  return (
    <span className="notification-app-icon">
      <i className="material-icons">{name}</i>
    </span>
  )
}

const AppName = ({name}) => {
  return (
    <span className="notification-app-name">
      {name}
    </span>
  )
}

const Timestamp = ({time}) => {
  return (
    <span className="notification-time">
      <Moment fromNow locale={strings.getLanguage()}>{time}</Moment>
    </span>
  )
}

const ContentTitle = ({title}) => {
  if (title) {
    return (
      <div className="notification-content-title">
        {title}
      </div>
    )
  } else {
    return null
  }
}

const ContentText = ({text}) => {
  if (text) {
    return (
      <div className="notification-content-text">
        {text}
      </div>
    )
  } else {
    return null
  }
}

const HeaderDelimiter = () => {
  return (
    <span className="notification-header-delimiter">
      {' ' + strings.header_delimiter + ' '}
    </span>
  )
}

export default BasicNotification
