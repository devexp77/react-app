import React from "react";
import "./style.css";

import strings from "../../localization/all";
import common_strings from "../../../common/localization/all";
import { DOCUMENTS } from "../../constants/documents";

/*
props
header
deleteFunction
*/

class DocumentChoosePopUp extends React.Component {
  formatCustomDocumentLabel(doc) {
    if (doc.doc_name) {
      return doc.doc_name;
    } else {
      return (
        common_strings[`doc_type_custom_document`].split(" ")[0] +
        " **" +
        doc.number.substr(-4)
      );
    }
  }

  render() {
    return (
      <div
        className="modal fade"
        id="documentPopUp"
        tabIndex="-1"
        role="dialog"
        aria-labelledby="exampleModalLabel"
        aria-hidden="true"
      >
        <div className="modal-dialog modal-sm without-padding" role="document">
          <div className="modal-content">
            <div className="modal-body">
              {Object.keys(DOCUMENTS).map(
                (prop, index) =>
                  prop !== "custom_document" && (
                    <a
                      key={index}
                      className="dropdown-item waves-effect"
                      onClick={() => this.props.onClick(prop)}
                    >
                      {common_strings[`doc_type_${prop}`]}
                    </a>
                  )
              )}

              {this.props.userDocs &&
                this.props.userDocs.map(
                  (doc, index) =>
                    doc.doc_type === "custom_document" && (
                      <a
                        key={index}
                        className="dropdown-item waves-effect"
                        onClick={() =>
                          this.props.onClick("custom_document", doc.doc_id)
                        }
                      >
                        {this.formatCustomDocumentLabel(doc)}
                      </a>
                    )
                )}

              <a
                className="dropdown-item waves-effect"
                onClick={() => this.props.onClick("custom_document")}
              >
                {common_strings[`button_new_custom_document`]}
              </a>
            </div>
            <div className="modal-footer">
              <button
                type="button"
                className="btn btn-flat"
                data-dismiss="modal"
              >
                {strings.button_cancel}
              </button>
            </div>
          </div>
        </div>
      </div>
    );
  }
}

export default DocumentChoosePopUp;
