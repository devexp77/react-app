import React from "react";
import "./style.css";
import { toCustomPath } from "../../actions/router";
import { connect } from "react-redux";
import { fetchCurrentObjectImage } from "../../actions/image";

class NavPanel extends React.Component {
  componentDidMount() {
    this.tooltipInit();
    if (this.props.app === "manage") {
      this.getObjectImage();
    }
  }

  tooltipInit() {
    if (this.isTouchDevice() === false) {
      $('[data-toggle="tooltip"]').tooltip();
      $('[data-toggle="tooltip"]').click(function() {
        $('[data-toggle="tooltip"]').tooltip("hide");
      });
    }
  }

  isTouchDevice() {
    return (
      true ==
      ("ontouchstart" in window ||
        (window.DocumentTouch && document instanceof DocumentTouch))
    );
  }

  toHistoryPath() {
    const { dispatch } = this.props;
    const fromHistory = this.props.router.history.pop();
    const historyPath = fromHistory
      ? fromHistory
      : this.props.router.customHistoryPath;
    dispatch(toCustomPath(historyPath));
  }

  toEntityMainPage() {
    const { dispatch } = this.props;
    dispatch(toCustomPath(`/${this.props.entityMainPageHref}`));
  }

  getObjectImage() {
    const { dispatch } = this.props;
    if (
      !this.props.image.currentObjectImage.result ||
      !this.props.image.currentObjectImage.result[this.props.params.object_id]
    ) {
      const data = {
        entity_type: "objects",
        entity_ids: [this.props.params.object_id]
      };

      const _this = this;
      dispatch(fetchCurrentObjectImage(data)).then(function(res) {
        _this.tooltipInit();
      });
    }
  }

  getImagePath() {
    let imgSrc = "";
    if (
      this.props.image.currentObjectImage.result &&
      this.props.image.currentObjectImage.result[this.props.params.object_id]
    ) {
      imgSrc =
        this.props.image.currentObjectImage.result[
          this.props.params.object_id
        ] +
        "?" +
        this.props.image.imgObjectSuffix;
    }

    return imgSrc;
  }

  render() {
    return (
      <nav
        className={`navbar navbar-nav-panel fixed-top navbar-dark navbar-expand
              ${this.props.marginClass ? this.props.marginClass : ""}`}
      >
        <div
          className={this.props.containerClass}
          style={this.props.width ? { maxWidth: this.props.width } : null}
        >
          {this.props.prevButton && (
            <i
              className="material-icons back"
              onClick={this.toHistoryPath.bind(this)}
            >
              arrow_back
            </i>
          )}

          {this.props.navigationTitle && (
            <p className={`navbar-brand float-left`}>
              {this.props.navigationTitle}
            </p>
          )}

          {this.props.app && this.props.app === "manage" ? (
            this.getImagePath() ? (
              <img
                src={this.getImagePath()}
                onClick={this.toEntityMainPage.bind(this)}
                data-toggle="tooltip"
                data-placement="bottom"
                title={
                  this.props.object.result && this.props.object.result.name
                }
              />
            ) : (
              <div
                key={`icon`}
                className={`object-icon`}
                onClick={this.toEntityMainPage.bind(this)}
                data-toggle="tooltip"
                data-placement="bottom"
                title={
                  this.props.object.result && this.props.object.result.name
                }
              >
                <i className="material-icons">business</i>
              </div>
            )
          ) : (
            <div className={`img-cap`} />
          )}
        </div>
      </nav>
    );
  }
}

const mapStateToProps = state => {
  return {
    router: state.router,
    image: state.image
  };
};

export default connect(mapStateToProps)(NavPanel);
