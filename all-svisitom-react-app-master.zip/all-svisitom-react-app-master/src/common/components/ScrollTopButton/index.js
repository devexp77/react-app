import React from "react";
import ScrollTop from "react-scrolltop-button";
import Icon from "../Icon";
import "./style.css";

class ScrollTopButton extends React.Component {
  render() {
    return (
      <ScrollTop
        text={``}
        className={`svisitom-scroll-to-button ${
          this.props.marginBottom ? "margin-bottom" : ""
        }`}
      />
    );
  }
}

export default ScrollTopButton;
