import React, { Component } from "react";
import update from "immutability-helper";

import "react-date-range/dist/styles.css"; // main style file
import "react-date-range/dist/theme/default.css"; // theme css file
import { DateRangePicker } from "react-date-range";
import "./dateRangePicker.css";

import strings from "../../localization/all";

import {defaultStaticRanges} from './defaultRanges'

import isTouchDevice from "../../../common/util/isTouchDevice";

class DateRangePickerComponent extends Component {
  constructor() {
    super();
    this.state = {
      locale: null
    };
  }

  componentWillMount() {
    this.createLocale();
  }

  createLocale() {
    const lang =
      strings.getLanguage() === "en" ? "en-US" : strings.getLanguage();

    const defaultLocale = require(`react-date-range/dist/locale/${lang}`).default;
    const customLocalize = require(`./locale/${lang}`);

    const newLocale = update(defaultLocale, {
      localize: { $set: customLocalize }
    });

    this.setState({
      locale: newLocale
    });
  }

  handleSelect(ranges) {
    this.props.onChange(
      ranges.selection.startDate,
      ranges.selection.endDate
    );
  }

  render() {
    const selectionRange = {
      startDate: this.props.startDate,
      endDate: this.props.endDate,
      key: "selection",
      color: "#207ea9"
    };
    console.log(defaultStaticRanges)

    return (
      <DateRangePicker
        ranges={[selectionRange]}

        onChange={this.handleSelect.bind(this)}
        inputRanges={[]}
        staticRanges={defaultStaticRanges}
        showPreview={!isTouchDevice()}
        months={screen.width > 1200 ? 2 : 1}
        direction={`horizontal`}
        locale={this.state.locale}
        className={`adaptive`}
      />
    );
  }
}

export default DateRangePickerComponent;
