import React, { useState } from "react";
import random_uuid from "../../util/random_uuid";
import "./style.css";
import Icon from "../Icon";

export const AccordionWrapper = ({
  classes,
  id = random_uuid(),
  children,
  marginBottom
}) => (
  <div
    className={`accordion md-accordion sv-accordion ${
      marginBottom ? "margin-bottom" : ""
    }`}
    id={id}
    role="tablist"
    aria-multiselectable="true"
  >
    {children}
  </div>
);

export const AccordionCard = ({
  classes,
  id = random_uuid(),
  header,
  parent_id = "",
  noPadding,
  children,
  renderWhenOpened = false,
  divHeightWhileRendering = 100
}) => {
  const [renderContent, setRenderContent] = useState(false);
  return (
    <div className="card">
      <div
        role="tab"
        id={id}
        className="card-header collapsed"
        data-toggle="collapse"
        data-target={"#collapse" + id}
        aria-expanded="false"
        aria-controls={"collapse" + id}
        data-parent={"#" + parent_id}
        onClick={() => (renderWhenOpened ? setRenderContent(true) : null)}
      >
        <h5 className="header">
          {header}
          <Icon name={`keyboard_arrow_down`} className={`rotate-icon`} />
        </h5>
      </div>

      <div
        id={"collapse" + id}
        className="collapse"
        role="tabpanel"
        aria-labelledby={id}
        data-parent={"#" + parent_id}
      >
        <div className={`card-body ${noPadding ? "no-padding" : ""}`}>
          {renderWhenOpened ? (
            renderContent ? (
              children
            ) : (
              <div style={{ height: `${divHeightWhileRendering}px` }} />
            )
          ) : (
            children
          )}
        </div>
      </div>
    </div>
  );
};
