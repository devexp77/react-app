import React from "react";

/*
  props:
    id
    value
    onChange
*/
class Select extends React.Component {
  constructor() {
    super();
    this.state = {
      value: ""
    };
  }

  componentDidMount() {
    if (!this.props.id) {
      throw "id property should be set for Select component";
    }

    this.initData(this.props);
    var _this = this;
    $(document).ready(function() {
      $(`#${_this.props.id}`).on("change", _this.handleInputChange.bind(_this));
    });
  }

  componentWillUnmount() {
    let _this = this;
    $(document).ready(function() {
      $(`#${_this.props.id}`).off();
    });
  }

  handleInputChange(event) {
    let id = event.target.id;
    const value = event.target.value.replace(/\s+/g, " ");

    this.setState({
      value: value
    });

    if (this.props.onChange) {
      this.props.onChange(value);
    }
  }

  initData(props) {
    this.setState(
      {
        value: props.value
      },
      function() {
        $(`#${this.props.id}`).material_select("destroy");
        $(`#${this.props.id}`).material_select();
      }
    );
  }

  shouldComponentUpdate(nextProps, nextState) {
    if (this.state.value !== nextProps.value) {
      this.initData(nextProps);
      return true;
    } else {
      return false;
    }
  }

  render() {
    return (
      <select
        id={this.props.id}
        value={this.state.value}
        onChange={this.handleInputChange.bind(this)}
        className={this.props.className || ""}
      >
        {this.props.children}
      </select>
    );
  }
}

export default Select;
