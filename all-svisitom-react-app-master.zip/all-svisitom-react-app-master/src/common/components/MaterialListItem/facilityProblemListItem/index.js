import React from 'react'
import MaterialListItem from "../twoLineItem";

const FacilityProblemListItem = ({problem, gotoItem}) => (
  <MaterialListItem
    item_id={problem.facility_id}
    firstLineContent={problem.name}
    icon={problem.icon_name ? problem.icon_name : 'sv-icon-fm-other'}
    gotoItem={gotoItem}
  />
);

export default FacilityProblemListItem;