import React, { Component } from "react";

import "./style.css";


class EmptyExpandItem extends Component {
  render() {
    return (
      <div className={`material-list-item-empty-expand clearfix ${this.props.className}`}>
        {this.props.children}
      </div>
    );
  }
}

export default EmptyExpandItem;
