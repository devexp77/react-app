import React, { Component } from "react";

import "../twoLineItem/style.css";
import "./style.css";

/*
  Properties:
    item_id
    icon
    className
    firstLineContent
    secondLineContent
    gotoItem(item_id)
*/
class KioskListItem extends Component {
  gotoItem = event => {
    if (this.props.gotoItem && event.target.tagName !== "LABEL") {
      this.props.gotoItem(this.props.item_id);
    } else {
      return null;
    }
  };

  render() {
    let showCursor = false;
    if ("gotoItem" in this.props) {
      showCursor = true;
    }

    let iconClassName = "";
    if (this.props.iconClassName) {
      iconClassName = this.props.iconClassName;
    }

    return (
      <div
        className={
          "shadow material-list-item kiosk-list-item" +
          (showCursor ? " material-list-item-clickable " : "") +
          (this.props.className ? " " + this.props.className : "") +
          (this.props.needSecondLine ? " with-second-line" : "")
        }
        style={
          this.props.checked
            ? { backgroundColor: "#e0e0e0" }
            : {}
        }
        data-id={this.props.item_id}
        onClick={this.gotoItem}
      >
        <div className={`kiosk-list-item-short-name`}>
          {this.props.shortName || ""}
        </div>


        <div className={`kiosk-list-item-content`}>
          <div className="kiosk-list-item-first-line">
            {this.props.firstLineContent}
          </div>
          {this.props.needSecondLine ? (
            <div className="kiosk-list-item-second-line">
              {this.props.secondLineContent || ""}
            </div>
          ) : null}
        </div>

        <div className={`material-list-item-icon`}>
          <div className="form-group">
            <input
              type="checkbox"
              id={this.props.item_id}
              checked={this.props.checked || false}
              onChange={this.props.checkboxOnChange || null}
            />
            <label htmlFor={this.props.item_id} />
          </div>
        </div>
      </div>
    );
  }
}

export default KioskListItem;
