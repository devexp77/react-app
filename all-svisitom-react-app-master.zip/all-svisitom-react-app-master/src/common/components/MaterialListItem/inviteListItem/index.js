import React from 'react'
import {industryRoleName} from '../../../util/objectTypes'
import format from 'string-format'
import Moment from 'react-moment'

import {UserAvatar} from '../../Avatar'

import strings from '../../../localization/all'

import '../twoLineItem/style.css'
import './style.css'

const InviteListItem = ({object_type, invite, incoming, onClick, user_image_urls={}}) => {
  moment.locale(strings.getLanguage());
  let rolesAt='';
  if (invite.roles) {
    let rolesList='';
    for (let index in invite.roles) {
      let role = invite.roles[index];
      rolesList += industryRoleName(object_type, role);
      if (index < invite.roles.length-1) {
        rolesList += ', ';
      }

      if (invite.entity_type == 'addressee') {
        rolesAt = format(strings.invite_list_roles_at, invite.entity_name, rolesList);
      } else {
        rolesAt = rolesList;
      }
    }
  }

  let person = invite.to_identifier;
  let userImageUrl = null;
  if (incoming) {
    person = invite.from_user_name + ' ' + invite.from_user_surname;
    userImageUrl = user_image_urls[invite.from_user_id]
  } else {
    if (invite.to_user_id) {
      userImageUrl = user_image_urls[invite.to_user_id];
    }
  }

  let object_label = invite.object_name;

  if (invite.invite_type === "visit"){
    object_label += " - " + invite.entity_name + " - " + strings.label_visit;
  }

  return (
    <div className={'material-list-item material-list-item-clickable'} onClick={onClick}>
      <div className={`material-list-item-icon`}>
        <div className="invite-list-item-icon-container">
          <UserAvatar
            imageUrl={userImageUrl}
            size={40}
          />
          <div className={`invite-status-indicator invite-list-item-icon-${invite.status}`} />
        </div>
      </div>
      <div className="material-list-item-first-line">
        {person}
        <span className="invite-list-date">
          {person ? ' '+strings.bullet_delimiter+' ' : ''}
          <Moment fromNow locale={strings.getLanguage()}>{invite.create_date}</Moment>
        </span>
      </div>
      <div className="material-list-item-second-line">
        <div>{object_label}</div>
        <div>{rolesAt}</div>
      </div>
    </div>
  )
};

export default InviteListItem;
