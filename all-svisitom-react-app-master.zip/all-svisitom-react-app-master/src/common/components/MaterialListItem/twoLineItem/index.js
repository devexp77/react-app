import React, { Component } from "react";
import Icon from "../../Icon";

import "./style.css";
import {FlatButton, RaisedButton} from "../../Button";

/*
  Properties:
    item_id
    icon
    className
    firstLineContent
    secondLineContent
    gotoItem(item_id)
*/
class MaterialListItem extends Component {
  gotoItem = event => {
    if (this.props.gotoItem && event.target.tagName !== "LABEL") {
      this.props.gotoItem(this.props.item_id);
    } else {
      return null;
    }
  };

  render() {
    let showCursor = false;
    if ("gotoItem" in this.props) {
      showCursor = true;
    }

    let iconClassName = "";
    if (this.props.iconClassName) {
      iconClassName = this.props.iconClassName;
    }

    return (
      <div
        className={
          "material-list-item" +
          (showCursor ? " material-list-item-clickable clearfix" : "") +
          (this.props.className ? " " + this.props.className : "")
        }
        style={
          this.props.checkbox && this.props.checked
            ? { backgroundColor: "#eee" }
            : {}
        }
        data-id={this.props.item_id}
        onClick={this.gotoItem}
      >
        {this.props.icon && (
          <React.Fragment>
            {!this.props.imgPath && (
              <div className={`material-list-item-icon ${iconClassName}`}>
                <Icon name={this.props.icon} style={this.props.iconStyle || {}}/>
              </div>
            )}
            {this.props.imgPath && (
              <div className={`material-list-item-icon ${iconClassName}`}>
                <img src={this.props.imgPath} />
              </div>
            )}
          </React.Fragment>
        )}
        {this.props.checkbox && (
          <div className={`material-list-item-icon ${iconClassName}`}>
            <div className="form-group">
              <input
                type="checkbox"
                id={this.props.item_id}
                checked={this.props.checked || false}
                onChange={this.props.checkboxOnChange || null}
              />
              <label htmlFor={this.props.item_id} />
            </div>
          </div>
        )}

        <div className="material-list-item-first-line">
          {this.props.firstLineContent}
        </div>
        {this.props.secondLineContent ? (
          <div className="material-list-item-second-line">
            {this.props.secondLineContent}
          </div>
        ) : null}
        {this.props.lineButtonClick ? (
          <FlatButton style={this.props.buttonStyle || {}} className={`float-right ${this.props.buttonClassName || ""}`} onClick={(e) => {e.stopPropagation(); this.props.lineButtonClick();}}>
            {this.props.buttonText || ""}
            {this.props.buttonIcon && <Icon name={this.props.buttonIcon}/>}
          </FlatButton>
        ) : null}
      </div>
    );
  }
}

export default MaterialListItem;
