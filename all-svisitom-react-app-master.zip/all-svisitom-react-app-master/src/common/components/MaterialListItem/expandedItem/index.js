import React, { Component } from "react";

import "./style.css";

/*
  Properties:
    item_id
    icon
    className
    firstLineContent
    secondLineContent
    gotoItem(item_id)
*/
class ExpandedItem extends Component {
  render() {


    return <div className={`material-list-item-expand clearfix ${this.props.expand} ${this.props.size ? this.props.size : ''}`}>{this.props.children}</div>;
  }
}

export default ExpandedItem;
