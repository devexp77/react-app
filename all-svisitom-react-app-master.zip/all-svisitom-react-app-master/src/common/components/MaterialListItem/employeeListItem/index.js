import React from "react";
import MaterialListItem from "../twoLineItem";
import { industryRoleName } from "../../../util/objectTypes";
import Icon from "../../Icon";
import Moment from "react-moment";
import strings from "../../../localization/notification";
import withStyles from "react-jss";

const doNotDisturbStyles = {
  do_not_disturb: {
    "& i": {
      float: "left",
      lineHeight: "20px",
      fontSize: 17
    }
  }
};

const EmployeeListItem = withStyles(doNotDisturbStyles)(
  ({
    classes,
    object_type,
    employee,
    onClick = null,
    user_image_urls = {},
    checkbox = false,
    checked = false,
    checkboxOnChange = null
  }) => {
    let goToItem = {};
    if (onClick) {
      goToItem = { gotoItem: onClick };
    }
    return (
      <MaterialListItem
        checkbox={checkbox}
        checked={checked}
        checkboxOnChange={checkboxOnChange}
        item_id={employee.user_id}
        firstLineContent={`${employee.surname ? employee.surname : ""} ${
          employee.name ? employee.name : ""
        } ${employee.patronymic ? employee.patronymic : ""}`}
        secondLineContent={
          <React.Fragment>
            {employee.job_title && <div>{employee.job_title}</div>}

            {employee.roles
              ? employee.roles.map((role, ind) => (
                  <span key={ind}>{industryRoleName(object_type, role)} </span>
                ))
              : null}
            {employee.do_not_disturb && (
              <div className={classes.do_not_disturb}>
                <Icon
                  name={`sv-icon-notifications-paused`}
                />
                <Moment fromNow locale={strings.getLanguage()}>
                  {employee.do_not_disturb_set_date}
                </Moment>
              </div>
            )}
          </React.Fragment>
        }
        icon={`account_circle`}
        imgPath={user_image_urls[employee.user_id]}
        iconClassName="user-icon"
        {...goToItem}
      />
    );
  }
);

export default EmployeeListItem;
