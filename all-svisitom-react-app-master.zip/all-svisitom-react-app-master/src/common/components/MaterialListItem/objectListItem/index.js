import React from 'react'

import {CDN_URL} from '../../../constants'

import AddressWithMap from '../../AddressWithMap'

import '../twoLineItem/style.css'
import './style.css'

 const ObjectMaterialListItem = ({object, imageUrl, onClick, children, actionChildren}) => {
  return (
    <div className={'material-list-item ' + (onClick ? 'material-list-item-clickable': '')} onClick={onClick}>
      {
        imageUrl
        ?
          <img className="mil-object-image" src={imageUrl} />
        :
          <div className="mil-object-image">
            <i className="material-icons">business</i>
          </div>
      }

      <div className="mil-object-item">
        <div className="mil-object-name">{object.name}</div>
        <div className="mil-object-address">
          <AddressWithMap
            address={object.city + ', '+object.address}
            geo_point={object.geo_point}
          />
        </div>
        <div className="mil-object-description">{object.description}</div>
        {
          children &&
          <div className="mil-object-children">
            {children}
          </div>
        }

      </div>
      {
        actionChildren &&
        <div className="mil-object-actions">
          {actionChildren}
        </div>
      }
    </div>
  )
}

export default ObjectMaterialListItem
