import React from 'react';

import Icon from '../../Icon';
import './style_add.css'

/*
Props:
  onClick,
  text,
  className,
  data-test-id
 */
const ObjectAddItem = (props) => (
  <div className={`mil-object-add-item ${props.className ? props.className : ""}`} onClick={props.onClick} data-test-id={props['data-test-id']}>
    <div className="mil-object-add-item-container">
      <div className="mil-object-add-plus">
        <Icon name="sv-icon-add" />
      </div>
      <div className="text">
        {props.text}
      </div>
    </div>
  </div>
);

export default ObjectAddItem;
