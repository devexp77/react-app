import React from 'react';

import strings from '../../../manage/localization/all'
import './style.css'

class ButtonShowMore extends React.Component {

	render() {
		return (
            <button className="btn btn-flat to-show-more" onClick={this.props.onClick}>{strings.button_show_all}</button>
			);
	}
}

export default ButtonShowMore;
