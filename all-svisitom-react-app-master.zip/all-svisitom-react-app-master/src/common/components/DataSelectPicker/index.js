import React from "react";

import "./style.css";

import { MONTH } from "../../constants/month";
import { DAYS } from "../../constants/days";

import strings from "../../localization/all";

class DataSelectPicker extends React.Component {
  constructor() {
    super();
    this.state = {
      years: [],
      issue_day: "",
      issue_month: "",
      issue_year: "",
      value: "",
      unique_id: ""
    };
  }

  componentDidMount() {
    let years = [];
    let currentYear = new Date().getFullYear();
    for (let i = 0; i < 100; i++) {
      years[i] = currentYear;
      currentYear--;
    }
    this.setState({
      years: years
    });

    let _this = this;
    this.setState(
      {
        unique_id: this.props.id.split(".").join("_")
      },
      function() {
        _this.initDate(this.props);
        $(document).ready(function() {
          $(`.issue_day_${_this.state.unique_id}`).on(
            "change",
            _this.handleInputChange.bind(_this)
          );
          $(`.issue_month_${_this.state.unique_id}`).on(
            "change",
            _this.handleInputChange.bind(_this)
          );
          $(`.issue_year_${_this.state.unique_id}`).on(
            "change",
            _this.handleInputChange.bind(_this)
          );
        });
      }
    );
  }

  componentWillUnmount() {
    let _this = this;
    $(document).ready(function() {
      $("#issue_day_" + _this.props.id).off();
      $("#issue_month_" + _this.props.id).off();
      $("#issue_year_" + _this.props.id).off();
    });
  }

  getValidIssueDate() {
    let issueDateValid = true;

    let date = this.getIssueDate();
    if (date){
      issueDateValid =
        date.getFullYear() == this.state.issue_year &&
        date.getDate() == this.state.issue_day &&
        date.getMonth() == this.state.issue_month - 1;

      return issueDateValid ? date.toISOString() : "invalidDate";
    }
    else{
      return ""
    }

  }

  handleInputChange(event) {
    let id = event.target.id;
    const value = event.target.value.replace(/\s+/g, " ");

    this.setState(
      {
        [id]: value
      },
      function() {
        this.setState(
          {
            value: this.getValidIssueDate()
          },
          function() {
            let newEvent = {
              target: {
                value: this.getValidIssueDate(),
                id: this.props.id
              }
            };
            this.props.handleInputChange(newEvent);
          }
        );
      }
    );
  }

  getIssueDate() {
    if (
      !(
        this.state.issue_year === "" &&
        this.state.issue_month === "" &&
        this.state.issue_day === ""
      )
    ) {
      return new Date(
        this.state.issue_year,
        this.state.issue_month - 1,
        this.state.issue_day,
        "12",
        "00"
      );
    } else {
      return "";
    }
  }

  initDate(props) {
    if (props.value) {
      const date = new Date(props.value);

      this.setState(
        {
          issue_day: date.getDate().toString(),
          issue_month: (date.getMonth() + 1).toString(),
          issue_year: date.getFullYear().toString(),
          value: props.value
        },
        function() {
          $(`.document-select_${this.state.unique_id}`).material_select(
            "destroy"
          );
          $(`.document-select_${this.state.unique_id}`).material_select();
        }
      );
    } else {
      this.setState(
        {
          issue_day: "",
          issue_month: "",
          issue_year: "",
          value: ""
        },
        function() {
          $(`.document-select_${this.state.unique_id}`).material_select(
            "destroy"
          );
          $(`.document-select_${this.state.unique_id}`).material_select();
        }
      );
    }
  }
  shouldComponentUpdate(nextProps, nextState) {
    if (
      this.state.value !== nextProps.value ||
      this.props.error !== nextProps.error ||
      this.state.years !== nextState.years ||
      this.state.unique_id !== nextState.unique_id
    ) {
      if (this.state.value !== nextProps.value) {
        this.initDate(nextProps);
      }
      return true;
    } else {
      return false;
    }
  }

  render() {
    return (
      <div
        className={`row issue-date ${
          this.props.errorClass ? this.props.errorClass(this.props.error) : ""
        }`}
      >
        <label className="issue-date">{this.props.label}</label>
        <div className="select-container col-4 float-left select-day">
          <select
            className={`document-select_${this.state.unique_id} issue_day_${
              this.state.unique_id
            }`}
            id={`issue_day`}
            value={this.state.issue_day}
            onChange={this.handleInputChange.bind(this)}
          >
            <option value="">{strings.label_day}</option>
            {DAYS.map((day, index) => (
              <option key={index} value={day}>
                {day}
              </option>
            ))}
          </select>
        </div>

        <div className="select-container col-4 float-left select-month">
          <select
            className={`document-select_${this.state.unique_id} issue_month_${
              this.state.unique_id
            }`}
            id={`issue_month`}
            value={this.state.issue_month}
            onChange={this.handleInputChange.bind(this)}
          >
            <option value="">{strings.label_month}</option>
            {MONTH.map((month, index) => (
              <option key={index} value={month.value}>
                {month.month}
              </option>
            ))}
          </select>
        </div>

        <div className="select-container col-4 float-left select-year">
          <select
            className={`document-select_${this.state.unique_id} issue_year_${
              this.state.unique_id
            }`}
            id={`issue_year`}
            value={this.state.issue_year}
            onChange={this.handleInputChange.bind(this)}
          >
            <option value="">{strings.label_year}</option>
            {this.state.years.map((year, index) => (
              <option key={index} value={year}>
                {year}
              </option>
            ))}
          </select>
        </div>
        {this.props.error ? (
          <div className="hint">
            {this.props.error === "init" ? "" : this.props.error}
          </div>
        ) : null}
      </div>
    );
  }
}

export default DataSelectPicker;
