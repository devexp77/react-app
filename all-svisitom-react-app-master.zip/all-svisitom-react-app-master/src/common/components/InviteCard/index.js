import React, { Component } from "react";

import ProfileInfo from "../ProfileInfo";
import { UserAvatar, ObjectAvatar } from "../../components/Avatar";

import strings from "../../localization/all";
import "./style.css";

/*
props:
  invite
  fromUserImageUrl
  toUserImageUrl
  objectImageUrl
*/

class InviteCard extends React.Component {
  render() {
    var { invite } = this.props;
    var status_name = strings["invite_status_" + invite.status]
      ? strings["invite_status_" + invite.status]
      : invite.status;
    var status_class = "invite-status-" + invite.status;

    return (
      <div>
        <ProfileInfo.Table title={invite.invite_type.indexOf('request_') >= 0 ? strings.invite_header_request : strings.invite_header}>
          <ProfileInfo.Row
            trClassName={`non-cursor`}
            mIconClass={`d-none`}
            title={strings.label_sent_date}
            data={moment(invite.create_date).format("L LT")}
          />

          <ProfileInfo.Row
            trClassName={`non-cursor`}
            mIconClass={`d-none`}
            title={strings.label_from_whom}
            data={
              <div className="clearfix">
                <UserAvatar
                  imageUrl={this.props.fromUserImageUrl}
                  size={40}
                  className="invite-card-user-avatar"
                />
                <div className="invite-card-avatar-text">
                  {invite.from_user_name + " " + invite.from_user_surname}
                </div>
              </div>
            }
          />

          {
            invite.to_identifier &&
            <ProfileInfo.Row
              trClassName={`non-cursor`}
              mIconClass={`d-none`}
              title={strings.label_to_whom}
              data={
                <div className="clearfix">
                  <UserAvatar
                    imageUrl={this.props.toUserImageUrl}
                    size={40}
                    className="invite-card-user-avatar"
                  />
                  <div className="invite-card-avatar-text">
                    {invite.to_identifier}
                  </div>
                  {(invite.to_user_name || invite.to_user_surname) && (
                    <div className="invite-card-avatar-text">
                      {invite.to_user_name + " " + invite.to_user_surname}
                    </div>
                  )}
                </div>
              }
            />
          }
        </ProfileInfo.Table>

        <ProfileInfo.Table
          title={
            strings['invite_header_' + invite.invite_type]
              ? strings['invite_header_' + invite.invite_type]
              : strings.label_invite_details
          }
        >
          <ProfileInfo.Row
            trClassName={`non-cursor`}
            mIconClass={`d-none`}
            title={strings.label_where}
            data={
              <div className="clearfix">
                <ObjectAvatar
                  imageUrl={this.props.objectImageUrl}
                  size={40}
                  className="invite-card-object-avatar"
                />
                <div className="invite-card-avatar-text">
                  {invite.object_name}
                </div>
                {invite.entity_type === "addressee" && (
                  <div className="invite-card-avatar-text">
                    {invite.entity_name}
                  </div>
                )}
              </div>
            }
          />

          {
            invite.entity_type == 'key' &&
            <ProfileInfo.Row
              trClassName={`non-cursor`}
              mIconClass={`d-none`}
              title={strings.label_key}
              data={invite.entity_name}
            />
          }

          {(invite.invite_type === "role" || invite.invite_type === 'request_role') && (
            <ProfileInfo.Row
              trClassName={`non-cursor`}
              mIconClass={`d-none`}
              title={strings.label_roles}
              secondClass={`for-chips`}
              data={
                <ProfileInfo.RolesChips
                  object_type={invite.object_type}
                  roles={invite.roles}
                />
              }
            />
          )}

          {invite.invite_type === "visit" &&
            invite.request_details &&
            invite.request_details.room &&
            invite.request_details.room.name && (
              <ProfileInfo.Row
                trClassName={`non-cursor`}
                mIconClass={`d-none`}
                title={strings.label_room}
                secondClass={`for-chips`}
                data={invite.request_details.room.name}
              />
            )}

          {invite.invite_type === "visit" &&
            invite.request_details &&
            invite.request_details.inviter &&
            invite.request_details.inviter.surname && (
              <ProfileInfo.Row
                trClassName={`non-cursor`}
                mIconClass={`d-none`}
                title={strings.label_inviter}
                secondClass={`for-chips`}
                data={`${invite.request_details.inviter.name} ${
                  invite.request_details.inviter.surname
                }`}
              />
            )}

          {invite.invite_type === "visit" &&
            invite.request_details &&
            invite.request_details.start_date && (
              <ProfileInfo.Row
                trClassName={`non-cursor`}
                mIconClass={`d-none`}
                title={strings.label_start_date}
                secondClass={`for-chips`}
                data={moment(invite.request_details.start_date).format("L LT")}
              />
            )}

          {invite.invite_type === "visit" &&
            invite.request_details &&
            invite.request_details.end_date && (
              <ProfileInfo.Row
                trClassName={`non-cursor`}
                mIconClass={`d-none`}
                title={strings.label_end_date}
                secondClass={`for-chips`}
                data={moment(invite.request_details.end_date).format("L LT")}
              />
            )}
        </ProfileInfo.Table>

        {invite.status != "sent" && (
          <ProfileInfo.Table title={strings.invite_header_response}>
            {invite.last_status_change && (
              <ProfileInfo.Row
                trClassName={`non-cursor`}
                mIconClass={`d-none`}
                title={strings.label_date}
                data={moment(invite.last_status_change).format("L LT")}
              />
            )}

            <ProfileInfo.Row
              trClassName={`non-cursor`}
              mIconClass={`d-none`}
              title={strings.label_response}
              data={<span className={status_class}>{status_name}</span>}
            />
          </ProfileInfo.Table>
        )}
      </div>
    );
  }
}

export default InviteCard;
