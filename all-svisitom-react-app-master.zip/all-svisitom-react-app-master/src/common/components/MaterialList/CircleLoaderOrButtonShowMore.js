import React from 'react'

import ButtonShowMore from './ButtonShowMore'
import CircleLoader from '../CircleLoader'

class CircleLoaderOrButtonShowMore extends React.Component {
  render() {
    if (this.props.fetching) {
      return (
        <CircleLoader />
      )
    } else if (this.props.hasMore) {
      return (
        <ButtonShowMore
          onClick={this.props.onShowMoreClick}
        />
      )
    } else {
      return null
    }
  }
}

export default CircleLoaderOrButtonShowMore
