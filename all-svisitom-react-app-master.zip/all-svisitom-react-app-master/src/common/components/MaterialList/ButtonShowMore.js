import React from 'react'

import strings from '../../localization/all'

class ButtonShowMore extends React.Component {

  render() {
    return (
      <div className="pull-right">
        <div className="btn btn-flat waves-effect" onClick={this.props.onClick}>{strings.button_show_more}</div>
      </div>
    )
  }
}

export default ButtonShowMore
