import React from 'react';

import strings from '../../localization/all'
import Icon from '../Icon'

const AddRow = ({onClick, text=strings.button_add, icon="sv-icon-add", description=""}) => (
  <div className="sv-material-list-add-row waves-effect" onClick={onClick}>
    <div className="sv-material-list-add-row-container">
      <div className="sv-material-list-add-row-text-container">
        <div>
          <Icon name={icon} style={{float:'left'}}/>
          <span className="sv-material-list-add-row-text">{text}</span>
        </div>
      </div>
      {
        description &&
        <div className="sv-material-list-add-row-description">{description}</div>
      }
    </div>
  </div>
);

export default AddRow;
