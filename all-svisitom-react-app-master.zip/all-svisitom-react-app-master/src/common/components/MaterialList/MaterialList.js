import React, { Component } from "react";

import "./style.css";

/*
  Props:
    emptyText - text to be shown if no children
*/
class MaterialList extends Component {
  render() {
    const children = this.props.children;
    if (!children || children.length == 0) {
      return (
        <div className={`sv-material-list-empty`}>{this.props.emptyText}</div>
      );
    }

    if (this.props.fixedList) {
      return (
        <div className="sv-material-list">
          <div className={`sv-material-list-item`}>{this.props.children}</div>
        </div>
      );
    }

    if (this.props.kioskList) {
      return (
        <div className="">
          {React.Children.map(
            children,
            (child, i) =>
              child ? (
                <div
                  className={`sv-material-list-item sv-kiosk-list-item clearfix`}
                >
                  {child}
                </div>
              ) : null
          )}
        </div>
      );
    }

    return (
      <div className="sv-material-list">
        {React.Children.map(
          children,
          (child, i) =>
            child ? (
              <div className={`sv-material-list-item clearfix`}>{child}</div>
            ) : null
        )}
      </div>
    );
  }
}

export default MaterialList;
