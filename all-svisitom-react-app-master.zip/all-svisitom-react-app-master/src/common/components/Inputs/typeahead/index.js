import React from "react";

import "react-bootstrap-typeahead/css/Typeahead.css";
import { Typeahead } from "react-bootstrap-typeahead";

class TypeaheadContainer extends React.Component {
  componentDidMount() {
    $(".rbt-input-main")
      .parents(".md-form")
      .find("label")
      .on("click", function(event) {
        event.preventDefault();
        $(this)
          .parent()
          .find(".rbt-input-main")
          .focus();
      });

    $(".rbt-input-main").on("focus", function(event) {
      event.preventDefault();
      $(this)
        .parents(".md-form")
        .find("label")
        .addClass("active")
        .addClass("color");
      /* Act on the event */
    });

    $(".rbt-input-main").on("focusout", function(event) {
      event.preventDefault();
      /* Act on the event */
      if (!$(this).val()) {
        $(this)
          .parents(".md-form")
          .find("label")
          .removeClass("active");
      }
      $(this)
        .parents(".md-form")
        .find("label")
        .removeClass("color");
    });
  }

  isInputFocus() {
    const el = $(`.md-form.${this.props.mdClass} .rbt-input-main`);
    return el.is(":focus");
  }

  onInputChange(search) {
    this.setState({
      keywords: search
    });
    if (!search) {
      this.props.onSearch("");
    }
  }

  render() {
    return (
      <div
        className={`md-form ${this.props.mdClass} ${
          this.props.errorClass ? this.props.errorClass(this.props.error) : ""
        }`}
      >
        <Typeahead
          emptyLabel=""
          options={this.props.options}
          selected={[this.props.value]}
          onInputChange={this.props.onInputChange}
          clearButton={this.props.clearButton}
          labelKey={this.props.labelKey || null}
          multiple={this.props.multiple || false}
        />

        <label
          id={`${this.props.id}_label`}
          className={`
            ${this.props.value || this.isInputFocus() ? "active" : ""}
            ${this.isInputFocus() ? " color" : ""}
          `}
        >
          {this.props.label}
        </label>
        {!this.props.value ? <b className="caret"/> : null}
        {this.props.error && this.props.error !== "init" ? (
          <div className="hint">{this.props.error}</div>
        ) : null}
      </div>
    );
  }
}

export default TypeaheadContainer;
