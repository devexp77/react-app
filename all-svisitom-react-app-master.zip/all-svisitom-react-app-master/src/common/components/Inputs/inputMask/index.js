import React from "react";
import InputMask from "react-input-mask";
import "./style.css";

/*
props
id
value
handleInputChange
label
*/

class InputMaskComponent extends React.Component {
  render() {
    return (
      <div
        className={`md-form input-mask ${
          this.props.mdClass ? this.props.mdClass : ""
        }	${
          this.props.errorClass ? this.props.errorClass(this.props.error) : ""
        }`}
      >
        <InputMask
          type="text"
          mask={this.props.mask}
          id={this.props.id}
          className={`form-control`}
          value={this.props.value}
          onChange={this.props.handleInputChange}
        />
        <label
          htmlFor={this.props.id}
          className={this.props.value === "" ? "" : "active"}
        >
          {this.props.label}
        </label>
        {this.props.error &&
          this.props.error !== "init" && (
            <div className="hint">{this.props.error}</div>
          )}
      </div>
    );
  }
}

export default InputMaskComponent;
