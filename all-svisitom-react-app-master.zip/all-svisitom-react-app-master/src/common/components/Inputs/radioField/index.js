import React from "react";

/*
props
id
value
handleInputChange
label
*/

class RadioField extends React.Component {

  render() {
    return (
      <div className="form-group">
        <input
          name={this.props.name}
          type="radio"
          id={this.props.id}
          value={this.props.value}
          onChange={this.props.onChange}
          checked={this.props.checked}
        />
        <label htmlFor={this.props.id}>{this.props.label}</label>
      </div>

    );
  }
}

export default RadioField;