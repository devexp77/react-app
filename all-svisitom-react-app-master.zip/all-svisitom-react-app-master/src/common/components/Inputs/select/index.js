import React from 'react';

import './style.css'

/*
props
id
value
handleInputChange
options
label
*/

class Select extends React.Component {
    componentDidMount() {
        const _this = this;
        $(document).ready(function () {
            $('.mdb-select').material_select('destroy');
            $('.mdb-select').material_select();
            $('.mdb-select').off();
            $('.mdb-select').on('change', _this.props.handleInputChange.bind(_this));
        });
    }

    render() {
        return (

            <div className="select-container select-field">
                <select
                    className="mdb-select"
                    id={this.props.id}
                    value={this.props.value}
                    onChange={this.props.handleInputChange}
                >

                    {this.props.options.map((option, index) =>
                        <option key={index} value={this.props.valueKey ? option[this.props.valueKey] : option.value}>
                            {this.props.labelKey ? option[this.props.labelKey] : option.label}
                        </option>
                    )
                    }

                </select>
                <label className="active">{this.props.label}</label>
            </div>


        );
    }
}


export default Select;
