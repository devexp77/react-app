import React from "react";

import "./style.css";

/*
props
id
value
handleInputChange
label
*/

class TextareaField extends React.Component {
  componentDidMount() {
    this.autosize(this.props.id, this.props)
  }

  componentDidUpdate(prevProps){
    if (prevProps.value !== this.props.value){
      this.autosize(this.props.id, this.props)
    }
  }

  autosize(id, props) {
    let el = document.getElementById(id);

    el.style.cssText = "height:auto";
    let scrollHeight = el.scrollHeight;

    if (scrollHeight > 40 && !this.props.readOnly) {
      scrollHeight += 10;
    }

    el.style.cssText = "height:" + scrollHeight + "px";
  }

  render() {
    const focusUsernameInputField = input => {
      if (input) {
        setTimeout(() => input.focus(), 100);
      }
    };
    return (
      <div
        className={`md-form textarea-field ${this.props.errorClass &&
          this.props.errorClass(this.props.error)}`}
      >
        <textarea
          rows="1"
          type="text"
          id={this.props.id}
          className={`md-textarea ${this.props.className || ""}`}
          value={this.props.value}
          onChange={this.props.handleInputChange}
          ref={this.props.focus && focusUsernameInputField}
          disabled={this.props.disabled || false}
          readOnly={this.props.readOnly || false}
        />
        <label
          htmlFor={this.props.id}
          className={this.props.value === "" ? "" : "active"}
        >
          {this.props.label}
        </label>
        {this.props.error ? (
          <div className="hint">
            {this.props.error === "init" ? "" : this.props.error}
          </div>
        ) : null}
      </div>
    );
  }
}

export default TextareaField;
