import React from "react";

/*
props
id
value
handleInputChange
label
*/

import "./style.css";

class CheckerField extends React.Component {
  render() {
    return (
      <div
        className={`form-group ${this.props.className || ""} ${
          this.props.noMargin ? "no-margin-bottom" : ""
        }`}
      >
        <input
          type="checkbox"
          id={this.props.id}
          onChange={this.props.onChange}
          checked={this.props.checked}
          disabled={this.props.disabled}
        />
        <label htmlFor={this.props.id}>{this.props.label}</label>
      </div>
    );
  }
}

export default CheckerField;
