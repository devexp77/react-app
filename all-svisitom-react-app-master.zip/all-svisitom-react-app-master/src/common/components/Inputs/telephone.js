import React from 'react';

import { PROTOCOL, HOST_NAME } from "../../../common/constants";

import ReactTelephoneInput from "react-telephone-input/lib/withStyles";
import "./telephone-input.css";

const TelephoneInput = ({id=null, onChange=null, value=null, defaultCountry="ru", preferredCountries=["ru"]}) => (
  <ReactTelephoneInput
    id={id}
    defaultCountry={defaultCountry}
    preferredCountries={preferredCountries}
    value={value}
    onChange={onChange}
    flagsImagePath={
      PROTOCOL + "//cdn." + HOST_NAME + "/img/flags.png"
    }
  />
)


export default TelephoneInput;
