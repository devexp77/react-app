import React from "react";

import "./style.css";
import Moment from "react-moment";
import common_strings from "../../../localization/all";
/*
props
id
value
onChange
label
errorClass
error
*/

class DatePicker extends React.Component {
  componentDidMount() {
    const datePicker = new MaterialDatetimePicker({
      cancelText: common_strings.button_cancel,
      okText: common_strings.button_done
    }).on("submit", val => {
      this.props.onChange(this.props.id, val._d);
    });

    const el = document.getElementById(this.props.id);
    el.addEventListener(
      "click",
      function() {
        datePicker.open();
      },
      false
    );
  }

  render() {
    return (
      <div
        className={`md-form data-picker input-field  ${this.props.errorClass &&
          this.props.errorClass(this.props.error)}`}
        id={this.props.id}
      >
        <div className="input form-control">
          <Moment format="DD.MM.YYYY">{this.props.value}</Moment>
        </div>
        {this.props.label && (
          <label htmlFor={this.props.id} className={"active"}>
            {this.props.label}
          </label>
        )}
      </div>
    );
  }
}

export default DatePicker;
