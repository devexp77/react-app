import React from "react";

import "./style.css";
import Icon from "../../Icon";

/*
props
id
value
handleInputChange
label
additionalClassName
type
*/

class InputField extends React.Component {
  constructor(props) {
    super(props);

    this.state = {
      value: props.value ? props.value: null,
      type: props.type
    };

    this.handleInputChange = this.handleInputChange.bind(this);
  }

  componentWillReceiveProps(newProps) {
    this.setState({
      value: newProps.value
    });
  }

  isInputFocus() {
    const el = $(`#md-form_${this.props.id.replace(/\.+/g, "_")} input`);
    return el.is(":focus");
  }

  showPassword() {
    this.setState({
      type: "text"
    });
  }

  hidePassword() {
    this.setState({
      type: "password"
    });
  }

  handleKeyPress = e => {
    if (e.key === "Enter" && this.props.onEnter) {
      this.props.onEnter();
    }
  };

  handleInputChange(event) {
    if (this.props.handleInputChange) {
      this.props.handleInputChange(event);
    }
  }

  render() {
    let additionalClassName = this.props.additionalClassName;
    if (!additionalClassName) {
      additionalClassName = '';
    }
    return (
      <div
        className={`md-form input-field ${
          this.props.mdClass ? this.props.mdClass : ""
        }	${
          this.props.errorClass ? this.props.errorClass(this.props.error) : ""
        }`}
        id={"md-form_" + this.props.id.replace(/\.+/g, "_")}
        style={this.props.style || {}}
      >
        <input
          type={this.state.type ? this.state.type : "text"}
          id={this.props.id}
          className={`form-control ${additionalClassName}`}
          value={this.state.value}
          onChange={this.handleInputChange}
          min={this.props.min ? this.props.min : null}
          max={this.props.max ? this.props.max : null}
          readOnly={this.props.readOnly || null}
          onKeyPress={this.handleKeyPress}
          disabled={this.props.disabled ? 'disabled': ''}
          ref={input => (this.input_field = input)}
          style={this.props.inputStyle || {}}
        />
        <label
          htmlFor={this.props.id}
          className={`
            ${this.props.value || this.isInputFocus() ? "active" : ""}
          `}
        >
          {this.props.label}
        </label>
        {this.props.error && this.props.error !== "init" && (
          <div className="hint">{this.props.error}</div>
        )}

        {this.props.afterText && this.props.value && (
          <p className={`after-input-text`}>{this.props.afterText}</p>
        )}

        {this.props.type == "password" && this.props.value && (
          <div
            className="password-visibility-icon"
            onMouseDown={this.showPassword.bind(this)}
            onMouseUp={this.hidePassword.bind(this)}
            onMouseOut={this.hidePassword.bind(this)}
          >
            <Icon
              name={
                this.state.type == "password" ? "visibility" : "visibility_off"
              }
            />
          </div>
        )}

        {this.props.clearButton && (
          <div
            className="password-visibility-icon"
            onClick={this.handleClearButtonClick}
          >
            <Icon name={`sv-icon-close`} />
          </div>
        )}
      </div>
    );
  }

  handleClearButtonClick = () => {
    const e = document.createEvent("HTMLEvents");
    e.initEvent("change", false, true);

    this.setState(
      {
        value: ""
      },
      () => {
        if (this.props.handleInputChange) {
          this.input_field.dispatchEvent(e);
        }
      }
    );
  };
}

export default InputField;
