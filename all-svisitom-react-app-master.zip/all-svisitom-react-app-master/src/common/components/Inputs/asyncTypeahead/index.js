import React from "react";

import "react-bootstrap-typeahead/css/Typeahead.css";
import { AsyncTypeahead } from "react-bootstrap-typeahead";

import strings from "../../../localization/all";

import "./style.css";

class AsyncTypeaheadContainer extends React.Component {
  constructor() {
    super();
    this.state = {
      keywords: ""
    };
  }

  componentDidMount() {
    $(".rbt-input-main").off();

    $(".rbt-input-main")
      .parents(".md-form")
      .find("label")
      .on("click", function(event) {
        event.preventDefault();
        $(this)
          .parent()
          .find(".rbt-input-main")
          .focus();
      });

    $(".rbt-input-main").on("focus", function(event) {
      event.preventDefault();
      $(this)
        .parents(".md-form")
        .find("label")
        .addClass("active")
        .addClass("color");
    });

    $(".rbt-input-main").on("focusout", function(event) {
      event.preventDefault();
      if (!$(this).val()) {
        $(this)
          .parents(".md-form")
          .find("label")
          .removeClass("active");
      }
      $(this)
        .parents(".md-form")
        .find("label")
        .removeClass("color");
    });
  }

  isInputFocus() {
    const el = $(`#md-form_${this.props.id.replace(/\.+/g, "_")} input`);
    return el.is(":focus");
  }

  onTypeAheadFocus() {
    if (this.props.multiple && !(this.props.options && this.props.options.length > 0)) {
      this.props.onSearch("");
    }


    if (
      !(this.props.options && this.props.options.length > 0) &&
      !this.props.selected
    ) {
      this.props.onSearch("");
    }
  }

  onInputChange(search) {
    this.setState({
      keywords: search
    });
    if (!search) {
      this.props.onSearch("");
    }

    if (this.props.onInput) {
      this.props.onInput(search);
    }
  }

  onSearch(search) {
    this.props.onSearch(search);
  }

  onBlur(search) {
    let value = search.target.value;

    if (this.props.onBlur && this.props.value !== value) {
      this.props.onBlur(value);
    }
  }

  render() {
    return (
      <div
        style={this.props.style || {}}
        className={`md-form ${this.props.mdClass} ${
          this.props.errorClass ? this.props.errorClass(this.props.error) : ""
        }`}
        id={"md-form_" + this.props.id.replace(/\.+/g, "_")}
      >
        <AsyncTypeahead
          disabled={this.props.disabled || false}
          promptText={
            this.props.hideMenu &&
            this.props.options &&
            this.props.options.length === 0
              ? ""
              : strings.typeahead_type_to_search
          }
          searchText={
            this.props.hideMenu &&
            this.props.options &&
            this.props.options.length === 0
              ? ""
              : strings.typeahead_searching
          }
          selectHintOnEnter={false}
          isLoading={false}
          clearButton={true}
          options={this.props.options}
          labelKey={this.props.labelkey}
          minLength={this.props.minLength || 0}
          selected={this.props.selected}
          onChange={this.props.onChange}
          onSearch={this.onSearch.bind(this)}
          onInputChange={this.onInputChange.bind(this)}
          onBlur={this.onBlur.bind(this)}
          onFocus={this.onTypeAheadFocus.bind(this)}
          multiple={this.props.multiple || false}
          renderMenuItemChildren={option => (
            <div className={`typeahead-menu-item`}>
              <div>
                {this.props.renderFields.map((field, index) =>
                  option[field] ? <span key={index}>{option[field]} </span> : ""
                )}
              </div>

              {this.props.secondLineRenderFields && (
                <div className={`second-line`}>
                  {this.props.secondLineRenderFields.map((field, index) =>
                    option[field] ? (
                      <span key={index}>{option[field]} </span>
                    ) : (
                      ""
                    )
                  )}
                </div>
              )}

              {this.props.thirdLineRenderFields && (
                <div className={`second-line`}>
                  {this.props.thirdLineRenderFields.map((field, index) =>
                    option[field] ? (
                      <span key={index}>
                        {index !== 0 ? ", " : ""}
                        {option[field]}
                      </span>
                    ) : (
                      ""
                    )
                  )}
                </div>
              )}
            </div>
          )}
        />
        <label
          id={`${this.props.id}_label`}
          className={`
            ${this.state.keywords || this.isInputFocus() ? "active" : ""}
            ${this.props.labelClassName ? this.props.labelClassName : ""}

            ${this.props.value && this.props.value.length > 0 ? "fixed" : ""}
            ${this.isInputFocus() ? " color" : ""}
          `}
        >
          {this.props.label}
        </label>

        {!(this.props.selected && this.props.selected.length > 0) ? (
          <b className="caret" />
        ) : null}

        {this.props.error && this.props.error !== "init" ? (
          <div className="hint">{this.props.error}</div>
        ) : null}
      </div>
    );
  }
}

export default AsyncTypeaheadContainer;
