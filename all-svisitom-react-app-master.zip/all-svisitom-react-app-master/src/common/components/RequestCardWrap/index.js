import React from 'react';

import './style.css';	

class RequestCardWrap extends React.Component {

	render(){
		return(
			<div className="request-cards-wrap clearfix">
				{this.props.children}
			</div>
		)
	}

}

export default RequestCardWrap
