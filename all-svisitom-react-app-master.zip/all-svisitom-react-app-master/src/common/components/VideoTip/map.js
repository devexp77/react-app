export const VideoMap = {
  "2.1": "p84vZPrK45o",
  "2.2": "lCmQmPLpfWo",
  "2.4": "Qq9spxzjWN8",
  "2.5": "kXcCyIXUpZs",
  "2.6": "2ghZtpwPpxI",
  "3.1": "6ebaL5q5rI8",
};

export default VideoMap;
