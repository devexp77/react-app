export const VideoTipStyles = {
  video_tip_wrapper: {
    position: "relative",
    width: "auto",
    height: "auto",
    pointerEvents: "auto",
    cursor: "pointer",
  },

  play_circle_icon: {
    lineHeight: "30px!important",
    fontSize: "30px!important",
    color: "#e4b114!important",
    width: "unset!important",
    height: "unset!important",
    backgroundColor: "unset!important",
    position: "absolute!important",
    top: "-1px!important",
    left: "-1px!important",
    zIndex: 1001,
    animation: "video-tip-animation 2s infinite"
  },

  play_circle: {
    position: "absolute",
    top: "-13px",
    right: "-13px",
    color: "#e4b114",
    width: "35px",
    height: "35px",
    lineHeight: "35px",

    "& div": {
      boxShadow: "0 5px 11px 0 rgba(0,0,0,0.30), 0 4px 15px 0 rgba(0,0,0,.25)",
      width: "30px",
      height: "30px",
      borderRadius: "30px",
      backgroundColor: "white",
      border: "1px solid #e4b114",
      position: "relative",
      zIndex: 1000,
    }
  },

  video_tip_modal: {
    pointerEvents: "auto"
  },
  video_tip_modal_body: {
    padding: "0 0 56.50% 0!important",
    position: "relative!important",
    width: "100%",
    height: 0,

    "& iframe": {
      position: "absolute",
      top: 0,
      left: 0,
      width: "100%",
      height: "100%"
    }
  },

  video_tip_modal_footer: {
    justifyContent: "space-between!important",

    "& label": {
      marginBottom: 0
    },

    "& div": {
      marginBottom: 0
    }
  }
};
