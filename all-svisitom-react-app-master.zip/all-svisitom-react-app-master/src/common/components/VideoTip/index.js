import React, { Fragment, useEffect, useState } from "react";
import withStyles from "react-jss";

import { VideoTipStyles } from "./style";
import Icon from "../Icon";
import { FlatButton } from "../Button";
import strings from "../../localization/all";
import random_uuid from "../../util/random_uuid";
import YouTube from "react-youtube";
import VideoMap from "./map";
import cookie from "react-cookies";
import CheckerField from "../Inputs/checkerField";
import { HOST_NAME } from "../../constants";
import ReactDOM from "react-dom";

import './style.css';

const getVideoId = number => {
  return VideoMap[number];
};

export const VideoTip = withStyles(VideoTipStyles)(
  ({ classes, children, number, display="inline-block" }) => {
    const videoId = getVideoId(number);

    const [cookies, setCookies] = useState(null);
    const [doNotShowAgain, setDoNotShowAgain] = useState(false);
    const [YouTubePlayerElement] = useState(React.createRef());
    const [VideoTipModalElement] = useState(React.createRef());

    useEffect(() => {
      setCookies(cookie.load("sv_video_hint_" + number));
    }, []);

    function cookiesSave() {
      if (doNotShowAgain) {
        const expires = new Date(Date.now() + 1000 * 60 * 60 * 24 * 365 * 10);

        cookie.save("sv_video_hint_" + number, new Date().toISOString(), {
          path: "/",
          expires,
          domain: `.${HOST_NAME}`
        });
      } else {
        cookie.remove("sv_video_hint_" + number, {
          path: "/",
          domain: `.${HOST_NAME}`
        });
      }
    }

    function onShown() {
      YouTubePlayerElement.current.play();
    }

    function onHide() {
      YouTubePlayerElement.current.pause();
      cookiesSave();
    }

    if (videoId && !cookies && strings.getLanguage() === "ru") {
      let innerStyle={
        display: display,
      };
      return (
        <Fragment>
          <div className={classes.video_tip_wrapper} style={innerStyle}>
            <div
              className={classes.play_circle}
              onClick={e => {
                e.stopPropagation();
                VideoTipModalElement.current.open();
              }}
            >
              <div>
                <Icon
                  name={"sv-icon-play-circle"}
                  className={classes.play_circle_icon}
                />
              </div>
            </div>
            {children}
          </div>
          <VideoTipModal
            number={number}
            ref={VideoTipModalElement}
            onCheckBoxChange={e => {
              setDoNotShowAgain(e.target.checked);
            }}
            onShownFunction={onShown}
            onHideFunction={onHide}
          >
            <YouTubePlayer ref={YouTubePlayerElement} videoId={videoId} />
          </VideoTipModal>
        </Fragment>
      );
    } else return children;
  }
);

const VideoTipDialog = withStyles(VideoTipStyles)(
  ({ classes, id, onClose, children, onCheckBoxChange }) => {
    const [doNotShowAgain, setDoNotShowAgain] = useState(false);
    return (
      <div
        className={`modal fade ${classes.video_tip_modal}`}
        id={id}
        tabIndex="-1"
        role="dialog"
        aria-hidden="true"
      >
        <div className="modal-dialog modal-lg" role="document">
          <div className="modal-content">
            <div className={`modal-body ${classes.video_tip_modal_body}`}>
              {children}
            </div>

            <div className={`modal-footer ${classes.video_tip_modal_footer}`}>
              <CheckerField
                id={`checkbox_` + id}
                onChange={e => {
                  onCheckBoxChange(e);
                  setDoNotShowAgain(e.target.checked);
                }}
                checked={doNotShowAgain}
                label={strings.do_not_show_again}
              />
              <FlatButton data-dismiss="modal" position={`right`}>
                {strings.button_close}
              </FlatButton>
            </div>
          </div>
        </div>
      </div>
    );
  }
);

class YouTubePlayer extends React.Component {
  constructor() {
    super();
    this.state = {
      player: null
    };
  }

  play = () => {
    this.state.player.playVideo();
  };

  pause = () => {
    this.state.player.pauseVideo();
  };

  onReady = event => {
    this.setState({
      player: event.target
    });
  };

  render() {
    return (
      <YouTube
        videoId={this.props.videoId}
        opts={{
          height: "380",
          playerVars: {
            autoplay: 0
          }
        }}
        onReady={this.onReady}
      />
    );
  }
}

class VideoTipModal extends React.Component {
  constructor() {
    super();
    this.state = { random_id: random_uuid() };
  }

  componentDidMount() {
    const id = this.props.id || this.state.random_id;
    (async () => {
      await renderModalInDOM(id, <VideoTipDialog {...this.props} id={id} />);

      this.props.onHideFunction &&
        $("#" + id).on("hide.bs.modal", () => {
          this.props.onHideFunction();
        });

      this.props.onShownFunction &&
        $("#" + id).on("shown.bs.modal", () => {
          this.props.onShownFunction();
        });
    })();
  }

  open = () => {
    const id = this.props.id || this.state.random_id;
    $("#" + id).modal("show");
  };

  close = () => {
    const id = this.props.id || this.state.random_id;
    $("#" + id).modal("hide");
  };

  render() {
    return null;
  }
}

function renderModalInDOM(id, children) {
  if (document.getElementById("video-tips")) {
    if (!document.getElementById("video-tip-" + id)) {
      let div = document.createElement("div");
      div.setAttribute("id", "video-tip-" + id);
      document.getElementById("video-tips").appendChild(div);
    }
    return new Promise(resolve => {
      ReactDOM.render(
        children,
        document.getElementById("video-tip-" + id),
        resolve
      );
    });
  }
  return null;
}

export default {
  VideoTip
};
