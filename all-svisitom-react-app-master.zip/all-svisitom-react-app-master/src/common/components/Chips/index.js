import React from 'react';

const Chips = ({children, onClick}) => (
  <span className="chip" onClick={onClick}>
    {children}
  </span>
);

export default Chips;