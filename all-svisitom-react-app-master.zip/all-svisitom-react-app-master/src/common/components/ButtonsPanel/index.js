import React from "react";
import { connect } from "react-redux";

import { toCustomPath } from "../../actions/router";
import strings from "../../localization/all";
import "./style.css";

/*
props
Submit function
cancelPath
isDelete
*/

class Buttons extends React.Component {
  goBack() {
    const { dispatch } = this.props;
    const path = this.props.cancelPath;
    dispatch(toCustomPath(path));
  }

  render() {
    return (
      <span
        className={`buttons-panel clearfix ${
          this.props.className ? this.props.className : ""
        } ${this.props.isDelete ? "column" : ""}`}
      >
        {
          this.props.Submit &&
          <button
            type="submit"
            className="btn btn-primary waves-effect waves-light none-margin-left"
            onClick={this.props.Submit}
            disabled={this.props.submitDisabled || null}
          >
            {this.props.submitText ? this.props.submitText : strings.button_save}
          </button>
        }

        {
          (this.props.cancelPath || this.props.Cancel)  &&
          <button
            className="btn btn-flat waves-effect float-left cancel-button"
            onClick={
              this.props.Cancel ? this.props.Cancel : this.goBack.bind(this)
            }
          >
            {this.props.cancelText
              ? this.props.cancelText
              : strings.button_cancel}
          </button>          
        }

        {this.props.isDelete ? (
          <button
            className="btn btn-flat waves-effect none-margin-right"
            data-toggle="modal"
            data-target="#deletePopUp"
          >
            {strings.button_delete}
          </button>
        ) : null}
      </span>
    );
  }
}

const mapStateToProps = () => {
  return {};
};

export default connect(mapStateToProps)(Buttons);
