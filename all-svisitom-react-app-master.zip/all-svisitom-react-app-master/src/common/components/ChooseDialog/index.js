import React from "react";
import "./style.css";

import strings from "../../localization/all";

/*
props
  id
  header
  deleteFunction
*/

class ChooseDialog extends React.Component {
  open = () => {
    $("#" + this.props.id).modal("show");
  };

  render() {
    let wavesEffect =
      this.props.wavesEffect == undefined ? true : this.props.wavesEffect;

    return (
      <div
        className={`modal fade ${this.props.className}`}
        id={this.props.id}
        tabIndex="-1"
        role="dialog"
        aria-labelledby="exampleModalLabel"
        aria-hidden="true"
      >
        <div className="modal-dialog modal-sm without-padding" role="document">
          <div className="modal-content">
            <div className="modal-body">
              <div
                className="choose-dialog-header"
                style={this.props.header ? { marginBottom: "15px" } : {}}
              >
                {this.props.header}
              </div>
              {!this.props.withOutWrapper &&
                React.Children.map(
                  this.props.children,
                  (child, index) =>
                    child &&
                    (child.type === "hr" ? (
                      child
                    ) : (
                      <div
                        key={"choose" + index}
                        className={
                          "dropdown-item choose-dialog-item-wrapper" +
                          (wavesEffect ? " waves-effect" : "")
                        }
                        data-dismiss="modal"
                      >
                        {child}
                      </div>
                    ))
                )}

              {this.props.withOutWrapper &&
                React.Children.map(this.props.children, (child, index) => (
                  <div key={"choose" + index} className="padding-wrapper">
                    {child}
                  </div>
                ))}
            </div>
            <div className="modal-footer">
              {this.props.submitAction && (
                <button
                  type="button"
                  className="btn btn-primary padding-right"
                  data-dismiss="modal"
                  onClick={this.props.submitAction}
                >
                  {strings.button_apply}
                </button>
              )}

              <button
                type="button"
                className="btn btn-flat"
                data-dismiss="modal"
              >
                {strings.button_cancel}
              </button>
            </div>
          </div>
        </div>
      </div>
    );
  }
}

export default ChooseDialog;
