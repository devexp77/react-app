import React from "react";
import Moment from "react-moment";
// import "moment-timezone";

import common_strings from "../../localization/all";

import "./style.css";
import { connect } from "react-redux";

class RequestCard extends React.Component {
  getImagePath(user_id) {
    let imgSrc = "";
    if (
      this.props.image.usersImage.result &&
      this.props.image.usersImage.result[user_id]
    ) {
      imgSrc = this.props.image.usersImage.result[user_id];
    }

    return imgSrc;
  }

  renderIconStatus(record) {
    return (
      <div className="icon">
        <div className={`status ${record.status.split(":")[0]}`} />
      </div>
    );
  }

  renderStatus(record) {
    return (
      <div className="pass-info col-12">
        <span>
          {common_strings["status_request_" + record.status.split(":")[0]] ||
            record.status}
        </span>
      </div>
    );
  }

  renderHead(record) {
    return (
      <div className="row head">
        {this.renderIconStatus(record)}
        <div className="col-12 no-padding">
          <div className="request-number col-6 float-left">
            №
            {record.number ? <span>{record.number} </span> : null}
          </div>

          <div className="requests-time col-6 float-left">
            {record.start_date ? (
              <span>
                <Moment format="DD.MM.YYYY">{record.start_date}</Moment>
              </span>
            ) : null}
          </div>

          {this.renderStatus(record)}
        </div>
      </div>
    );
  }

  renderPerson(record) {
    let imgPath = "";
    if (
      record.visitors &&
      record.visitors[0] &&
      record.visitors[0].user_id &&
      this.getImagePath(record.visitors[0].user_id)
    ) {
      imgPath = this.getImagePath(record.visitors[0].user_id);
    }
    if (record.visitors) {
      return (
        <div className="row person">
          {imgPath ? (
            <div className="icon">
              <img src={imgPath} />
            </div>
          ) : (
            <div className="icon">
              <i className="material-icons">account_circle</i>
            </div>
          )}

          <div className="col-12 no-padding person">
            <div className="person-name">
              {record.visitors[0] && record.visitors[0].surname ? (
                <span>{record.visitors[0].surname} </span>
              ) : null}
              {record.visitors[0] && record.visitors[0].name ? (
                <span>{record.visitors[0].name} </span>
              ) : null}
              {record.visitors[0] && record.visitors[0].patronymic ? (
                <span>{record.visitors[0].patronymic} </span>
              ) : null}
            </div>

            {this.props.objectRequest ? (
              <div className="person-jobtitle">
                {record.visitors[0] && record.visitors[0].job_title ? (
                  <span>{record.visitors[0].job_title} </span>
                ) : null}
              </div>
            ) : null}

            {this.props.objectRequest ? (
              <div className="person-company">
                {record.visitors[0] && record.visitors[0].company ? (
                  <span>{record.visitors[0].company} </span>
                ) : null}
              </div>
            ) : null}

            {!this.props.objectRequest ? (
              <div className="object">
                {record.object && record.object.name ? (
                  <span>{record.object.name} </span>
                ) : null}
              </div>
            ) : null}

            {!this.props.objectRequest ? (
              <div className="addressee">
                {record.addressee && record.addressee.name ? (
                  <span>{record.addressee.name} </span>
                ) : null}
              </div>
            ) : null}
          </div>
        </div>
      );
    } else return null;
  }

  renderTransport(record) {
    return (
      <div className="transport row">
        {record.vehicles &&
        record.vehicles[0] &&
        record.vehicles[0].license_plate ? (
          <div className={`details`}>
            <i className="material-icons">directions_car</i>
            {record.vehicles[0].license_plate}
          </div>
        ) : null}
      </div>
    );
  }

  renderPermit(record) {
    let permits = this.props.permitRecords;
    return (
      <div className="pass row">
        {record.visitors && record.visitors[0] && record.visitors[0].permit_id &&
        permits.result &&
        permits.result.find(permit => permit.permit_id === record.visitors[0].permit_id) ? (
          <div className={`details`}>
            <i className="material-icons">contact_mail</i>
            {
              permits.result.find(
                permit => permit.permit_id === record.visitors[0].permit_id
              ).number
            }
          </div>
        ) : null}
      </div>
    );
  }

  render() {
    let record = this.props.record;
    return (
      <div className="requests-item col-12 col-sm-12 col-md-6 col-lg-4 col-xl-3 clearfix">
        <div
          className="visitor-info waves-effect"
          onClick={() => this.props.action(record.request_id)}
        >
          {this.renderHead(record)}
          <hr />
          {this.renderPerson(record)}

          {this.renderTransport(record)}

          {this.renderPermit(record)}
        </div>
      </div>
    );
  }
}

const mapStateToProps = state => {
  return {
    image: state.image
  };
};

export default connect(mapStateToProps)(RequestCard);
