import React from "react";
import { MapStaticSingleMarker } from "../../components/Map";

import "./style.css";

import strings from "../../localization/all"
import Icon from "../Icon";

class AddressWithMap extends React.Component {
  constructor() {
    super();
    this.state = {
      mapVisible: false,
      zoom: 17
    };
  }

  toggleMapVisibility(event) {
    event.stopPropagation();
    this.setState({
      mapVisible: !this.state.mapVisible
    });
  }

  render() {
    var lat = this.props.lat;
    var lng = this.props.lng;

    if (this.props.geo_point && this.props.geo_point.length == 2) {
      lat = this.props.geo_point[0];
      lng = this.props.geo_point[1];
    }

    return [
      <div
        key={`address`}
        className={`address-with-map ${lat && lng ? "clickable" : ""}`}
        onClick={lat && lng ? this.toggleMapVisibility.bind(this) : null}
      >
        <Icon name="sv-icon-location-on"/>
        {this.props.address}
      </div>,

      <div
        key={`map-full-screen`}
        className={`full-screen-map-container ${
          !this.state.mapVisible ? "d-none" : ""
        }`}
      >
        <div
          className={`button-full-screen-exit shadow`}
          onClick={this.toggleMapVisibility.bind(this)}
        >
          <div className={`float-left`}>{strings.button_close}</div>
          <Icon name="sv-icon-close" className="float-left"/>
        </div>
        <MapStaticSingleMarker
          key={`map`}
          entityClassName={`request-add-full-screen`}
          lat={lat}
          lng={lng}
          zoom={this.state.zoom}
        />
      </div>
    ];
  }
}

export default AddressWithMap;
