import React from 'react';

import {CDN_URL} from '../../constants';

const Preloader = ({object}) => (
	<img className="svisitom-preloader-delayed-fadein" src={`${CDN_URL}/img/logo/logo-blue.svg`}/>
)
export default Preloader
