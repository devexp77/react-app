import React from "react";

import "./style.css";

/*
Props:
  onClick
  children
  position="middle",
  wavesEffect=true
  style={}
  className=""
  data-test-id
 */
export const FlatButton = props => {
  let wavesEffectClass = props.wavesEffect ? "waves-effect" : "";
  return (
    <button
      id={props.id || ""}
      title={props.title || ""}
      type="button"
      className={`btn btn-flat ${props.position} ${wavesEffectClass} ${
        props.className
      } ${props.size || ""}`}
      style={props.style}
      onClick={props.onClick}
      data-test-id={props["data-test-id"]}
      disabled={props.disabled}
      data-dismiss={props["data-dismiss"] || false}
    >
      {props.children}
    </button>
  );
};
FlatButton.defaultProps = {
  position: "middle",
  wavesEffect: true,
  style: {},
  className: "",
  disabled: false
};

/*
Props:
  children,
  onClick,
  dataToggle,
  dataTarget,
  style={},
  className=''
  data-test-id
 */
export const RaisedButton = props => {
  let wavesEffectClass = props.wavesEffect ? "waves-effect" : "";
  return (
    <button
      type="button"
      className={`btn btn-primary ${wavesEffectClass} ${props.position} ${
        props.className
      }`}
      onClick={props.onClick}
      data-toggle={props.dataToggle}
      data-target={props.dataTarget}
      style={props.style}
      data-test-id={props["data-test-id"]}
      disabled={props.disabled}
    >
      {props.children}
    </button>
  );
};

RaisedButton.defaultProps = {
  style: {},
  className: "",
  position: "middle",
  wavesEffect: true,
  disabled: false
};

/*
Props:
  inverse=false,
  onClick
  children
  data-test-id
 */
export const FramedButton = props => {
  let inverseClass = props.inverse ? "inverse" : "";
  return (
    <button
      type="button"
      className={`btn btn-flat btn-framed ${inverseClass}`}
      onClick={props.onClick}
      data-test-id={props["data-test-id"]}
    >
      {children}
    </button>
  );
};
FramedButton.defaultProps = {
  inverse: false
};
