import React from "react";
import "./style.css";
import ShareDialog from "../ShareDialog";
import { HOST_NAME, PROTOCOL } from "../../constants";
import connect from "react-redux/es/connect/connect";
import Parser from "html-react-parser";
import Icon from "../Icon";
import manage_strings from "../../../manage/localization/all";

class IosEditor extends React.Component {
  constructor() {
    super();
    this.state = {
      ios_id: "",
      listener: this.listener.bind(this),
      needToggleEdit: false,
      fullScreen: false,
      zonesInfo: [],
      expandedList: true
    };
  }

  listener(event) {
    if (event && event.detail && event.detail.action) {
      switch (event.detail.action) {
        case "view":
          this.setState(
            {
              needToggleEdit: true
            },
            () =>
              setTimeout(function() {
                const iframe = document.querySelector("#ios-iframe");
                iframe.contentWindow.dispatchEvent(
                  new CustomEvent("to-ios-message", {
                    detail: {
                      event: "event:save-floor-request"
                    }
                  })
                );
              }, 600)
          );

          break;

        case "edit":
          this.props.toogleEditMode ? this.props.toogleEditMode() : null;
          break;

        case "selection-changed":
          this.props.onSelectZone
            ? this.props.onSelectZone(event.detail.data)
            : null;
          break;

        case "share":
          if (event.detail.data && !this.props.getPositionButtonPressed) {
            this.setState(
              {
                ios_id: event.detail.data
              },
              () => $("#share-dialog").modal("show")
            );
          }

          if (
            event.detail.data &&
            this.props.getPositionButtonPressed &&
            this.props.saveIOSOrient
          ) {
            this.props.saveIOSOrient( event.detail.data);
          }
          break;

        case "add-meta-info":
          if (event.detail.id && this.props.mapZoneToRoom) {
            this.props.mapZoneToRoom(event.detail.id);
          }
          break;

        case "more-info":
          if (event.detail.id && this.props.onZoneClick) {
            this.props.onZoneClick(event.detail.id);
          }
          break;

        case "event:object-deleted":
          if (event.detail.id && this.props.deleteIosZone) {
            this.props.deleteIosZone(event.detail.id);
          }
          break;

        case "event:floor-saved":
          if (this.state.needToggleEdit && this.props.toogleEditMode) {
            (async () => {
              await this.props.saveIOS();
              this.props.getISODataFromServer();
              this.setState({
                needToggleEdit: false
              });
            })();
          } else if (this.props.saveButtonPressed) {
            (async () => {
              await this.props.saveIOS();
              this.props.toHistoryPath();
            })();
          } else {
            this.props.saveIOS();
          }
          break;

        case "fullscreen":
          this.fullScreenMode();
          break;

        case "zones-list-changed":
          setTimeout(function() {
            const iframe = document.querySelector("#ios-iframe");
            iframe.contentWindow.dispatchEvent(
              new CustomEvent("to-ios-message", {
                detail: {
                  event: "look-at",
                  args: null
                }
              })
            );
          }, 600);
          this.getZonesInfo(event.detail.data);

          break;
        default:
          break;
      }
    }
  }

  getZonesInfo(zones_ids) {
    let zonesInfo = [];
    if (zones_ids && zones_ids.length > 0) {
      const iosMeta = JSON.parse(this.props.ios.iosMetaById);
      for (let zone of zones_ids) {
        if (iosMeta[zone]) {
          zonesInfo.push({
            tooltip_html: iosMeta[zone].tooltip_html,
            zone_id: zone
          });
        }
      }
    }

    this.setState({ zonesInfo: zonesInfo });
  }

  sendFullScreenButtonChange() {
    setTimeout(() => {
      const iframe = document.querySelector("#ios-iframe");
      iframe.contentWindow.dispatchEvent(
        new CustomEvent("to-ios-message", {
          detail: {
            event: "fullscreen-button-change",
            args: {
              isFullscreen: this.state.fullScreen
            }
          }
        })
      );
    });
  }

  fullScreenMode = () => {
    if (this.state.fullScreen) {
      this.closeFullscreen();
    } else {
      const elem = document.getElementById(
        this.props.fullScreenContainerId || "ios-iframe-container"
      );
      this.openFullscreen(elem);
    }
  };

  openFullscreen(elem) {
    if (elem.requestFullscreen) {
      elem.requestFullscreen();
      this.setState({ fullScreen: true }, () =>
        this.sendFullScreenButtonChange()
      );
    } else if (elem.mozRequestFullScreen) {
      elem.mozRequestFullScreen();
      this.setState({ fullScreen: true }, () =>
        this.sendFullScreenButtonChange()
      );
    } else if (elem.webkitRequestFullscreen) {
      elem.webkitRequestFullscreen();
      this.setState({ fullScreen: true }, () =>
        this.sendFullScreenButtonChange()
      );
    } else if (elem.msRequestFullscreen) {
      elem.msRequestFullscreen();
      this.setState({ fullScreen: true }, () =>
        this.sendFullScreenButtonChange()
      );
    }
  }

  closeFullscreen() {
    if (document.exitFullscreen) {
      document.exitFullscreen();
      this.setState({ fullScreen: false }, () =>
        this.sendFullScreenButtonChange()
      );
    } else if (document.mozCancelFullScreen) {
      document.mozCancelFullScreen();
      this.setState({ fullScreen: false }, () =>
        this.sendFullScreenButtonChange()
      );
    } else if (document.webkitExitFullscreen) {
      document.webkitExitFullscreen();
      this.setState({ fullScreen: false }, () =>
        this.sendFullScreenButtonChange()
      );
    } else if (document.msExitFullscreen) {
      document.msExitFullscreen();
      this.setState({ fullScreen: false }, () =>
        this.sendFullScreenButtonChange()
      );
    }
  }

  render() {
    /*for ios editor*/
    let app = this.props.action === "view" ? "building-viewer" : "floor-editor";
    let id = this.props.action === "view" ? this.props.id : this.props.id.split(',')[0];
    let url = `/ios/ios/` + app + "/index.html?" + id;

    /*for share pop up*/
    let href = `${PROTOCOL}//ios.${HOST_NAME}/#/${this.state.ios_id}`;
    let shareIframeHref = `${PROTOCOL}//ios.${HOST_NAME}/#/${this.props.id}`;
    const code = `<iframe src="${shareIframeHref}" width="800" height="400" frameborder="0"></iframe>`;

    return (
      <div id={`ios-iframe-container`}>
        <iframe
          id="ios-iframe"
          src={url}
          className={`ios-editor`}
          key={`editor`}
        />
        {this.props.shareButton && (
          <ShareDialog
            key={`dialog`}
            id={`share-dialog`}
            href={href}
            code={code}
          />
        )}
        {this.state.zonesInfo &&
          this.state.zonesInfo.length > 0 &&
          this.props.action === "view" && (
            <div
              className={`ios-zones-list shadow ${
                this.state.expandedList ? "" : "collapsed"
              }`}
            >
              <div className={`ios-zones-title`} onClick={this.expandZonesList}>
                <p>{manage_strings.subtitle_rooms}</p>
                <div className={`ios-zones-button`}>
                  <Icon
                    name={
                      this.state.expandedList
                        ? `keyboard_arrow_up`
                        : `keyboard_arrow_down`
                    }
                  />
                </div>
              </div>
              <div className={`list-scroll`}>
                {this.state.zonesInfo.map((zone, index) => (
                  <div
                    key={index}
                    className={`zone-item`}
                    onClick={() => this.onZoneInListClick(zone.zone_id)}
                  >
                    {Parser(zone.tooltip_html)}
                  </div>
                ))}
              </div>
            </div>
          )}
      </div>
    );
  }

  expandZonesList = () => {
    this.setState({ expandedList: !this.state.expandedList });
  };

  onZoneInListClick = zone_id => {
    const iframe = document.querySelector("#ios-iframe");
    iframe.contentWindow.dispatchEvent(
      new CustomEvent("to-ios-message", {
        detail: {
          event: "look-at",
          args: zone_id
        }
      })
    );
  };

  componentDidMount() {
    window.addEventListener("ios-message", this.state.listener);
  }

  componentWillUnmount() {
    window.removeEventListener("ios-message", this.state.listener);
  }
}

const mapStateToProps = state => {
  return {
    ios: state.ios
  };
};

export default connect(mapStateToProps)(IosEditor);
