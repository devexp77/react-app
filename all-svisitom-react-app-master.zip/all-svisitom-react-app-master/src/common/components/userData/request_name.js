import React from "react";
import "./style.css";

import strings from "../../localization/all";
import InputField from "../Inputs/inputField";
import AutoScroll from '../AutoScroll'

class Name extends React.Component {
  render() {
    return (
      <span className="user-name-component">
        <AutoScroll enabled={this.props.autoScroll}>
          <InputField
            id="visitor.surname"
            value={this.props.surname}
            handleInputChange={this.props.handleInputChange}
            label={strings.label_user_surname}
            errorClass={this.props.errorClass}
            error={this.props.formErrors.surname}
            mdClass={`surname`}
          />
        </AutoScroll>

        <AutoScroll enabled={this.props.autoScroll}>
          <InputField
            id="visitor.name"
            value={this.props.name}
            handleInputChange={this.props.handleInputChange}
            label={strings.label_user_name}
            errorClass={this.props.errorClass}
            error={this.props.formErrors.name}
            mdClass={`name`}
          />
        </AutoScroll>

        <AutoScroll enabled={this.props.autoScroll}>
          <InputField
            id="visitor.patronymic"
            value={this.props.patronymic}
            handleInputChange={this.props.handleInputChange}
            label={strings.label_user_patronymic}
            mdClass={`patronymic`}
          />
        </AutoScroll>
      </span>
    );
  }
}

export default Name;
