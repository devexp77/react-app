import React from 'react';
import { Link } from 'react-router';
import './style.css';

import strings from '../../localization/all'

class Name extends React.Component {
  render() {
  	return (
        <span className="user-name-component">
        	<div className="row user-name">
		        <div className="md-form col-md-6 name">
			        <input
			          type="text"
			          id="name"
			          className={`form-control`}
			          value={this.props.name}
			          onChange={this.props.handleInputChange}
			        />
			        <label htmlFor="name" className={this.props.name === "" ? ''  : 'active'}>{strings.label_user_name} *</label>
		        </div>

		        <div className="md-form col-md-6 patronymic">
			        <input
			          type="text"
			          id="patronymic"
			          className={`form-control`}
			          value={this.props.patronymic}
			          onChange={this.props.handleInputChange}
			        />
			        <label htmlFor="patronymic" className={this.props.patronymic === "" ? ''  : 'active'}>{strings.label_user_patronymic}</label>
		        </div>
		    </div>

	        <div className="md-form surname">
		        <input
		          type="text"
		          id="surname"
		          className={`form-control`}
		          value={this.props.surname}
		          onChange={this.props.handleInputChange}
		          />
				<label htmlFor="surname" className={this.props.surname === "" ? ''  : 'active'}>{strings.label_user_surname} *</label>
	         </div>


		    </span>


);
  }
}


export default Name;
