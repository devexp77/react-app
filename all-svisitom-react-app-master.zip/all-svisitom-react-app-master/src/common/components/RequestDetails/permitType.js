import React from 'react';

import strings from '../../localization/all'

class PermitType extends React.Component {
  	render() {

  		var record = this.props.record;
	    return (

			<table className={`col-12`}>
				<tbody>
					<tr>
						<td className="grey-title">{strings.label_permit_type+':'}</td>
						<td>{strings['permit_type_'+ (record.request_type || record.permit_type)]}</td>
					</tr>
				</tbody>
			</table>

	 	);

  	}
}


export default PermitType;
