import React from "react";
import strings from "../../localization/all";

/*
props
record
*/

class CreatedByDetail extends React.Component {
  render() {
    if (this.props.record.created_by) {
      const created_by = this.props.record.created_by;
      return (
        <table className={`col-12`}>
          <tbody>
            {!this.props.noMargin && (
              <tr>
                <td />
                <td />
              </tr>
            )}

            {this.props.facilityRequest && this.props.record.is_scheduled && (
              <tr>
                <td className="grey-title">{strings.label_created_by + ":"}</td>
                <td className="font-weight-bold">
                  {strings.title_request_by_schedule}
                </td>
              </tr>
            )}

            {created_by.surname || created_by.name || created_by.patronymic ? (
              <tr>
                <td className="grey-title">{strings.label_created_by + ":"}</td>
                <td className="font-weight-bold">
                  {created_by.surname ? (
                    <span>{created_by.surname} </span>
                  ) : null}
                  {created_by.name ? <span>{created_by.name} </span> : null}
                  {created_by.patronymic ? (
                    <span>{created_by.patronymic} </span>
                  ) : null}
                </td>
              </tr>
            ) : this.props.facilityRequest && !this.props.record.is_scheduled ? (
              <tr>
                <td className="grey-title">{strings.label_created_by + ":"}</td>
                <td className="font-weight-bold">
                  {strings.title_request_by_anonymous}
                </td>
              </tr>
            ) : null}
          </tbody>
        </table>
      );
    } else {
      return null;
    }
  }
}

export default CreatedByDetail;
