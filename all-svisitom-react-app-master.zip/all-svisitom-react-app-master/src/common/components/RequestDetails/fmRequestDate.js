import React from "react";

import strings from "../../localization/all";
import Moment from "react-moment";

class ProblemDate extends React.Component {
  render() {
    return (
      <table className={`col-12`}>
        <tbody>
          <tr>
            <td className="grey-title">
              {strings["label_date_" + this.props.field] + ":"}
            </td>
            <td>
              {this.props.date && (
                <Moment locale={strings.getLanguage()} format="L LT">
                  {this.props.date}
                </Moment>
              )}
            </td>
          </tr>
        </tbody>
      </table>
    );
  }
}

export default ProblemDate;
