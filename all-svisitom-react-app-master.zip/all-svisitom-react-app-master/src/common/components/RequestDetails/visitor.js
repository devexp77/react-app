import React from "react";
import strings from "../../localization/all";
import { isFieldChanged } from "./checkFields";

/*
props
record
*/

class VisitorDetails extends React.Component {
  render() {
    let changedFields = this.props.changedFields;
    const index = this.props.index;

    if (this.props.visitor) {
      const visitor = this.props.visitor;

      return (
        <table
          className={`col-12`}
        >
          <tbody>
          {!this.props.noMargin && (
            <tr>
              <td />
              <td />
            </tr>
          )}

            {visitor.surname ||
            visitor.name ||
            visitor.patronymic ||
            isFieldChanged(`visitors.${index}.${index}.surname`, changedFields) ||
            isFieldChanged(`visitors.${index}.name`, changedFields) ||
            isFieldChanged(`visitors.${index}.patronymic`, changedFields) ? (
              <tr
                className={
                  isFieldChanged(`visitors.${index}.surname`, changedFields) ||
                  isFieldChanged(`visitors.${index}.name`, changedFields) ||
                  isFieldChanged(`visitors.${index}.patronymic`, changedFields)
                    ? "changed"
                    : ""
                }
              >
                <td className="grey-title">
                  {strings.label_visitor_name + ":"}
                </td>
                <td className="font-weight-bold">
                  {visitor.surname ? <span>{visitor.surname} </span> : null}
                  {visitor.name ? <span>{visitor.name} </span> : null}
                  {visitor.patronymic ? (
                    <span>{visitor.patronymic} </span>
                  ) : null}
                </td>
              </tr>
            ) : null}

            {visitor.job_title ||
            isFieldChanged(`visitors.${index}.job_title`, changedFields) ? (
              <tr
                className={
                  changedFields &&
                  isFieldChanged(`visitors.${index}.job_title`, changedFields)
                    ? "changed"
                    : ""
                }
              >
                <td className="grey-title">
                  {strings.label_visitor_job_name + ":"}
                </td>
                <td>{visitor.job_title && visitor.job_title}</td>
              </tr>
            ) : null}

            {visitor.company ||
            isFieldChanged(`visitors.${index}.company`, changedFields) ? (
              <tr
                className={
                  changedFields &&
                  isFieldChanged(`visitors.${index}.company`, changedFields)
                    ? "changed"
                    : ""
                }
              >
                <td className="grey-title">
                  {strings.label_visitor_company + ":"}
                </td>
                <td>{visitor.company && visitor.company}</td>
              </tr>
            ) : null}

            {visitor.email ||
              isFieldChanged(`visitors.${index}.email`, changedFields) ? (
              <tr
                className={
                  changedFields &&
                  isFieldChanged(`visitors.${index}.email`, changedFields)
                    ? "changed"
                    : ""
                }
              >
                <td className="grey-title">
                  {strings.label_third_party_email + ":"}
                </td>
                <td>{visitor.email && visitor.email}</td>
              </tr>
            ) : null}

            {visitor.phone_number ||
              isFieldChanged(`visitors.${index}.phone_number`, changedFields) ? (
              <tr
                className={
                  changedFields &&
                  isFieldChanged(`visitors.${index}.phone_number`, changedFields)
                    ? "changed"
                    : ""
                }
              >
                <td className="grey-title">
                  {strings.label_third_party_phone_number + ":"}
                </td>
                <td>{visitor.phone_number && visitor.phone_number}</td>
              </tr>
            ) : null}
          </tbody>
        </table>
      );
    } else {
      return null;
    }
  }
}

export default VisitorDetails;
