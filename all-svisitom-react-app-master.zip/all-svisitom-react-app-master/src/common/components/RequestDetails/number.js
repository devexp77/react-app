import React from 'react';

import strings from '../../localization/all'

class RecordNumber extends React.Component {
  	render() {

  		var record = this.props.record;
	    return (

			<table className={`col-12`}>
				<tbody>
					<tr>
						<td className="grey-title">{strings.label_number+':'}</td>
						<td>
							{record.number
	                			?	record.number
	                			: 	null
							}
						</td>
					</tr>
				</tbody>
			</table>

	 	);

  	}
}


export default RecordNumber;
