import Container from "./container";

import DateDetails from "./date";
import VisitDate from "./visitDate";
import RecordNumber from "./number";
import RequestNumber from "./requestNumber";
import PermitType from "./permitType";
import Status from "./status";
import FmRequestStatus from "./fmRequestStatus";
import Margin from "./margin";
import Document from "./document";
import Transport from "./transport";
import Inviter from "./inviter";
import Visitor from "./visitor";
import Visitors from "./visitors";
import ObjectName from "./object";
import PassInfo from "./passInfo";
import RegisterPassButtons from "./registerPassButtons";
import RequestButtons from "./requestButtons";
import UserRequestButtons from "./userRequestButtons";
import History from "./history";
import CreatedBy from "./createdBy";
import TopRightButtons from './toprightButtons';
import QR from './qr';
import ProblemDetail from "./problemDetail"
import FmRequestDate from "./fmRequestDate"
import Master from "./master"
import Signature from "./signature"
import FacilityRequestDetails from "./facilityRequestDetails"
import FmRequestRealWorkTime from "./facilityRequestRealWorkTime"
import WorkTimeLogbookInfo from "./workTimeLogbookInfo";
import AcceptedBy from "./acceptor";

import "./style.css";


export default {
  Container,
  Margin,
  RecordNumber,
  PermitType,
  Status,
  DateDetails,
  Document,
  Transport,
  Inviter,
  Visitor,
  Visitors,
  ObjectName,
  PassInfo,
  RegisterPassButtons,
  RequestButtons,
  VisitDate,
  History,
  CreatedBy,
  UserRequestButtons,
  TopRightButtons,
  QR,
  RequestNumber,
  FmRequestStatus,
  ProblemDetail,
  FmRequestDate,
  Master,
  FacilityRequestDetails,
  Signature,
  FmRequestRealWorkTime,
  WorkTimeLogbookInfo,
  AcceptedBy
};
