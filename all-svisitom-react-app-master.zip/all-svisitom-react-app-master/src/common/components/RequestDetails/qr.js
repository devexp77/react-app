import React from 'react';

import {HOST_NAME, PROTOCOL} from "../../constants";

class Qr extends React.Component {
    render() {
        return (
          <div className={`qr-code`}>
            <img src={`${PROTOCOL}//qr.${HOST_NAME}/${this.props.permit_id}?box_size=5`}/>
          </div>
        );
    }
}

export default Qr;
