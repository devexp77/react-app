export const isFieldChanged = (field, changedFields) => {
  if (changedFields) {
    return changedFields.hasOwnProperty(field);
  } else return false;
};

export const isEmptyObject = obj => {
  for (var i in obj) {
    if (obj.hasOwnProperty(i)) {
      return false;
    }
  }
  return true;
};
