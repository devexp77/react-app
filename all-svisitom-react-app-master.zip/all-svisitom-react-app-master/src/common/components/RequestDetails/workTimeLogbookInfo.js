import React from "react";
import strings from "../../localization/all";
import Icon from "../Icon";
import Moment from "react-moment";

/*
props
record
*/

class WorkTimeLogbookInfo extends React.Component {
  getProblemIcon(record) {
    const { problem } = record;
    let reverseProblems = [];

    Object.assign(reverseProblems, problem);

    reverseProblems.reverse();

    let icon = "sv-icon-fm-other";

    for (let i in reverseProblems) {
      if (reverseProblems[i].icon_name) {
        icon = reverseProblems[i].icon_name.trim();
        return icon;
      }
    }

    return icon;
  }

  render() {
    if (this.props.record) {
      const record = this.props.record;
      return (
        <table className={`col-12`}>
          <tbody>
            <tr>
              <td className="grey-title">
                {strings.label_facility_request_number + ":"}
              </td>
              <td>{record.facility_request && record.facility_request.number}</td>
            </tr>
            <tr>
              <td className="grey-title">{strings.label_problem + ":"}</td>
              <td>
                <div className={`problem-block clearfix`}>
                  <div className={"problem-icon"}>
                    <Icon name={this.getProblemIcon(record)} />
                  </div>
                  {record.facility_request && record.facility_request.problem &&
                    record.facility_request.problem.length > 0 &&
                    record.facility_request.problem.map((problem, index) => (
                      <div className={`problem-name`} key={index}>
                        {problem.name}
                      </div>
                    ))}
                </div>
              </td>
            </tr>
            <tr>
              <td className="grey-title">{strings.label_room + ":"}</td>
              <td>{record.room && record.room.name}</td>
            </tr>
            <tr>
              <td/>
              <td/>
            </tr>
            <tr
            >
              <td className="grey-title">{strings.label_master_name + ":"}</td>
              <td className="font-weight-bold">
                {record.master && record.master.surname ? (
                  <span>{record.master.surname} </span>
                ) : null}

                {record.master && record.master.name ? (
                  <span>{record.master.name} </span>
                ) : null}

                {record.master && record.master.patronymic ? (
                  <span>{record.master.patronymic} </span>
                ) : null}
              </td>
            </tr>

            <tr>
              <td className="grey-title">{strings.label_work_start + ":"}</td>
              <td>
                {record.work_interval && record.work_interval.length > 0 ? (
                  <Moment format="L LT" locale={strings.getLanguage()}>
                    {record.work_interval[0]}
                  </Moment>
                ) : null}
              </td>
            </tr>
            <tr>
              <td className="grey-title">{strings.label_work_end + ":"}</td>
              <td>
                {record.work_interval && record.work_interval.length > 1 ? (
                  <Moment format="L LT" locale={strings.getLanguage()}>
                    {record.work_interval[1]}
                  </Moment>
                ) : null}
              </td>
            </tr>
          </tbody>
        </table>
      );
    } else {
      return null;
    }
  }
}

export default WorkTimeLogbookInfo;
