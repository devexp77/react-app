import React from "react";

class RequestContainer extends React.Component {
  render() {
    return (
      <div
        className={
          this.props.className
            ? this.props.className
            : `request-card-detail clearfix  ${
              this.props.noStyle ? " no-style" : ""
              }`
        }
      >
        {this.props.children}
      </div>
    );
  }
}

export default RequestContainer;
