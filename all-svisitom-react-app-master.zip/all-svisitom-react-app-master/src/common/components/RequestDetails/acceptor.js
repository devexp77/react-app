import React from "react";
import strings from "../../localization/all";

/*
props
record
*/

class CreatedByDetail extends React.Component {
  render() {
    if (this.props.record.accepted_by) {
      const accepted_by = this.props.record.accepted_by;
      return (
        <table className={`col-12`}>
          <tbody>
            {!this.props.noMargin && (
              <tr>
                <td />
                <td />
              </tr>
            )}

            {accepted_by.surname || accepted_by.name || accepted_by.patronymic ? (
              <tr>
                <td className="grey-title">{strings.label_accepted_by + ":"}</td>
                <td className="font-weight-bold">
                  {accepted_by.surname ? (
                    <span>{accepted_by.surname} </span>
                  ) : null}
                  {accepted_by.name ? <span>{accepted_by.name} </span> : null}
                  {accepted_by.patronymic ? (
                    <span>{accepted_by.patronymic} </span>
                  ) : null}
                </td>
              </tr>
            ) : null}
          </tbody>
        </table>
      );
    } else {
      return null;
    }
  }
}

export default CreatedByDetail;
