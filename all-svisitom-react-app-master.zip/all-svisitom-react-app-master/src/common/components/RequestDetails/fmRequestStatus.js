import React from "react";

import strings from "../../localization/all";

class FmRequestStatus extends React.Component {
  render() {
    const record = this.props.record;
    return (
      <table className={`col-12`}>
        <tbody>
          <tr>
            <td className="grey-title">{strings.label_status + ":"}</td>
            <td className="font-weight-bold">
              {strings["status_facility_request_" + record.status]}
            </td>
          </tr>
        </tbody>
      </table>
    );
  }
}

export default FmRequestStatus;
