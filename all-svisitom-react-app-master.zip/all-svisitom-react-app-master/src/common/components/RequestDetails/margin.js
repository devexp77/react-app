import React from 'react';

class Margin extends React.Component {
  	render() {
	    return (

			<table className={`col-12`}>
				<tbody>
					<tr>
						<td></td>
						<td></td>
					</tr>
				</tbody>
			</table>

	 	);

  	}
}


export default Margin;
