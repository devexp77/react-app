import React from "react";

import strings from "../../localization/all";
import Icon from "../Icon";
import format from "string-format";

class ProblemDetail extends React.Component {
  getProblemIcon(record) {
    const { problem } = record;
    let reverseProblems = [];

    Object.assign(reverseProblems, problem);

    reverseProblems.reverse();

    let icon = "sv-icon-fm-other";

    for (let i in reverseProblems) {
      if (reverseProblems[i].icon_name) {
        icon = reverseProblems[i].icon_name.trim();
        return icon;
      }
    }

    return icon;
  }

  render() {
    const record = this.props.record;
    return (
      <table className={`col-12`}>
        <tbody>
          <tr>
            <td className="grey-title">{strings.label_room + ":"}</td>
            <td className="font-weight-bold">{record.room.name}</td>
          </tr>
          <tr>
            <td className="grey-title">{strings.label_problem + ":"}</td>
            <td>
              <div className={`problem-block clearfix`}>
                <div className={"problem-icon"}>
                  <Icon name={this.getProblemIcon(record)} />
                </div>
                {record.problem &&
                  record.problem.length > 0 &&
                  record.problem.map((problem, index) => (
                    <div className={`problem-name`} key={index}>
                      {problem.name}
                    </div>
                  ))}
              </div>
            </td>
          </tr>
          {
            this.props.record.detail &&
            <tr>
              <td className="grey-title">{strings.label_detail + ":"}</td>
              <td>{this.props.record.detail}</td>
            </tr>
          }
          <tr>
            <td className="grey-title"/>
            <td className="font-weight-bold"/>
          </tr>
          {
            this.props.record.price !== undefined && this.props.record.price !== null &&
            <tr>
              <td className="grey-title">{strings.label_price + ":"}</td>
              <td>{format(strings.problem_price, this.props.record.price)}</td>
            </tr>
          }
          {
            this.props.record.quantity !== undefined && this.props.record.quantity !== null &&
            <tr>
              <td className="grey-title">{strings.label_quantity + ":"}</td>
              <td>{this.props.record.quantity}</td>
            </tr>
          }
          {
            this.props.record.total_price !== undefined && this.props.record.total_price !== null &&
            <tr>
              <td className="grey-title">{strings.label_total_price + ":"}</td>
              <td>{format(strings.problem_price, this.props.record.total_price)}</td>
            </tr>
          }

          {
            this.props.record.is_payable &&
            <tr>
              <td className="grey-title">{strings.label_is_paid + ":"}</td>
              <td>{this.props.record.is_paid ? strings.label_yes : strings.label_no}</td>
            </tr>
          }
        </tbody>
      </table>
    );
  }
}

export default ProblemDetail;
