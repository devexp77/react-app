import React from "react";
import strings from "../../localization/all";

/*
props
master
*/

class Master extends React.Component {
  render() {

    if (this.props.master && this.props.master.surname) {
      const master = this.props.master;

      return (
        <table className={`col-12`}>
          <tbody>
            <tr>
              <td className="grey-title">{strings.label_master_name + ":"}</td>
              <td className="font-weight-bold">
                {master.surname ? <span>{master.surname} </span> : null}
                {master.name ? <span>{master.name} </span> : null}
                {master.patronymic ? <span>{master.patronymic} </span> : null}
              </td>
            </tr>
          </tbody>
        </table>
      );
    } else {
      return null;
    }
  }
}

export default Master;
