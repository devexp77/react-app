import React from "react";
import strings from "../../localization/all";
import { isFieldChanged } from "./checkFields";
import MaterialSurface from "../PageContainers/materialSurface";
import update from "immutability-helper";
import { TRANSPORT_ICONS_PATH } from "../../constants";
/*
props
record with transport
*/

class TransportDetails extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      transportsIndexes: []
    };
  }

  componentDidMount() {
    if (this.props.handleCheckerChange) {
      let vehicles = this.props.record.vehicles;
      let transportsIndexes = [];
      for (let i = 0; i < vehicles.length; i++) {
        if (vehicles[i].approved !== false) {
          transportsIndexes.push(i);
        }
      }

      this.setState({ transportsIndexes: transportsIndexes }, function() {
        this.props.handleCheckerChange(this.state.transportsIndexes);
      });
    }
  }

  checkerOnChange(event) {
    const id = event.target.getAttribute("data-index");
    const checked = event.target.checked;
    if (checked) {
      this.setState(
        {
          transportsIndexes: update(this.state.transportsIndexes, {
            $push: [Number(id)]
          })
        },
        function() {
          this.props.handleCheckerChange(this.state.transportsIndexes);
        }
      );
    } else {
      let transportsIndexes = this.state.transportsIndexes.slice(0);

      transportsIndexes.splice(transportsIndexes.indexOf(Number(id)), 1);
      this.setState(
        {
          transportsIndexes: transportsIndexes
        },
        function() {
          this.props.handleCheckerChange(this.state.transportsIndexes);
        }
      );
    }
  }

  isChecked(index) {
    return this.state.transportsIndexes.indexOf(index) > -1;
  }

  render() {
    let changedFields = this.props.changedFields;
    let vehicles = this.props.record.vehicles;
    const status = this.props.record.status ? this.props.record.status : "";

    return vehicles
      ? vehicles.map((transport, index) => (
          <MaterialSurface marginBottom key={index}>
            {this.props.checker &&
              (transport.approved !== false && !transport.permit_id) && (
                <div className="form-group checker">
                  <input
                    type="checkbox"
                    id={`transport_${index}`}
                    data-index={index}
                    onChange={this.checkerOnChange.bind(this)}
                    checked={this.isChecked.bind(this)(index)}
                  />
                  <label htmlFor={`transport_${index}`}>
                    {status === "approved" || status === "registered"
                      ? strings.button_create_permit
                      : strings.button_approve}
                  </label>
                </div>
              )}
            {transport.approved === false && (
              <div className={`clearfix`}>
                <i
                  className="material-icons float-left"
                  style={{ marginRight: "12px" }}
                >
                  close
                </i>
                <p className={`float-left`} style={{ marginBottom: "8px" }}>
                  {strings.status_item_rejected}
                </p>
              </div>
            )}

            {transport.permit_id && (
              <div
                className={`clearfix`}
                style={this.props.onPermitClick ? { cursor: "pointer" } : null}
                onClick={
                  this.props.onPermitClick
                    ? () => this.props.onPermitClick(transport.permit_id)
                    : null
                }
              >
                <i
                  className="material-icons float-left"
                  style={
                    this.props.onPermitClick
                      ? { marginRight: "12px", color: "#207ea9" }
                      : { marginRight: "12px" }
                  }
                >
                  check_circle
                </i>
                <p
                  className={`float-left`}
                  style={
                    this.props.onPermitClick
                      ? { marginBottom: "8px", color: "#207ea9" }
                      : { marginBottom: "8px" }
                  }
                >
                  {strings.status_request_registered}
                </p>
              </div>
            )}

            {(transport.license_plate ||
              isFieldChanged(
                `vehicles.${index}.license_plate`,
                changedFields
              ) ||
              isFieldChanged(`vehicles.${index}.brand`, changedFields) ||
              isFieldChanged(`vehicles.${index}.model`, changedFields) ||
              isFieldChanged(`vehicles.${index}.color`, changedFields)) && (
              <table key={`transport-${index}`} className={`col-12 `}>
                <tbody>
                  {!this.props.noMargin && (
                    <tr>
                      <td />
                      <td />
                    </tr>
                  )}

                  {transport.license_plate ||
                  isFieldChanged(
                    `vehicles.${index}.license_plate`,
                    changedFields
                  ) ? (
                    <tr
                      className={
                        isFieldChanged(
                          `vehicles.${index}.license_plate`,
                          changedFields
                        )
                          ? "changed"
                          : ""
                      }
                    >
                      <td className="grey-title">
                        {strings.label_license_plate + ":"}
                      </td>
                      <td className="font-weight-bold">
                        {transport.license_plate && transport.license_plate}
                      </td>
                    </tr>
                  ) : null}
                  {transport.brand ||
                  isFieldChanged(`vehicles.${index}.brand`, changedFields) ? (
                    <tr
                      className={
                        isFieldChanged(`vehicles.${index}.brand`, changedFields)
                          ? "changed"
                          : ""
                      }
                    >
                      <td className="grey-title">
                        {strings.label_transport_brand + ":"}
                      </td>
                      <td>{transport.brand && transport.brand}</td>
                    </tr>
                  ) : null}
                  {transport.model ||
                  isFieldChanged(`vehicles.${index}.model`, changedFields) ? (
                    <tr
                      className={
                        isFieldChanged(`vehicles.${index}.model`, changedFields)
                          ? "changed"
                          : ""
                      }
                    >
                      <td className="grey-title">
                        {strings.label_transport_model + ":"}
                      </td>
                      <td>{transport.model && transport.model}</td>
                    </tr>
                  ) : null}
                  {transport.color ||
                  isFieldChanged(`vehicles.${index}.color`, changedFields) ? (
                    <tr
                      className={
                        isFieldChanged(`vehicles.${index}.color`, changedFields)
                          ? "changed"
                          : ""
                      }
                    >
                      <td className="grey-title">
                        {strings.label_transport_color + ":"}
                      </td>
                      <td>{transport.color && transport.color}</td>
                    </tr>
                  ) : null}

                  {transport.category ||
                  isFieldChanged(
                    `vehicles.${index}.category`,
                    changedFields
                  ) ? (
                    <tr
                      className={
                        isFieldChanged(
                          `vehicles.${index}.category`,
                          changedFields
                        )
                          ? "changed"
                          : ""
                      }
                    >
                      <td className="grey-title">
                        {strings.label_transport_category + ":"}
                      </td>
                      <td className={`transport-category`}>
                        <span>{transport.category && transport.category}</span>
                        <img
                          src={`${TRANSPORT_ICONS_PATH}/${
                            transport.category
                          }.svg`}
                        />
                      </td>
                    </tr>
                  ) : null}

                  {this.renderTransportDriverName(transport, index)}
                  {this.renderTransportDriverEmail(transport, index)}
                  {this.renderTransportDriverPhoneNumber(transport, index)}
                </tbody>
              </table>
            )}
          </MaterialSurface>
        ))
      : null;
  }

  renderTransportDriverName(transport, index) {
    let changedFields = this.props.changedFields;
    if (transport.driver) {
      return transport.driver.name ||
        transport.driver.surname ||
        isFieldChanged(`vehicles.${index}.driver.name`, changedFields) ||
        isFieldChanged(`vehicles.${index}.driver.surname`, changedFields) ? (
        <tr
          className={
            isFieldChanged(`vehicles.${index}.driver.name`, changedFields) ||
            isFieldChanged(`vehicles.${index}.driver.surname`, changedFields)
              ? "changed"
              : ""
          }
        >
          <td className="grey-title">{strings.label_driver + ":"}</td>
          <td>
            {transport.driver.surname ? transport.driver.surname : ""}{" "}
            {transport.driver.name ? transport.driver.name : ""}
          </td>
        </tr>
      ) : null;
    } else return null;
  }

  renderTransportDriverEmail(transport, index) {
    let changedFields = this.props.changedFields;
    if (transport.driver) {
      return transport.driver.email ||
        isFieldChanged(`vehicles.${index}.driver.email`, changedFields) ? (
        <tr
          className={
            isFieldChanged(`vehicles.${index}.driver.email`, changedFields)
              ? "changed"
              : ""
          }
        >
          <td className="grey-title">
            {strings.label_third_party_email + ":"}
          </td>
          <td>{transport.driver.email ? transport.driver.email : ""}</td>
        </tr>
      ) : null;
    } else return null;
  }

  renderTransportDriverPhoneNumber(transport, index) {
    let changedFields = this.props.changedFields;
    if (transport.driver) {
      return transport.driver.phone_number ||
        isFieldChanged(`vehicles.${index}.driver.phone_number`, changedFields) ? (
        <tr
          className={
            isFieldChanged(`vehicles.${index}.driver.phone_number`, changedFields)
              ? "changed"
              : ""
          }
        >
          <td className="grey-title">
            {strings.label_third_party_phone_number + ":"}
          </td>
          <td>{transport.driver.phone_number ? transport.driver.phone_number : ""}</td>
        </tr>
      ) : null;
    } else return null;
  }
}

export default TransportDetails;
