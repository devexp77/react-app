import React from 'react'


const TopRightButtons = ({children, style}) => (
  <div className="top-right-buttons" style={style || {}}>
    {React.Children.map(
      children,
      (child, index) => (
        <div className="top-right-button" key={index}>
          {child}
        </div>
      )
    )}
  </div>
)

export default TopRightButtons;
