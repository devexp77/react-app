import React from "react";

import strings from "../../localization/all";
import TextareaField from "../Inputs/textarea";
import Buttons from "../../components/ButtonsPanel";

class RequestButtons extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      reject: false,
      comment: "",
      formErrors: {
        comment: "init"
      }
    };
  }

  showRejectForm(show) {
    this.setState({
      reject: show
    });
  }

  validateComment(value) {
    let fieldValidationErrors = this.state.formErrors;
    let commentValid = true;
    fieldValidationErrors.comment = "";

    if (value.length < 1) {
      commentValid = false;
      fieldValidationErrors.comment = strings.hint_comment_too_short;
    }

    this.setState({
      formErrors: fieldValidationErrors
    });

    return commentValid;
  }

  validateBeforeReject() {
    return this.validateComment(this.state.comment);
  }

  rejectRequest() {
    if (this.validateBeforeReject()) {
      if (this.props.canRegister) {
        this.props.registerRequest(false, this.state.comment);
      }

      if (this.props.canApprove) {
        this.props.approveRequest(false, this.state.comment);
      }
    }
  }

  handleInputChange(event) {
    const id = event.target.id;
    const value = event.target.value;
    this.setState({ [id]: value });
    this.validateComment(value);
  }

  render() {
    if (this.props.canRegister || this.props.canApprove || true) {
      return [
        <div
          key={`r_form`}
          className={` reject-form-wrapper clearfix`}
        >
          {this.renderApproveBlock()}

          {this.renderRegisterBlock()}

          {this.renderRejectForm()}
        </div>,

        this.renderEditBlock()
      ];
    } else {
      return null;
    }
  }

  renderRejectForm() {
    return (
      <div
        className={`reject-form clearfix ${this.state.reject && `expanded`}`}
      >
        <TextareaField
          handleInputChange={this.handleInputChange.bind(this)}
          id={`comment`}
          value={this.state.comment}
          label={strings.comment_label}
          focus={true}
          errorClass={this.errorClass.bind(this)}
          error={this.state.formErrors.comment}
        />
        <Buttons
          Submit={this.rejectRequest.bind(this)}
          submitText={strings.button_reject}
          Cancel={() => this.showRejectForm.bind(this)(false)}
        />
      </div>
    );
  }

  renderApproveBlock() {
    return (
      this.props.canApprove && (
        <div
          className={`approve-block clearfix ${this.state.reject &&
            `expanded`}`}
          key={`approve`}
        >
          <button
            className="btn btn-primary waves-effect waves-light"
            onClick={() => this.props.approveRequest(true)}
          >
            {strings.button_approve}
          </button>
          <button
            className="btn btn-flat waves-effect"
            onClick={this.showRejectForm.bind(this)}
          >
            {strings.button_reject}
          </button>
        </div>
      )
    );
  }

  renderRegisterBlock() {
    return (
      this.props.canRegister && (
        <div
          className={`approve-block clearfix ${this.state.reject &&
            `expanded`}`}
          key={`register`}
        >
          <button
            className="btn btn-primary waves-effect waves-light"
            onClick={() => this.props.registerRequest(true)}
          >
            {strings.button_create_permit}
          </button>
          <button
            className="btn btn-flat waves-effect"
            onClick={() => this.showRejectForm.bind(this)(true)}
          >
            {strings.button_reject}
          </button>
        </div>
      )
    );
  }

  renderEditBlock() {
    const record = this.props.record;
    return (
      this.props.canApprove && record.status === "approval:inviter" && (
        <div className="edit-block clearfix" key={`edit`}>
          <i className="material-icons" onClick={this.props.toEdit}>
            mode_edit
          </i>
        </div>
      )
    );
  }

  errorClass(error) {
    if (error.length === 0) {
      return "success";
    } else if (error === "init") {
      return "";
    } else {
      return "wrong";
    }
  }
}

export default RequestButtons;
