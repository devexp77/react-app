import React from "react";
import strings from "../../localization/all";
import format from "string-format";
/*
props
record
*/

class FmRequestRealWorkTime extends React.Component {
  render() {
    if (this.props.record.real_work_time || this.props.record.scheduled_work_time) {
      const real_work_time = this.props.record.real_work_time;
      const scheduled_work_time = this.props.record.scheduled_work_time;
      return (
        <table className={`col-12`}>
          <tbody>
            {
              scheduled_work_time &&
              <tr>
                <td className="grey-title">{strings.label_scheduled_work_time + ":"}</td>
                <td>
                  {format(
                    strings.field_fm_request_real_work_time,
                    Math.round(scheduled_work_time / 60)
                  )}
                </td>
              </tr>
            }

            {
              real_work_time &&
              <tr>
                <td className="grey-title">{strings.label_real_work_time + ":"}</td>
                <td>
                  {format(
                    strings.field_fm_request_real_work_time,
                    Math.round(real_work_time / 60)
                  )}
                </td>
              </tr>
            }
          </tbody>
        </table>
      );
    } else {
      return null;
    }
  }
}

export default FmRequestRealWorkTime;
