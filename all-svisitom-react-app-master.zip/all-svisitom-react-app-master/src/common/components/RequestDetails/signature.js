import React from 'react';

import strings from '../../localization/all'

class RecordNumber extends React.Component {
  	render() {

	    return (

			<table className={`col-12`}>
				<tbody>
					<tr>
						<td className="grey-title"></td>
						<td>
              <img className={`signature-img`} src={this.props.signature} />
						</td>
					</tr>
				</tbody>
			</table>

	 	);

  	}
}


export default RecordNumber;
