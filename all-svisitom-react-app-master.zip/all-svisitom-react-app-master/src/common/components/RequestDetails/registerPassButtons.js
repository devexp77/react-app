import React from "react";

import strings from "../../localization/all";
import { isMobile } from "react-device-detect";
class RegisterPassButtons extends React.Component {
  render() {
    if (!this.props.allowedActions) {
      return null;
    }

    if (
      (this.props.allowedActions.indexOf("in") >= 0 &&
        !this.props.selfAction) ||
      (this.props.selfAction &&
        this.props.allowedActions.indexOf("self_in") >= 0)
    ) {
      return (
        <div className={`permit-pass-block ${isMobile ? "mobile" : ""}`}>
          <div>
            <button
              className="btn btn-primary waves-effect waves-light"
              onClick={this.props.showQRCodeReader}
            >Read QR</button>
          </div>
          <div>
            <button
              className="btn btn-primary waves-effect waves-light"
              onClick={this.props.registerPass}
            >
              {this.props.entityType && this.props.entityType === "transport"
                ? strings.button_register_transport_enter
                : strings.button_register_enter}
            </button>
          </div>
        </div>
      );
    }

    if (
      (this.props.allowedActions.indexOf("out") >= 0 &&
        !this.props.selfAction) ||
      (this.props.selfAction &&
        this.props.allowedActions.indexOf("self_out") >= 0)
    ) {
      return (
        <div className={`permit-pass-block ${isMobile ? "mobile" : ""}`}>
          <div>
            <button
              className="btn btn-primary waves-effect waves-light"
              onClick={this.props.showQRCodeReader}
            >Read QR</button>
          </div>
          <div>
            <button
              className="btn btn-primary waves-effect waves-light"
              onClick={this.props.registerPass}
            >
              {this.props.entityType && this.props.entityType === "transport"
                ? strings.button_register_transport_exit
                : strings.button_register_exit}
            </button>
          </div>
        </div>
      );
    }

    return null;
  }
}

export default RegisterPassButtons;
