import React from "react";

import strings from "../../localization/all";

class Status extends React.Component {
  render() {
    if (this.props.permit) {
      const permit = this.props.record;
      return (
        <table
          className={`col-12`}
        >
          <tbody>
            <tr>
              <td className="grey-title">{strings.label_status + ":"}</td>
              <td className="font-weight-bold">
                {strings["status_permit_" + permit.status]}
              </td>
            </tr>
          </tbody>
        </table>
      );
    } else {
      const record = this.props.record;
      return (
        <table
          className={`col-12`}
        >
          <tbody>
            <tr>
              <td className="grey-title">{strings.label_status + ":"}</td>
              <td className="font-weight-bold">
                {record.status === "registered" && this.props.action ? (
                  <a
                    style={{ color: "blue" }}
                    onClick={() => this.props.action(record.permit_id)}
                  >
                    {strings.status_request_permit_created}
                  </a>
                ) : (
                  strings["status_request_" + record.status] || record.status
                )}
              </td>
            </tr>
          </tbody>
        </table>
      );
    }
  }
}

export default Status;
