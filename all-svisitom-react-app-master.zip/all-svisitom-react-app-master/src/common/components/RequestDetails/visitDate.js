import React from 'react';

import Moment from 'react-moment';
// import 'moment-timezone';

import strings from '../../localization/all'


class VisitDate extends React.Component {
  	render() {

  		var record = this.props.record;
	    return (

			<table className={`col-12`}>
				<tbody>
					<tr>
						<td className="grey-title">{strings.confirm_label_visit_date}:</td>
						<td>
						{record.start_date
                			?	<Moment format="DD.MM.YYYY HH:mm">{record.start_date}</Moment>
                			: 	null
						}
						</td>
					</tr>
				</tbody>
			</table>

	 	);

  	}
}


export default VisitDate;
