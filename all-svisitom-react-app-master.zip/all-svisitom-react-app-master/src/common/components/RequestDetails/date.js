import React from 'react';

import Moment from 'react-moment';
// import 'moment-timezone';

import strings from '../../localization/all'
import {isFieldChanged} from "./checkFields";


class DateDetails extends React.Component {
  render() {

    let record = this.props.record;
    let changedFields = this.props.changedFields;

    return (

      <table className={`col-12`}>
        <tbody>
        <tr className={changedFields && isFieldChanged('start_date', changedFields) ? 'changed' : ''}>
          <td className="grey-title">{strings.label_start_date}:</td>
          <td>
            {record.start_date
              ? <Moment format="DD.MM.YYYY HH:mm">{record.start_date}</Moment>
              : null
            }
          </td>
        </tr>
        <tr className={changedFields && isFieldChanged('end_date', changedFields) ? 'changed' : ''}>
          <td className="grey-title">{strings.label_end_date}:</td>
          <td>
            {record.end_date
              ? <Moment format="DD.MM.YYYY HH:mm">{record.end_date}</Moment>
              : null
            }
          </td>
        </tr>
        </tbody>
      </table>

    );

  }
}


export default DateDetails;
