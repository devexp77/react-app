import React from "react";
import strings from "../../localization/all";
import { isFieldChanged } from "./checkFields";

/*
props
record with transport
*/

class InviterDetails extends React.Component {
  render() {
    if (this.props.record) {
      let record = this.props.record;
      let changedFields = this.props.changedFields;
      return (
        <table
          className={`col-12`}
        >
          <tbody>
          {!this.props.noMargin && (
            <tr>
              <td />
              <td />
            </tr>
          )}

            {(record.inviter &&
              (record.inviter.surname ||
                record.inviter.name ||
                record.inviter.patronymic)) ||
            isFieldChanged("inviter.user_id", changedFields) ? (
              <tr
                className={
                  changedFields &&
                  isFieldChanged("inviter.user_id", changedFields)
                    ? "changed"
                    : ""
                }
              >
                <td className="grey-title">{strings.label_inviter + ":"}</td>
                <td className="font-weight-bold">
                  {record.inviter.surname ? (
                    <span>{record.inviter.surname} </span>
                  ) : null}

                  {record.inviter.name ? (
                    <span>{record.inviter.name} </span>
                  ) : null}

                  {record.inviter.patronymic ? (
                    <span>{record.inviter.patronymic} </span>
                  ) : null}
                </td>
              </tr>
            ) : null}

            {record.addressee &&
            (record.addressee.name ||
              isFieldChanged("addressee.addressee_id", changedFields)) ? (
              <tr
                className={
                  changedFields &&
                  isFieldChanged("addressee.addressee_id", changedFields)
                    ? "changed"
                    : ""
                }
              >
                <td className="grey-title">{strings.label_where + ":"}</td>
                <td>{record.addressee.name && record.addressee.name}</td>
              </tr>
            ) : null}
            {record.room &&
            (record.room.name ||
              isFieldChanged("room.room_id", changedFields)) ? (
              <tr
                className={
                  changedFields && isFieldChanged("room.room_id", changedFields)
                    ? "changed"
                    : ""
                }
              >
                <td className="grey-title">{strings.label_room + ":"}</td>
                <td>{record.room.name && record.room.name}</td>
              </tr>
            ) : null}

          {(record.accompany &&
            (record.accompany.surname ||
              record.accompany.name ||
              record.accompany.patronymic)) ||
          isFieldChanged("accompany.user_id", changedFields) ? (
            <tr
              className={
                changedFields &&
                isFieldChanged("accompany.user_id", changedFields)
                  ? "changed"
                  : ""
              }
            >
              <td className="grey-title">{strings.label_accompany + ":"}</td>
              <td>
                {record.accompany.surname ? (
                  <span>{record.accompany.surname} </span>
                ) : null}

                {record.accompany.name ? (
                  <span>{record.accompany.name} </span>
                ) : null}

                {record.accompany.patronymic ? (
                  <span>{record.accompany.patronymic} </span>
                ) : null}
              </td>
            </tr>
          ) : null}

            {record.visit_reason ||
            isFieldChanged("visit_reason", changedFields) ? (
              <tr
                className={
                  changedFields && isFieldChanged("visit_reason", changedFields)
                    ? "changed"
                    : ""
                }
              >
                <td className="grey-title">
                  {strings.label_visit_reason + ":"}
                </td>
                <td>{record.visit_reason && record.visit_reason}</td>
              </tr>
            ) : null}
          </tbody>
        </table>
      );
    } else {
      return null;
    }
  }
}

export default InviterDetails;
