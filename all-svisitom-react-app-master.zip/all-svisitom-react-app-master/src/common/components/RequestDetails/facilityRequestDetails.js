import React from "react";
import strings from "../../localization/all";

/*
props
record
*/

class FacilityRequestDetails extends React.Component {
  render() {
    if (this.props.record.detail) {
      const detail = this.props.record.detail;
      return (
        <table className={`col-12`}>
          <tbody>
            <tr>
              <td className="grey-title">{strings.label_detail + ":"}</td>
              <td>
                {detail}
              </td>
            </tr>
          </tbody>
        </table>
      );
    } else {
      return null;
    }
  }
}

export default FacilityRequestDetails;
