import React from "react";

import strings from "../../localization/all";
import DeletePopUp from "../DeletePopUp";

class UserRequestButtons extends React.Component {
  render() {
    return [
      <div key={`r_form`} className={`reject-form-wrapper clearfix`}>
        {this.renderApproveBlock()}
      </div>,

      this.renderEditBlock(),

      <DeletePopUp
        deleteFunction={this.props.cancelRequest}
        header={strings.title_revoke_request}
        key={`delete_pop_up`}
        confirmLabel={strings.button_revoke}
      />
    ];
  }

  renderApproveBlock() {
    const record = this.props.record;
    return (
      <div className={`approve-block clearfix`} key={`approve`}>
        {this.props.canSendRequestForApproval && (
          <button
            className="btn btn-primary waves-effect waves-light"
            onClick={() => this.props.approveRequest(true)}
          >
            {strings.button_send_for_approval}
          </button>
        )}
        {this.props.canEdit &&
          record.status !== "cancelled" &&
          record.status !== "rejected" &&
          record.status !== "registered" && (
            <button
              className="btn btn-flat waves-effect"
              data-toggle="modal"
              data-target="#deletePopUp"
            >
              {strings.button_revoke}
            </button>
          )}
      </div>
    );
  }

  renderEditBlock() {
    const record = this.props.record;
    return (
      <div className="edit-block clearfix" key={`edit`}>
        <i className="material-icons" onClick={this.props.toRequestRepeat}>
          loop
        </i>
        {this.props.canEdit &&
          record.status === "review" && (
            <i className="material-icons edit" onClick={this.props.toEdit}>
              mode_edit
            </i>
          )}
      </div>
    );
  }
}

export default UserRequestButtons;
