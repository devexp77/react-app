import React from "react";

import Moment from "react-moment";
// import "moment-timezone";

import strings from "../../localization/all";

class PassInfo extends React.Component {
  render() {
    return (
      <React.Fragment>
        {!this.props.noMargin && (
          <table className={`col-12`}>
            <tbody>
              <tr>
                <td />
                <td />
              </tr>
            </tbody>
          </table>
        )}

        {this.props.recordNumber ? (
          <table className={`col-12`}>
            <tbody>
              <tr>
                <td className="grey-title">
                  {strings.label_number_in_logbook}:
                </td>
                <td>
                  <span className={`href`} onClick={this.props.recordClick}>
                    {this.props.recordNumber}
                  </span>
                </td>
              </tr>
            </tbody>
          </table>
        ) : (
          ""
        )}
        <table className={`col-12`}>
          <tbody>
            <tr>
              <td className="grey-title">
                {this.props.entityType && this.props.entityType === "transport"
                  ? strings.label_transport_enter_time + ":"
                  : strings.label_enter_time + ":"}
              </td>
              <td>
                {this.props.pass_in ? (
                  <Moment format="DD.MM.YYYY HH:mm">
                    {this.props.pass_in}
                  </Moment>
                ) : (
                  ""
                )}
              </td>
              <td>
              {this.props.passInImg && <img className={`signature-img`} src={this.props.passInImg} />}
              </td>
            </tr>
          </tbody>
        </table>


        <table className={`col-12`}>
          <tbody>
            <tr>
              <td className="grey-title">
                {this.props.entityType && this.props.entityType === "transport"
                  ? strings.label_transport_exit_time + ":"
                  : strings.label_exit_time + ":"}
              </td>
              <td style={this.props.beyond_permit ? { color: "red" } : null}>
                {this.props.pass_out ? (
                  <Moment format="DD.MM.YYYY HH:mm">
                    {this.props.pass_out}
                  </Moment>
                ) : (
                  ""
                )}
              </td>
              <td>
                {this.props.passOutImg && <img className={`signature-img`} src={this.props.passOutImg} />}
              </td>
            </tr>
          </tbody>
        </table>
      </React.Fragment>
    );
  }
}

export default PassInfo;
