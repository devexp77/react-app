import React from "react";

import Moment from "react-moment";
// import "moment-timezone";

import strings from "../../localization/all";
import { isFieldChanged } from "./checkFields";

/*
props
record with transport
*/

class DocumentDetails extends React.Component {
  render() {
    let changedFields = this.props.changedFields;
    const index = this.props.index;

    if (
      this.props.document &&
      (this.props.document.doc_type ||
        isFieldChanged(`visitors.${index}.document.doc_type`, changedFields) ||
        isFieldChanged(`visitors.${index}.document.number`, changedFields) ||
        isFieldChanged(`visitors.${index}.document.issue_place`, changedFields) ||
        isFieldChanged(`visitors.${index}.document.issue_date`, changedFields) ||
        isFieldChanged(`visitors.${index}.document.other_info`, changedFields))
    ) {
      let doc = this.props.document;
      return (
        <table
          className={`col-12`}
        >
          <tbody>
            {/*<tr>*/}
            {/*<td />*/}
            {/*<td />*/}
            {/*</tr>*/}

            {doc.doc_type ||
            isFieldChanged(`visitors.${index}.document.doc_type`, changedFields) ? (
              <tr
                className={
                  isFieldChanged(`visitors.${index}.document.doc_type`, changedFields)
                    ? "changed"
                    : ""
                }
              >
                <td className="grey-title">{strings.label_document + ":"}</td>
                <td className="font-weight-bold">
                  {strings['doc_type_' + doc.doc_type]}
                </td>
              </tr>
            ) : null}

            {doc.doc_name ||
            isFieldChanged(`visitors.${index}.document.doc_name`, changedFields) ? (
              <tr
                className={
                  isFieldChanged(`visitors.${index}.document.doc_name`, changedFields)
                    ? "changed"
                    : ""
                }
              >
                <td className="grey-title">{strings.label_document_doc_name + ":"}</td>
                <td className="font-weight-bold">
                  {doc.doc_name}
                </td>
              </tr>
            ) : null}

            {doc.number || isFieldChanged(`visitors.${index}.document.number`, changedFields) ? (
              <tr
                className={
                  isFieldChanged(`visitors.${index}.document.number`, changedFields)
                    ? "changed"
                    : ""
                }
              >
                <td className="grey-title">
                  {strings.label_document_number + ":"}
                </td>
                <td>{doc.number && doc.number}</td>
              </tr>
            ) : null}

            {doc.issue_place ||
            doc.issue_date ||
            (isFieldChanged(`visitors.${index}.document.issue_place`, changedFields) ||
              isFieldChanged(`visitors.${index}.document.issue_date`, changedFields)) ? (
              <tr
                className={
                  isFieldChanged(`visitors.${index}.document.issue_place`, changedFields) ||
                  isFieldChanged(`visitors.${index}.document.issue_date`, changedFields)
                    ? "changed"
                    : ""
                }
              >
                <td className="grey-title">
                  {strings.label_document_issue_date_place + ":"}
                </td>
                <td>
                  {doc.issue_place ? doc.issue_place + ", ": null}
                  {doc.issue_date ? (
                    <span>
                      <Moment format="DD.MM.YYYY">{doc.issue_date}</Moment>
                    </span>
                  ) : null}
                </td>
              </tr>
            ) : null}

            {
            doc.surname ||
            doc.name ||
            doc.other_info ||
            (isFieldChanged(`visitors.${index}.document.name`, changedFields) ||
              isFieldChanged(`visitors.${index}.document.surname`, changedFields) ||
              isFieldChanged(`visitors.${index}.document.other_info`, changedFields)) ? (
              <tr
                className={
                  isFieldChanged(`visitors.${index}.document.name`, changedFields) ||
                  isFieldChanged(`visitors.${index}.document.surname`, changedFields) ||
                  isFieldChanged(`visitors.${index}.document.other_info`, changedFields)
                    ? "changed"
                    : ""
                }
              >
                <td className="grey-title">
                  {strings.label_document_other_info + ":"}
                </td>
                <td>
                  {doc.name ? doc.name + " ": null}
                  {doc.surname ? doc.surname + " ": null}
                  {doc.other_info ? doc.other_info + " ": null}
                </td>
              </tr>
            ) : null}
          </tbody>
        </table>
      );
    } else return null;
  }
}

export default DocumentDetails;
