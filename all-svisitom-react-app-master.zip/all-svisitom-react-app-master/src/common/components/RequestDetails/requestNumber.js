import React from 'react';

import strings from '../../localization/all'

class RequestNumber extends React.Component {
  	render() {

  		var record = this.props.record;
	    return (

			<table className={`col-12`}>
				<tbody>
					<tr>
						<td className="grey-title">{strings.label_request_number+':'}</td>
						<td>
							<span className={`href`} onClick={this.props.onClick}>{record && record.number
	                			?	record.number
	                			: 	null
							}</span>
						</td>
					</tr>
				</tbody>
			</table>

	 	);

  	}
}


export default RequestNumber;
