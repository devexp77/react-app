import React from "react";
import strings from "../../localization/all";

class History extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      expanded: false
    };
  }

  getHistoryIcon(action) {
    switch (action) {
      case "approved":
        return "assignment_turned_in";

      case "rejected":
        return "do_not_disturb_on";

      case "set_request":
        return "edit";

      case "send_for_review":
        return "reply";

      case "send_for_approval":
        return "assignment_turned_in";

      case "cancelled":
        return "cancel";

      case "registered":
        return "assignment_turned_in";

      default:
        return "do_not_disturb_on";
    }
  }

  expandHistory() {
    this.setState({
      expanded: !this.state.expanded
    });
  }

  render() {
    const requestHistory = this.props.requestHistory;
    return (
      <div
        className={`request-history clearfix col-12`}
      >
        <p className={`clearfix`}>
          <span onClick={this.expandHistory.bind(this)}>
            {strings.title_approval_history}{" "}
          </span>

          <i className="material-icons" onClick={this.expandHistory.bind(this)}>
            {this.state.expanded ? "expand_less" : "expand_more"}
          </i>
        </p>
        <ul
          className={`history-container ${
            this.state.expanded ? "expanded" : ""
          }`}
        >
          {requestHistory.map((record, index) => (
            <li key={index}>
              <i className="material-icons">
                {record.action && this.getHistoryIcon(record.action)}
              </i>
              <span>{`${record.surname && record.surname} ${record.name &&
                record.name} ${record.patronymic ? record.patronymic : ""} ${
                record.comment ? "- " + record.comment : ""
              }`}</span>
            </li>
          ))}
        </ul>
      </div>
    );
  }
}

export default History;
