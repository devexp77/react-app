import React from 'react';

import strings from '../../localization/all'

class ObjectName extends React.Component {
    render() {
        const record = this.props.record;
        return (
            <table className={`col-12`}>
                <tbody>
                <tr>
                    <td className="grey-title">{strings.label_object + ':'}</td>
                    <td className={`font-weight-bold`}>
                        {record.object && record.object.name
                            ? record.object.name
                            : null
                        }
                    </td>
                </tr>
                </tbody>
            </table>
        );
    }
}

export default ObjectName;
