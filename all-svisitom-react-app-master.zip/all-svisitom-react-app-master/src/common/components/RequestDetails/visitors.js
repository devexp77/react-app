import React from "react";
import Request from "../RequestDetails";
import update from "immutability-helper";
import MaterialSurface from "../PageContainers/materialSurface";
import strings from "../../localization/all";
import { Link } from "react-router";
/*
props
record
*/

class Visitors extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      visitorsIndexes: []
    };
  }

  componentDidMount() {
    if (this.props.handleCheckerChange) {
      const visitors = this.props.record.visitors;
      let visitorsIndexes = [];
      for (let i = 0; i < visitors.length; i++) {
        if (visitors[i].approved !== false) {
          visitorsIndexes.push(i);
        }
      }

      this.setState({ visitorsIndexes: visitorsIndexes }, function() {
        this.props.handleCheckerChange(this.state.visitorsIndexes);
      });
    }
  }

  checkerOnChange(event) {
    const id = event.target.id;
    const checked = event.target.checked;
    if (checked) {
      this.setState(
        {
          visitorsIndexes: update(this.state.visitorsIndexes, {
            $push: [Number(id)]
          })
        },
        function() {
          this.props.handleCheckerChange(this.state.visitorsIndexes);
        }
      );
    } else {
      let visitorsIndexes = this.state.visitorsIndexes.slice(0);

      visitorsIndexes.splice(visitorsIndexes.indexOf(Number(id)), 1);
      this.setState(
        {
          visitorsIndexes: visitorsIndexes
        },
        function() {
          this.props.handleCheckerChange(this.state.visitorsIndexes);
        }
      );
    }
  }

  isChecked(index) {
    return this.state.visitorsIndexes.indexOf(index) > -1;
  }

  render() {
    let changedFields = this.props.changedFields;

    if (this.props.record.visitors) {
      const visitors = this.props.record.visitors;
      const status = this.props.record.status ? this.props.record.status : "";

      return visitors.map((visitor, index) => (
        <MaterialSurface marginBottom key={index}>
          {this.props.checker &&
            (visitor.approved !== false && !visitor.permit_id) && (
              <div className="form-group checker">
                <input
                  type="checkbox"
                  id={index}
                  onChange={this.checkerOnChange.bind(this)}
                  checked={this.isChecked.bind(this)(index)}
                />
                <label htmlFor={index}>
                  {status === "approved" || status === "registered"
                    ? strings.button_create_permit
                    : strings.button_approve}
                </label>
              </div>
            )}

          {visitor.approved === false && (
            <div className={`clearfix`}>
              <i
                className="material-icons float-left"
                style={{ marginRight: "12px" }}
              >
                close
              </i>
              <p className={`float-left`} style={{ marginBottom: "8px" }}>
                {strings.status_item_rejected}
              </p>
            </div>
          )}

          {visitor.permit_id && (
            <div
              className={`clearfix`}
              style={this.props.onPermitClick ? { cursor: "pointer" } : null}
              onClick={
                this.props.onPermitClick
                  ? () => this.props.onPermitClick(visitor.permit_id)
                  : null
              }
            >
              <i
                className="material-icons float-left"
                style={
                  this.props.onPermitClick
                    ? { marginRight: "12px", color: "#207ea9" }
                    : { marginRight: "12px" }
                }
              >
                check_circle
              </i>
              <p
                className={`float-left`}
                style={
                  this.props.onPermitClick
                    ? { marginBottom: "8px", color: "#207ea9" }
                    : { marginBottom: "8px" }
                }
              >
                {strings.status_request_registered}
              </p>
            </div>
          )}

          <Request.Visitor
            key={`visitor-${index}`}
            visitor={visitor}
            changedFields={changedFields}
            index={index}
            noMargin
          />
          {visitor.document && (
            <Request.Document
              key={`visitor-document-${index}`}
              document={visitor.document}
              changedFields={changedFields}
              index={index}
            />
          )}
        </MaterialSurface>
      ));
    } else {
      return null;
    }
  }
}

export default Visitors;
