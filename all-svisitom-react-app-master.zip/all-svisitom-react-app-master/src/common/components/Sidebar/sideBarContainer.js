import React, { Component } from "react";

import { PROTOCOL, HOST_NAME } from "../../../common/constants";

import common_strings from "../../../common/localization/all";

class SidebarContainer extends Component {
  componentDidMount() {
    $(document).on("click touch", ".menu-toogle", function(e) {
      var menu = $(".menu");
      var nav = $(".margin-for-menu");

      if (menu.hasClass("menu-hidden")) {
        menu.addClass("slideInLeft");
        menu.removeClass("menu-hidden");
        $("#root").append('<div class="disable-bg animated fadeIn"></div>');
      } else {
        menu.removeClass("slideInLeft");
        menu.addClass("slideOutLeft");
        $("div.disable-bg").removeClass("fadeIn");
        $("div.disable-bg").addClass("fadeOut");
        menu.one(
          "webkitAnimationEnd mozAnimationEnd MSAnimationEnd oanimationend animationend",
          function() {
            if (menu.hasClass("slideOutLeft")) {
              menu.addClass("menu-hidden");
              $("div.disable-bg").remove();
              menu.removeClass("slideOutLeft");
            }
          }
        );
      }
    });

    $("body").on("mouseup touchend", function(e) {
      var menu = $(".menu");
      var li = $(".list-group-item");

      if (
        !menu.is(e.target) &&
        menu.has(e.target).length == 0 &&
        $(document).width() <= 768
      ) {
        if (!menu.hasClass("menu-hidden")) {
          menu.removeClass("slideInLeft");
          menu.addClass("slideOutLeft");
          $("div.disable-bg").removeClass("fadeIn");
          $("div.disable-bg").addClass("fadeOut");
          menu.one(
            "webkitAnimationEnd mozAnimationEnd MSAnimationEnd oanimationend animationend",
            function() {
              if (menu.hasClass("slideOutLeft")) {
                menu.addClass("menu-hidden");
                menu.removeClass("slideOutLeft");
                $("div.disable-bg").remove();
              }
            }
          );
        }
      }

      if (
        li.is(e.target) ||
        (!li.has(e.target).length == 0 && $(document).width() <= 768)
      ) {
        if (!menu.hasClass("menu-hidden")) {
          menu.removeClass("slideInLeft");
          menu.addClass("slideOutLeft");
          $("div.disable-bg").removeClass("fadeIn");
          $("div.disable-bg").addClass("fadeOut");
          menu.one(
            "webkitAnimationEnd mozAnimationEnd MSAnimationEnd oanimationend animationend",
            function() {
              if (menu.hasClass("slideOutLeft")) {
                menu.addClass("menu-hidden");
                menu.removeClass("slideOutLeft");
                $("div.disable-bg").remove();
              }
            }
          );
        }
      }
    });
  }

  componentWillUnmount() {
    $(document).off("click touch", ".menu-toogle");
    $("body").off("mouseup touchend");
  }

  render() {
    return (
      <div className="menu animated menu-hidden">
        {/*<div className="menu-brand-container">*/}
          {/*<a href={this.props.href || "/#/"} className="menu-brand">*/}
            {/*{this.props.imgPath && (*/}
                {/*<img*/}
                  {/*src={this.props.imgPath}*/}
                {/*/>*/}
              {/*)}*/}

            {/*{this.props.icon && (*/}
              {/*<i className="material-icons">{this.props.icon}</i>*/}
            {/*)}*/}

            {/*{!this.props.imgPath && !this.props.icon && (*/}
              {/*<img*/}
                {/*src={`${PROTOCOL}//cdn.${HOST_NAME}/img/logo/logo-blue-64.png`}*/}
              {/*/>*/}
            {/*)}*/}

            {/*{this.props.productName || common_strings.product_name}*/}
          {/*</a>*/}
        {/*</div>*/}
        <ul className="nav-mobile list-group">{this.props.children}</ul>
      </div>
    );
  }
}

export default SidebarContainer;
