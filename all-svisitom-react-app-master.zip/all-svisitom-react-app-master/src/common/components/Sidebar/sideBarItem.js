import React, { Component } from "react";
import { connect } from "react-redux";
import { Link } from "react-router";
import Icon from "../Icon";

/*
link
icon
title
regular
enabled
*/

class sideBarItem extends Component {
  render() {
    const { routerPrevPath } = this.props.router;
    return (
      <li
        className={`list-group-item list-group-item-action
        ${this.props.enabled ? "waves-effect" : "disabled-item"}
        ${
          this.props.regular && routerPrevPath.match(this.props.regular)
            ? "selected"
            : ""
        }`}
      >
        {this.props.enabled ? (
          this.props.onClick ?
            <Link onClick={this.props.onClick}>
              <Icon name={this.props.icon} />
              {this.props.title}
            </Link>
            :
          this.props.href ? (
            <a href={this.props.href} target={this.props.blank && "_blank"}>
              <Icon name={this.props.icon} />
              {this.props.title}
            </a>
          ) : (
            <Link to={this.props.link}>
              <Icon name={this.props.icon} />
              {this.props.title}
            </Link>
          )
        ) : (
          <div>
            <Icon name={this.props.icon} />
            {this.props.title}
          </div>
        )}

        {this.props.children}

        {this.props.arrowIcon && (
          <Icon name={`sv-icon-keyboard-arrow-right`} className={`arrow-icon`} />
        )}
      </li>
    );
  }
}

sideBarItem.defaultProps = {
  enabled: true
};

const mapStateToProps = (state, ownProps) => {
  return {
    router: state.router
  };
};

export default connect(mapStateToProps)(sideBarItem);
