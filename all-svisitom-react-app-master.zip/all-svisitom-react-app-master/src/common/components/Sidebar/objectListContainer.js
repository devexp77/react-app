import React, { Component } from "react";

class ProfileList extends Component {
  render() {
    return <ul className="nav-mobile list-group object-list clearfix">{this.props.children}</ul>;
  }
}

export default ProfileList;
