import React, {Component} from 'react'

class sideBarLine extends Component {

  render(){
    return(
      <hr className="sidebar-line"/> 
      )
  }

}


export default sideBarLine
