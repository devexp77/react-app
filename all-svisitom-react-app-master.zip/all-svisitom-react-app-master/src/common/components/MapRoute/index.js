import React from "react";
import { GOOGLE_MAP_URL } from "../../constants";

class MapRoute extends React.Component {
  constructor() {
    super();
    this.state = {};
    this.polyline = null;
  }

  componentDidMount() {
    $.getScript(GOOGLE_MAP_URL, () => {
      if (this.props.state === "view") {
        this.initializeView();
      } else {
        this.initialize();
      }
    });
  }

  initializeView() {
    const { mapCenter } = this.props;
    if (mapCenter) {
      var latLng = new google.maps.LatLng(mapCenter[0], mapCenter[1]);
    } else {
      var latLng = new google.maps.LatLng(55.755826, 37.617299900000035);
    }
    const mapOptions = {
      zoom: 17,
      center: latLng
    };

    var map = new google.maps.Map(
      document.getElementById("map-canvas"),
      mapOptions
    );

    let popylineCoords = [];
      for (let polyline of this.props.polylineCoords) {
        popylineCoords.push({ lat: polyline[0], lng: polyline[1] });
      }


    this.polyline = new google.maps.Polyline({
      path: popylineCoords,
      strokeColor: "#FF0000",
      strokeOpacity: 1.0,
      strokeWeight: 2,
      editable: false,
      draggable: false
    });

    this.polyline.setMap(map);
  }

  initialize() {
    const { mapCenter } = this.props;
    if (mapCenter) {
      var latLng = new google.maps.LatLng(mapCenter[0], mapCenter[1]);
    } else {
      var latLng = new google.maps.LatLng(55.755826, 37.617299900000035);
    }
    const mapOptions = {
      zoom: 17,
      center: latLng
    };

    var map = new google.maps.Map(
      document.getElementById("map-canvas"),
      mapOptions
    );

    let popylineCoords = [];
    if (this.props.state === "edit" && this.props.polylineCoords) {
      for (let polyline of this.props.polylineCoords) {
        popylineCoords.push({ lat: polyline[0], lng: polyline[1] });
      }
    }

    this.polyline = new google.maps.Polyline({
      path: popylineCoords,
      strokeColor: "#FF0000",
      strokeOpacity: 1.0,
      strokeWeight: 2,
      editable: true,
      draggable: true
    });

    google.maps.event.addListener(
      this.polyline,
      "dragend",
      this.getPath.bind(this)
    );
    google.maps.event.addListener(map, "click", this.addPoint.bind(this));
    google.maps.event.addListener(
      this.polyline.getPath(),
      "insert_at",
      this.getPath.bind(this)
    );
    google.maps.event.addListener(
      this.polyline.getPath(),
      "remove_at",
      this.getPath.bind(this)
    );
    google.maps.event.addListener(
      this.polyline.getPath(),
      "set_at",
      this.getPath.bind(this)
    );
    this.polyline.setMap(map);
  }

  addPoint(event) {
    let path = this.polyline.getPath();
    path.push(event.latLng);
    this.getPath();
  }

  getPath() {
    let path = this.polyline.getPath().getArray();
    let coords = [];

    for (let i = 0; i < path.length; i++) {
      let lat = path[i].lat();
      let lng = path[i].lng();
      coords.push([lat, lng]);
    }

    this.props.onRouteChange ? this.props.onRouteChange(coords) : null;
  }

  render() {
    return (
      <div>
        <div id="map-canvas" style={{ minHeight: "400px", width: "100%" }} />
      </div>
    );
  }
}

export default MapRoute;
