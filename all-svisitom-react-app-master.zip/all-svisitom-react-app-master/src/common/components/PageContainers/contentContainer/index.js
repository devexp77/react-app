import React from 'react';

import './style.css'

/*
childrens
*/

class ContainerPage extends React.Component {
	render() {
		return (
		
				<div className="container container-content">
					<div className = "content clearfix">
						{this.props.children} 
					</div>
				</div>	
			);
	}
}


export default ContainerPage;
