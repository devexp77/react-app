import React from "react";

import "./style.css";

/*
childrens
*/

class MaterialSurface extends React.Component {
  render() {
    return (
      <div
        className={`material-surface
        ${this.props.noPadding ? " no-padding" : ""}
        ${this.props.marginTop ? " margin-top" : ""}
        ${this.props.marginBottom ? " margin-bottom" : ""}
        ${this.props.smallPadding ? " small-padding" : ""}
        ${this.props.className ? this.props.className : ""}
        `}
        style={{
          height: this.props.height ? this.props.height : "auto",
          padding: this.props.padding ? this.props.padding : ""
        }}
      >
        {this.props.children}
      </div>
    );
  }
}

export default MaterialSurface;
