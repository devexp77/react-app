import React from 'react';

import PageWithSidebar from '../pageWithSidebar'

import './style.css'

/*
childrens
*/

class ContainerWithCustomPadding extends React.Component {
	render() {
		return (
			<PageWithSidebar>
				<div className="container custom-padding">
					{this.props.children} 
				</div>	
			</PageWithSidebar>	
			);
	}
}


export default ContainerWithCustomPadding;
