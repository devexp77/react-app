import React from 'react';

import './style.css'

const LandingPage = ({children, withNavPanel}) => (
  <div className={`container landing-page ${withNavPanel ? "with-nav-panel" : ""}`}>
    {children}
  </div>
)

const LandingPageSection = ({children}) => (
  <div className="landing-page-section">
    {children}
  </div>
)

export {LandingPage, LandingPageSection}
