import React from 'react';

import PageWithSidebar from '../pageWithSidebar'
import './style.css'

/*
pageTitle
childrens
*/

class EditPage extends React.Component {
  render() {
  	return (
        <PageWithSidebar>
        	<div className="container edit-page">
          	<h5>{this.props.pageTitle}</h5>
          	<div className="form clearfix">
		        {this.props.children} 
		        </div>
		      </div>
        </PageWithSidebar>	
 		
);
  }
}


export default EditPage;
