import React from "react";
import "./style.css";

/*
childrens
*/

class SinglePageWithCustomPadding extends React.Component {
  render() {
    return (
      <div
        className="container single-custom-padding"
        style={this.props.width ? { maxWidth: this.props.width } : null}
      >
        {this.props.children}
      </div>
    );
  }
}

export default SinglePageWithCustomPadding;
