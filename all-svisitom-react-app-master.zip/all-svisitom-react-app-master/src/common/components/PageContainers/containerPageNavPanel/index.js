import React from 'react';

import './style.css'

/*
childrens
*/

class ContainerPageNavPanel extends React.Component {
	render() {
		return (
		
				<div className="container container-content-nav">
						{this.props.children}
				</div>	
			);
	}
}


export default ContainerPageNavPanel;
