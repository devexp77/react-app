import React from 'react';

import PageWithSidebar from '../pageWithSidebar'

import './style.css'

/*
childrens
*/

class ContainerPage extends React.Component {
	render() {
		return (
				<div className="container top-padding">
					{this.props.children} 
				</div>
			);
	}
}


export default ContainerPage;
