import React from 'react';

import './style.css'

/*
childrens
*/

class PageWithSidebar extends React.Component {
  render() {
  	return (

        <div className="page-with-sidebar clearfix">
		        {this.props.children} 
        </div>	
);
  }
}


export default PageWithSidebar;
