import React from 'react';

import PageWithSidebar from '../pageWithSidebar'
import './style.css'

/*
pageTitle
childrens
*/

class EditSinglePage extends React.Component {
  render() {
  	return (
        	<div className="container edit-single-page">
          	{this.props.pageTitle && <h5>{this.props.pageTitle}</h5>}
          	<div className="form clearfix">
		        {this.props.children} 
		        </div>
		      </div>
 		
);
  }
}


export default EditSinglePage;
