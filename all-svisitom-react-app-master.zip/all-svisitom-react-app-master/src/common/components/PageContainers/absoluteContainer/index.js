import React from 'react';

import './style.css'

/*
childrens
*/

class AbsoluteContainer extends React.Component {
	render() {
		return (
		
				<div className={`absolute ${this.props.marginClass}`}>
					{this.props.children} 
				</div>	
			);
	}
}


export default AbsoluteContainer;
