import React from "react";
import "./style.css";

/*
childrens
*/

class SinglePageWithCustomPaddingNavPanel extends React.Component {

  render() {
    return (
      <div
        className={`container single-custom-padding-nav ${this.props.className || ""}`}
        style={this.props.width ? { maxWidth: this.props.width } : null}
      >
        {this.props.children}
      </div>
    );
  }
}

export default SinglePageWithCustomPaddingNavPanel;
