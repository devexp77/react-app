import React from "react";
import isTouchDevice from "../../util/isTouchDevice";

class Tooltip extends React.Component {
  componentDidMount() {
    this.tooltipInit();
  }

  tooltipInit() {
    if (!isTouchDevice()) {
      $(`#${this.props.id}`).tooltip();
      $(`#${this.props.id}`).click(function() {
        if (this.props && this.props.id) {
          $(`#${this.props.id}`).tooltip("hide");
        }
      });
    }
  }

  render() {
    return (
      <div
        data-toggle="tooltip"
        data-placement="bottom"
        title={this.props.title}
        id={this.props.id}
        className={`clearfix`}
        style={this.props.style || {}}
      >
        {this.props.children}
      </div>
    );
  }

  componentWillUnmount() {
    $(`#${this.props.id}`).tooltip("hide");
  }
}

export default Tooltip;
