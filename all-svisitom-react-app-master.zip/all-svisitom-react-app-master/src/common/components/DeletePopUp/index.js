import React from "react";
import "./style.css";

import strings from "../../localization/all";
import { FlatButton } from "../Button";

/*
props
header
deleteFunction
*/

class DeletePopUp extends React.Component {
  open = () => {
    const id = this.props.id || "deletePopUp";
    $("#" + id).modal("show");
  };

  render() {
    return (
      <div
        className="modal fade"
        id={this.props.id ? this.props.id : `deletePopUp`}
        tabIndex="-1"
        role="dialog"
        aria-labelledby="exampleModalLabel"
        aria-hidden="true"
      >
        <div className="modal-dialog modal-sm" role="document">
          <div className="modal-content">
            <div className="modal-body">{this.props.header}</div>
            <div className="modal-footer">
              <FlatButton position={`right`} data-dismiss="modal">
                {strings.button_cancel}
              </FlatButton>

              <FlatButton
                position={`right`}
                data-dismiss="modal"
                onClick={this.props.deleteFunction}
              >
                {this.props.confirmLabel
                  ? this.props.confirmLabel
                  : strings.button_delete}
              </FlatButton>
            </div>
          </div>
        </div>
      </div>
    );
  }
}

export default DeletePopUp;
