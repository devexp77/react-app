import React from "react";
import Moment from "react-moment";

import strings from "../../../object/localization/all";
import common_strings from "../../localization/all";

import "./style.css";
import { connect } from "react-redux";
import Icon from "../Icon";
import Tooltip from "../Tooltip";

class RequestRow extends React.Component {
  getImagePath(user_id) {
    let imgSrc = "";
    if (
      this.props.image.usersImage.result &&
      this.props.image.usersImage.result[user_id]
    ) {
      imgSrc = this.props.image.usersImage.result[user_id];
    }

    return imgSrc;
  }

  renderAccompany(record) {
    if (record.accompany && record.accompany.surname) {
      return (
        <Tooltip
          title={common_strings.label_accompany}
          id={`accompany-${record.permit_id}`}
          style={{ float: "left", height: "34px" }}
        >
          <div className={`accompany-block clearfix`}>
            <Icon name={`supervised_user_circle`} />

            <div className="accompany-name">
              {record.accompany && record.accompany.surname ? (
                <span>{record.accompany.surname} </span>
              ) : null}
              {record.accompany && record.accompany.name ? (
                <span>{record.accompany.name.substring(0, 1)}. </span>
              ) : null}
              {record.accompany && record.accompany.patronymic ? (
                <span>{record.accompany.patronymic.substring(0, 1)}.</span>
              ) : null}
            </div>
          </div>
        </Tooltip>
      );
    } else return null;
  }

  renderPerson(record) {
    let imgPath = "";
    if (
      record.visitor &&
      record.visitor.user_id &&
      this.getImagePath(record.visitor.user_id)
    ) {
      imgPath = this.getImagePath(record.visitor.user_id);
    }
    return (
      <div className={`person-block clearfix`}>
        <div className="icon">
          {imgPath ? (
            <img src={imgPath} />
          ) : (
            <i className="material-icons">account_circle</i>
          )}
        </div>

        <div className="person-name">
          {record.visitor && record.visitor.surname ? (
            <span>{record.visitor.surname} </span>
          ) : null}
          {record.visitor && record.visitor.name ? (
            <span>{record.visitor.name} </span>
          ) : null}
        </div>
        <div className="person-patronymic">
          {record.visitor && record.visitor.patronymic ? (
            <span>{record.visitor.patronymic} </span>
          ) : null}
        </div>
      </div>
    );
  }

  renderTransport(record) {
    return (
      <div className={`transport-block clearfix`}>
        <div className="icon">
          <i className="material-icons">directions_car</i>
        </div>

        <div className="person-name">
          {record.transport && record.transport.brand ? (
            <span>{record.transport.brand} </span>
          ) : null}
          {record.transport && record.transport.model ? (
            <span>{record.transport.model} </span>
          ) : null}
        </div>
        <div className="person-patronymic">
          {record.transport && record.transport.license_plate ? (
            <span>{record.transport.license_plate} </span>
          ) : null}
        </div>
        <div className="person-patronymic">
          {record.transport &&
          record.transport.driver &&
          record.transport.driver.surname ? (
            <span>{record.transport.driver.surname} </span>
          ) : null}
          {record.transport &&
          record.transport.driver &&
          record.transport.driver.name ? (
            <span>{record.transport.driver.name.substring(0, 1)}. </span>
          ) : null}
          {record.transport &&
          record.transport.driver &&
          record.transport.driver.patronymic ? (
            <span>{record.transport.driver.patronymic.substring(0, 1)}.</span>
          ) : null}
        </div>
      </div>
    );
  }

  getEnterTime(permit) {
    const logbookRecordsByIds = this.props.logbookRecordsByIds.result
      ? this.props.logbookRecordsByIds.result.slice().reverse()
      : null;
    const transportLogbookRecordsByIds = this.props.transportLogbookRecordsByIds
      .result
      ? this.props.transportLogbookRecordsByIds.result.slice().reverse()
      : null;

    if (permit.entity_type === "visitor" && logbookRecordsByIds) {
      if (
        logbookRecordsByIds.find(
          record => record.record_id === permit.last_record_id
        ) &&
        logbookRecordsByIds.find(
          record => record.record_id === permit.last_record_id
        ).pass_in
      ) {
        return logbookRecordsByIds.find(
          record => record.record_id === permit.last_record_id
        ).pass_in.date;
      }
      return null;
    }

    if (permit.entity_type === "transport" && transportLogbookRecordsByIds) {
      if (
        transportLogbookRecordsByIds.find(
          record => record.record_id === permit.last_record_id
        ) &&
        transportLogbookRecordsByIds.find(
          record => record.record_id === permit.last_record_id
        ).pass_in
      ) {
        return transportLogbookRecordsByIds.find(
          record => record.record_id === permit.last_record_id
        ).pass_in.date;
      }
      return null;
    }

    return null;
  }

  getExitTime(permit) {
    const logbookRecordsByIds = this.props.logbookRecordsByIds.result
      ? this.props.logbookRecordsByIds.result.slice().reverse()
      : null;
    const transportLogbookRecordsByIds = this.props.transportLogbookRecordsByIds
      .result
      ? this.props.transportLogbookRecordsByIds.result.slice().reverse()
      : null;

    if (permit.entity_type === "visitor" && logbookRecordsByIds) {
      if (
        logbookRecordsByIds.find(
          record => record.record_id === permit.last_record_id
        ) &&
        logbookRecordsByIds.find(
          record => record.record_id === permit.last_record_id
        ).pass_out
      ) {
        return logbookRecordsByIds.find(
          record => record.record_id === permit.last_record_id
        ).pass_out.date;
      }
      return null;
    }

    if (permit.entity_type === "transport" && transportLogbookRecordsByIds) {
      if (
        transportLogbookRecordsByIds.find(
          record => record.record_id === permit.last_record_id
        ) &&
        transportLogbookRecordsByIds.find(
          record => record.record_id === permit.last_record_id
        ).pass_out
      ) {
        return transportLogbookRecordsByIds.find(
          record => record.record_id === permit.last_record_id
        ).pass_out.date;
      }
      return null;
    }

    return null;
  }

  renderPermitNumber (record) {
    return (
        <td className={`permit-number`}>{record.number}</td>
      );
  }

  renderPermitDate (record, start_date, end_date) {
    return (
        <td className={`permit-date`}>
          <p>
            <Moment format="L" locale={strings.getLanguage()}>
              {record.start_date}
            </Moment>
          </p>
          {new Date(
            start_date.getFullYear(),
            start_date.getMonth(),
            start_date.getDate()
          ).toISOString() !==
            new Date(
              end_date.getFullYear(),
              end_date.getMonth(),
              end_date.getDate()
            ).toISOString() && (
            <p>
              <Moment format="L" locale={strings.getLanguage()}>
                {record.end_date}
              </Moment>
            </p>
          )}
          {record.permit_type === "multiple_use" && (
            <Tooltip
              title={common_strings.permit_type_multiple_use}
              id={`${record.permit_type}-${record.permit_id}`}
            >
              <Icon name={`sv-icon-${record.permit_type}`} />
            </Tooltip>
          )}
        </td>
      );
  }

  renderPermitStatus (record) {
    return (
        <td className={`permit-status`}>
          <div
            title={
              common_strings["status_permit_" + record.status] +
              (record.is_suspended
                ? ` (${common_strings.permit_suspended})`
                : "")
            }
            className={`status ${record.status} `}
            onClick={e => {
              e.stopPropagation();
              this.props.statusClick();
            }}
          >
            <div className={record.is_suspended ? "suspended" : ""} />
          </div>

          {record.visitor_is_waiting ? (
            <div
              onClick={e => {
                e.stopPropagation();
                this.props.visitorClick();
              }}
            >
              <Icon name={`sv-icon-arrives`} style={{ color: "#ffcc00" }} />
            </div>
          ) : (
            <div
              onClick={e => {
                e.stopPropagation();
                this.props.visitorClick();
              }}
            >
              <Icon name={`sv-icon-` + record.entity_status} />
            </div>
          )}
        </td>
      );
  }

  renderPassIn (record) {
    return (
        <td className={`permit-pass-in`}>
          {this.getEnterTime(record) ? (
            <React.Fragment>
              <p>
                <Moment format="L" locale={strings.getLanguage()}>
                  {this.getEnterTime(record)}
                </Moment>
              </p>
              <p>
                <Moment format="LT" locale={strings.getLanguage()}>
                  {this.getEnterTime(record)}
                </Moment>
              </p>
            </React.Fragment>
          ) : (
            ""
          )}
        </td>
      );
  }

  renderPassOut (record) {
    return (
        <td className={`permit-pass-out`}>
          {this.getExitTime(record) ? (
            <React.Fragment>
              <p>
                <Moment format="L" locale={strings.getLanguage()}>
                  {this.getExitTime(record)}
                </Moment>
              </p>
              <p>
                <Moment format="LT" locale={strings.getLanguage()}>
                  {this.getExitTime(record)}
                </Moment>
              </p>
            </React.Fragment>
          ) : (
            ""
          )}
        </td>
      );
  }

  renderVisitor (record) {
    return (
        <td className={`permit-visitor`}>
          {record.entity_type === "visitor" && this.renderPerson(record)}
          {record.entity_type === "transport" && this.renderTransport(record)}
          {this.renderAccompany(record)}
        </td>
      );
  }

  renderCompany (record) {
    return (
        <td className={`permit-company`}>
          <div className="person-company">
            {record.visitor && record.visitor.company ? (
              <span>{record.visitor.company} </span>
            ) : null}
          </div>

          <div className="person-jobtitle">
            {record.visitor && record.visitor.job_title ? (
              <span>{record.visitor.job_title} </span>
            ) : null}
          </div>
        </td>
      );
  }

  renderAddressee (record) {
    return (
        <td className={`permit-addressee`}>
          <div className="addressee">
            {record.addressee && record.addressee.name ? (
              <span>{record.addressee.name} </span>
            ) : null}
          </div>
          <div
            className="addressee"
            onClick={e => {
              e.stopPropagation();
              this.props.roomClick();
            }}
          >
            {record.room && record.room.name ? (
              <span>{record.room.name} </span>
            ) : (
              <a>Назначить помещение</a>
            )}
          </div>
          <div className="inviter">
            {record.inviter && record.inviter.surname ? (
              <span>{record.inviter.surname} </span>
            ) : null}
            {record.inviter && record.inviter.name ? (
              <span>{record.inviter.name.substring(0, 1)}. </span>
            ) : null}
            {record.inviter && record.inviter.patronymic ? (
              <span>{record.inviter.patronymic.substring(0, 1)}.</span>
            ) : null}
          </div>
        </td>
      );
  }

  render() {
    let record = this.props.record;
    const start_date = new Date(record.start_date);
    const end_date = new Date(record.end_date);

    return (
      <tr
        className={`permit-row`}
        onClick={() => this.props.action(record.permit_id)}
      >
        
        {/*this.renderPermitNumber(record)
        this.renderPermitDate(record, start_date, end_date)
        this.renderPermitStatus(record)
        this.renderPassIn(record)
        this.renderPassOut(record)
        this.renderVisitor(record)
        this.renderCompany(record)
        this.renderAddressee(record)*/}

        {this.props.table.columns.map(col => {
          if (!col.visible) return;
          if (col.content == 'logbook_record_no') return this.renderPermitNumber(record)
          if (col.content == 'dashboard_visit_date') return this.renderPermitDate(record, start_date, end_date)
          if (col.content == 'dashboard_permit_status') return this.renderPermitStatus(record)
          if (col.content == 'dashboard_time_enter') return this.renderPassIn(record)
          if (col.content == 'dashboard_time_exit') return this.renderPassOut(record)
          if (col.content == 'logbook_visitor_fio') return this.renderVisitor(record)
          if (col.content == 'dashboard_visitor_company') return this.renderCompany(record)
          if (col.content == 'logbook_inviter_fio') return this.renderAddressee(record)
          return;
        })}

        <td className={`permit-children`}>{this.props.children}</td>
      </tr>
    );
  }
}

const mapStateToProps = state => {
  return {
    image: state.image
  };
};

export default connect(mapStateToProps)(RequestRow);
