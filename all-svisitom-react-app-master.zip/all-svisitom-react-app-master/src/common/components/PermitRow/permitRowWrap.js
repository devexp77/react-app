import React from "react";
import strings from "../../../object/localization/all"

import "../../../object/components/jquery-resizable-columns";
import { Container, Draggable } from 'react-smooth-dnd';
import CheckerField from "../../../common/components/Inputs/checkerField";

// import "jquery-resizable-columns";

function FacilityRequestTableStore () {
  this.set = function (k, v) {
    window.localStorage.setItem(`permitsTable_${k}`, v);
  }
  this.get = function (k) {
    return Number( window.localStorage.getItem(`permitsTable_${k}`) );
  }
}

class PermitRowWrap extends React.Component {

  componentDidMount() {
    $.resizableColumns.prototype.generateColumnId = function ($el) {
      return $el[0].id;
    };

    this.resizableColumns = $("table").resizableColumns({
      store: new FacilityRequestTableStore(),
      resizeFromBody: false,
      storagePrefix: 'permitsTable',
      minWidth: 5
    });
  }

  componentDidUpdate () {
    $('table').resizableColumns('destroy');
    this.resizableColumns = $("table").resizableColumns({
      store: new FacilityRequestTableStore(),
      resizeFromBody: false,
      storagePrefix: 'permitsTable',
      minWidth: 5
    });
  }

  showTableSettings (e) {
    var y = document.getElementsByClassName('permits-table')[0].getBoundingClientRect().y;
    document.getElementById("facility-requests-table-settings-container").style["top"] = y + "px";
    document.getElementById("facility-requests-table-settings-close").style["top"] = (y + 18) + "px";
    document.getElementById("facility-requests-table-settings").style["display"] = "block"; 
    document.body.style.overflowY = "hidden";
  }

  closeTableSettings (e) {
    document.getElementById("facility-requests-table-settings").style["display"] = "none";
    document.body.style.overflowY = "auto";
  }

  get_i18n_title(title_string) {
    return strings[title_string.split('.')[1]];
  }

  change_visibility(c) {
    c.visible = !c.visible;
    this.props.updateTableAction(this.props.table);
  }

  updateSort(arr) {
    arr.forEach((el, i) => {
      el.sort = i;
    });
  }

  applyDrag(arr, dragResult) {
    const { removedIndex, addedIndex, payload } = dragResult;
    if (removedIndex === null && addedIndex === null) return arr;

    const result = [...arr];
    let itemToAdd = payload;

    if (removedIndex !== null) {
      itemToAdd = result.splice(removedIndex, 1)[0];
    }

    if (addedIndex !== null) {
      result.splice(addedIndex, 0, itemToAdd);
    }

    return result;
  }

  applyDragToForm(arr, dragResult) {
    var f = this.props.table;
    f.columns = this.applyDrag(arr, dragResult);
    this.updateSort(f.columns);
    return f;
  }

  renderHeaderTH(col) {
    if (col.content == 'logbook_record_no')         return (<th>{strings.logbook_record_no}</th>);
    if (col.content == 'dashboard_visit_date')      return (<th>{strings.dashboard_visit_date}</th>);
    if (col.content == 'dashboard_permit_status')   return (<th>{strings.dashboard_permit_status}</th>);
    if (col.content == 'dashboard_time_enter')      return (<th>{strings.dashboard_time_enter}</th>);
    if (col.content == 'dashboard_time_exit')       return (<th>{strings.dashboard_time_exit}</th>);
    if (col.content == 'logbook_visitor_fio')       return (<th>{strings.logbook_visitor_fio}</th>);
    if (col.content == 'dashboard_visitor_company') return (<th>{strings.dashboard_visitor_company}</th>);
    if (col.content == 'logbook_inviter_fio')       return (<th>{strings.logbook_inviter_fio}</th>);
    return(<th/>);
  }

  renderForPerson(){
    return (
      <div>
        <div id="facility-requests-table-settings" style={{display: "none"}}>
          <div id="facility-requests-table-settings-close">
            <i className="sv-icon sv-icon-close" onClick={this.closeTableSettings.bind(this)} />
          </div>
          <div id="facility-requests-table-settings-container">
            <Container orientation="horizontal" lockAxis={"x"} onDrop={e => this.props.updateTableAction(this.applyDragToForm(this.props.table.columns, e))}>
              {this.props.table.columns.map(c => {
                return (
                  <Draggable key={c.id}>
                    <div className="draggable-item-horizontal">
                      <CheckerField 
                        id={c.id}
                        className={`no-margin`}
                        label={this.get_i18n_title(c.title)} 
                        checked={c.visible} 
                        onChange={this.change_visibility.bind(this, c)}

                      >
                      </CheckerField>
                      {/*{ c.title }*/}
                    </div>
                  </Draggable>
                );
              })}
            </Container>
          </div>
        </div>
        <table className={`table table-striped table-hover permits-table`}>
          <thead>
          <tr>
            {
              this.props.table.columns.map(c => {
                if (c.visible) return this.renderHeaderTH(c);
              })
            }
            <th id="title_facility_dashboard_actions" style={{width: "30px"}}>
              <i className="sv-icon sv-icon-settings" onClick={this.showTableSettings.bind(this)} />
            </th>
          </tr>
          </thead>
          <tbody>
          {this.props.children}
          </tbody>
        </table>
      </div>
    )
  }

  render() {

    return this.renderForPerson();
  }
}


export default PermitRowWrap;
