import React from "react";
import "./style.css";

class ProfileStartPageBackground extends React.Component {
  render() {
    return (
      <div className={`img-profile-abs`}>
      </div>
    );
  }
}

export default ProfileStartPageBackground;
