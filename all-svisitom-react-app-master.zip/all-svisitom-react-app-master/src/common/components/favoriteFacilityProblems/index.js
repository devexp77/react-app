import React from "react";
import Icon from "../Icon";
import "./style.css";

import strings from "../../localization/all";
import format from "string-format";

const FavoriteFacilityProblems = ({
  problems,
  onClick,
  moreButton = true,
  addCategoryButton = false,
  returnOnClickIndex = false
}) => {
  return (
    <ul className="facility-problems clearfix">
      {problems &&
        problems.length > 0 &&
        problems.map((problem, index) => (
          <li
            data-test-id={`facility-problems-${index}`}
            key={index}
            onClick={() =>
              onClick(returnOnClickIndex ? index : problem.problem_id)
            }
          >
            <Icon
              name={problem.icon_name ? problem.icon_name : `sv-icon-fm-other`}
            />
            <span className="facility-problems-text">{problem.name}</span>
            {problem.is_payable && (
              <span className="facility-problems-price">{ format(strings.problem_price, problem.price)}</span>
            )}
          </li>
        ))}

      {moreButton && (
        <li
          data-test-id="facility-problems-more"
          onClick={() => onClick("more")}
        >
          <Icon name={`sv-icon-fm-more`} />
          <span className="facility-problems-text">
            {strings.button_more}
          </span>
        </li>
      )}

      {addCategoryButton && (!problems || problems.length < 5) && (
        <li
          data-test-id="facility-problems-add"
          onClick={() => onClick("addNew")}
        >
          <Icon name={`sv-icon-fm-add`} style={{ color: "grey" }} />
          <span className="facility-problems-text">
            {strings.button_add}
          </span>
        </li>
      )}
    </ul>
  );
};

export default FavoriteFacilityProblems;
