import React from 'react'

import strings from '../../localization/all'

import './style.css'

const SupportWidget = () => {
  return (
    <div className="support-widget" onClick={() => jivo_api.open()}>
      <div className="support-widget-text">
        {strings.ask_question}
      </div>
    </div>
  )
}

export default SupportWidget
