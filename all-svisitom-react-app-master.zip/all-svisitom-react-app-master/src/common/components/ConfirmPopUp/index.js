import React from "react";
import "./style.css";
import cookie from "react-cookies";
import strings from "../../localization/all";
import CheckerField from "../Inputs/checkerField";
import { HOST_NAME } from "../../constants";


class ConfirmPopUp extends React.Component {
  constructor() {
    super();
    this.state = {
      setCookie: false,
      ignoreDisagreeFunction: false
    };
  }

  open = () => {
    if (this.props.doNotShowAgain && this.state.cookies) {
      this.props.agreeFunction();
    } else {
      $("#" + this.props.id).modal("show");
    }
  };

  componentDidMount() {
    if (this.props.disagreeFunction) {
      $("#" + this.props.id).on("hidden.bs.modal", e => {
        if (!this.state.ignoreDisagreeFunction) {
          this.props.disagreeFunction();
        } else {
          this.setState({ ignoreDisagreeFunction: false });
        }
      });
    }

    if (this.props.doNotShowAgain) {
      const cookies = cookie.load("svisitom_cookies_" + this.props.id);
      this.setState({ cookies: cookies });
    }
  }

  agreeFunction() {
    if (this.props.doNotShowAgain && this.state[`setCookie_${this.props.id}`]) {
      const expires = new Date(Date.now() + 1000 * 60 * 60 * 24 * 365 * 10);
      cookie.save(
        "svisitom_cookies_" + this.props.id,
        new Date().toISOString(),
        {
          path: "/",
          expires,
          domain: `.${HOST_NAME}`
        }
      );
      this.setState({
        cookies: cookie.load("svisitom_cookies_" + this.props.id)
      });
    }

    this.setState({ ignoreDisagreeFunction: true }, () => {
      $("#" + this.props.id).modal("hide");
      this.props.agreeFunction();
    });
  }

  handleCheckboxChange(event) {
    const value = event.target.checked;
    const id = event.target.id;
    this.setState({ [id]: value });
  }

  render() {
    return (
      <div
        className="modal fade confirmPopUp"
        id={this.props.id || `confirmPopUp`}
        tabIndex="-1"
        role="dialog"
        aria-labelledby="exampleModalLabel"
        aria-hidden="true"
      >
        <div className="modal-dialog modal-sm" role="document">
          <div className="modal-content">
            {this.props.header && (
              <div className="modal-header">
                <h4 className="modal-title" id="exampleModalLabel">
                  {this.props.header}
                </h4>
              </div>
            )}
            <div className="modal-body">
              {this.props.content}

              {this.props.doNotShowAgain && (
                <div className={`do-not-show-again`}>
                  <CheckerField
                    id={`setCookie_${this.props.id}`}
                    onChange={this.handleCheckboxChange.bind(this)}
                    checked={this.state[`setCookie_${this.props.id}`] || false}
                    label={strings.do_not_show_again}
                  />
                </div>
              )}
            </div>
            <div className="modal-footer">
              <button
                type="button"
                className="btn btn-flat"
                data-dismiss="modal"
              >
                {strings.button_disagree}
              </button>
              <button
                type="button"
                className="btn btn-flat confirm-delete"
                onClick={this.agreeFunction.bind(this)}
              >
                {this.props.agreeButton || strings.button_agree}
              </button>
            </div>
          </div>
        </div>
      </div>
    );
  }
}

export default ConfirmPopUp;
