import React from 'react';
import strings from '../../../manage/localization/all'
import common_strings from '../../../common/localization/all'
import {industryRoleName} from '../../util/objectTypes'

import './style.css'
class AddresseeRoles extends React.Component {

	constructor() {
		super();
		this.role_names = ['responsible', 'accompany', 'inviter']

	}

	render() {
		return (
			<div className="roles">
			<label className={`label ${this.props.errorClass ? this.props.errorClass(this.props.error) : ''}`}>{strings.title_role} *</label>
			{this.role_names.map(
				(role_name) =>
				(
					<div className="form-group" key={'role_checkbox_'+role_name}>
					<input type="checkbox" id={'role_'+role_name} onChange={this.props.handleCheckboxChange} checked={this.props['role_'+role_name]}/>
					<label htmlFor={'role_'+role_name}>
						{industryRoleName(this.props.object_type, role_name)}
						<div className="role-description">{common_strings['description_role_' + role_name]}</div>
					</label>
					</div>
					)
				)}
			</div>
			);
	}
}

export default AddresseeRoles;
