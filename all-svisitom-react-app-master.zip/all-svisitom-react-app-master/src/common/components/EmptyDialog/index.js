import React from "react";
import "./style.css";

import strings from "../../localization/all";
import { FlatButton } from "../Button";
import ProfileInfo from "../ProfileInfo";

/*
props
  id
  header
  deleteFunction
*/

class EmptyDialog extends React.Component {
  open = () => {
    $("#" + this.props.id).modal("show");
  };

  close = () => {
    $("#" + this.props.id).modal("hide");
  };

  render() {
    return (
      <div
        className={`modal fade ${this.props.withOutBorder &&
          "with-out-border"}`}
        id={this.props.id}
        tabIndex="-1"
        role="dialog"
        aria-hidden="true"
      >
        <div
          className={`modal-dialog modal-${
            this.props.modalSize ? this.props.modalSize : "sm"
          }modal-sm empty-dialog`}
          role="document"
          style={this.props.style || {}}
        >
          <div className="modal-content">
            {this.props.header && (
              <div className="modal-header">
                <ProfileInfo.Div title={this.props.header} />
              </div>
            )}

            <div className="modal-body">{this.props.children}</div>

            {(this.props.closeButton || this.props.leftButton) && (
              <div className="modal-footer">
                {this.props.closeButton && (
                  <FlatButton data-dismiss="modal" className={`float-right`} position={`right`}>
                    {strings.button_close}
                  </FlatButton>
                )}

                {this.props.leftButton && (
                  <FlatButton
                    data-dismiss="modal"
                    position={`left`}
                    className={`float-left`}
                    onClick={this.props.leftButtonClick || false}
                  >
                    {this.props.leftButtonText}
                  </FlatButton>
                )}
              </div>
            )}
          </div>
        </div>
      </div>
    );
  }
}

export default EmptyDialog;
