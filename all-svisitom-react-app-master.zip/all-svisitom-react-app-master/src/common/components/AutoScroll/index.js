import React from 'react';

import isTouchDevice from '../../util/isTouchDevice'

class AutoScroll extends React.Component {
  constructor(props) {
    super(props);
    this.handleClick = this.handleClick.bind(this);
  }

  handleClick(event) {
    if (isTouchDevice()) {
      var offset = $(this.refElement).offset();
      window.scrollTo({top: offset.top - 90, behavior: "smooth"});
    }
  }

  render() {
    if (this.props.enabled) {
      return (
        <div ref={(node) => {this.refElement=node}} onClick={this.handleClick} onFocus={this.handleClick}>
          {this.props.children}
        </div>
      )
    } else {
      return this.props.children;
    }
  }
}

AutoScroll.defaultProps = {
  enabled: true
}

export default AutoScroll;
