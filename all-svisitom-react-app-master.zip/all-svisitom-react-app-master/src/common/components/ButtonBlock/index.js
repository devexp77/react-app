import React from 'react';

import './style.css'

const ButtonBlock = ({children}) => (
  <div className="button-block">
    {children}
  </div>
);

export default ButtonBlock;