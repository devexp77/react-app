import React from "react";

/*
title
*/

class ProfileInfoTable extends React.Component {
  render() {
    return (
      <div className="profile-info-table clearfix" data-test-id={this.props['data-test-id']}>
        {this.props.title && <h5>{this.props.title}</h5>}
        {this.props.children ? (
          <table className="table">
            <tbody>{this.props.children}</tbody>
          </table>
        ) : null}
      </div>
    );
  }
}

export default ProfileInfoTable;
