import React from "react";
import { connect } from "react-redux";

import { pushHistory, toCustomPath } from "../../actions/router";

/*
trClassName ('non-cursor' for cursor default)
editField ('/profile/name')
title
data
mIconClass ('d-none' for no display )
testId
*/

class ProfileInfoRow extends React.Component {
  toEditField(next_url) {
    const { dispatch } = this.props;
    dispatch(toCustomPath(next_url));
  }

  render() {
    return (
      <tr
        className={`profile-info-row ${this.props.trClassName}`}
        onClick={
          this.props.editField
            ? () => this.toEditField(this.props.editField)
            : this.props.editFieldFunction
              ? this.props.editFieldFunction
              : null
        }
        data-test-id={this.props['data-test-id']}
      >
        <td className="first">{this.props.title}</td>

        <td
          className={`td-grey second ${this.props.overflowShow ? "overflow-show" : ""} ${
            this.props.secondClass ? this.props.secondClass : ""
          }`}
        >
          {this.props.data}

          {this.props.rightButtons ? this.props.rightButtons : ""}
        </td>

        <td className="td-grey last">
          <i className={`material-icons ${this.props.mIconClass}`}>&#xE5CC;</i>
        </td>
      </tr>
    );
  }
}

const mapStateToProps = (state, ownProps) => {
  return {};
};

export default connect(mapStateToProps)(ProfileInfoRow);
