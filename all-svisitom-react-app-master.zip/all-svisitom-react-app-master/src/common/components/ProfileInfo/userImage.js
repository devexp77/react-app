import React from 'react'

import Icon from '../Icon';

const UserImage = ({image_url=null, children}) => (
  <div className="profile-info-user-photo">
    {
      image_url
      ? <span className="profile-info-user-photo-image" style={{backgroundImage: `url(${image_url})`}} />
      : <Icon name="account_circle" />
    }
    { children }
  </div>
);

export default UserImage;
