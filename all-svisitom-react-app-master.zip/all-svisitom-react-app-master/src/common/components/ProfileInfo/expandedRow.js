import React from "react";
import random_uuid from "../../util/random_uuid";

class ProfileInfoRow extends React.Component {
  constructor(props) {
    super(props);
    this.random_id = random_uuid();
  }

  componentDidMount() {
    this.autosizeExData(this.props.id || this.random_id);
  }

  componentDidUpdate(prevProps) {
    if (
      prevProps.expand !== this.props.expand ||
      prevProps.data !== this.props.data ||
      prevProps.children !== this.props.children
    ) {
      this.autosizeExData(this.props.id || this.random_id);
    }
  }

  autosizeExData(id) {
    if (this.props.expand) {
      let el = document.getElementById(id);
      if (el) {
        const height = el.getElementsByClassName("transition")[0].scrollHeight;

        el.getElementsByClassName("transition")[0].style.maxHeight =
          height + 100 + "px";
      }
    } else {
      let el = document.getElementById(id);
      if (el) {
        const height = el.getElementsByClassName("ex-data")[0].scrollHeight;

        el.getElementsByClassName("transition")[0].style.maxHeight =
          height + "px";
      }
    }
  }

  render() {
    return (
      <tr
        id={this.props.id || this.random_id}
        className={`profile-info-row expanded-row ${
          this.props.expand ? "non-cursor" : ""
        }`}
        onClick={!this.props.expand ? this.props.onClick : null}
      >
        <td className="first">{this.props.title}</td>

        <td
          className={`td-grey second`}
          colSpan={this.props.expand ? "2" : "1"}
        >
          <span className={`ex-data ${this.props.expand ? "expand" : ""}`}>
            {this.props.data}
          </span>
          <div
            className={`transition clearfix ${
              this.props.expand ? "expand" : ""
            }`}
            style={
              this.props.expand && this.props.maxHeight
                ? { maxHeight: this.props.maxHeight }
                : {}
            }
          >
            {this.props.children}
          </div>
        </td>

        <td className={`td-grey last ${this.props.expand ? "d-none" : ""}`}>
          <i className={`material-icons ${this.props.expand ? "expand" : ""}`}>
            &#xE5CC;
          </i>
        </td>
      </tr>
    );
  }
}

export default ProfileInfoRow;
