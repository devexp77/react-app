import AddIcon from "./addIcon";
import Div from "./div";
import AddresseeHeader from "./addresseeHeader";
import Row from "./row";
import ExpandedRow from "./expandedRow";
import Table from "./table";
import RolesChips from './rolesChips'
import Title from './title'
import UserImage from './userImage'

import "./style.css";

export default {
  AddIcon,
  Div,
  AddresseeHeader,
  Row,
  ExpandedRow,
  Table,
  RolesChips,
  Title,
  UserImage
};
