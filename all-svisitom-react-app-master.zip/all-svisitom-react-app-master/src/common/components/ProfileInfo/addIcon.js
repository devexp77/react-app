import React from "react";

/*
icon
toAddPage
*/

class ProfileInfoAddIcon extends React.Component {
  render() {
    return (
      <div className={`btn-group ${this.props.paddingGrey ? "padding-grey" : ""} ${this.props.colorGrey ? "color-grey" : ""}`}>
        {this.props.dropdown && (
          <i className="material-icons" data-toggle="dropdown">
            {this.props.icon}
          </i>
        )}

        {this.props.dropdown && this.props.children}

        {!this.props.dropdown && (
          <i className="material-icons" onClick={() => this.props.toAddPage()}>
            {this.props.icon}
          </i>
        )}
      </div>
    );
  }
}

export default ProfileInfoAddIcon;
