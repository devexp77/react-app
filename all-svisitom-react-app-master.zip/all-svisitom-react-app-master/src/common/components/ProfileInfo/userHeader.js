import React from "react";

import strings from "../../../profile/localization/all";

/*
content
*/

class ProfileUserHeader extends React.Component {
  render() {
    return (
      <div className="profile-info-header clearfix">
        <div className=" col-md-12 col-lg-5 col-xl-4 img-container">
          {this.props.imgSrc ? (
            <div className={`img-wrap`}>
              <img src={this.props.imgSrc} />
            </div>
          ) : (
            <i className="material-icons">&#xE853;</i>
          )}

          <button className={`btn btn-flat`} onClick={this.props.addImage}>
            {this.props.imgSrc
              ? strings.button_update_image
              : strings.button_add_image}
          </button>

          {this.props.imgSrc ? (
            <button className={`btn btn-flat`} onClick={this.props.deleteImage}>
              {strings.button_delete_image}
            </button>
          ) : null}
        </div>
        <div className="col-lg-7 col-md-12 col-xl-8 text">
          <p>{this.props.content}</p>
        </div>
      </div>
    );
  }
}

export default ProfileUserHeader;
