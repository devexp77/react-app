import React from 'react'
import {industryRoleName} from '../../util/objectTypes';

const RolesChips = ({object_type, roles}) => {
  if (roles) {
    return roles.map(role => (
      <span className="chip" key={"role_display_" + role}>
        {industryRoleName(object_type, role)}
      </span>
    ))
  } else {
    return null;
  }
}

export default RolesChips;
