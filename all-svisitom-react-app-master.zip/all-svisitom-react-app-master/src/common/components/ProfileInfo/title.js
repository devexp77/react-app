import React from "react";

/*
title
*/

class Title extends React.Component {
  render() {
    return (
      <h5 className={`h5-title`} style={this.props.style || {}}>
        {this.props.title}
      </h5>
    );
  }
}

export default Title;
