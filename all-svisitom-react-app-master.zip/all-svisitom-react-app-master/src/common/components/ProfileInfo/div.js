import React from "react";

/*
title
*/

class ProfileInfoDiv extends React.Component {
  render() {
    return (
      <div
        className={`profile-info-div clearfix ${
          this.props.bottomBorder ? "bottomBorder" : ""
        } ${this.props.xLarge ? "xLarge" : ""}`}
        style={this.props.style || {}}
      >
        <h5>{this.props.title}</h5>
        {this.props.children}
      </div>
    );
  }
}

export default ProfileInfoDiv;
