
import React from "react";

/*
icon
toAddPage
*/
import "./style.css"

class ProfileInfoAddIcon extends React.Component {
  render() {
    return (
      <p className={`edit-page-description`}>{this.props.description}</p>
    );
  }
}

export default ProfileInfoAddIcon;
