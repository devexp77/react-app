import React from "react";

import Icon from "../Icon";

/*
content
*/

class ProfileAddresseeHeader extends React.Component {
  render() {
    return (
      <div className="profile-addressee-header clearfix" style={this.props.style || {}}>
        <div className="addressee-icon">
          {this.props.imgPath ? (
            <img src={this.props.imgPath} />
          ) : (
            <div className={`i-back`}>
              <Icon name={this.props.iconName ? this.props.iconName: 'business'}/>
            </div>
          )}

          {this.props.onClick &&
          <div className={`img-add-back`} onClick={this.props.onClick}>
            <i className="material-icons">add</i>
          </div>
          }
        </div>
        {this.props.children}
      </div>
    );
  }
}

export default ProfileAddresseeHeader;
