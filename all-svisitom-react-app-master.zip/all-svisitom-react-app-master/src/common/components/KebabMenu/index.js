import React from "react";

import "./style.css";
import Icon from "../Icon";
import random_uuid from "../../util/random_uuid";

class KebabMenu extends React.Component {
  constructor(props) {
    super(props);
    this.random_id = random_uuid();
  }

  getId() {
    let id = this.props.id;
    if (!id) {
      id = this.random_id;
    }
    return id;
  }

  onClick(e) {
    e.stopPropagation();
    let id = this.getId();

    let dropdown = $("#" + id + "-dropdown");
    let li = $("#" + id);

    if (li.is(e.target) || !li.has(e.target).length == 0) {
      if (dropdown.hasClass("show")) {
        dropdown.removeClass("show");
        if (this.props.onClose) {
          this.props.onClose();
        }
      } else {
        dropdown.addClass("show");
        if (this.props.onClick) {
          this.props.onClick();
        }

        let _this = this;
        $(document).off("mouseup touchend");
        $(document).on("mouseup touchend", function(e) {
          var dropdown = $("#" + id + "-dropdown");
          var li = $("#" + id);

          if (
              !dropdown.is(e.target) &&
              dropdown.has(e.target).length == 0
              &&
            !li.is(e.target) &&
            li.has(e.target).length == 0
          ) {
            if (dropdown.hasClass("show")) {
              dropdown.removeClass("show");
              // if (_this.props.onClose) {
              //   _this.props.onClose();
              // }
            }
          }
        });
      }
    }
  }

  itemClick(e) {
    e.stopPropagation();
  }

  render() {
    return (
      <div
        className={
          "kebab nav-item dropdown" +
          (this.props.className ? " " + this.props.className : "")
        }
      >
        <a
          className="kebab-icon waves-effect"
          id={this.getId()}
          onClick={this.onClick.bind(this)}
        >
          <Icon name="sv-icon-more-vert" />
        </a>
        <div
          className="dropdown-menu dropdown-menu-right dropdown-unique kebab-dropdown"
          id={this.getId() + "-dropdown"}
          onClick={this.itemClick}
        >
          {this.props.children}
        </div>
      </div>
    );
  }
}

export default KebabMenu;
