import React from 'react';

import Icon from '../Icon';
import plan_strings from '../../localization/plan'

import './style.css'

const PlanDetails = ({plan}) => (
  <div className="plan-details">
    <div className="plan-name">{plan.name}</div>
    <div className="plan-subheader">{plan_strings.header_payment_options}</div>
    <div className="plan-payment">
      {plan_strings.monthly_payment}
      <div className="plan-payment-value">
        {-plan.monthly} <Icon name="sv-icon-ruble" />
      </div>
    </div>

    {
      plan.one_time.pass_in &&
      <div className="plan-payment">
        {plan_strings.one_time_pass_in}
        <div className="plan-payment-value">
          {-plan.one_time.pass_in} <Icon name="sv-icon-ruble" />
        </div>
      </div>
    }

    <div className="plan-subheader">{plan_strings.header_feature_options}</div>
    {
      plan.functions &&
      plan.functions.map((name) => (
        <div className="plan-feature" key={name}>
          {plan_strings['feature_'+name] ? plan_strings['feature_'+name] : name}
        </div>
      ))
    }
    <div className="plan-feature">
      {plan_strings.default_feature}
    </div>
  </div>
)

export default PlanDetails;
