import React from "react";

import "./style.css";

class FloatingButton extends React.Component {
  render() {
    return (
      <a className={`btn-floating btn-lg btn-floating-add ${this.props.withFooter && 'with-footer'}`}>
        <i className="material-icons add" onClick={this.props.addFunction}>
          add
        </i>
      </a>
    );
  }
}

export default FloatingButton;
