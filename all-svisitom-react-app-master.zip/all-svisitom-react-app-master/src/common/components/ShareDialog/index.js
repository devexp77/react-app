import React from "react";
import "./style.css";
import {CopyToClipboard} from 'react-copy-to-clipboard';

import strings from "../../localization/all";
import MaterialTabs from "../MaterialTabs";
import Icon from "../Icon";
import {FlatButton} from "../Button";

class ShareDialog extends React.Component {
  render() {
    return (
      <div
        className="modal fade"
        id={this.props.id}
        tabIndex="-1"
        role="dialog"
        aria-labelledby="exampleModalLabel"
        aria-hidden="true"
      >
        <div className="modal-dialog modal-sm without-padding" role="document">
          <div className="modal-content">
            <div className="modal-body" style={{ paddingTop: "10px" }}>
              <MaterialTabs
                tabs={[strings.label_link, strings.label_code]}
                tabsContent={[
                  <React.Fragment>
                  <textarea
                    spellCheck="false"
                    className="form-control rounded-0"
                    style={{
                      resize: "none",
                      height: "auto",
                      width: "auto",
                      margin: "0",
                      padding: "13px"
                    }}
                    id="shareIos"
                    rows="6"
                    cols="25"
                    value={this.props.href}
                    readOnly
                  />
                    <CopyToClipboard text={this.props.href}>
                      <FlatButton style={{float: 'right'}}><Icon name={`file_copy`}/></FlatButton>
                    </CopyToClipboard>
                  </React.Fragment>,

                  <React.Fragment>
                  <textarea
                    spellCheck="false"
                    className="form-control rounded-0"
                    style={{
                      resize: "none",
                      height: "auto",
                      width: "auto",
                      margin: "0",
                      padding: "13px"
                    }}
                    id="shareIos"
                    rows="6"
                    cols="25"
                    value={this.props.code}
                    readOnly
                  />
                    <CopyToClipboard text={this.props.code}>
                      <FlatButton style={{float: 'right'}}><Icon name={`file_copy`}/></FlatButton>
                    </CopyToClipboard>
                  </React.Fragment>
                ]}
              />
            </div>
            <div className="modal-footer">
              <button
                type="button"
                className="btn btn-flat"
                data-dismiss="modal"
              >
                {strings.button_cancel}
              </button>
            </div>
          </div>
        </div>
      </div>
    );
  }
}

export default ShareDialog;
