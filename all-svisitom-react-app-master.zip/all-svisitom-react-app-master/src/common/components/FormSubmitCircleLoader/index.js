import React from "react";

import AbsoluteContainer from "../PageContainers/absoluteContainer";
import CircleLoader from "../CircleLoader";

import "./style.css";
import { connect } from "react-redux";

class FormSubmitCircleLoader extends React.Component {
  isFetching() {
    const addresseeOperationIsFetching = this.props.addressee ? this.props.addressee.addresseeOperationIsFetching : false;
    const userDocOperationIsFetching = this.props.documents ? this.props.documents.userDocOperationIsFetching :false;
    const imageOperationIsFetching = this.props.image ? this.props.image.imageOperationIsFetching  : false;
    const inviteOperationIsFetching = this.props.invites ? this.props.invites.inviteOperationIsFetching : false;
    const logbookOperationIsFetching = this.props.logbook ? this.props.logbook.logbookOperationIsFetching  : false;
    const planOperationIsFetching = this.props.plans ? this.props.plans.planOperationIsFetching : false;
    const promoOperationIsFetching = this.props.promo ? this.props.promo.promoOperationIsFetching : false;
    const requestOperationIsFetching = this.props.requests ? this.props.requests.requestOperationIsFetching : false;
    const roomOperationIsFetching = this.props.rooms ? this.props.rooms.roomOperationIsFetching : false;
    const objectOperationStatusIsFetching = this.props.objects ? this.props.objects.objectOperationStatusIsFetching : false;
    const permitOperationIsFetching = this.props.permits ? this.props.permits.permitOperationIsFetching : false;
    const userTransportOperationIsFetching = this.props.transport ? this.props.transport.userTransportOperationIsFetching : false;
    const userOperationIsFetching = this.props.user ? this.props.user.userOperationIsFetching : false;
    const addressByGeoPointIsFetching = this.props.geocoder ? this.props.geocoder.addressByGeoPointIsFetching : false;
    const geoPointByAddressIsFetching = this.props.geocoder ? this.props.geocoder.geoPointByAddressIsFetching : false;
    const setConfigExecuteMethodIsFetching = this.props.devices ? this.props.devices.setConfigExecuteMethodIsFetching : false;
    const keyOperationIsFetching = this.props.keys ? this.props.keys.keyOperationIsFetching : false;
    const notificationOperationIsFetching = this.props.notifications ? this.props.notifications.notificationOperationIsFetching : false;
    const webPushOperationIsFetching = this.props.webPush ? this.props.webPush.operationIsFetching : false;
    const facilityProblemActionIsFetching = this.props.facility ? this.props.facility.facilityProblemActionIsFetching : false;
    const commentsOperationIsFetching = this.props.comments ? this.props.comments.commentsOperationIsFetching : false;
    const taskOperationIsFetching = this.props.periodic_tasks ? this.props.periodic_tasks.taskOperationIsFetching : false;
    const sharedLinksOperationIsFetching = this.props.shared_links ? this.props.shared_links.sharedLinksOperationIsFetching : false;
    const fmrequestOperationIsFetching = this.props.facility_requests ? this.props.facility_requests.requestOperationIsFetching : false;
    const documentOperationIsFetching = this.props.document_attachments ? this.props.document_attachments.documentOperationIsFetching : false;
    const beaconOperationIsFetching = this.props.beacons ? this.props.beacons.beaconOperationIsFetching : false;

    return (
      addresseeOperationIsFetching ||
      userDocOperationIsFetching ||
      imageOperationIsFetching ||
      inviteOperationIsFetching ||
      logbookOperationIsFetching ||
      planOperationIsFetching ||
      promoOperationIsFetching ||
      requestOperationIsFetching ||
      roomOperationIsFetching ||
      objectOperationStatusIsFetching ||
      permitOperationIsFetching ||
      userTransportOperationIsFetching ||
      userOperationIsFetching ||
      addressByGeoPointIsFetching ||
      geoPointByAddressIsFetching ||
      setConfigExecuteMethodIsFetching ||
      keyOperationIsFetching ||
      notificationOperationIsFetching ||
      webPushOperationIsFetching ||
      facilityProblemActionIsFetching ||
      commentsOperationIsFetching ||
      taskOperationIsFetching ||
      sharedLinksOperationIsFetching ||
      fmrequestOperationIsFetching ||
      documentOperationIsFetching ||
      beaconOperationIsFetching
    );
  }

  render() {
    if (this.isFetching()) {
      return (
        <AbsoluteContainer marginClass={this.props.marginClass}>
          <CircleLoader />
        </AbsoluteContainer>
      );
    } else return null;
  }
}

const mapStateToProps = state => {
  return {
    addressee: state.addressee,
    documents: state.documents,
    image: state.image,
    invites: state.invites,
    logbook: state.logbook,
    objects: state.objects,
    permits: state.permits,
    transport: state.transport,
    plans: state.plans,
    promo: state.promo,
    requests: state.requests,
    rooms: state.rooms,
    user: state.user,
    geocoder: state.geocoder,
    devices: state.devices,
    keys: state.keys,
    notifications: state.notifications,
    webPush: state.webPush,
    facility: state.facility,
    facility_requests: state.facility_requests,
    comments: state.comments,
    periodic_tasks: state.periodic_tasks,
    shared_links: state.shared_links,
    document_attachments: state.document_attachments,
    beacons: state.beacons,
  };
};

export default connect(mapStateToProps)(FormSubmitCircleLoader);
