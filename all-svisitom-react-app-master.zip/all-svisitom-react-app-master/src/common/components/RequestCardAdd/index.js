import React from 'react';

import Icon from '../Icon'

import strings from '../../localization/all';

import './style.css'

const RequestCardAdd = ({onClick, text}) => (
  <div className="requests-item col-12 col-sm-12 col-md-6 col-lg-4 col-xl-3 clearfix">
    <div className="add-request-item waves-effect" onClick={onClick}>
      <div className="add-request-item-container">
        <div>
          <Icon name="add" />
        </div>
        <div className="text">
          {text}
        </div>
      </div>
    </div>
  </div>
)

export default RequestCardAdd;
