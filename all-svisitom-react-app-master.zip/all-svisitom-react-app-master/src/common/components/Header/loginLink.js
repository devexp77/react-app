import React from "react";
import strings from "../../localization/all";

const LoginLink = ({ login }) => (
  <li className="nav-item">
    <a href={login} className="nav-link">
      {strings.button_login}
    </a>
  </li>
);

export default LoginLink;
