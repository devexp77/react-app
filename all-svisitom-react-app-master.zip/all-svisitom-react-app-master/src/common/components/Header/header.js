import React from "react";
import "./style.css";
import { HOST_NAME, PROTOCOL } from "../../constants";
import strings from "../../localization/all";

import LoginLink from "../Header/loginLink";
import UserDropDownPanel from "../Header/userDropDownPanel";
import BellDropDownPanel from "../Header/bellDropDownPanel";
import BentoMenu from "./bentoMenu";

class Header extends React.Component {
  render() {
    return (
      <header>
        <nav
          className={`navbar fixed-top navbar-dark navbar-expand
              ${this.props.marginClass && this.props.marginClass} ${this.props
            .customClass && this.props.customClass} ${this.props.inverseColor &&
            'inverse-color'}`}
        >
          <div className={this.props.containerClass}>
            <span className="col-7 col-sm-8 header-container">
              {this.props.marginClass ? (
                <div className="menu-toogle float-left">
                  <i className="material-icons">&#xE5D2;</i>
                </div>
              ) : (
                ""
              )}

              {!this.props.secondBrand ? (
                <a
                  href={this.props.mainPage}
                  className={`navbar-brand float-left
                  ${this.props.marginClass ? "brand-padding" : ''}`}
                  data-test-id="header-home"
                >
                  {!this.props.marginClass ? (
                    <span>
                      {this.props.inverseColor
                      ? <img
                          src={`${PROTOCOL}//cdn.${HOST_NAME}/img/logo/logo-blue-64.png`}
                        />
                      : <img
                          src={`${PROTOCOL}//cdn.${HOST_NAME}/img/logo/logo-white-64.png`}
                        />
                      }

                      {this.props.productName
                        ? this.props.productName
                        : strings.product_name}
                    </span>
                  ) : null}
                </a>
              ) : null}

              {this.props.secondBrand ? (
                <a
                  href={`/#/`}
                  className={`navbar-brand float-left
                  ${this.props.marginClass ? "brand-padding" : null}`}
                >
                  {this.props.secondBrand}
                </a>
              ) : null}
            </span>

            <ul className="navbar-nav nav-flex-icons ml-auto">
              <BentoMenu
                ShowBentoDropdown={this.props.ShowBentoDropdown}
              />

              {this.props.user.result && (
                <BellDropDownPanel
                  user={this.props.user.result}
                  notifications={this.props.notifications}
                  DeleteNotification={this.props.DeleteNotification}
                  DeleteNotifications={this.props.DeleteNotifications}
                  ShowNotifications={this.props.ShowNotifications}
                  NotificationAction={this.props.NotificationAction}
                  UpdateNotifications={this.props.UpdateNotifications}
                  SetDoNotDisturbState={this.props.SetDoNotDisturbState}
                  ShowMore={this.props.ShowMore}
                />
              )}

              {this.props.user.result ? (
                <UserDropDownPanel
                  user={this.props.user.result}
                  logout={this.props.logout}
                  ShowUserDropdown={this.props.ShowUserDropdown}
                  objects={this.props.relevantObjects}
                />
              ) : (
                <LoginLink login={this.props.login} />
              )}
            </ul>
          </div>
        </nav>
      </header>
    );
  }
}
export default Header;
