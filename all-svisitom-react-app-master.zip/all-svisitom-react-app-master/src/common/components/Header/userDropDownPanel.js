import React, { Component } from "react";
import { connect } from "react-redux";
import { HOST_NAME, PROTOCOL } from "../../constants";

import strings from "../../localization/all";
import {demoEmails} from '../../constants/demo'
import {FlatButton} from "../Button";
import ObjectAvatar from "../Avatar/ObjectAvatar";
import Icon from "../Icon";


class UserDropDownPanel extends Component {
  getImagePath() {
    let imgSrc = "";
    if (
      this.props.image.currentUserImage.result &&
      this.props.image.currentUserImage.result[
        this.props.user.user.result.user_id
      ]
    ) {
      imgSrc =
        this.props.image.currentUserImage.result[
          this.props.user.user.result.user_id
        ] +
        "?" +
        this.props.image.imgSuffix;
    }

    return imgSrc;
  }

  toMyObjects() {
    return (window.location.href = `${PROTOCOL}//profile.${HOST_NAME}/#/me/objects`);
  }

  render() {
    const user = this.props.user.user.result;
    const logout = this.props.logout;
    const imgSrc = this.getImagePath();
    return (
      <li className="nav-item dropdown">
        <a
          className="nav-link clearfix"
          id="profile-li"
          onClick={this.props.ShowUserDropdown}
          data-test-id="header-user-button"
        >
          <Icon name="sv-icon-account-circle"/>
          {
            demoEmails.indexOf(user.email)>=0 &&
            <div className="demo-note">
              {strings.demo_short_note}
            </div>
          }
        </a>
        <div
          className="dropdown-menu dropdown-menu-right dropdown-unique"
          aria-labelledby="navbarDropdownMenuLink"
          id="dropdown-profile"
        >
          <div className="clearfix">
            <div className="user-icon">
              {imgSrc ? (
                <img src={imgSrc} />
              ) : (
                <i className="material-icons">&#xE853;</i>
              )}
            </div>
            <div className="user-info">
              <p className="user-info-name">
                {user.name + ' ' + user.surname}
              </p>
              <p className="user-info-email">
                {user.email ? <span>{user.email}</span> : null}
              </p>
              <a
                onClick={() => {$("#dropdown-profile").removeClass("show"); document.location = `${PROTOCOL}//profile.${HOST_NAME}/#/`}}
                className="btn btn-primary waves-effect waves-light"
                data-test-id="header-user-profile-button"
              >
                {strings.button_my_profile}
              </a>
            </div>
          </div>

          {
            this.props.objects.length > 0 &&
            <div>
              <div className="user-dropdown-objects-header">
                <FlatButton onClick={this.toMyObjects.bind(this)}>{strings.bento_my_objects}</FlatButton>
              </div>
              <ul className={`bento clearfix user-objects`}>
                {
                  this.props.objects.map((obj, index) =>(
                    <li onClick={() => {$("#dropdown-profile").removeClass("show"); document.location = obj.control_url}} key={index}>
                      <ObjectAvatar
                        imageUrl={obj.image_url}
                        className="bento-object-icon"
                        size={48}
                      />
                      <span className="bento-text">{obj.object_name}</span>
                    </li>
                  ))
                }
              </ul>
            </div>
          }

          <div className="user-logout">
            <a className="btn btn-flat logout" href={logout}>
              {strings.button_logout}
            </a>
          </div>
        </div>
      </li>
    );
  }
}
const mapStateToProps = state => {
  return {
    user: state.user,
    image: state.image
  };
};
export default connect(mapStateToProps)(UserDropDownPanel);
