import React from 'react';
import {Link} from 'react-router';
import {HOST_NAME, PROTOCOL} from '../../constants'
import format from 'string-format'

import Moment from 'react-moment';
// import 'moment-timezone';

import {Notification} from '../Notification'

import nstrings from '../../localization/notification'
import strings from '../../localization/all'
import Icon from "../Icon";
import CircleLoader from "../CircleLoader";

const BellDropDownPanel = ({notifications, DeleteNotification, DeleteNotifications, ShowNotifications, ShowMore, NotificationAction, UpdateNotifications,
                             user, SetDoNotDisturbState}) => (

  <li className="nav-item dropdown">
    <a className="nav-link clearfix" id="navbarDropdownMenuLink" aria-haspopup="true" aria-expanded="false"
       id="notification-li" onClick={ShowNotifications} data-test-id="header-notifications-button">

      {user.do_not_disturb
        ? <Icon name="sv-icon-notifications-paused" />
        : notifications
          ? notifications.userNotificationsCount
            ? notifications.userNotificationsCount.result
              ? notifications.userNotificationsCount.result != 0
                ? <Icon name="sv-icon-notifications"/>
                : null
              : <Icon name="sv-icon-notifications-none"/>
            : null
          : null
      }
      {!user.do_not_disturb && notifications && notifications.userNotificationsCount
      && notifications.userNotificationsCount.result
      && notifications.userNotificationsCount.result !== 0
        ? <span className="circle">{notifications.userNotificationsCount.result > 9 ? "9+" : notifications.userNotificationsCount.result }</span>
        : null
      }
    </a>
    <div className="dropdown-menu dropdown-menu-right notifications dropdown-unique"
         aria-labelledby="navbarDropdownMenuLink" id="dropdown-notifications">
      <div className="notifications-dropdown-header">
        <h5 className="text-center">{nstrings.title_notifications}</h5>

        <div className="header-popup-do-not-disturb-button"
             onClick={() => SetDoNotDisturbState(!user.do_not_disturb)}
              title={user.do_not_disturb ? nstrings.tooltip_notifications_disabled : nstrings.tooltip_notifications_enabled}>
          {
            user.do_not_disturb
            ? <div className="switch-notifications-button">
                <Icon name="sv-icon-notifications-paused"/>
              </div>
            : <div className="switch-notifications-button">
                <Icon name="sv-icon-notifications" />
              </div>
          }
        </div>
      </div>

      {
        user.do_not_disturb &&
          <div className="notifications-pause-time">
            {format(nstrings.notifications_disabled, moment(user.do_not_disturb_set_date).fromNow())}
          </div>
      }

      {notifications
        ? notifications.userNotifications
          ? notifications.userNotifications.result
            ? notifications.userNotifications.result.length > 0
              ? <span><span className="all-delete" onClick={() => DeleteNotifications()}><Icon name="sv-icon-clear-all"/></span>

                                        <div className="notification-list">
                                            {notifications.fixedUserNotificationsCount.result < notifications.userNotificationsCount.result
                                              ? <button className="btn btn-flat waves-effect waves-effect center"
                                                        onClick={() => UpdateNotifications()}>
                                                {notifications.userNotificationsCount.result - notifications.fixedUserNotificationsCount.result == 1
                                                  ? <span>{nstrings.show_1_new_notification}</span>
                                                  :
                                                  <span>{format(nstrings.show_n_new_notifications, notifications.userNotificationsCount.result - notifications.fixedUserNotificationsCount.result)}</span>
                                                }
                                              </button>
                                              : null
                                            }

                                          {notifications.userNotifications.result.map((notification, index) =>
                                            <Notification
                                              key={index}
                                              notification={notification}
                                              onClick={() => NotificationAction(notification.notification_id)}
                                              onDelete={() => DeleteNotification(notification.notification_id)}
                                            />
                                          )}
                                          {notifications.userNotifications.result.length < notifications.fixedUserNotificationsCount.result && !notifications.userNotificationsIsFetching
                                            ? <button className="btn btn-flat waves-effect waves-effect float-right"
                                                      onClick={() => ShowMore()}>{strings.button_show_more}</button>
                                            : null
                                          }

                                        </div>




                                        </span>
              : <p className="text-center notifications-none">{nstrings.no_notifications}</p>
            : null
          : null
        : null
      }
      {notifications.userNotificationsIsFetching
        ? <div className="notification-preload col-12 clearfix">
          <CircleLoader  size="small"/>
        </div>
        : null
      }
    </div>
  </li>


)

export default BellDropDownPanel;
