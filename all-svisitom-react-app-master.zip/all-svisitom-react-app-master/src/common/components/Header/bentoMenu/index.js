import React, { Component } from "react";
import { HOST_NAME, PROTOCOL } from "../../../constants";

import strings from "../../../localization/all";
import { connect } from "react-redux";
import "./style.css";

import { FlatButton } from "../../Button";
import Icon from "../../Icon";
import { VideoTip } from "../../VideoTip";

class BentoMenu extends Component {
  toBentoItem(subdomain) {
    window.location.href = `${PROTOCOL}//${subdomain}.${HOST_NAME}/#/`;
    var dropdown_bento = $("#dropdown-bento");
    dropdown_bento.removeClass("show");
  }

  toMainPage() {
    window.location.href = `${PROTOCOL}//${HOST_NAME}/#/`;
    var dropdown_bento = $("#dropdown-bento");
    dropdown_bento.removeClass("show");
  }

  render() {
    return (
      <li className="nav-item dropdown">
        <a
          className="nav-link clearfix"
          id="bento-li"
          onClick={this.props.ShowBentoDropdown}
          data-test-id="header-bento-button"
        >
          <Icon name="sv-icon-apps" />
        </a>
        <div
          className="dropdown-menu dropdown-menu-right dropdown-unique bento-dropdown"
          aria-labelledby="navbarDropdownMenuLink"
          id="dropdown-bento"
        >
          <div className="bento-header">
            <FlatButton
              onClick={this.toMainPage.bind(this)}
              data-test-id="header-bento-home"
            >
              {strings.product_name}
            </FlatButton>
          </div>
          <ul className={`bento clearfix`}>
            <li
              onClick={() => this.toBentoItem.bind(this)("fm")}
              data-test-id="header-bento-fm-profile"
            >
              <VideoTip number={`3.1`}>
                <Icon name={`sv-icon-facility-request`} />
              </VideoTip>
              <span className="bento-text">{strings.bento_fm_request}</span>
            </li>

            <li
              onClick={() => this.toBentoItem.bind(this)("request")}
              data-test-id="header-bento-send-request"
            >
              <Icon name={"sv-icon-request"} />
              <span className="bento-text">{strings.bento_send_request}</span>
            </li>

            <li
              onClick={() => this.toBentoItem.bind(this)("join")}
              data-test-id="header-bento-add-object"
            >
              <VideoTip number={`2.2`}>
                <Icon name={"sv-icon-add-location"}/>
              </VideoTip>
              <span className="bento-text">
                {strings.bento_register_object}
              </span>
            </li>

            <li
              onClick={() => this.toBentoItem.bind(this)("manage")}
              data-test-id="header-bento-manage"
            >
              <Icon name={"sv-icon-building"} />
              <span className="bento-text">{strings.bento_manage_objects}</span>
            </li>
          </ul>
        </div>
      </li>
    );
  }
}
const mapStateToProps = state => {
  return {
    user: state.user,
    image: state.image
  };
};
export default connect(mapStateToProps)(BentoMenu);
