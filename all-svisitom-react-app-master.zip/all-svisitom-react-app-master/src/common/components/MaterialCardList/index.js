import React, { Component } from "react";

import "./style.css";

/*
  Props:
    emptyText - text to be shown if no children
*/
class MaterialCardList extends Component {
  render() {
    const children = this.props.children;
    if (!children || children.length == 0) {
      return (
        <div className={`sv-material-card-list-empty`}>{this.props.emptyText}</div>
      );
    }

    var maxColumn = 2;
    if (this.props.maxColumn) {
      maxColumn = this.props.maxColumn;
    }

    return (
      <div className={`sv-material-card-list clearfix`}>
        {React.Children.map(
          children,
          (child, i) =>
            child ? (
              <div
                className={`sv-material-card-list-item ${child.props.actionItem ? '' : 'shadow'} clearfix max-column-${maxColumn}`}
              >
                {child}
              </div>
            ) : null
        )}
      </div>
    );
  }
}

export {MaterialCardList};
