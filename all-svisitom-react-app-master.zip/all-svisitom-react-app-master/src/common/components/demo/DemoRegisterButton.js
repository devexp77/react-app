import React from 'react';

import strings from '../../localization/all';
import {demoEmails} from '../../constants/demo';
import {HOST_NAME, PROTOCOL} from "../../constants";

import './style.css'
import Icon from "../Icon";

class DemoRegisterButton extends React.Component {
  render() {
    return (
      <a
        className="demo-register-floating-button"
        href={`${PROTOCOL}//${HOST_NAME}/logout?next=${PROTOCOL}//accounts.${HOST_NAME}/register`}>
        <Icon name="sv-icon-person-add" />
        {strings.button_register}
      </a>
    );
  }
}


export default DemoRegisterButton;
