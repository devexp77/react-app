import React from "react";
import { connect } from "react-redux";

import DemoRegisterButton from "./DemoRegisterButton";

import { demoEmails } from "../../constants/demo";
import { HOST_NAME, PROTOCOL } from "../../constants";

import "./style.css";
import { VideoTip } from "../VideoTip";

class DemoModeWidget extends React.Component {
  constructor(props) {
    super(props);
  }

  onClick() {
    document.location = `${PROTOCOL}://${HOST_NAME}/logout?next=${PROTOCOL}://accounts.${HOST_NAME}/register`;
  }

  render() {
    let userEmail = null;
    let { user } = this.props;
    if (user.user && user.user.result) {
      userEmail = user.user.result.email.toLowerCase();
    }

    if (demoEmails.indexOf(userEmail) >= 0) {
      return (
        <div className="demo-register-container">
          <VideoTip number={`2.1`}>
            <DemoRegisterButton />
          </VideoTip>
        </div>
      );
    } else {
      return null;
    }
  }
}

const mapStateToProps = state => {
  return {
    user: state.user
  };
};

export { demoEmails };
export default connect(mapStateToProps)(DemoModeWidget);
