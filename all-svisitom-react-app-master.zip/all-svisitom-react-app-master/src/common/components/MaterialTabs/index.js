import React, { Component } from "react";

import "./style.css";

class MaterialTabs extends Component {
  render() {
    return (
      <div className="classic-tabs">
        <ul className="nav" role="tablist">
          {this.props.tabs.map((tab, index) => (
            <li className="nav-item" key={index}>
              <a
                className={`nav-link waves-light ${
                  index === 0 ? "active" : ""
                }`}
                data-toggle="tab"
                href={`#tab_${index}`}
                role="tab"
              >
                {tab}
              </a>
            </li>
          ))}
        </ul>

        <div className="tab-content card">
          {this.props.tabsContent.map((tabContent, index) => (
            <div
              className={`tab-pane fade in show ${index === 0 ? "active" : ""}`}
              id={`tab_${index}`}
              role="tabpanel"
              key={index}
            >
              {tabContent}
            </div>
          ))}
        </div>
      </div>
    );
  }
}

export default MaterialTabs;
