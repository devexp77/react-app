import React from "react";
import "./style.css";

/*
color: red or yellow
*/

class InfoPanel extends React.Component {

  render() {
    return (
      <div className={`info-panel`}>
        <p className={`desc`}>{this.props.description}</p>
      </div>
    );
  }
}


export default InfoPanel;
