import React from "react";
import "./style.css";
import SignatureCanvas from "react-signature-canvas";
import MaterialSurface from "../PageContainers/materialSurface";
import Buttons from "../../../common/components/ButtonsPanel";
import common_strings from "../../../common/localization/all";
import ProfileInfo from "../../../common/components/ProfileInfo";

class Signature extends React.Component {
  constructor() {
    super();
    this.state = {};
  }

  getImage = () => {
    this.props.submitFunction(
      this.sigCanvas.getTrimmedCanvas().toDataURL("image/png")
    );
  };

  render() {
    return (
      <React.Fragment>
        <ProfileInfo.Title
          title={
            this.props.signatureText
              ? this.props.signatureText
              : common_strings.title_enter_signature
          }
        />
        <MaterialSurface padding={`30px`}>
          <div className={`sig-canvas-container`}>
            <SignatureCanvas
              clearOnResize={false}
              ref={ref => {
                this.sigCanvas = ref;
              }}
              penColor="black"
              minWidth={2}
              canvasProps={{
                width: 600,
                height: 250,
                className: "sig-canvas"
              }}
            />
          </div>
        </MaterialSurface>
        <Buttons
          Submit={this.getImage}
          submitText={this.props.submitText || common_strings.button_next}
          // cancelText={common_strings.button_back}
          Cancel={this.props.cancelFunction}
        />
      </React.Fragment>
    );
  }
  componentDidMount() {
    this.canvasFitToPage();
    window.addEventListener("resize", this.canvasFitToPage);
    window.scrollTo({ top: 0 });
  }

  canvasFitToPage() {
    const canvas = document.querySelector("canvas");
    const width = $(canvas).outerWidth();
    const parentWidth = $(canvas)
      .parent()
      .outerWidth();

    if (width - 2 !== parentWidth) {
      canvas.setAttribute("width", parentWidth);
    }
  }

  componentWillUnmount() {
    window.removeEventListener("resize", this.canvasFitToPage);
  }
}

export default Signature;
