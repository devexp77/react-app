import React from 'react';
import './style.css';
import {HOST_NAME, PROTOCOL} from '../../constants'

const ErrorPage = ({object}) => (
    <div className="error-uc">
            <img src={`${PROTOCOL}//cdn.${HOST_NAME}/img/errors/uc.jpg`}/>   
    </div>
)
export default ErrorPage