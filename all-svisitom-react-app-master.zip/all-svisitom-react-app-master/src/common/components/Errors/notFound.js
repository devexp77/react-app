import React from 'react';
import './style.css';
import {HOST_NAME, PROTOCOL} from '../../constants'

const NotFound = ({object}) => (
    <div className="error-uc">
            <a href={`${PROTOCOL}//${HOST_NAME}`}><img src={`${PROTOCOL}//cdn.${HOST_NAME}/img/errors/404.png`}/></a>   
    </div>
)
export default NotFound