import React from 'react'

const Icon = ({name, style, className=''}) => {
  if (name.startsWith('sv-icon-')) {
    return (
      <i className={'sv-icon '+name+' '+className} style={style}></i>
    )
  } else if (name.startsWith('fa-')) {
    return (
      <i className={'fas '+name+' '+className} style={style}></i>
    )
  } else {
    return (
      <i className={"material-icons"+' '+className} style={style}>{name}</i>
    )
  }
}

export default Icon;
