import React from 'react'

import './style.css'

const ProgressBar = ({value, indeterminate}) => (
  <div className={"progress" + (indeterminate ? " primary-color-dark" : "")} style={{height: '20px'}}>
    {
      indeterminate
      ?
        <div
          className="indeterminate"
          style={{
            height: '20px'
          }}>
        </div>
      :
        <div
          className="progress-bar"
          role="progressbar"
          style={{
            height: '20px',
            width: `${value}%`
          }}>
        </div>
    }
  </div>
);


export default ProgressBar;
