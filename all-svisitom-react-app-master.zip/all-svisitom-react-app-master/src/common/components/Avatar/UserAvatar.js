import React from 'react';

import Avatar from './Avatar'

const UserAvatar = ({imageUrl, className, size}) => (
  <Avatar
    defaultIcon='account_circle'
    imageUrl={imageUrl}
    className={className}
    size={size}
    borderRadius={size/2+'px'}
  />
)

export default UserAvatar;
