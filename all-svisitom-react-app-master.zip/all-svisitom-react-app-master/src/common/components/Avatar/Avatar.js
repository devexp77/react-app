import React from 'react';

const Avatar = ({defaultIcon, imageUrl, className='', size, borderRadius}) => {
  if (imageUrl) {
    return (
      <span
        className={className}
        style={{
          backgroundImage: `url(${imageUrl})`,
          backgroundPosition: 'center',
          backgroundRepeat: 'no-repeat',
          backgroundSize: 'cover',
          display: 'inherit',
          width: size,
          height: size,
          borderRadius: borderRadius
        }}
      />
    )
  } else {
    return (
      <i
        className={`material-icons ${className}`}
        style={{
          width: size,
          height: size,
          fontSize: size,
          borderRadius: borderRadius
        }}>
        {defaultIcon}
      </i>
    )
  }
}

export default Avatar;
