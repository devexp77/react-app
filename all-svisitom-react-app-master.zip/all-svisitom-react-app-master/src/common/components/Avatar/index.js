import UserAvatar from './UserAvatar';
import ObjectAvatar from './ObjectAvatar';

export {UserAvatar, ObjectAvatar}
