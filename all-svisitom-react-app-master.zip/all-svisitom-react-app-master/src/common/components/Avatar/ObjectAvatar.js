import React from 'react';

import Avatar from './Avatar'

const ObjectAvatar = ({imageUrl, className, size}) => (
  <Avatar
    defaultIcon="business"
    imageUrl={imageUrl}
    className={className}
    size={size}
    borderRadius="8px"
  />
)

export default ObjectAvatar;
