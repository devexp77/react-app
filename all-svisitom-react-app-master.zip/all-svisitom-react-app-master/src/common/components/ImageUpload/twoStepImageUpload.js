import React from "react";
import fetch from "isomorphic-fetch";
import ReactAvatarEditor from "react-avatar-editor";
import Dropzone from "react-dropzone";
import Buttons from "../ButtonsPanel";
const EXIF = require("exif-js");

import "./style.css";
import { fetchSetImage } from "../../actions/image";
import { connect } from "react-redux";
import { ErrorToast } from "../../Toasts/error";
import strings from "../../localization/all";

class ImageUpload extends React.Component {
  constructor() {
    super();
    this.state = {
      image: [],
      step: 1,
      firstCanvas: "",
      rotate: 0,
      scale: 1,
      firstWidth: 600,
      firstHeight: 300
    };
  }

  componentDidMount() {
    $(".img-upload-page").on("touchmove", "canvas", function(e) {
      e.preventDefault();
    });
  }

  handleDrop = dropped => {
    const that = this;
    EXIF.getData(dropped[0], function() {
      const orientation = EXIF.getTag(this, "Orientation");
      let rotatePic = 0;
      let firstWidth = 600;
      let firstHeight = 300;
      switch (orientation) {
        case 8:
          rotatePic = 270;
          firstWidth = 300;
          firstHeight = 600;
          break;
        case 6:
          rotatePic = 90;
          firstWidth = 300;
          firstHeight = 600;
          break;
        case 3:
          rotatePic = 180;
          break;
        default:
          rotatePic = 0;
      }
      that.setState({
        rotate: rotatePic,
        firstWidth: firstWidth,
        firstHeight: firstHeight
      });
    });

    this.setState({
      image: dropped[0],
      rotate: 0,
      scale: 1,
      firstWidth: 600,
      firstHeight: 300
    });
  };

  firstStepSave = () => {
    if (this.editor) {
      //creating a dummy CANVAS and copying the original CANVAS content onto it.
      const srcCanvas = this.editor.getImageScaledToCanvas();
      let destinationCanvas = document.createElement("canvas");
      destinationCanvas.width = srcCanvas.width;
      destinationCanvas.height = srcCanvas.height;

      let destCtx = destinationCanvas.getContext('2d');
      destCtx.fillStyle = "#F5F5F5";
      destCtx.fillRect(0,0,srcCanvas.width,srcCanvas.height);
      destCtx.drawImage(srcCanvas, 0, 0);
      //

      const canvas = destinationCanvas.toDataURL();
      this.setState({
        firstCanvas: canvas,
        step: 2
      });
    }
  };

  onClickSave = () => {
    const { dispatch } = this.props;
    if (this.editor) {
      //creating a dummy CANVAS and copying the original CANVAS content onto it.
      const srcCanvas = this.editor.getImageScaledToCanvas();
      let destinationCanvas = document.createElement("canvas");
      destinationCanvas.width = srcCanvas.width;
      destinationCanvas.height = srcCanvas.height;

      let destCtx = destinationCanvas.getContext('2d');
      destCtx.fillStyle = "#F5F5F5";
      destCtx.fillRect(0,0,srcCanvas.width,srcCanvas.height);
      destCtx.drawImage(srcCanvas, 0, 0);
      //

      const canvas = destinationCanvas.toDataURL();

      (async () => {
        /*first image*/
        let firstRes = await fetch(this.state.firstCanvas); // get crop image
        let firstBlob = await firstRes.blob();
        let firstForm = new FormData(); //prepare form to post
        firstForm.append("file", firstBlob, "file.png");
        firstForm.append("entity_type", this.props.entityType);
        firstForm.append("entity_id", this.props.entityId);
        firstForm.append("suffix", `main`);
        /*****/

        /*second image*/
        let secondRes = await fetch(canvas); // get crop image
        let secondBlob = await secondRes.blob();
        let secondForm = new FormData(); //prepare form to post
        secondForm.append("file", secondBlob, "file.png");
        secondForm.append("entity_type", this.props.entityType);
        secondForm.append("entity_id", this.props.entityId);
        secondForm.append("suffix", `default`);
        /*****/

        const _this = this;
        dispatch(fetchSetImage(firstForm)).then(function(res) {
          if (res.payload && res.payload.result) {
            dispatch(fetchSetImage(secondForm)).then(function(res) {
              if (res.payload && res.payload.result) {
                _this.props.SuccessFunction();
              }

              if (res.payload && res.payload.error) {
                ErrorToast(res.payload.error);
              }
            });
          }

          if (res.payload && res.payload.error) {
            ErrorToast(res.payload.error);
          }
        });
      })();
    }
  };

  clearImage() {
    this.setState({
      image: []
    });
  }

  handleRange(event) {
    const id = event.target.id;
    const value = event.target.value;
    this.setState({ [id]: value });
  }

  handleRotate(value) {
    const firstHeight = this.state.firstHeight;
    const firstWidth = this.state.firstWidth;

    this.setState({
      rotate: this.state.rotate + value,
      firstHeight: firstWidth,
      firstWidth: firstHeight
    });
  }

  goBack() {
    this.setState({
      step: 1
    });
  }

  setEditorRef = editor => (this.editor = editor);

  renderFirstStep() {
    return (
      <div
        className={`img-upload-page ${this.state.image.size ? "medium" : ""}`}
      >
        {!this.state.image.size ? (
          <Dropzone
            onDrop={this.handleDrop}
            multiple={false}
            className={`dropzone`}
            activeClassName={`dropzone-active`}
          >
            <div>
              <span>{strings.drag_and_drop_title}</span>
              <i className="material-icons">cloud_upload</i>
            </div>
          </Dropzone>
        ) : null}

        {this.state.image.size
          ? [
              <p key={`help`}>{strings.object_main_image_desc}</p>,
              <ReactAvatarEditor
                key={`canvas`}
                width={this.state.firstWidth}
                height={this.state.firstHeight}
                borderRadius={0}
                image={this.state.image}
                ref={this.setEditorRef}
                rotate={this.state.rotate}
                scale={this.state.scale}
              />,

              <form className="range-field">
                <input
                  type="range"
                  min="0.1"
                  max="4"
                  step="0.1"
                  value={this.state.scale}
                  onChange={this.handleRange.bind(this)}
                  id={`scale`}
                />
              </form>,

              <button
                key={`1`}
                className={`btn btn-flat rotate`}
                onClick={() => this.handleRotate.bind(this)(-90)}
              >
                <i className="material-icons">rotate_left</i>
              </button>,
              <button
                key={`2`}
                className={`btn btn-flat rotate`}
                onClick={() => this.handleRotate.bind(this)(+90)}
              >
                <i className="material-icons">rotate_right</i>
              </button>,

              <Buttons
                key={`buttons`}
                Submit={this.firstStepSave.bind(this)}
                submitText={strings.button_next}
                Cancel={this.clearImage.bind(this)}
                cancelText={strings.button_clear}
              />
            ]
          : null}
      </div>
    );
  }

  renderSecondStep() {
    return (
      <div className={`img-upload-page small`}>
        {this.state.image.size
          ? [
              <p key={`help`}>{strings.object_default_image_desc}</p>,
              <ReactAvatarEditor
                key={`canvas`}
                width={300}
                height={300}
                borderRadius={0}
                image={this.state.image}
                rotate={this.state.rotate}
                scale={this.state.scale}
                ref={this.setEditorRef}
              />,

              <form className="range-field">
                <input
                  type="range"
                  min="0.1"
                  max="4"
                  step="0.1"
                  value={this.state.scale}
                  onChange={this.handleRange.bind(this)}
                  id={`scale`}
                />
              </form>,

              <button
                key={`1`}
                className={`btn btn-flat rotate`}
                onClick={() => this.handleRotate.bind(this)(-90)}
              >
                <i className="material-icons">rotate_left</i>
              </button>,
              <button
                key={`2`}
                className={`btn btn-flat rotate`}
                onClick={() => this.handleRotate.bind(this)(+90)}
              >
                <i className="material-icons">rotate_right</i>
              </button>,

              <Buttons
                key={`buttons`}
                Submit={this.onClickSave.bind(this)}
                Cancel={this.goBack.bind(this)}
                cancelText={strings.button_back}
              />
            ]
          : null}
      </div>
    );
  }

  render() {
    switch (this.state.step) {
      case 1:
        return this.renderFirstStep();
      case 2:
        return this.renderSecondStep();
      default:
        return null;
    }
  }
}

const mapStateToProps = state => {
  return {
    user: state.user,
    images: state.images
  };
};

export default connect(mapStateToProps)(ImageUpload);
