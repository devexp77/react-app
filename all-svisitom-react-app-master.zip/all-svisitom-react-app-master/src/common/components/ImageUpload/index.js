import React from "react";
import fetch from "isomorphic-fetch";
import ReactAvatarEditor from "react-avatar-editor";
import Dropzone from "react-dropzone";
const EXIF = require("exif-js");

import Buttons from "../ButtonsPanel";

import "./style.css";
import { fetchSetImage } from "../../actions/image";
import { connect } from "react-redux";
import { ErrorToast } from "../../Toasts/error";
import strings from "../../localization/all";

class ImageUpload extends React.Component {
  constructor() {
    super();
    this.state = { image: [], rotate: 0, scale: 1 };
  }

  componentDidMount() {
    $(".img-upload-page").on("touchmove", "canvas", function(e) {
      e.preventDefault();
    });
  }

  handleDrop = dropped => {
    const that = this;
    EXIF.getData(dropped[0], function() {
      const orientation = EXIF.getTag(this, "Orientation");
      let rotatePic = 0;
      switch (orientation) {
        case 8:
          rotatePic = 270;
          break;
        case 6:
          rotatePic = 90;
          break;
        case 3:
          rotatePic = 180;
          break;
        default:
          rotatePic = 0;
      }
      that.setState({ rotate: rotatePic });
    });

    this.setState({ image: dropped[0], rotate: 0, scale: 1 });
  };

  onClickSave = () => {
    const { dispatch } = this.props;
    if (this.editor) {

      //creating a dummy CANVAS and copying the original CANVAS content onto it.
      const srcCanvas = this.editor.getImageScaledToCanvas();
      let destinationCanvas = document.createElement("canvas");
      destinationCanvas.width = srcCanvas.width;
      destinationCanvas.height = srcCanvas.height;

      let destCtx = destinationCanvas.getContext('2d');
      destCtx.fillStyle = "#F5F5F5";
      destCtx.fillRect(0,0,srcCanvas.width,srcCanvas.height);
      destCtx.drawImage(srcCanvas, 0, 0);
      //

      const canvas = destinationCanvas.toDataURL();

      (async () => {
        let res = await fetch(canvas); // get crop image
        let blob = await res.blob();
        let fd = new FormData(); //prepare form to post
        fd.append("file", blob, "file.png");
        fd.append("entity_type", this.props.entityType);
        fd.append("entity_id", this.props.entityId);
        if (this.props.suffix) {
          fd.append("suffix", this.props.suffix);
        }

        const _this = this;
        dispatch(fetchSetImage(fd)).then(function(res) {
          if (res.payload && res.payload.result) {
            _this.props.SuccessFunction();
          }

          if (res.payload && res.payload.error) {
            ErrorToast(res.payload.error);
          }
        });
      })();
    }
  };

  clearImage() {
    this.setState({
      image: []
    });
  }

  handleRange(event) {
    const id = event.target.id;
    const value = event.target.value;
    this.setState({ [id]: value });
  }

  handleRotate(value) {
    this.setState({ rotate: this.state.rotate + value });
  }

  setEditorRef = editor => (this.editor = editor);

  render() {
    return (
      <div
        className={`img-upload-page ${this.state.image.size ? "small" : ""}`}
      >
        {!this.state.image.size ? (
          <Dropzone
            onDrop={this.handleDrop}
            multiple={false}
            className={`dropzone`}
            activeClassName={`dropzone-active`}
          >
            <div>
              <span>{strings.drag_and_drop_title}</span>
              <i className="material-icons">cloud_upload</i>
            </div>
          </Dropzone>
        ) : null}

        {this.state.image.size ? (
          <ReactAvatarEditor
            width={this.props.width}
            height={this.props.height}
            borderRadius={this.props.radius}
            image={this.state.image}
            ref={this.setEditorRef}
            rotate={this.state.rotate}
            scale={this.state.scale}
          />
        ) : null}

        {this.state.image.size ? (
          <form className="range-field">
            <input
              type="range"
              min="0.1"
              max="4"
              step="0.1"
              value={this.state.scale}
              onChange={this.handleRange.bind(this)}
              id={`scale`}
            />
          </form>
        ) : null}

        {this.state.image.size
          ? [
              <button
                key={`1`}
                className={`btn btn-flat rotate`}
                onClick={() => this.handleRotate.bind(this)(-90)}
              >
                <i className="material-icons">rotate_left</i>
              </button>,
              <button
                key={`2`}
                className={`btn btn-flat rotate`}
                onClick={() => this.handleRotate.bind(this)(+90)}
              >
                <i className="material-icons">rotate_right</i>
              </button>
            ]
          : null}

        {this.state.image.size ? (
          <Buttons
            Submit={this.onClickSave.bind(this)}
            Cancel={this.clearImage.bind(this)}
            cancelText={strings.button_clear}
          />
        ) : null}
      </div>
    );
  }
}

const mapStateToProps = state => {
  return {
    user: state.user,
    images: state.images
  };
};

export default connect(mapStateToProps)(ImageUpload);
