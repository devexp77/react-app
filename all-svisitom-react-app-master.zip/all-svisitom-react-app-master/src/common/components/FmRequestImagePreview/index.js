import React from "react";
import "./style.css";

class FmRequestImagePreview extends React.Component {
  render() {
    return (
      <div className={`img-wrap ${this.props.count === 3 && 'three-in-row' }`}>
        <img className={`img-preview`} src={this.props.src} />
      </div>
    );
  }
}
export default FmRequestImagePreview;
