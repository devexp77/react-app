import React from "react";
import "./style.css";

import Typeahead from "../../../common/components/Inputs/typeahead";

import { CARS } from "../../constants/cars";
import { COLORS } from "../../constants/colors";
import { CATEGORIES } from "../../constants/categories";

import strings from "../../localization/all";
import InputField from "../Inputs/inputField";
import AutoScroll from "../AutoScroll";
import Select from "../Select";
import { TRANSPORT_ICONS_PATH } from "../../constants";

class Transport extends React.Component {
  handleTransportCategoryChange = value => {
    let newEvent = {
      target: {
        value: value,
        id: this.props.categoryId || "category"
      }
    };
    this.props.handleInputChange(newEvent);
  };

  render() {
    var carBrand = [];
    for (var k in CARS) {
      carBrand[k] = CARS[k].brand;
    }
    carBrand = carBrand.sort();

    var models = [];
    if (this.props.brand) {
      if (CARS.find(cars => cars.brand === this.props.brand)) {
        models = CARS.find(cars => cars.brand === this.props.brand).models;
      }
    }
    models = models.sort();

    var colors = COLORS;
    colors = colors.sort();

    let licensePlateError = null;
    if (this.props.formErrors) {
      licensePlateError = !this.props.indexIgnore && this.props.index.toString()
        ? this.props.formErrors.licensePlate[this.props.index]
        : this.props.formErrors.licensePlate;
    }

    const { request_fields } = this.props;
    return (
      <span className="transport-component">
        {!(
          request_fields &&
          request_fields.vehicles.license_plate &&
          !request_fields.vehicles.license_plate.visibility
        ) && (
          <AutoScroll enabled={this.props.autoScroll}>
            <InputField
              id={
                this.props.license_plateId
                  ? this.props.license_plateId
                  : "license_plate"
              }
              value={this.props.license_plate}
              handleInputChange={this.props.handleInputChange}
              label={strings.label_license_plate + " *"}
              errorClass={this.props.errorClass}
              error={licensePlateError}
            />
          </AutoScroll>
        )}

        {!(
          request_fields &&
          request_fields.vehicles.brand &&
          !request_fields.vehicles.brand.visibility
        ) && (
          <AutoScroll enabled={this.props.autoScroll}>
            <Typeahead
              id={this.props.brandId ? this.props.brandId : "brand"}
              options={carBrand}
              value={this.props.brand}
              onInputChange={this.props.handleTypeAheadChange(
                this.props.brandId ? this.props.brandId : "brand"
              )}
              clearButton={!!this.props.brand}
              mdClass={`car-brand`}
              label={strings.label_transport_brand}
            />
          </AutoScroll>
        )}

        {!(
          request_fields &&
          request_fields.vehicles.model &&
          !request_fields.vehicles.model.visibility
        ) && (
          <AutoScroll enabled={this.props.autoScroll}>
            <Typeahead
              id={this.props.modelId ? this.props.modelId : "model"}
              options={models}
              value={this.props.model}
              onInputChange={this.props.handleTypeAheadChange(
                this.props.modelId ? this.props.modelId : "model"
              )}
              clearButton={!!this.props.model}
              mdClass={`car-model`}
              label={strings.label_transport_model}
            />
          </AutoScroll>
        )}

        {!(
          request_fields &&
          request_fields.vehicles.color &&
          !request_fields.vehicles.color.visibility
        ) && (
          <AutoScroll enabled={this.props.autoScroll}>
            <Typeahead
              id={this.props.colorId ? this.props.colorId : "color"}
              options={colors}
              value={this.props.color}
              onInputChange={this.props.handleTypeAheadChange(
                this.props.colorId ? this.props.colorId : "color"
              )}
              clearButton={!!this.props.color}
              mdClass={`car-color`}
              label={strings.label_transport_color}
            />
          </AutoScroll>
        )}

        {!(
          request_fields &&
          request_fields.vehicles.category &&
          !request_fields.vehicles.category.visibility
        ) && (
          <AutoScroll enabled={this.props.autoScroll}>
            <div className="select-container select-field">
              <Select
                id={
                  this.props.categoryId
                    ? this.props.categoryId.split(".").join("_")
                    : "category"
                }
                value={this.props.category}
                onChange={this.handleTransportCategoryChange}
                className={`transport-category`}
              >
                <option value={``}>{strings.label_option_not_selected}</option>
                {CATEGORIES.map(category => (
                  <option
                    value={category}
                    key={category}
                    data-icon={`${TRANSPORT_ICONS_PATH}/${category}.svg`}
                  >
                    {category}
                  </option>
                ))}
              </Select>
              <label className="active">
                {strings.label_transport_category}
              </label>
            </div>
          </AutoScroll>
        )}
      </span>
    );
  }
}

export default Transport;
