import { push } from 'react-router-redux';
import {setRoutePath} from './actions/router';
import {notificationsUpdate} from './notificationsUpdate';


export const setRouteHistory = (nextState, callback, store) => {

	const { dispatch, getState } = store;

	dispatch(setRoutePath(nextState.location.pathname));
	notificationsUpdate(dispatch, getState().user);
	return callback()	

}
