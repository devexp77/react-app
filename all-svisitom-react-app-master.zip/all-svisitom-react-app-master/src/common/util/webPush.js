import { fetchAddWebPush, fetchDeleteWebPush } from "../actions/webPush";
import { ErrorToast } from "../Toasts";

export const initWebPush = (dispatch, sender_id, user_id) => {
  firebase.initializeApp({
    messagingSenderId: sender_id
  });

  if (Notification.permission === "default" && firebase.messaging.isSupported()) {
    subscribeWebPush(dispatch, user_id);
  }

};

export const subscribeWebPush = (dispatch, user_id, callback) => {
  let messaging = firebase.messaging();
  messaging
    .requestPermission()
    .then(function() {
      // получаем ID устройства
      messaging
        .getToken()
        .then(function(currentToken) {
          // console.log(currentToken);

          if (currentToken) {
            sendTokenToServer(dispatch, currentToken, callback);
          } else {
            console.warn("Не удалось получить токен.");
            setTokenSentToServer(false);
          }
        })
        .catch(function(err) {
          console.warn("При получении токена произошла ошибка.", err);
          setTokenSentToServer(false);
        });
    })
    .catch(function(err) {
      console.warn("Не удалось получить разрешение на показ уведомлений.", err);
      const token = getCurrentToken();
      if (token) {
        unsubscribeWebPush(dispatch, token, user_id, callback);
      }
    });
};

// отправка ID на сервер
function sendTokenToServer(dispatch, currentToken, callback) {
  if (!isTokenSentToServer(currentToken)) {
    console.log("Отправка токена на сервер...");

    dispatch(
      fetchAddWebPush({
        device_id: currentToken
      })
    ).then(res => {
      if (res.payload.result) {
        setTokenSentToServer(currentToken);
        if (callback) {
          callback();
        }
      }
      if (res.payload.error) {
        ErrorToast(res.payload.error);
      }
    });
  } else {
    console.log("Токен уже отправлен на сервер.");
    if (callback) {
      callback();
    }
  }
}

// используем localStorage для отметки того,
// что пользователь уже подписался на уведомления
function isTokenSentToServer(currentToken) {
  return (
    window.localStorage.getItem("sentFirebaseMessagingToken") == currentToken
  );
}

function setTokenSentToServer(currentToken) {
  window.localStorage.setItem(
    "sentFirebaseMessagingToken",
    currentToken ? currentToken : ""
  );
}

export const unsubscribeWebPush = (
  dispatch,
  currentToken,
  user_id,
  callback
) => {
  dispatch(
    fetchDeleteWebPush({ device_id: currentToken, user_id: user_id })
  ).then(res => {
    if (res.payload.result) {
      setTokenSentToServer(false);
      if (callback) {
        callback();
      }
    }
    if (res.payload.error) {
      ErrorToast(res.payload.error);
    }
  });
};

export const getCurrentToken = () => {
  return window.localStorage.getItem("sentFirebaseMessagingToken");
};
