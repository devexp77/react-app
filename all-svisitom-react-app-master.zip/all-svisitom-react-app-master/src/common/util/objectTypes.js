import strings from '../localization/objectTypes'

export const industryRoleName = (object_type, role_name) => {
  if (!object_type) {
    object_type = 'basic';
  }
  let key_name = object_type + '_role_' + role_name;
  if (strings[key_name]) {
    return strings[key_name];
  } else {
    let basic_key_name = 'basic_role_' + role_name;
    if (strings[basic_key_name]) {
      return strings[basic_key_name]
    } else {
      return key_name;
    }
  }
};

export const objectType = (object_type) => {
  var key = object_type + '_type';
  if (strings[key]) {
    return strings[key];
  } else {
    return key;
  }
};
