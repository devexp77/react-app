const userName = (user) => (
  `${user.name} ${user.surname}`
);

export default userName