export const init_support = (user) => {
  if (typeof jivo_api !== 'undefined') {
    //console.log('call jivo_api.setContactInfo(...)');
    try {
      jivo_api.setContactInfo({
        "name": user.name+' '+user.surname,
        "email": user.email,
        "phone": user.phone_number,
        "description": ""
      });
      //console.log('JivoSite intialized');
    } catch (e) {
      console.log(e);
    }
  } else {
    //console.log('jivo_api is not ready. Waiting 1000ms ...');
    var timer = setTimeout(init_support, 1000, user);
  }
}
