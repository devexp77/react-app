import drawImageToCanvas from "./drawImageToCanvas";
const EXIF = require("exif-js");

export default async function getBlobByImgSrc(src) {
  let image = new Image();
  image.src = src;

  await new Promise(resolve => {
    image.onload = () => resolve();
  });

  let newWidth = image.width;
  let newHeight = image.height;

  if (image.width >= image.height) {
    if (image.width > 1920) {
      newWidth = 1920;
      newHeight = Math.floor((image.height / image.width) * newWidth);
    }
  } else {
    if (image.height > 1080) {
      newHeight = 1080;
      newWidth = Math.floor((image.width / image.height) * newHeight);
    }
  }

  const orientation = await new Promise(resolve => {
    EXIF.getData(image, function() {
      resolve(EXIF.getTag(this, "Orientation"));
    });
  });

  const imageCanvas = drawImageToCanvas(
    image,
    orientation,
    0,
    0,
    newWidth,
    newHeight
  );

  let blob = await new Promise(resolve => {
    imageCanvas.toBlob(
      blob => {
        resolve(blob);
      },
      "image/jpeg",
      0.5
    );
  });

  return {
    blob: blob,
    galleryImage: {
      src: URL.createObjectURL(blob),
      w: imageCanvas.width,
      h: imageCanvas.height
    }
  };
}
