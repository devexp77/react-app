import { HOST_NAME, PROTOCOL } from "../constants";
import openSocket from "socket.io-client";

const connectSocket = user => {
  const websocketUrl = PROTOCOL + "//api." + HOST_NAME + "/";
  let socket = null;

  // console.log("Connect to Websocket " + websocketUrl);
  socket = openSocket(websocketUrl);
  socket.on("connect", () => {
    // console.log("Websocket connected");
    // console.log('Emit "ehlo" with session_token=' + user.result.session_token);
    socket.emit("ehlo", {
      session_token: user.result.session_token
    });
  });

  socket.on("ehlo", () => {
    // console.log("Websocket joined");
  });

  socket.on("disconnect", () => {
    // console.log("Websocket disconnected");
  });

  socket.on("echo", data => {
    // console.log("Websocket echo=" + data);
  });

  return socket;
};

export default connectSocket;
