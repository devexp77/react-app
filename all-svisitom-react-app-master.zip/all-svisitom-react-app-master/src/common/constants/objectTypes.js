import strings from '../localization/objectTypes'

export const OBJECT_TYPES = [
  {value: "basic", label: strings.basic_type},
  {value: "housekeeping", label: strings.housekeeping_type},
  {value: "business_center", label: strings.business_center_type},
  {value: "school", label: strings.school_type},
  {value: "healthcare",  label: strings.healthcare_type},
];
