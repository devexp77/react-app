export const ROLE_ADMIN = "admin";
export const ROLE_SUPPORT = "support";
export const ROLE_MODERATOR = "moderator";

export const ROLE_MANAGER = "manager";
export const ROLE_REGISTRATOR = "registrator";
export const ROLE_INSPECTOR = "inspector";
export const ROLE_SECURITY = "security";

export const ROLE_RESPONSIBLE = "responsible";
export const ROLE_ACCOMPANY = "accompany";
export const ROLE_INVITER = "inviter";
