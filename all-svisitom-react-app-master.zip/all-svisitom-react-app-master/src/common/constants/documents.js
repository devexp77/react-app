import strings from "../localization/objectTypes";

export const DOCUMENTS = {
  passport: [
    {
      id: "number",
      type: "input",
      required: true,
      mask: "9999 999999",
      match: /^([0-9 ])+$/g
    },
    {
      id: "issue_date",
      type: "date"
    },
    {
      id: "issue_place",
      type: "input"
    }
  ],

  international_passport: [
    {
      id: "surname",
      type: "input"
    },
    {
      id: "name",
      type: "input"
    },
    {
      id: "number",
      type: "input",
      required: true,
      mask: "99 9999999",
      match: /^([0-9 ])+$/g
    },
    {
      id: "issue_date",
      type: "date"
    },
    {
      id: "issue_place",
      type: "input"
    }
  ],

  drivers_license: [
    {
      id: "number",
      type: "input",
      required: true,
      mask: "9999999999",
      match: /^([0-9 ])+$/g
    },
    {
      id: "issue_date",
      type: "date"
    },
    {
      id: "issue_place",
      type: "input"
    }
  ],

  custom_document: [
    {
      id: "doc_name",
      type: "input"
    },
    {
      id: "number",
      type: "input",
      required: true,
      match: /^(.)+$/g
    },
    {
      id: "issue_date",
      type: "date"
    },
    {
      id: "issue_place",
      type: "input"
    },
    {
      id: "other_info",
      type: "input"
    }
  ]
};
