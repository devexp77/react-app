
import colors from '../localization/colors';
export const COLORS = [
  colors.black,
  colors.blue,
  colors.light_blue,
  colors.green,
  colors.lyme,
  colors.turquoise,
  colors.purple,
  colors.minty,
  colors.brown,
  colors.gray,
  colors.indigo,
  colors.emerald,
  colors.pink,
  colors.gold,
  colors.beige,
  colors.khaki,
  colors.olive,
  colors.light_green,
  colors.orange,
  colors.lilac,
  colors.yellow,
  colors.ivory,
  colors.white,
  colors.silver,
  colors.red
]
