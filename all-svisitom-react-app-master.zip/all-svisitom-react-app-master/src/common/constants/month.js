import months from '../localization/months'

export const MONTH =
[
{month: months.january,   value: 1},
{month: months.february,  value: 2},
{month: months.march,     value: 3},
{month: months.april,   value: 4},
{month: months.may,      value: 5},
{month: months.june,     value: 6},
{month: months.july,     value: 7},
{month: months.august,   value: 8},
{month: months.september, value: 9},
{month: months.october,  value: 10},
{month: months.november,   value: 11},
{month: months.december,  value: 12}, 
]
