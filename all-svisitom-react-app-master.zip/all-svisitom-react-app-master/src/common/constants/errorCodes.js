
const errorCodes = {
  ROOM_FACILITY_CONFIG_NOT_FOUND: -32082,
};

export default errorCodes;
