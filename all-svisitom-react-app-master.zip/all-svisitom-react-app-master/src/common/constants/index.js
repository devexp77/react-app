// export const HOST_NAME = window.location.hostname;

export const IS_SUBDOMAIN = true;
var _from = 0;
var _to = 2;

if (IS_SUBDOMAIN) {
	_from = 0;
	_to = 3;
}

export var HOST_NAME = window.location.hostname.split('.').reverse().slice(_from, _to).reverse().join('.');
export var SUB_DOMAIN = window.location.hostname.split('.').reverse().slice(_to-1, _to).join('');

// export const HOST_NAME = "svisitom.00l.dev";
// export const SUB_DOMAIN = "manage";

export var FULL_HOST_NAME = window.location.hostname;
export var PROTOCOL = window.location.protocol;
// export const PROTOCOL = 'https:';

if ((PROTOCOL == 'file:') || (HOST_NAME == 'localhost')) {
	HOST_NAME = 'svisitom.00l.dev';
	SUB_DOMAIN = 'manage';
	
	let loc = window.location.href.split("#")[0];
	
	if (loc.indexOf('admin') > -1)   {SUB_DOMAIN = 'admin'}
	if (loc.indexOf('fm') > -1)      {SUB_DOMAIN = 'fm'}
	if (loc.indexOf('ios') > -1)     {SUB_DOMAIN = 'ios'}
	if (loc.indexOf('join') > -1)    {SUB_DOMAIN = 'join'}
	if (loc.indexOf('object') > -1)  {SUB_DOMAIN = 'object'}
	if (loc.indexOf('request') > -1) {SUB_DOMAIN = 'request'}
	if (loc.indexOf('shared') > -1)  {SUB_DOMAIN = 'shared'}
	if (loc.indexOf('support') > -1) {SUB_DOMAIN = 'support'}
	if (loc.indexOf('profile') > -1) {SUB_DOMAIN = 'profile'}
	
	PROTOCOL = 'https:';
}

export const OBJECT_ROLES = ['manager', 'registrator', 'inspector', 'security', 'engineer', 'master'];

export const CDN_URL = `${PROTOCOL}//cdn.${HOST_NAME}`;
export const SVISITOM_URL = `${PROTOCOL}//${HOST_NAME}`;
export const PROFILE_URL = `${PROTOCOL}//profile.${HOST_NAME}`;

export const OBJECT_ICON = `${PROTOCOL}//cdn.${HOST_NAME}/img/icons/object/object.png`;

export const NOTIFICATION_LIMIT = 5;
export const NOTIFICATION_ORDER = '-create_date';

export const GOOGLE_API_KEY = 'AIzaSyAriseuZ90QqiVw_NihABttqK-hS0XkDM4';
export const GOOGLE_MAP_URL = `https://maps.googleapis.com/maps/api/js?key=${GOOGLE_API_KEY}&libraries=geometry,drawing,places`;

export const TRANSPORT_ICONS_PATH = `${CDN_URL}/img/transport-categories`;

export const IDLE_WAIT = 10000;
