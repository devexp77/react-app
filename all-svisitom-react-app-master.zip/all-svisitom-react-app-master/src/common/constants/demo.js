export const demoEmails = [
  'demo@svisitom.ru',
  'mini@svisitom.ru',
  'maxi@svisitom.ru'
]
