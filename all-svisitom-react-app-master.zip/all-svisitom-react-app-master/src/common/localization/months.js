import LocalizedStrings from "react-localization";

const months = new LocalizedStrings({
  "en": {
    "april": "April",
    "august": "August",
    "december": "December",
    "february": "February",
    "january": "January",
    "july": "July",
    "june": "June",
    "march": "March",
    "may": "May",
    "november": "November",
    "october": "October",
    "september": "September"
  },
  "ru": {
    "april": "Апрель",
    "august": "Август",
    "december": "Декабрь",
    "february": "Февраль",
    "january": "Январь",
    "july": "Июль",
    "june": "Июнь",
    "march": "Март",
    "may": "Май",
    "november": "Ноябрь",
    "october": "Октябрь",
    "september": "Сентябрь"
  },
  "de": {
    "april": "April",
    "august": "August",
    "december": "Dezember",
    "february": "Februar",
    "january": "Januar",
    "july": "Juli",
    "june": "Juni",
    "march": "März",
    "may": "Mai",
    "november": "November",
    "october": "Oktober",
    "september": "September"
  }
});

export default months;
