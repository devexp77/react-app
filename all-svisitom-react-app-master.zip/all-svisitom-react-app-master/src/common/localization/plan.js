import LocalizedStrings from "react-localization";

const plan = new LocalizedStrings({
  "en": {
    "default_feature": "Visitors log book",
    "feature_analytics": "Analytics",
    "feature_requests": "Requests for permits",
    "header_feature_options": "Features",
    "header_payment_options": "Pricing",
    "monthly_payment": "monthly subscription fee",
    "one_time_pass_in": "Transaction-Payment"
  },
  "ru": {
    "default_feature": "Журнал посещений",
    "feature_analytics": "Аналитика",
    "feature_requests": "Заказ пропуска",
    "header_feature_options": "Доступные функции",
    "header_payment_options": "Стоимость",
    "monthly_payment": "Абонентская плата (мес.)",
    "one_time_pass_in": "Плата за одну транзакцию"
  },
  "de": {
    "default_feature": "Logbuch",
    "feature_analytics": "Analyse",
    "feature_requests": "Besuch anmelden",
    "header_feature_options": "Funktionen",
    "header_payment_options": "Preise",
    "monthly_payment": "Monatliche Abogebühr",
    "one_time_pass_in": "Transaktionsgebühr"
  }
});

export default plan;
