import {fetchUser}           from '../actions/user';
import {HOST_NAME, PROTOCOL} from '../constants/index';

export const checkAuth = (nextPath, dispatch, user) => {

    const url = encodeURIComponent(nextPath);

    (async () => {
        try {
            if (!user.user.result) {
                await dispatch(fetchUser());
                if (!user.user.result) {
                    return window.location.href = `${PROTOCOL}//${HOST_NAME}/authorize/svisitom?next=${url}`;
                }
                else {
                    return window.location.href = nextPath;
                }
            }
            else {
                return window.location.href = nextPath;
            }
        } catch (e) {
            dispatch(push('/'));
            console.log('catch');
            return ''

        } finally {
        }
    })();
};
