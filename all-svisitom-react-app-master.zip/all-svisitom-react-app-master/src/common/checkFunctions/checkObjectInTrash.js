import { toCustomPath } from "../actions/router";
import { fetchCurrentObject } from "../actions/objects";

export const checkObjectInTrash = (nextState, callback, store) => {
  const { dispatch, getState } = store;

  let objects = getState().objects;

  (async () => {
    try {
      if (!objects.currentObject.result) {
        await dispatch(fetchCurrentObject());
      }

      if (
        getState().objects.currentObject.result &&
        getState().objects.currentObject.result.scheduled_delete
      ) {
        if (nextState.location.pathname !== "/") {
          dispatch(toCustomPath("/"));
        }
      }
      return callback();
    } catch (e) {
      console.log(e);
      return callback();
    } finally {
    }
  })();
};
