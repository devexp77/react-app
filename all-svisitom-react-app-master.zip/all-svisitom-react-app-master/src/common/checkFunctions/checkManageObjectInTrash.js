import { toCustomPath } from "../actions/router";
import { fetchObjectById } from "../actions/objects";

export const checkManageObjectInTrash = (nextState, callback, store) => {
  const { dispatch, getState } = store;

  let objects = getState().objects;

  const object_id = nextState.params.object_id;

  (async () => {
    try {
      if (!objects.objectById.result) {
        await dispatch(fetchObjectById({ object_id: object_id }));
      }

      if (
        getState().objects.objectById.result &&
        getState().objects.objectById.result.scheduled_delete
      ) {
        if (nextState.location.pathname !== "/") {
          dispatch(toCustomPath("/"));
        }
      }
      return callback();
    } catch (e) {
      console.log(e);
      return callback();
    } finally {
    }
  })();
};
