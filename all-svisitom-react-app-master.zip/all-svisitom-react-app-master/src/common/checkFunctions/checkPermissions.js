export const isAdmin = (user) => {
    return user.result && user.result.roles && user.result.roles.find(role => role === 'admin');
};

export const isSupport = (user) => {
    return user.result && user.result.roles && user.result.roles.find(role => role === 'support');
};

export const isManager = (objectPermissions) => {
    return objectPermissions.result && objectPermissions.result.roles
        && objectPermissions.result.roles.find(role => role === 'manager');
};
