import {push}                from 'react-router-redux';
import {FULL_HOST_NAME}      from '../constants/index';
import {HOST_NAME, PROTOCOL} from '../constants/index';

import {fetchUser}                     from '../actions/user';
import {setRoutePath, toRoot}          from '../actions/router';
import {fetchObjectPermissions}        from '../actions/objects'
import {notificationsUpdate}           from '../notificationsUpdate';
import {ErrorToast}                    from '../Toasts/error'
import {isAdmin, isSupport, isManager} from './checkPermissions'

export const checkAdmin = (nextState, callback, store) => {

    const nextPath = nextState.location.pathname;
    const object_id = nextState.params.object_id;
    const url = encodeURIComponent(`${PROTOCOL}//${FULL_HOST_NAME}/#${nextPath}`);
    const {dispatch, getState} = store;

    const router = getState().router;
    const state = getState().user;

    (async () => {
        try {
            if (!state.user.result) {
                await dispatch(fetchUser());
                if (!getState().user.user.result) {
                    if (router.routerPrevPath !== '') {
                        dispatch(push(router.routerPrevPath));
                    }
                    return window.location.href = `${PROTOCOL}//${HOST_NAME}/authorize/svisitom?next=${url}`;
                }
            }
            if (getState().user.user.result) {
                let user = getState().user.user;
                if (isAdmin(user) || isSupport(user)) {
                    dispatch(setRoutePath(nextState.location.pathname));
                    notificationsUpdate(dispatch, getState().user);
                    return callback()
                }
                else {
                    return window.location.href = `${PROTOCOL}//${HOST_NAME}`
                }
            }
        } catch (e) {
            console.log(e);
            return ''
        }
    })();
};
