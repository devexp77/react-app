import {push}                from 'react-router-redux';
import {FULL_HOST_NAME}      from '../constants/index';
import {HOST_NAME, PROTOCOL} from '../constants/index';

import {fetchUser}                     from '../actions/user';
import {setRoutePath, toRoot}          from '../actions/router';
import {fetchObjectPermissions}        from '../actions/objects'
import {notificationsUpdate}           from '../notificationsUpdate';
import {ErrorToast}                    from '../Toasts/error'
import {isAdmin, isSupport, isManager} from './checkPermissions'

export const checkManage = (nextState, callback, store) => {

    const nextPath = nextState.location.pathname;
    const object_id = nextState.params.object_id;
    const url = encodeURIComponent(`${PROTOCOL}//${FULL_HOST_NAME}/#${nextPath}`);
    const {dispatch, getState} = store;

    const router = getState().router;
    const state = getState().user;

    (async () => {
        try {
            if (!state.user.result) {
                await dispatch(fetchUser());
                if (!getState().user.user.result) {
                    if (router.routerPrevPath !== '') {
                        dispatch(push(router.routerPrevPath));
                    }
                    return window.location.href = `${PROTOCOL}//${HOST_NAME}/authorize/svisitom?next=${url}`;
                }
            }
            if (getState().user.user.result) {
                const {objectPermissions} = getState().objects;
                if (!(objectPermissions.result && objectPermissions.result.entity_id
                        && objectPermissions.result.entity_id === object_id)) {
                    const data = {
                        object_id: object_id,
                        user_id  : getState().user.user.result.user_id
                    };
                    await dispatch(fetchObjectPermissions(data));
                }

                let objPermissions = getState().objects.objectPermissions;
                let user = getState().user.user;
                if (isManager(objPermissions)) {
                    dispatch(setRoutePath(nextState.location.pathname));
                    notificationsUpdate(dispatch, getState().user);
                    return callback()
                }
                else if (isAdmin(user) || isSupport(user)) {
                    dispatch(setRoutePath(nextState.location.pathname));
                    notificationsUpdate(dispatch, getState().user);
                    return callback()
                }
                else {
                    dispatch(toRoot());
                    const error = {
                        code: '-32045'
                    };
                    ErrorToast(error);
                }
            }
        } catch (e) {
            console.log(e);
            return ''

        } finally {
        }
    })();
};
