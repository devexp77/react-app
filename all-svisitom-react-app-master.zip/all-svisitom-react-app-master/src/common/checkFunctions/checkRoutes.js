import {push}                     from 'react-router-redux';
import {fetchUser}                from '../actions/user';
import {setRoutePath}             from '../actions/router';
import {FULL_HOST_NAME, PROTOCOL} from '../constants/index';
import {HOST_NAME}                from '../constants/index';
import {notificationsUpdate}      from '../notificationsUpdate';

export const checkRoutes = (nextState, callback, store) => {

    const nextPath = nextState.location.pathname;
    const url = encodeURIComponent(`${PROTOCOL}//${FULL_HOST_NAME}/#${nextPath}`);
    const {dispatch, getState} = store;

    let router = getState().router;
    let state = getState().user;

    (async () => {
        try {
            if (!state.user.result) {
                await dispatch(fetchUser());
                if (!getState().user.user.result) {
                    if (router.routerPrevPath !== '') {
                        dispatch(push(router.routerPrevPath));
                    }
                    return window.location.href = `${PROTOCOL}//${HOST_NAME}/authorize/svisitom?next=${url}`;
                }
                else {
                    dispatch(setRoutePath(nextState.location.pathname));
                    notificationsUpdate(dispatch, getState().user);
                    return callback()
                }
            }
            else {
                dispatch(setRoutePath(nextState.location.pathname));
                notificationsUpdate(dispatch, getState().user);
                return callback()
            }
        } catch (e) {
            console.log(e);
            return ''
        } finally {
        }
    })();
};
