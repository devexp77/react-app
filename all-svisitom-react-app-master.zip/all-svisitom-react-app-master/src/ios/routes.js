import { Route, IndexRoute } from "react-router";
import React from "react";

import App from "./containers/App";

export default function configRoutes(store) {
  return <Route path="/:object_id" component={App} />;
}
