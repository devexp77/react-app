import React, { Component } from "react";
import { connect } from "react-redux";

import { ErrorToast } from "../../common/Toasts/error";
import {
  fetchIosById, fetchIosMetaById,
  fetchIosMetaUrl,
  fetchIosUrl
} from "../../common/actions/ios";
import IosEditor from "../../common/components/IosEditor";

import "./style.css";
import Preloader from "../../common/components/Preloader/preloader";

class AppContainer extends Component {
  constructor() {
    super();
    this.state = {
      IOSFileLoaded: false,
      IOSMetaFileLoaded: false
    };
  }

  componentDidMount() {
    this.getISODataFromServer();
  }

  getISODataFromServer() {
    const { dispatch } = this.props;

    (async () => {
      try {
        await this.setState({
          IOSFileLoaded: false,
          IOSMetaFileLoaded: false
        });
        await window.ios.Storage.clear();
        const object_id = this.props.params.object_id.split(",")[0];
        const data = {
          object_id: object_id
        };
        await dispatch(fetchIosUrl(data));
        if (this.props.ios.iosUrl.result) {
          (async () => {
            await dispatch(fetchIosById(this.props.ios.iosUrl.result));
            window.ios.Storage.importBuilding(this.props.ios.iosById, () =>
              this.setState({
                IOSFileLoaded: true
              })
            );
          })();

          (async () => {
            await dispatch(
              fetchIosMetaUrl({
                object_id: object_id,
                file_type: "meta"
              })
            );
            if (this.props.ios.iosMetaUrl.result) {
              await dispatch(fetchIosMetaById(this.props.ios.iosMetaUrl.result));
              window.ios.Storage.importMetadata(
                object_id,
                JSON.parse(this.props.ios.iosMetaById),
                () => {
                  this.setState({ IOSMetaFileLoaded: true });
                }
              );
            } else {
              this.setState({ IOSMetaFileLoaded: true });
            }
          })();
        }
      } catch (e) {
        ErrorToast();
        console.log(e);
      } finally {
      }
    })();
  }

  render() {
    if (this.state.IOSMetaFileLoaded && this.state.IOSFileLoaded) {
      return (
        <IosEditor
          action={`view`}
          id={this.props.params.object_id}
          shareButton
        />
      );
    } else return <Preloader />;
  }
}

const mapStateToProps = state => {
  return {
    ios: state.ios
  };
};

export default connect(mapStateToProps)(AppContainer);
