import { combineReducers } from "redux";
import { routerReducer } from "react-router-redux";

import ios from "../../common/reducers/ios";

export default combineReducers({
  routing: routerReducer,
  ios
});
