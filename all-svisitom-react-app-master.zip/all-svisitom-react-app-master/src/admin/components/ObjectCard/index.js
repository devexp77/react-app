import React, {Component} from 'react'
import Moment from 'react-moment'
import strings from '../../localization/all'
import { PROTOCOL, HOST_NAME } from '../../../common/constants'

class ObjectCard extends Component {

  constructor() {
    super()
    this.handleInputChange = this.handleInputChange.bind(this)
    this.handleButtonCancelClick = this.handleButtonCancelClick.bind(this)
    this.state = {
      expanded_item: ''
    }
  }

  componentDidMount() {
    if (this.props.object) {
      this.setState({
        object_blocked: this.props.object.blocked + '',
        object_suspended: this.props.object.suspended + ''
      })
    }
  }

  handleInputChange(event) {
    const id = event.target.id;
    const value = event.target.value;
    this.setState({[id]: value});
  }

  expandItem(name) {
    this.setState({
      expanded_item: name
    }, function() {
      var _this=this
      $(document).ready(function() {
        $('.mdb-select').material_select('destroy');
        $('.mdb-select').material_select();
        $('#object_blocked').off()
        $('#object_blocked').on('change', _this.handleInputChange);
        $('#object_suspended').off()
        $('#object_suspended').on('change', _this.handleInputChange);
      });
    })
  }

  handleButtonCancelClick() {
    this.setState({
      expanded_item: ''
    })
  }

  handleSaveBlocked() {
    this.props.onSaveBlocked(this.state.object_blocked == 'true');
    this.setState({
      expanded_item: ''
    });
  }

  handleSaveSuspended() {
    this.props.onSaveSuspended(this.state.object_suspended == 'true');
    this.setState({
      expanded_item: ''
    });
  }

  renderObjectBlockedCollapsed() {
    return (
      <tr key="object_blocked_row" onClick={this.expandItem.bind(this, 'blocked')}>
        <td className="first">{strings.label_blocked}</td>
        <td className="td-grey second">
          {this.props.object.blocked ? strings.text_yes: strings.text_no}
        </td>
        <td className="last">
          <i className="material-icons">mode_edit</i>
        </td>
      </tr>
    )
  }

  renderObjectBlockedExpanded() {
    return (
      <tr key="object_blocked_row">
        <td className="first">{strings.label_blocked}</td>
        <td className="second" colSpan="2">
          <div>
            <select id="object_blocked" className="mdb-select" value={this.state.object_blocked} onChange={this.handleInputChange}>
              <option value="true">{strings.text_yes}</option>
              <option value="false">{strings.text_no}</option>
            </select>
          </div>
          <div>
            <button className="btn btn-flat waves-effect" onClick={this.handleSaveBlocked.bind(this)}>{strings.button_save}</button>
            <button className="btn btn-flat waves-effect" onClick={this.handleButtonCancelClick}>{strings.button_cancel}</button>
          </div>
        </td>
      </tr>
    )
  }

  renderObjectSuspendedCollapsed() {
    return (
      <tr key="object_suspended_row" onClick={this.expandItem.bind(this, 'suspended')}>
        <td className="first">{strings.label_suspended}</td>
        <td className="td-grey second">
          {this.props.object.suspended ? strings.text_yes: strings.text_no}
        </td>
        <td className="last">
          <i className="material-icons">mode_edit</i>
        </td>
      </tr>
    )
  }

  renderObjectSuspendedExpanded() {
    return (
      <tr key="object_suspended_row">
        <td className="first">{strings.label_suspended}</td>
        <td className="second" colSpan="2">
          <div>
            <select id="object_suspended" className="mdb-select" value={this.state.object_suspended} onChange={this.handleInputChange}>
              <option value="true">{strings.text_yes}</option>
              <option value="false">{strings.text_no}</option>
            </select>
          </div>
          <div>
            <button className="btn btn-flat waves-effect" onClick={this.handleSaveSuspended.bind(this)}>{strings.button_save}</button>
            <button className="btn btn-flat waves-effect" onClick={this.handleButtonCancelClick}>{strings.button_cancel}</button>
          </div>
        </td>
      </tr>
    )
  }

  render() {
    if (this.props.object) {
      var object = this.props.object
      var owner = this.props.owner
      return (
        <div className="profile">
          <table className="table">
            <tbody>
              <tr className="non-cursor">
                <td className="first">{strings.name}</td>
                <td className="td-grey second">{object.name}</td>
                <td className="last"></td>
              </tr>

              <tr className="non-cursor">
                <td className="first">{strings.description}</td>
                <td className="td-grey second">{object.description}</td>
                <td className="last"></td>
              </tr>

              <tr className="non-cursor">
                <td className="first">{strings.domain_name}</td>
                <td className="td-grey second">{object.domain_name}</td>
                <td className="last"></td>
              </tr>

              <tr className="non-cursor">
                <td className="first">{strings.create_date}</td>
                <td className="td-grey second">
                  {
                    object.create_date
                    ? <Moment format="DD.MM.YYYY HH:mm">{object.create_date}</Moment>
                    : strings.no_data
                  }
                </td>
                <td className="last"></td>
              </tr>

              <tr className="non-cursor">
                <td className="first">{strings.owner}</td>
                <td className="td-grey second">
                  {owner
                    ? <a onClick={this.props.gotoOwner} className="link">{owner.surname} {owner.name}</a>
                    : strings.no_data}
                </td>
                <td className="last"></td>
              </tr>

              {
                this.state.expanded_item == 'blocked'
                ?
                  this.renderObjectBlockedExpanded()
                :
                  this.renderObjectBlockedCollapsed()
              }

              {
                this.state.expanded_item == 'suspended'
                ?
                  this.renderObjectSuspendedExpanded()
                :
                  this.renderObjectSuspendedCollapsed()
              }

            </tbody>
          </table>

          <div>
            <a href={PROTOCOL + '//' + object.domain_name + '.' + HOST_NAME} className="btn btn-flat waves-effect" target="_blank">
              {strings.button_goto_object}
            </a>
          </div>
        </div>
      )
    } else {
      return (
        <div>No object</div>
      )
    }
  }
}

export default ObjectCard
