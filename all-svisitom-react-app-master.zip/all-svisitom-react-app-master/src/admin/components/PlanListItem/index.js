import React from 'react'
import format from 'string-format'
import strings from '../../localization/all'

const PlanListItem = ({plan}) => {
  return (
    <div className="material-list-item non-cursor" data-id={plan.plan_id}>
      <div className="material-list-item-icon"><i className="material-icons">attach_money</i></div>
      <div className="material-list-item-first-line">{plan.name}</div>
      <div className="material-list-item-second-line">{format(strings.monthly_payment, plan.monthly)}</div>
      {
        plan.one_time && plan.one_time.pass_in
        ? <div className="material-list-item-second-line">{format(strings.single_pass_payment, plan.one_time.pass_in)}</div>
        : null
      }

    </div>
  )
}

export default PlanListItem
