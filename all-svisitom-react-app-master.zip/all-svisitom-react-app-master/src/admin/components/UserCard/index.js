import React, {Component} from 'react'
import Moment from 'react-moment'
import strings from '../../localization/all'
import format from 'string-format'

import Icon from '../../../common/components/Icon'

import './style.css'
import common_strings from "../../../common/localization/all";
import {FlatButton, RaisedButton} from "../../../common/components/Button";

class UserCard extends Component {

  constructor() {
    super()
    this.role_names = ['admin', 'support', 'moderator']

    this.state = {
      expanded_item: '',
      user_status: 'active',
      user_comment: '',
      block_reason: '',
      balance_correction: 0,
      balance_correction_comment: '',
      promo_period_deadline: '',
    }

    this.handleInputChange = this.handleInputChange.bind(this)
    this.handleCheckboxChange = this.handleCheckboxChange.bind(this)
    this.handleButtonCancelClick = this.handleButtonCancelClick.bind(this)
    this.handleButtonSaveUserStatusClick = this.handleButtonSaveUserStatusClick.bind(this)
    this.handleButtonSaveUserCommentClick = this.handleButtonSaveUserCommentClick.bind(this)
    this.handleButtonSaveUserRolesClick = this.handleButtonSaveUserRolesClick.bind(this)
    this.handleUserStatusClick = this.handleUserStatusClick.bind(this)
    this.handleUserCommentClick = this.handleUserCommentClick.bind(this)
    this.handleUserRolesClick = this.handleUserRolesClick.bind(this)
    this.handleBalanceClick = this.handleBalanceClick.bind(this)
    this.handleButtonSaveBalanceCorrection = this.handleButtonSaveBalanceCorrection.bind(this)
  }

  componentDidMount() {
    if (this.props.billingAccount) {

    }

    this.datePicker = new MaterialDatetimePicker({
      cancelText: common_strings.button_cancel,
      okText: common_strings.button_done
    })
    .on('submit', (val) => {
      this.updateDate(val._d);
    });
  }

  componentWillUnmount() {
    this.loadStatesFromProps(this.props);
  }

  componentWillReceiveProps(nextProps) {
    this.loadStatesFromProps(nextProps);

    const _this=this;
    $(document).ready(function() {
      $('.mdb-select').material_select('destroy');
      $('.mdb-select').material_select();
      $('#user_status').off();
      $('#user_status').on('change', _this.handleInputChange);
    });
  }

  updateDate(date) {
    this.setState({
      promo_period_deadline: date
    })
  }

  loadStatesFromProps(props) {
    if (!props || !props.user) {
      return
    }

    var new_state = {
      user_status: props.user.status,
      user_comment: props.user.comment
    };

    var roles = props.user.roles;
    if (roles != null) {
      for (var i=0; i<this.role_names.length; i++) {
        new_state['role_'+this.role_names[i]] = roles.includes(this.role_names[i])
      }
    }

    if (props.billingAccount) {
      new_state['promo_period_deadline'] = props.billingAccount.promo_period_deadline;
    }

    this.setState(new_state)
  }

  render() {
    if (this.props.user) {
      var { billingAccount } = this.props;

      return (
        <div>
          <table className="table">
            <tbody>
              <tr className="non-cursor">
                <td className="first">{strings.name}</td>
                <td className="td-grey second">{this.props.user.surname} {this.props.user.name} {this.props.user.patronymic}</td>
                <td className="last"></td>
              </tr>

              <tr className="non-cursor">
                <td className="first">{strings.email}</td>
                <td className="td-grey second">{this.props.user.email}</td>
                <td className="last"></td>
              </tr>

              <tr className="non-cursor">
                <td className="first">{strings.phone}</td>
                <td className="td-grey second">{this.props.user.phone_number}</td>
                <td className="last"></td>
              </tr>

              <tr className="non-cursor">
                <td className="first">{strings.register_date}</td>
                <td className="td-grey second">
                  <Moment format="DD.MM.YYYY HH:mm">{this.props.user.create_date}</Moment>
                </td>
                <td className="last"></td>
              </tr>

              {
                billingAccount && billingAccount.partner_id
                ?
                  <tr className="non-cursor">
                    <td className="first">{strings.partner}</td>
                    <td className="td-grey second">
                      {format(strings.partner_id, billingAccount.partner_id)}
                    </td>
                    <td className="last"></td>
                  </tr>
                : null
              }

              {
                this.props.expanded_item == 'balance'
                ?
                  this.renderBalanceExpanded()
                :
                  this.renderBalanceCollapsed()
              }

              {
                this.props.expanded_item == 'promo_period_deadline'
                ?
                  this.renderPromoPeriodDeadlineExpanded()
                :
                  this.renderPromoPeriodDeadlineCollapsed()
              }
            </tbody>
          </table>

          <h3>{strings.subtitle_user_system_properties}</h3>

          <table className="table">
            <tbody>

              {
                this.props.expanded_item == 'status'
                ?
                  this.renderUserStatusExpanded()
                :
                  this.renderUserStatusCollapsed()
              }

              {
                this.props.expanded_item == 'comment'
                ?
                  this.renderUserCommentExpanded()
                :
                  this.renderUserCommentCollapsed()
              }

              {
                this.props.expanded_item == 'roles'
                ?
                  this.renderUserRolesExpanded()
                :
                  this.renderUserRolesCollapsed()
              }
            </tbody>
          </table>

        </div>
      )
    } else {
      return (
        <div>No user</div>
      )
    }
  }

  renderBalanceCollapsed() {
    return (
      <tr key="user_balance_row" onClick={this.handleBalanceClick}>
        <td className="first">{strings.balance}</td>
        <td className="td-grey second">
          {this.props.billingAccount ? format(strings.balance_value, this.props.billingAccount.balance) : ''}
        </td>
        <td className="last">
          <i className="material-icons">mode_edit</i>
        </td>
      </tr>
    )
  }

  renderBalanceExpanded() {
    return (
      <tr key="user_balance_row">
        <td className="first">{strings.balance}</td>
        <td className="second" colSpan="2">
          <div className="md-form">
            <input id="balance_correction" type="number" value={this.state.user_balance} onChange={this.handleInputChange} className="form-control"/>
            <label htmlFor="balance_correction">{strings.label_balance_correction}</label>
          </div>
          <div className="md-form">
            <input id="balance_correction_comment" type="text" value={this.state.user_balance} onChange={this.handleInputChange} className="form-control"/>
            <label htmlFor="balance_correction_comment">{strings.label_balance_correction_comment}</label>
          </div>
          <div>
            <button className="btn btn-flat waves-effect" onClick={this.handleButtonSaveBalanceCorrection}>{strings.button_save}</button>
            <button className="btn btn-flat waves-effect" onClick={this.handleButtonCancelClick}>{strings.button_cancel}</button>
          </div>
        </td>
      </tr>
    )
  }

  renderUserStatusCollapsed() {
    return (
      <tr key="user_status_row" onClick={this.handleUserStatusClick}>
        <td className="first">{strings.status}</td>
        <td className="td-grey second">
          {strings['status_'+this.props.user.status]}
        </td>
        <td className="td-grey last">
          <i className="material-icons">chevron_right</i>
        </td>
      </tr>
    )
  }

  renderUserStatusExpanded() {
    return (
      <tr key="user_status_row">
        <td className="first">{strings.status}</td>
        <td className="second" colSpan="2">
          <div>
            <select id="user_status" className="mdb-select" value={this.state.user_status} onChange={this.handleInputChange}>
              <option value="active">{strings.status_active}</option>
              <option value="blocked">{strings.status_blocked}</option>
            </select>
          </div>
          <div>
            <button className="btn btn-flat waves-effect" onClick={this.handleButtonSaveUserStatusClick}>{strings.button_save}</button>
            <button className="btn btn-flat waves-effect" onClick={this.handleButtonCancelClick}>{strings.button_cancel}</button>
          </div>
        </td>
      </tr>
    )
  }

  renderUserCommentCollapsed() {
    return (
      <tr key="user_comment_row" onClick={this.handleUserCommentClick}>
        <td className="first">{strings.comment}</td>
        <td className="td-grey second">
          {this.props.user.comment}
        </td>
        <td className="td-grey last">
          <i className="material-icons">chevron_right</i>
        </td>
      </tr>
    )
  }

  renderUserCommentExpanded() {
    return (
      <tr key="user_comment_row">
        <td className="first">{strings.comment}</td>
        <td className="second" colSpan="2">
          <div className="md-form">
            <input id="user_comment" type="text" value={this.state.user_comment} onChange={this.handleInputChange} className="form-control"/>
          </div>
          <div>
            <button className="btn btn-flat waves-effect" onClick={this.handleButtonSaveUserCommentClick}>{strings.button_save}</button>
            <button className="btn btn-flat waves-effect" onClick={this.handleButtonCancelClick}>{strings.button_cancel}</button>
          </div>
        </td>
      </tr>
    )
  }

  renderUserRolesCollapsed() {
    return (
      <tr key="user_roles_row" onClick={this.handleUserRolesClick}>
        <td className="first">{strings.roles}</td>
        <td className="td-grey second">
          {
            this.props.user.roles
            ?
              this.props.user.roles.map((role, index) =>
                (<span className="chip" key={'role_display_'+role}>{strings['role_'+role] ? strings['role_'+role] : role}</span>)
              )
            : null
          }
        </td>
        <td className="td-grey last">
          <i className="material-icons">chevron_right</i>
        </td>
      </tr>
    )
  }

  renderUserRolesExpanded() {
    var roles = []
    if (this.props.user && this.props.user.roles) {
      roles = this.props.user.roles
    }

    return (
      <tr key="user_roles_row">
        <td className="first">{strings.roles}</td>
        <td className="second" colSpan="2">
          {
            this.role_names.map(
              (role_name) =>
              (
                <div className="form-group" key={'role_checkbox_'+role_name}>
                    <input type="checkbox" id={'role_'+role_name} onChange={this.handleCheckboxChange} checked={this.state['role_'+role_name]}/>
                    <label htmlFor={'role_'+role_name}>{strings['role_'+role_name]}</label>
                </div>
              )
            )
          }
          <div>
            <button className="btn btn-flat waves-effect" onClick={this.handleButtonSaveUserRolesClick}>{strings.button_save}</button>
            <button className="btn btn-flat waves-effect" onClick={this.handleButtonCancelClick}>{strings.button_cancel}</button>
          </div>
        </td>
      </tr>
    )
  }

  renderPromoPeriodDeadlineCollapsed() {
    if (this.props.user) {
      return (
        <tr className="" onClick={this.handlePromoPeriodDeadlineClick.bind(this)}>
          <td className="first">{strings.promo_period_deadline}</td>
          <td className="td-grey second">
            {
              this.state.promo_period_deadline
              ?
              <Moment format="DD.MM.YYYY HH:mm">{this.state.promo_period_deadline}</Moment>
              :
              strings.no_promo_period_deadline
            }
          </td>
          <td className="last"></td>
        </tr>
      )
    } else {
      return null;
    }
  }

  renderPromoPeriodDeadlineExpanded() {
    let {billingAccount} = this.props;
    return (
      <tr key="promo_period_deadline_row">
        <td className="first">{strings.promo_period_deadline}</td>
        <td className="second" colSpan="2">
          <div className="md-form">
            <div className="admin-date-field" onClick={this.handleChoosePromoPeriodDeadline.bind(this)}>
              {
                this.state.promo_period_deadline
                ?
                  <Moment format="DD.MM.YYYY HH:mm">{this.state.promo_period_deadline}</Moment>
                :
                  strings.no_promo_period_deadline
              }

              <Icon name="date_range" />
            </div>
          </div>
          <div>
            <RaisedButton onClick={this.handleSavePromoPeriodDeadline.bind(this)}>{strings.button_save}</RaisedButton>
            <FlatButton onClick={this.handleButtonCancelClick}>{strings.button_cancel}</FlatButton>
            <FlatButton onClick={this.handleClearPromoPeriodDeadline.bind(this)} style={{float: 'right'}}>{common_strings.button_delete}</FlatButton>
          </div>
        </td>
      </tr>

    )
  }


  handleInputChange(event) {
    const id = event.target.id;
    const value = event.target.value;
    this.setState({[id]: value});
  }

  handleCheckboxChange(event) {
    const id = event.target.id;
    const value = event.target.checked;
    this.setState({[id]: value});
  }

  handleButtonCancelClick() {
    this.loadStatesFromProps();
    this.props.expandItem('')
  }

  handleUserStatusClick() {
    this.props.expandItem('status')
  }

  handleUserCommentClick() {
    this.props.expandItem('comment')
  }

  handleUserRolesClick() {
    this.props.expandItem('roles')
  }

  handleBalanceClick() {
    this.props.expandItem('balance')
  }

  handlePromoPeriodDeadlineClick() {
    this.props.expandItem('promo_period_deadline')
  }

  handleButtonSaveUserStatusClick() {
    var data = {
      user_id: this.props.user.user_id,
      status: this.state.user_status
    };

    this.props.setUser(data)
  }

  handleButtonSaveUserCommentClick() {
    var data = {
      user_id: this.props.user.user_id,
      comment: this.state.user_comment
    };

    this.props.setUser(data)
  }

  handleButtonSaveUserRolesClick() {
    var roles = [];
    if (this.state.role_admin) {
      roles.push('admin')
    }

    if (this.state.role_support) {
      roles.push('support')
    }

    if (this.state.role_moderator) {
      roles.push('moderator');
    }

    var data = {
      user_id: this.props.user.user_id,
      roles: roles
    };

    this.props.setUser(data)
  }

  handleButtonSaveBalanceCorrection() {
    this.props.correctBalance(this.state.balance_correction, this.state.balance_correction_comment)
  }

  handleChoosePromoPeriodDeadline() {
    this.datePicker.open()
  }

  handleClearPromoPeriodDeadline() {
    this.props.clearPromoPeriodDeadline()
  }

  handleSavePromoPeriodDeadline() {
    this.props.setPromoPeriodDeadline(this.state.promo_period_deadline)
  }
}

export default UserCard
