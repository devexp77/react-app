import React from "react";
import { connect } from "react-redux";

import ProfileInfo from "../../../common/components/ProfileInfo";

import strings from "../../localization/all";
import {
  setCustomHistoryPath,
  setTitle,
  toCustomPath
} from "../../../common/actions/router";
import {
  clearDeviceById,
  fetchCheckDevicesOnline,
  fetchDeleteDevice,
  fetchDeviceById
} from "../../../common/actions/devices";
import { ErrorToast } from "../../../common/Toasts";
import {
  clearObjectById,
  fetchObjectById
} from "../../../common/actions/objects";
import CircleLoader from "../../../common/components/CircleLoader";
import SinglePageWithCustomPaddingNavPanel from "../../../common/components/PageContainers/singlePageCustomPaddingNavPanel";
import ButtonDelete from "../../../common/components/ButtonDelete";
import DeletePopUp from "../../../common/components/DeletePopUp";
import { FlatButton } from "../../../common/components/Button";

class DeviceContainer extends React.Component {
  componentDidMount() {
    window.scrollTo(0, 0);
    const { dispatch } = this.props;
    dispatch(setCustomHistoryPath(`/devices`));
    dispatch(setTitle(""));

    this.loadDevice();
  }

  componentWillUnmount() {
    const { dispatch } = this.props;
    dispatch(clearObjectById());
    dispatch(clearDeviceById());
  }

  loadDevice() {
    const { dispatch } = this.props;
    const device_id = this.props.params.device_id;

    (async () => {
      try {
        await dispatch(
          fetchDeviceById({
            device_id: device_id
          })
        );

        let { deviceById } = this.props.devices;
        if (deviceById.error) {
          ErrorToast(deviceById.error);
          return;
        }

        if (deviceById.result) {
          dispatch(
            fetchCheckDevicesOnline({
              serials: [deviceById.result.device_serial]
            })
          ).then(res => {
            if (res.payload.error) {
              ErrorToast(res.payload.error);
            }
          });
        }

        dispatch(setTitle(deviceById.result.device_serial));

        if (deviceById.result.object_id) {
          await dispatch(
            fetchObjectById({
              object_id: deviceById.result.object_id
            })
          );
        }

        let { objectById } = this.props.objects;
        if (objectById.error) {
          ErrorToast(objectById.error);
        }
      } catch (e) {
        console.log(e);
        ErrorToast();
      }
    })();
  }

  toHistoryPath() {
    const { dispatch } = this.props;
    const fromHistory = this.props.router.history.pop();
    const historyPath = fromHistory
      ? fromHistory
      : this.props.router.customHistoryPath;
    dispatch(toCustomPath(historyPath));
  }

  deleteDevice() {
    const { dispatch } = this.props;
    const device_id = this.props.params.device_id;

    (async () => {
      try {
        await dispatch(
          fetchDeleteDevice({
            devices_ids: [device_id]
          })
        );

        let { deviceOperation } = this.props.devices;
        if (deviceOperation.error) {
          ErrorToast(deviceOperation.error);
          return;
        }

        if (deviceOperation.result) {
          this.toHistoryPath();
        }
      } catch (e) {
        console.log(e);
        ErrorToast();
      }
    })();
  }

  toCreateTunnel() {
    const { dispatch } = this.props;
    const device_id = this.props.params.device_id;
    dispatch(toCustomPath(`/devices/${device_id}/tunnel`));
  }

  render() {
    let { deviceById } = this.props.devices;
    let { objectById } = this.props.objects;
    let { deviceByIdIsFetching, checkDevicesOnline } = this.props.devices;
    if (!deviceById) {
      return null;
    }

    if (!deviceById.result || deviceByIdIsFetching) {
      return <CircleLoader />;
    }

    return (
      <SinglePageWithCustomPaddingNavPanel>
        <ProfileInfo.Table title={""}>
          <ProfileInfo.Row
            trClassName={`non-cursor`}
            mIconClass={`d-none`}
            title={strings.label_device_name}
            data={deviceById.result.device_name}
          />

          <ProfileInfo.Row
            trClassName={`non-cursor`}
            mIconClass={`d-none`}
            title={strings.label_device_serial}
            data={deviceById.result.device_serial}
          />

          <ProfileInfo.Row
            trClassName={`non-cursor`}
            mIconClass={`d-none`}
            title={strings.label_device_object}
            data={objectById.result ? objectById.result.name : null}
          />

          <ProfileInfo.Row
            trClassName={`non-cursor`}
            mIconClass={`d-none`}
            title={strings.label_device_status}
            data={
              strings[
                `label_device_status_${
                  checkDevicesOnline.result
                    ? checkDevicesOnline.result[deviceById.result.device_serial]
                    : null
                }`
              ]
            }
          />
        </ProfileInfo.Table>

        <ButtonDelete buttonTitle={strings.button_delete_device} />
        <FlatButton onClick={this.toCreateTunnel.bind(this)}>
          SSH Tunnel
        </FlatButton>
        <DeletePopUp
          header={strings.confirm_delete_device}
          deleteFunction={this.deleteDevice.bind(this)}
        />
      </SinglePageWithCustomPaddingNavPanel>
    );
  }
}

const mapStateToProps = (state, ownProps) => {
  return {
    objects: state.objects,
    devices: state.devices,
    router: state.router,
  };
};

export default connect(mapStateToProps)(DeviceContainer);
