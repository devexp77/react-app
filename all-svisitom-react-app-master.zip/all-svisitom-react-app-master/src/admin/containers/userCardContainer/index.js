import React, { Component } from 'react'
import { connect } from 'react-redux'

import {
  fetchUser,
  fetchSetUser,
  expandUserPageItem,
  clearUserInfo,
  fetchSetPromoPeriodDeadline,
  fetchClearPromoPeriodDeadline,
} from '../../actions/admin'

import {
  fetchBillingAccount,
  clearBillingAccount,
  fetchAddBillingTransaction
} from '../../../common/actions/billing'

import { setCustomHistoryPath, setTitle } from "../../../common/actions/router";


import strings from '../../localization/all'

import UserCard from '../../components/UserCard'
import ObjectsListContainer from '../objectsListContainer'
import NavigationTitle from '../../../common/components/NavigationTitle'
import SinglePageWithCustomPaddingNavPanel from "../../../common/components/PageContainers/singlePageCustomPaddingNavPanel";
import {ErrorToast} from '../../../common/Toasts/error'


class UserCardContainer extends Component {

  constructor() {
    super()
    this.state = {
      expanded_item: ''
    }
  }

  componentDidMount() {
    const { dispatch } = this.props;
    dispatch(setTitle(''));
    dispatch(setCustomHistoryPath("/users"));

    this.loadUser()
  }

  componentWillUnmount() {
    var {dispatch} = this.props
    dispatch(clearUserInfo())
    dispatch(clearBillingAccount())
  }

  loadUser() {
    const { dispatch } = this.props;
    (async () => {
      try {
        var user_id = this.props.params.user_id;
        var data = {
          user_id: user_id
        };

        await dispatch(fetchUser(data));
        var {user} = this.props.admin
        if (user.error) {
          ErrorToast(user.error)
          return
        }

        dispatch(setTitle(user.result.email));

        await dispatch(fetchBillingAccount({user_id: user_id}))
        var {account} = this.props.billing
        if (account.error && account.error.code != -32076) {
          ErrorToast(account.error)
          return
        }
      } catch (e) {
        console.log(e);
        ErrorToast()
      }
    })();
  }

  render() {
    var user = this.props.admin.user.result
    if (!user) {
      return null
    }

    return (
      <SinglePageWithCustomPaddingNavPanel>
        <NavigationTitle title= {strings.title_user} />
          <div className="profile">
              {
                this.props.admin.user
                ?
                  <UserCard
                    user={user}
                    billingAccount={this.props.billing.account.result}
                    correctBalance={this.correctBalance.bind(this)}
                    setUser={this.setUser.bind(this)}
                    expandItem={this.expandUserPageItem.bind(this)}
                    expanded_item={this.state.expanded_item}
                    setPromoPeriodDeadline={this.setPromoPeriodDeadline.bind(this)}
                    clearPromoPeriodDeadline={this.clearPromoPeriodDeadline.bind(this)}
                  />
                : null
              }
          </div>

          <div>
              <h3>{strings.subtitle_user_objects}</h3>
          </div>
          <ObjectsListContainer
            filter={{
              owner_id: user.user_id
            }}
            query_order="+name"
          />
      </SinglePageWithCustomPaddingNavPanel>
    )
  }

  setUser(data) {
    const { dispatch } = this.props;

    (async () => {
      try {
        await dispatch(fetchSetUser(data));

        if (this.props.admin.set_user_response.result) {
          this.expandUserPageItem('')
          this.loadUser()
        }
      } catch (e) {
        console.log(e);
      } finally {
      }
    })();
  }

  correctBalance(value, comment) {
    const {dispatch} = this.props;

    (async () => {
      try {
        var data = {
          tranx_data: {
            user_id: this.props.params.user_id,
            amount: parseFloat(value),
            key: 'correction',
            comment: comment
          }
        };

        await dispatch(fetchAddBillingTransaction(data));

        var {billing} = this.props
        if (billing.addTransaction.error) {
          ErrorToast(billing.addTransaction.error)
          return
        }

        if (billing.addTransaction.result) {
          this.expandUserPageItem('')
          this.loadUser()
        }
      } catch (e) {
        console.log(e);
        ErrorToast()
      }
    })();
  }

  expandUserPageItem(item_name) {
    this.setState({
      expanded_item: item_name
    })
  }

  setPromoPeriodDeadline(date) {
    const {dispatch} = this.props;

    (async () => {
      try {
        const data = {
          user_id: this.props.params.user_id,
          promo_period_deadline: date,
        };

        await dispatch(fetchSetPromoPeriodDeadline(data));

        let {admin} = this.props;
        if (admin.billingOperationStatus.error) {
          ErrorToast(admin.billingOperationStatus.error);
          return
        }

        if (admin.billingOperationStatus.result) {
          this.expandUserPageItem('');
          this.loadUser()
        }
      } catch (e) {
        console.log(e);
        ErrorToast()
      }
    })();
  }

  clearPromoPeriodDeadline() {
    const {dispatch} = this.props;

    (async () => {
      try {
        const data = {
          user_id: this.props.params.user_id,
        };

        await dispatch(fetchClearPromoPeriodDeadline(data));

        let {admin} = this.props;
        if (admin.billingOperationStatus.error) {
          ErrorToast(admin.billingOperationStatus.error);
          return
        }

        if (admin.billingOperationStatus.result) {
          this.expandUserPageItem('');
          this.loadUser()
        }
      } catch (e) {
        console.log(e);
        ErrorToast()
      }
    })();
  }

}

const mapStateToProps = (state, ownProps) => {
  return {
   admin: state.admin,
   billing: state.billing
  }
}

export default connect(mapStateToProps)(UserCardContainer)
