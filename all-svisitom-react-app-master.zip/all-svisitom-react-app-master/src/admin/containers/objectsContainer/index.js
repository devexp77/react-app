import React, { Component } from 'react'
import { connect } from 'react-redux'
import { saveObjectsQuery, gotoObject } from '../../actions/admin'
import { clearObjects, fetchObjects, fetchMoreObjects } from '../../../common/actions/objects'
import { setCustomHistoryPath, setTitle } from "../../../common/actions/router";
import strings from '../../localization/all'

import { MaterialList } from '../../../common/components/MaterialList'
import CircleLoader from '../../../common/components/CircleLoader'
import SearchInput from '../../../common/components/SearchInput'
import ObjectsListContainer from '../objectsListContainer'
import SinglePageWithCustomPaddingNavPanel from "../../../common/components/PageContainers/singlePageCustomPaddingNavPanel";

class ObjectsContainer extends Component {
  constructor () {
    super();
    this.state = {
      filter: {
          keywords: ''
      },
      query_order: '+name'
    }
  }

  componentDidMount() {
    const { dispatch } = this.props;
    dispatch(setTitle(strings.title_all_objects));
    dispatch(setCustomHistoryPath("/"));

    this.setState({
      filter: this.props.admin.objects_query.filter
    })

    var _this=this
    $(document).ready(function() {
      $('.mdb-select').material_select('destroy');
      $('.mdb-select').material_select();
      $('#query_order').off();
      $('#query_order').on('change', _this.handleQueryOrderChange.bind(_this));
    });
  }

  saveQuery() {
    const { dispatch } = this.props;

    var data = {
      filter: this.state.filter,
      query_order: this.state.query_order
    }

    dispatch(saveObjectsQuery(data))
  }

  render() {
    return (
      <SinglePageWithCustomPaddingNavPanel>
        {this.renderQueryField()}
        <ObjectsListContainer
          filter={this.props.admin.objects_query.filter}
          query_order={this.props.admin.objects_query.query_order} />
      </SinglePageWithCustomPaddingNavPanel>
    )
  }

  renderQueryField() {
    return (
      <div className="query-container">
        <SearchInput
          id="query_string"
          query={this.state.filter.keywords}
          placeholder={strings.search}
          onChange={this.handleSearchInputChange.bind(this)}
          onSearch={this.handleSearch.bind(this)} />
      </div>
    )
  }

  handleInputChange(event) {
    const id = event.target.id;
    const value = event.target.value;
    this.setState({[id]: value});
  }

  handleSearchInputChange(event) {
    var new_filter = {
      ...this.state.filter,
      keywords: event.target.value
    }

    this.setState({
      filter: new_filter
    })
  }

  handleQueryOrderChange(event) {
    this.handleInputChange(event)
    this.saveQuery()
  }

  handleSearch(query_string) {
    var _this = this

    var new_filter = {
      ...this.state.filter,
      keywords: query_string
    }

    this.setState({
      filter: new_filter
    }, function() {
      _this.saveQuery()
    })
  }
}

const mapStateToProps = (state, ownProps) => {
  return {
   admin: state.admin,
   objects: state.objects
  }
}

export default connect(mapStateToProps)(ObjectsContainer)
