import React, { Component } from 'react'
import { connect } from 'react-redux'

import {LandingPage, LandingPageSection} from '../../../common/components/PageContainers/landingPage';
import SideBar from "../../../common/components/Sidebar";

import strings from '../../localization/all'

class StartPageContainer extends Component {
	componentDidMount() {
		const { dispatch } = this.props;
    //dispatch(toUsers());
  }


  render() {
    return (
			<LandingPage>
				<SideBar.ProfileList>
					<SideBar.SideBarItem
						link={"/users"}
						icon={"people"}
						title={strings.menu_users}
					/>
					<SideBar.SideBarItem
						link={"/audit"}
						icon={"event_note"}
						title={strings.menu_audit}
					/>
					<SideBar.SideBarItem
						link={"/objects"}
						icon={"business"}
						title={strings.menu_objects}
					/>
          <SideBar.SideBarItem
            link={"/devices"}
            icon={"devices"}
            title={strings.menu_devices}
          />
					<SideBar.SideBarItem
						link={"/plans"}
						icon={"attach_money"}
						title={strings.menu_plans}
					/>
				</SideBar.ProfileList>

			</LandingPage>
		)
  }
}

const mapStateToProps = (state, ownProps) => {
  return {
   user: state.user
  }
}

export default connect(mapStateToProps)(StartPageContainer)
