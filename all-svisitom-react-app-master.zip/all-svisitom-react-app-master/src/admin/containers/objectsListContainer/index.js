import React, { Component } from 'react'
import { connect } from 'react-redux'
import { gotoObject } from '../../actions/admin'
import { clearObjects, fetchObjects, fetchMoreObjects } from '../../../common/actions/objects'
import strings from '../../localization/all'

import { MaterialList } from '../../../common/components/MaterialList'
import MaterialListItem from '../../../common/components/MaterialListItem/twoLineItem'
import CircleLoader from '../../../common/components/CircleLoader'
import SearchInput from '../../../common/components/SearchInput'

class ObjectsListContainer extends Component {
  constructor () {
    super();
    this.state = {
      limit: 20,
      offset: 0
    }
  }

  componentDidMount() {
    this.setState({
      filter: this.props.filter,
      query_order: this.props.query_order
    }, function() {
      this.showQuery()
    })
  }

  componentWillReceiveProps(nextProps) {
    if (JSON.stringify(nextProps.filter)==JSON.stringify(this.props.filter) &&
        nextProps.query_order==this.props.query_order) {
          return;
    }

    this.setState({
      filter: nextProps.filter,
      query_order: nextProps.query_order,
      offset: 0
    }, function() {
      this.showQuery()
    })
  }

  componentWillUnmount(){
    const { dispatch } = this.props;
    dispatch(clearObjects());
  }

  showQuery() {
    const { dispatch } = this.props;

    (async () => {
      try {
        var data = {
          filter: this.state.filter,
          limit: this.state.limit+1,
          offset: 0,
          order: this.state.query_order
        };

        await dispatch(fetchObjects(data));
      } catch (e) {
        console.log(e);
      }finally {
      }
    })();
  }

  more() {
    const { dispatch } = this.props;
    const { objects } = this.props;

    var data = {
      filter: this.state.filter,
      limit: this.state.limit,
      offset: this.state.offset+this.state.limit+1,
      order: this.state.query_order
    };

    (async () => {
      try {
        await dispatch(fetchMoreObjects(data));
        if (!objects.allObjects.error) {
          var offset = this.state.offset + this.state.limit;
          this.setState({
            offset: offset
          });
        }
      } catch (e) {
        console.log(e);
      } finally {
      }
    })();
  }

  render() {
    var objects = []
    var fetching = false
    var hasMore = false

    if (this.props.objects) {
      fetching = this.props.objects.objectsIsFetching
    }

    if (this.props.objects && this.props.objects.allObjects && this.props.objects.allObjects.result) {
      objects = this.props.objects.allObjects.result
      if (objects.length >= this.state.offset + this.state.limit) {
        objects = objects.slice(0, this.state.offset + this.state.limit)
        hasMore = true
      }
    }

    return (
      <div>
        <MaterialList
          emptyText={fetching ? '' : strings.nothing_found}>
          {objects.map((obj, index) => (
                <MaterialListItem
                  key={obj.object_id}
                  item_id={obj.object_id}
                  icon="business"
                  gotoItem={this.handleObjectClick.bind(this)}
                  firstLineContent={obj.name}
                />
              )
            )
          }
        </MaterialList>
        {fetching
          ? <CircleLoader />
          : hasMore
            ?
              <div className="admin-users-button-more-container">
                <div className="btn btn-flat waves-effect" onClick={this.more.bind(this)}>{strings.button_more}</div>
              </div>
            : null
        }
      </div>
    )
  }

  handleObjectClick(object_id) {
    const { dispatch } = this.props;
    dispatch(gotoObject(object_id))
  }
}

const mapStateToProps = (state, ownProps) => {
  return {
   objects: state.objects
  }
}

export default connect(mapStateToProps)(ObjectsListContainer)
