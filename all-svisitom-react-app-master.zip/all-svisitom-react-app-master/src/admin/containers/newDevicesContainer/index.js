import React from 'react';
import {connect} from "react-redux";
import {fetchTemporaryDevicesIds, fetchTouchTemporaryDevice} from "../../../common/actions/devices";
import {ErrorToast, SuccessToast} from "../../../common/Toasts";
import strings from "../../localization/all";
import SinglePageWithCustomPaddingNavPanel
  from "../../../common/components/PageContainers/singlePageCustomPaddingNavPanel";
import {MaterialList} from "../../../common/components/MaterialList";
import MaterialListItem from "../../../common/components/MaterialListItem/twoLineItem";
import CircleLoader from "../../../common/components/CircleLoader";
import {setCustomHistoryPath, setTitle, toCustomPath} from "../../../common/actions/router";

import './style.css';

class NewDevicesContainer extends React.Component {

  constructor(props) {
    super(props);

    this.state = {
      dataReceived: false
    }
  }

  componentDidMount() {
    const { dispatch } = this.props;
    dispatch(setTitle(strings.title_temporary_devices));
    dispatch(setCustomHistoryPath("/devices"));

    this.loadData();
  }

  async loadData() {
    const {dispatch} = this.props;
    await dispatch(fetchTemporaryDevicesIds({}))

    let {temporaryDevices} = this.props.devices;
    if (temporaryDevices.error) {
      ErrorToast(temporaryDevices.error);
    }

    this.setState({
      dataReceived: true
    })
  }


  gotoDevice(temp_serial) {
    const {dispatch} = this.props;
    dispatch(toCustomPath(`/newDevices/${temp_serial}`))
  }

  async touchDevice(temp_serial) {
    const {dispatch} = this.props;
    await dispatch(fetchTouchTemporaryDevice({
      temp_serial: temp_serial,
      click_count: 5
    }));

    let {deviceOperation} = this.props.devices;
    if (deviceOperation.error) {
      ErrorToast(deviceOperation.error);
    }
    if (deviceOperation.result) {
      SuccessToast("Device touched");
    }
  }

  render() {
    let fetching = !this.state.dataReceived;
    if (fetching) {
      return (
        <SinglePageWithCustomPaddingNavPanel>
          <CircleLoader/>
        </SinglePageWithCustomPaddingNavPanel>
      )
    }

    let devices = [];
    if (this.state.dataReceived) {
      let {temporaryDevices} = this.props.devices;
      if (temporaryDevices.result) {
        devices = temporaryDevices.result;
      }
    }

    return (
      <SinglePageWithCustomPaddingNavPanel>
        <MaterialList
          emptyText={fetching? '' : strings.nothing_found}>
          {devices.map((device) => (
              <MaterialListItem
                key={device.temp_serial}
                item_id={device.temp_serial}
                icon="devices"
                gotoItem={this.gotoDevice.bind(this)}
                firstLineContent={device.temp_serial}
                secondLineContent={device.online_time}
                buttonText="Touch"
                lineButtonClick={this.touchDevice.bind(this, device.temp_serial)}
              />
            )
          )
          }
        </MaterialList>
      </SinglePageWithCustomPaddingNavPanel>
    )
  }
}


const mapStateToProps = (state, ownProps) => {
  return {
    admin: state.admin,
    objects: state.objects,
    devices: state.devices,
  }
};

export default connect(mapStateToProps)(NewDevicesContainer)
