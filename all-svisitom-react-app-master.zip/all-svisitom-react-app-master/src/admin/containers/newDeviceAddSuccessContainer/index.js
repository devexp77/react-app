import React from 'react';
import {connect} from 'react-redux';
import {setCustomHistoryPath, setTitle, toCustomPath} from "../../../common/actions/router";
import strings from "../../localization/all";
import SinglePageWithCustomPaddingNavPanel
  from "../../../common/components/PageContainers/singlePageCustomPaddingNavPanel";
import Buttons from "../../../common/components/ButtonsPanel";
import common_strings from "../../../common/localization/all";
import EditSinglePage from "../../../common/components/PageContainers/editSinglePage";

class NewDeviceAddSuccess extends React.Component {

  componentDidMount() {
    window.scrollTo(0, 0);
    const { dispatch } = this.props;
    dispatch(setCustomHistoryPath(`/newDevices`));
    dispatch(setTitle(strings.title_device_activated));
  }

  toDevices() {
    const { dispatch } = this.props;
    dispatch(toCustomPath('/devices'));
  }

  render() {
    let {deviceOperation} = this.props.devices;

    return (
      <SinglePageWithCustomPaddingNavPanel>
        <EditSinglePage>

          <p>{deviceOperation.result.device_name}</p>

          <p>
            {deviceOperation.result.device_serial}
          </p>

          <Buttons
            submitText={common_strings.button_done}
            Submit={this.toDevices.bind(this)}
          />
        </EditSinglePage>
      </SinglePageWithCustomPaddingNavPanel>
    )
  }
}


const mapStateToProps = state => {
  return {
    devices: state.devices,
    router: state.router
  };
};

export default connect(mapStateToProps)(NewDeviceAddSuccess);
