import React, { Component } from "react";
import { connect } from "react-redux";
import { fetchUserGlobal } from "../../common/actions/user";
import { HOST_NAME, PROTOCOL } from "../../common/constants";

import strings from "../localization/all";
import common_strings from "../../common/localization/all";

import { init_support } from "../../common/util/support";
import SupportWidget from "../../common/components/support";

import Header from "../../common/containers/headerContainer/header";
import Preloader from "../../common/components/Preloader/preloader";
import Footer from "../../common/components/Footer/footer";
import FormSubmitCircleLoader from "../../common/components/FormSubmitCircleLoader";
import NavPanel from "../../common/components/NavPanel/navPanel";
import connectSocket from "../../common/util/socket";
import "./style.css";
import UseCookies from "../../common/components/UseCookies";

class AppContainer extends Component {
  constructor() {
    super();
    this.socket = null;
    this.state = {
      socket: null
    };
  }

  componentDidMount() {
    document.title =
      strings.title_administration + " - " + common_strings.product_name;

    const { dispatch } = this.props;

    (async () => {
      await dispatch(fetchUserGlobal());

      const { user } = this.props.user;
      if (user.result) {
        init_support(user.result);
        this.setState({socket: connectSocket(user)});
      }
    })();
  }

  render() {
    moment.locale(strings.getLanguage());
    const { userGlobalIsFetching } = this.props.user;
    let prevButton = !!this.props.router.customHistoryPath;

    if (userGlobalIsFetching) {
      return <Preloader />;
    }

    let containerClass = "container custom";
    if (this.props.router.routerPrevPath === "/requests") {
      containerClass = "container";
    }

    return [
      <Header
        key={`header`}
        logout={`${PROTOCOL}//${HOST_NAME}/logout`}
        login={`${PROTOCOL}//${HOST_NAME}/authorize/svisitom?next=${encodeURIComponent(
          window.location.href
        )}`}
        mainPage={`#`}
        containerClass={containerClass}
        productName={strings.title_administration}
        socket={this.state.socket}
      />,
      this.props.router.routerPrevPath !== "/" && (
        <NavPanel
          navigationTitle={this.props.router.title}
          prevButton={prevButton}
          containerClass={containerClass}
          key={`nav`}
        />
      ),
      <FormSubmitCircleLoader key={`loader`} />,
      React.cloneElement(this.props.children, { key: "children" }),
      this.props.router.routerPrevPath == "/" &&
      <Footer containerClass={containerClass} key={`footer`}/>,
      <SupportWidget key={`supportWidget`}/>,
      <UseCookies key={`cookies`}/>,
      <div key="video-tips" id="video-tips" />
    ];
  }

  componentWillUnmount() {
    this.state.socket.close();
    this.state.socket = null;
  }
}

const mapStateToProps = state => {
  return {
    user: state.user,
    router: state.router
  };
};

export default connect(mapStateToProps)(AppContainer);
