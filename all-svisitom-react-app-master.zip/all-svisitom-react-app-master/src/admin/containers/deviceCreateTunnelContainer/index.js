import React from 'react';
import { connect } from 'react-redux'
import {setCustomHistoryPath, setTitle, toCustomPath} from "../../../common/actions/router";
import {fetchDeviceExecuteMethod} from "../../../common/actions/devices";

import strings from '../../localization/all';
import common_strings from '../../../common/localization/all';
import SinglePageWithCustomPaddingNavPanel from "../../../common/components/PageContainers/singlePageCustomPaddingNavPanel";
import InputField from '../../../common/components/Inputs/inputField';
import TextareaField from '../../../common/components/Inputs/textarea';
import EditSinglePage from "../../../common/components/PageContainers/editSinglePage";
import Buttons from "../../../common/components/ButtonsPanel";
import {ErrorToast, SuccessToast} from "../../../common/Toasts";

class DeviceCreateTunnelContainer extends React.Component {

  constructor(props) {
    super(props);
    this.state = {
      ip_address: '',
      port: 55777,
      user_name: '',
      password: '',
      pkey: '',
      passphrase: '',
      device_port_on_remote: '',
      local_port_on_remote: '',
      timeout: '',
    }
  }

  componentDidMount() {
    window.scrollTo(0, 0);

    const device_id = this.props.params.device_id;

    const { dispatch } = this.props;
    dispatch(setCustomHistoryPath(`/devices/${device_id}`));
    dispatch(setTitle(strings.title_create_ssh_tunnel));
  }

  handleInputChange(event) {
    const id = event.target.id;
    const value = event.target.value;
    this.setState({[id]: value});
  }

  toHistoryPath() {
    const { dispatch } = this.props;
    const fromHistory = this.props.router.history.pop();
    const historyPath = fromHistory
      ? fromHistory
      : this.props.router.customHistoryPath;
    dispatch(toCustomPath(historyPath));
  }

  async handleSubmit() {
    const { dispatch } = this.props;
    const device_id = this.props.params.device_id;
    let data = {
      device_id: device_id,
      method_name: 'make_ssh_tunnel',
      method_parameters: {
        server_address: this.state.ip_address
      }
    };

    if (this.state.port) {
      data.method_parameters.server_ssh_port = parseInt(this.state.port, 10);
    }

    if (this.state.user_name) {
      data.method_parameters.username = this.state.user_name;
    }

    if (this.state.password) {
      data.method_parameters.password = this.state.password;
    }

    if (this.state.pkey) {
      data.method_parameters.pkey = this.state.pkey;
    }

    if (this.state.passphrase) {
      data.method_parameters.passphrase = this.state.passphrase;
    }

    if (this.state.device_port_on_remote) {
      data.method_parameters.device_port_on_remote = parseInt(this.state.device_port_on_remote, 10);
    }

    if (this.state.local_port_on_remote) {
      data.method_parameters.local_port_on_remote = parseInt(this.state.local_port_on_remote, 10);
    }

    if (this.state.timeout) {
      data.method_parameters.timeout = parseInt(this.state.timeout, 10);
    }

    await dispatch(fetchDeviceExecuteMethod(data));

    let {executeMethodResult} = this.props.devices;
    if (executeMethodResult.error) {
      ErrorToast(executeMethodResult.error);
    }

    if (executeMethodResult.result) {
      SuccessToast(strings.success_ssh_tunnel_created);
      toCustomPath(`/devices/${device_id}`);
    }
  }

  render() {
    return (
      <SinglePageWithCustomPaddingNavPanel>
        <EditSinglePage>
          <InputField
            id="ip_address"
            value={this.state.ip_address}
            handleInputChange={this.handleInputChange.bind(this)}
            label="IP address"
          />

          <InputField
            id="port"
            type="number"
            value={this.state.port}
            handleInputChange={this.handleInputChange.bind(this)}
            label="Port"
          />

          <InputField
            id="user_name"
            value={this.state.user_name}
            handleInputChange={this.handleInputChange.bind(this)}
            label="User name"
          />

          <InputField
            id="password"
            type="password"
            value={this.state.password}
            handleInputChange={this.handleInputChange.bind(this)}
            label="Password"
          />

          <TextareaField
            id="pkey"
            value={this.state.pkey}
            handleInputChange={this.handleInputChange.bind(this)}
            label="Private key"
          />

          <InputField
            id="passphrase"
            value={this.state.passphrase}
            handleInputChange={this.handleInputChange.bind(this)}
            label="Passphrase"
          />

          <InputField
            id="device_port_on_remote"
            type="number"
            value={this.state.device_port_on_remote}
            handleInputChange={this.handleInputChange.bind(this)}
            label="Device port on remote"
          />

          <InputField
            id="local_port_on_remote"
            type="number"
            value={this.state.local_port_on_remote}
            handleInputChange={this.handleInputChange.bind(this)}
            label="Local port on remote"
          />

          <InputField
            id="timeout"
            type="number"
            value={this.state.timeout}
            handleInputChange={this.handleInputChange.bind(this)}
            label="Timeout"
          />

          <Buttons
            Submit={this.handleSubmit.bind(this)}
            submitText={common_strings.button_create}
            Cancel={this.toHistoryPath.bind(this)}
          />
        </EditSinglePage>
      </SinglePageWithCustomPaddingNavPanel>
    );

  }

}


const mapStateToProps = (state, ownProps) => {
  return {
    objects: state.objects,
    devices: state.devices,
    router: state.router
  }
};

export default connect(mapStateToProps)(DeviceCreateTunnelContainer)

