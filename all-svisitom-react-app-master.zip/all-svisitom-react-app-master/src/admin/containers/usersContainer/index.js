import React, { Component } from 'react'
import { connect } from 'react-redux'
import { fetchUsers, fetchMoreUsers, gotoUser, clearUserList, saveUsersQuery } from '../../actions/admin'
import { setCustomHistoryPath, setTitle } from "../../../common/actions/router";
import strings from '../../localization/all'

import { MaterialList } from '../../../common/components/MaterialList'
import MaterialListItem from '../../../common/components/MaterialListItem/twoLineItem'
import CircleLoader from '../../../common/components/CircleLoader'
import SearchInput from '../../../common/components/SearchInput'
import SinglePageWithCustomPaddingNavPanel from "../../../common/components/PageContainers/singlePageCustomPaddingNavPanel";

import './style.css';

class UsersContainer extends Component {
  constructor () {
    super();
    this.state = {
      query_string: '',
      query_order: '+surname',
      limit: 20,
      offset: 0
    }
  }

  componentDidMount() {
    const { dispatch } = this.props;
    dispatch(setTitle(strings.title_all_users));
    dispatch(setCustomHistoryPath("/"));

    if (this.props.admin && this.props.admin.users_query) {
      this.setState({
        query_string: this.props.admin.users_query.query_string,
        query_order: this.props.admin.users_query.query_order
      }, function() {
        this.showQuery()
      })
    }

    var _this=this
    $(document).ready(function() {
      $('.mdb-select').material_select('destroy');
      $('.mdb-select').material_select();
      $('#query_order').off();
      $('#query_order').on('change', _this.handleQueryOrderChange.bind(_this));
    });
  }

  componentWillUnmount(){
    const { dispatch } = this.props;
    dispatch(clearUserList());
  }

  saveQuery() {
    const { dispatch } = this.props;

    var data = {
      query_string: this.state.query_string,
      query_order: this.state.query_order
    }

    dispatch(saveUsersQuery(data))
  }

  showQuery() {
    const { dispatch } = this.props;

    (async () => {
      try {
        var data = {
          filter: {
            keywords: this.state.query_string
          },
          limit: this.state.limit+1,
          offset: 0,
          order: this.state.query_order
        };

        await dispatch(fetchUsers(data));
      } catch (e) {
        console.log(e);
      }finally {
      }
    })();
  }

  more() {
    const { dispatch } = this.props;
    const { admin } = this.props;

    var data = {
      filter: {
        keywords: this.state.query_string
      },
      limit: this.state.limit,
      offset: this.state.offset+this.state.limit+1,
      order: this.state.query_order
    };

    (async () => {
      try {
        await dispatch(fetchMoreUsers(data));
        if (!admin.users.error) {
          var offset = this.state.offset + this.state.limit;
          this.setState({
            offset: offset
          });
        }
      } catch (e) {
        console.log(e);
      }finally {
      }
    })();
  }

  gotoUser(user_id) {
    const { dispatch } = this.props;
    dispatch(gotoUser(user_id))
  }

  render() {
    var users = []
    var fetching = false
    var hasMore = false

    if (this.props.admin) {
      fetching = this.props.admin.isFetching
    }

    if (this.props.admin && this.props.admin.users && this.props.admin.users.result) {
      users = this.props.admin.users.result
      if (users.length >= this.state.offset + this.state.limit) {
        users = users.slice(0, this.state.offset + this.state.limit)
        hasMore = true;
      }
    }

    return (
      <SinglePageWithCustomPaddingNavPanel>
          {this.renderQueryField()}
              <MaterialList
                emptyText={fetching? '' : strings.nothing_found}>
                {users.map((user, index) => (
                      <MaterialListItem
                        key={user.user_id}
                        item_id={user.user_id}
                        icon="account_circle"
                        gotoItem={this.gotoUser.bind(this)}
                        firstLineContent={user.surname + ' ' + user.name}
                        secondLineContent={user.email}
                      />
                    )
                  )
                }
              </MaterialList>
          {fetching
            ? <CircleLoader />
            : hasMore
              ?
                <div className="admin-users-button-more-container">
                  <div className="btn btn-flat waves-effect" onClick={this.more.bind(this)}>{strings.button_more}</div>
                </div>
              : null
          }
      </SinglePageWithCustomPaddingNavPanel>
    )
  }

  renderQueryField() {
    return (
      <div className="row query-container">
        <div className="col-md-8">
          <SearchInput
            id="query_string"
            query={this.state.query_string}
            placeholder={strings.search}
            onChange={this.handleInputChange.bind(this)}
            onSearch={this.handleSearch.bind(this)} />
        </div>
        <div className="col-md-4">
          <div className="select-container">
            <select name="query_order" id="query_order" className="mdb-select" value={this.state.query_order} onChange={this.handleQueryOrderChange.bind(this)}>
              <option value="+surname">{strings.sort_by_surname_ascending}</option>
              <option value="+email">{strings.sort_by_email_ascending}</option>
            </select>
          </div>
        </div>
      </div>
    )
  }

  handleInputChange(event) {
    const id = event.target.id;
    const value = event.target.value;
    this.setState({[id]: value});
  }

  handleSearchInputChange(value) {
    this.setState({
      query_string: value
    })
  }

  handleQueryOrderChange(event) {
    this.handleInputChange(event)
    this.saveQuery()
    this.showQuery()
  }

  handleSearch(query_string) {
    var _this = this

    this.setState({
      query_string: query_string
    }, function() {
      _this.saveQuery()
      _this.showQuery()
    })
  }
}

const mapStateToProps = (state, ownProps) => {
  return {
   admin: state.admin
  }
}

export default connect(mapStateToProps)(UsersContainer)
