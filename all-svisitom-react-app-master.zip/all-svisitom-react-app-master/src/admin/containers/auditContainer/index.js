import React, { Component } from 'react'
import { connect } from 'react-redux'
import strings from '../../localization/all'
import Moment from 'react-moment'
import {Link} from "react-router";

import { saveAuditQuery, fetchAuditEvents, fetchAuditEventsMore, clearAuditEvents } from '../../actions/audit'
import { setCustomHistoryPath, setTitle } from "../../../common/actions/router";

import CircleLoader from '../../../common/components/CircleLoader'
import { MaterialList } from '../../../common/components/MaterialList'
import MaterialListItem from '../../../common/components/MaterialListItem/twoLineItem'
import SearchInput from '../../../common/components/SearchInput'
import SinglePageWithCustomPaddingNavPanel from "../../../common/components/PageContainers/singlePageCustomPaddingNavPanel";


class AuditContainer extends Component {
  constructor () {
    super();
    this.state = {
      query_string: '',
      query_order: '-create_date',
      limit: 20,
      offset: 0
    }

    this.handleInputChange = this.handleInputChange.bind(this)
    this.handleSearch = this.handleSearch.bind(this)
  }

  componentDidMount() {
    const { dispatch } = this.props;
    dispatch(setTitle(strings.title_audit));
    dispatch(setCustomHistoryPath("/"));

    if (this.props.audit && this.props.audit.audit_query) {
      this.setState({
        query_string: this.props.audit.audit_query.query_string
      }, function() {
        this.showQuery()
      })
    }
  }

  componentWillUnmount(){
    const { dispatch } = this.props;
    dispatch(clearAuditEvents());
  }

  saveQuery() {
    const { dispatch } = this.props;

    var data = {
      query_string: this.state.query_string
    }

    dispatch(saveAuditQuery(data))
  }

  showQuery() {
    const { dispatch } = this.props;

    (async () => {
      try {
        var data = {
          filter: {
            //keywords: this.state.query_string
          },
          limit: this.state.limit+1,
          offset: 0,
          order: this.state.query_order
        };

        await dispatch(fetchAuditEvents(data));
      } catch (e) {
        console.log(e);
      }finally {
      }
    })();
  }

  more() {
    const { dispatch } = this.props;
    const { audit } = this.props;

    var data = {
      filter: {
        //keywords: this.state.query_string
      },
      limit: this.state.limit,
      offset: this.state.offset+this.state.limit+1,
      order: this.state.query_order
    };

    (async () => {
      try {
        await dispatch(fetchAuditEventsMore(data));
        if (!audit.events.error) {
          var offset = this.state.offset + this.state.limit;
          this.setState({
            offset: offset
          });
        }
      } catch (e) {
        console.log(e);
      }finally {
      }
    })();
  }

  render() {
    var events = []
    var fetching = false
    var hasMore = false

    if (this.props.audit) {
      fetching = this.props.audit.isFetching
    }

    if (this.props.audit && this.props.audit.events && this.props.audit.events.result) {
      events = this.props.audit.events.result
      if (events.length >= this.state.offset + this.state.limit) {
        events = events.slice(0, this.state.offset + this.state.limit)
        hasMore = true
      }
    }

    return (
      <SinglePageWithCustomPaddingNavPanel>
          {this.renderQueryField()}
          <MaterialList
            emptyText={fetching ? '' : strings.nothing_found}>
            {events.map((event, index) => (
                <MaterialListItem
                  key={event.event_id}
                  item_id={event.event_id}
                  icon="event_note"
                  firstLineContent={<div><Moment format="DD.MM.YYYY HH:mm">{event.create_date}</Moment> - {event.event_message_id}</div>}
                  secondLineContent={
                    <div>
                      {
                        event.user && event.user.user_id &&
                          <div>
                            <Link to={'/users/' + event.user.user_id}>{event.user.name + ' ' + event.user.surname}</Link>
                          </div>
                      }
                      {
                        event.object &&
                          <div>
                            <Link to={'/objects/' + event.object.object_id}>{event.object.name}</Link>
                          </div>
                      }
                      {
                        event.addressee &&
                          <div>
                            {event.addressee.name}
                          </div>
                      }
                      {
                        event.key &&
                          <div>
                            {event.key.name}
                          </div>
                      }
                    </div>
                  }
                />
                )
              )
            }
          </MaterialList>
          {fetching
            ? <CircleLoader />
            : hasMore
              ?
                <div className="admin-users-button-more-container">
                  <div className="btn btn-flat waves-effect" onClick={this.more.bind(this)}>{strings.button_more}</div>
                </div>
              : null
          }
      </SinglePageWithCustomPaddingNavPanel>
    )
  }

  renderQueryField() {
    return (
      <div className="query-container">
        <SearchInput
          id="query_string"
          query={this.state.query_string}
          placeholder={strings.search}
          onChange={this.handleInputChange}
          onSearch={this.handleSearch}
        />
      </div>
    )
  }

  handleInputChange(event) {
    const id = event.target.id;
    const value = event.target.value;
    this.setState({[id]: value});
  }

  handleSearch(query_string) {
    var _this = this

    this.setState({
      query_string: query_string
    }, function() {
      _this.saveQuery()
      _this.showQuery()
    })
  }
}

const mapStateToProps = (state, ownProps) => {
  return {
   audit: state.audit
  }
}

export default connect(mapStateToProps)(AuditContainer)
