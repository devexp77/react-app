import React, { Component } from "react";
import { connect } from "react-redux";

import {
  setCustomHistoryPath,
  setTitle,
  toCustomPath,
} from "../../../common/actions/router";

import Buttons from "../../../common/components/ButtonsPanel";
import InputField from "../../../common/components/Inputs/inputField";

import strings from "../../localization/all";

import { ErrorToast } from "../../../common/Toasts/error";
import SinglePageWithCustomPaddingNavPanel from "../../../common/components/PageContainers/singlePageCustomPaddingNavPanel";
import EditSinglePage from "../../../common/components/PageContainers/editSinglePage";
import {fetchRegisterTemporaryDevice} from "../../../common/actions/devices";

class DeviceAddContainer extends Component {
  constructor(props) {
    super(props);
    this.state = {
      device_name: '',
      temp_serial: props.params.temp_serial,
    };
  }

  componentDidMount() {
    window.scrollTo(0, 0);
    const { dispatch } = this.props;
    dispatch(setCustomHistoryPath(`/newDevices`));
    dispatch(setTitle(strings.title_activate_device));
  }

  handleInputChange(event) {
    const id = event.target.id;
    const value = event.target.value;
    this.setState({ [id]: value });
  }

  handleSubmit() {
    const { dispatch } = this.props;
    const temp_serial = this.props.params.temp_serial;
    const data = {
      device_name: this.state.device_name,
      temp_serial: temp_serial,
    };

    (async () => {
      try {
        await dispatch(fetchRegisterTemporaryDevice(data));
        let {devices} = this.props;
        if (devices.deviceOperation.error) {
          ErrorToast(devices.deviceOperation.error);
          return
        }

        if (devices.deviceOperation.result) {
          dispatch(toCustomPath('/newDevices/success'));
        }
      } catch (e) {
        console.log(e);
        ErrorToast();
      }
    })();
  }

  toHistoryPath() {
    const { dispatch } = this.props;
    const fromHistory = this.props.router.history.pop();
    const historyPath = fromHistory
      ? fromHistory
      : this.props.router.customHistoryPath;
    dispatch(toCustomPath(historyPath));
  }

  render() {
    return (
      <SinglePageWithCustomPaddingNavPanel>
        <EditSinglePage>
          <InputField
            handleInputChange={this.handleInputChange.bind(this)}
            id={`temp_serial`}
            value={this.state.temp_serial}
            label={strings.label_device_temp_serial}
            disabled={true}
          />

          <InputField
            handleInputChange={this.handleInputChange.bind(this)}
            id={`device_name`}
            value={this.state.device_name}
            label={strings.label_device_name}
          />

          <Buttons
            Submit={this.handleSubmit.bind(this)}
            Cancel={this.toHistoryPath.bind(this)}
          />
        </EditSinglePage>
      </SinglePageWithCustomPaddingNavPanel>
    );
  }
}

const mapStateToProps = state => {
  return {
    devices: state.devices,
    router: state.router
  };
};

export default connect(mapStateToProps)(DeviceAddContainer);
