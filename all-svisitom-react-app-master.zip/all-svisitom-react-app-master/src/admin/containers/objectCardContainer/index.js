import React, {Component} from 'react'
import { connect } from 'react-redux'
import Moment from 'react-moment'
import strings from '../../localization/all'

import { fetchObjectById } from '../../../common/actions/objects'
import {
  fetchUser,
  gotoUser,
  fetchSetObjectBlocked,
  fetchSetObjectSuspended
} from '../../actions/admin'
import { setCustomHistoryPath, setTitle } from "../../../common/actions/router";

import ObjectCard from '../../components/ObjectCard'
import SinglePageWithCustomPaddingNavPanel from "../../../common/components/PageContainers/singlePageCustomPaddingNavPanel";

import {ErrorToast} from '../../../common/Toasts'


class ObjectCardContainer extends Component {

  constructor(props) {
    super(props);
  }

  componentDidMount() {
    const { dispatch } = this.props;
    dispatch(setTitle(''));
    dispatch(setCustomHistoryPath("/objects"));

    this.loadObject()
  }

  loadObject() {
    const { dispatch } = this.props;
    (async () => {
      try {
        var object_id = this.props.params.object_id;
        var data = {
          object_id: object_id
        };

        await dispatch(fetchObjectById(data));
        var {objectById} = this.props.objects;

        if (objectById.result) {
          dispatch(setTitle(objectById.result.name));

          var data_user = {
            user_id: objectById.result.owner_id
          }

          await dispatch(fetchUser(data_user))
        }
      } catch (e) {
        console.log(e);
        ErrorToast()
      }
    })();
  }

  render() {
    return (
      <SinglePageWithCustomPaddingNavPanel>
        {
          this.props.objects.objectById
          ?
            <ObjectCard
              object={this.props.objects.objectById.result}
              owner={this.props.admin.user.result}
              gotoOwner={this.gotoOwner.bind(this)}
              onSaveBlocked={this.handleSaveObjectBlocked.bind(this)}
              onSaveSuspended={this.handleSaveObjectSuspended.bind(this)}
            />
          : null
        }
      </SinglePageWithCustomPaddingNavPanel>
    )
  }

  gotoOwner() {
    var { dispatch } = this.props
    dispatch(gotoUser(this.props.admin.user.result.user_id))
  }

  handleSaveObjectBlocked(blocked) {
    var {dispatch} = this.props;

    (async () => {
      try {
        var object_id = this.props.params.object_id;
        var data = {
          object_id: object_id,
          blocked: blocked
        };

        await dispatch(fetchSetObjectBlocked(data));
        var {objectOperationStatus} = this.props.admin;

        if (objectOperationStatus.error) {
          ErrorToast(objectOperationStatus.error);
        }

        this.loadObject()
      } catch (e) {
        console.log(e);
        ErrorToast()
      }
    })();
  }

  handleSaveObjectSuspended(suspended) {
    var {dispatch} = this.props;

    (async () => {
      try {
        var object_id = this.props.params.object_id;
        var data = {
          object_id: object_id,
          suspended: suspended
        };

        await dispatch(fetchSetObjectSuspended(data));
        var {objectOperationStatus} = this.props.admin;

        if (objectOperationStatus.error) {
          ErrorToast(objectOperationStatus.error);
        }

        this.loadObject()
      } catch (e) {
        console.log(e);
        ErrorToast()
      }
    })();
  }

}

const mapStateToProps = (state, ownProps) => {
  return {
    objects: state.objects,
    admin: state.admin
  }
}

export default connect(mapStateToProps)(ObjectCardContainer)
