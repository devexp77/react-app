import React, { Component } from 'react'
import { connect } from 'react-redux'
import { clearPlans, fetchPlans } from '../../../common/actions/plans'
import { setCustomHistoryPath, setTitle } from "../../../common/actions/router";
import strings from '../../localization/all'

import { MaterialList } from '../../../common/components/MaterialList'
import CircleLoader from '../../../common/components/CircleLoader'
import ErrorToast from '../../../common/Toasts/error'
import PlanListItem from '../../components/PlanListItem'
import SinglePageWithCustomPaddingNavPanel from "../../../common/components/PageContainers/singlePageCustomPaddingNavPanel";

import '../../../common/components/MaterialListItem/twoLineItem/style.css'

class PlansContainer extends Component {
  constructor () {
    super();
    this.state = {
    }
  }

  componentDidMount() {
    const { dispatch } = this.props;
    dispatch(setTitle(strings.title_plans));
    dispatch(setCustomHistoryPath("/"));

    this.showQuery()
  }

  componentWillUnmount(){
    const { dispatch } = this.props;
    dispatch(clearPlans());
  }

  showQuery() {
    const { dispatch } = this.props;

    (async () => {
      try {
        var data = {
          filter: {}
        };

        await dispatch(fetchPlans(data));

        if (this.props.plans.plans.error) {
          ErrorToast(this.props.plans.plans.error)
          return
        }
      } catch (e) {
        console.log(e);
        ErrorToast()
      }finally {
      }
    })();
  }

  render() {
    var plans = []
    var fetching = false

    if (this.props.plans) {
      fetching = this.props.plans.plansIsFetching
    }

    if (this.props.plans && this.props.plans.plans && this.props.plans.plans.result) {
      plans = this.props.plans.plans.result
    }

    return (
      <SinglePageWithCustomPaddingNavPanel>
        <MaterialList
          emptyText={fetching ? '' : strings.nothing_found}>
          {plans.map((plan, index) => (
                <PlanListItem
                  key={plan.plan_id}
                  plan={plan}
                />
              )
            )
          }
        </MaterialList>
        {fetching
          ? <CircleLoader />
          : null
        }
      </SinglePageWithCustomPaddingNavPanel>
    )
  }
}

const mapStateToProps = (state, ownProps) => {
  return {
   plans: state.plans
  }
}

export default connect(mapStateToProps)(PlansContainer)
