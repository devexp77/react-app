import React, { Component } from "react";
import { connect } from "react-redux";

import {
  setCustomHistoryPath,
  setTitle,
  toCustomPath,
  toRoot
} from "../../../common/actions/router";

import Buttons from "../../../common/components/ButtonsPanel";
import InputField from "../../../common/components/Inputs/inputField";

import strings from "../../localization/all";

import { ErrorToast } from "../../../common/Toasts/error";
import SinglePageWithCustomPaddingNavPanel from "../../../common/components/PageContainers/singlePageCustomPaddingNavPanel";
import EditSinglePage from "../../../common/components/PageContainers/editSinglePage";
import {fetchAddDevice} from "../../../common/actions/devices";

class DeviceAddContainer extends Component {
  constructor() {
    super();
    this.state = {
      device_serial: '',
      device_name: '',
    };
  }

  componentDidMount() {
    window.scrollTo(0, 0);
    const { dispatch } = this.props;
    dispatch(setCustomHistoryPath(`/devices`));
    dispatch(setTitle(strings.title_add_device));
  }

  handleInputChange(event) {
    const id = event.target.id;
    const value = event.target.value;
    this.setState({ [id]: value });
  }

  handleSubmit() {
    const { dispatch } = this.props;
    const data = {
      device_name: this.state.device_name,
      device_serial: this.state.device_serial,
    };

    (async () => {
      try {
        await dispatch(fetchAddDevice(data));
        let {devices} = this.props;
        if (devices.deviceOperation.error) {
          ErrorToast(devices.deviceOperation.error);
          return
        }

        if (devices.deviceOperation.result) {
          this.toHistoryPath();
        }
      } catch (e) {
        console.log(e);
        ErrorToast();
      }
    })();
  }

  toHistoryPath() {
    const { dispatch } = this.props;
    const fromHistory = this.props.router.history.pop();
    const historyPath = fromHistory
      ? fromHistory
      : this.props.router.customHistoryPath;
    dispatch(toCustomPath(historyPath));
  }

  render() {
    return (
      <SinglePageWithCustomPaddingNavPanel>
        <EditSinglePage>
          <InputField
            handleInputChange={this.handleInputChange.bind(this)}
            id={`device_serial`}
            value={this.state.device_serial}
            label={strings.label_device_serial}
          />

          <InputField
            handleInputChange={this.handleInputChange.bind(this)}
            id={`device_name`}
            value={this.state.device_name}
            label={strings.label_device_name}
          />

          <Buttons
            Submit={this.handleSubmit.bind(this)}
            Cancel={this.toHistoryPath.bind(this)}
          />
        </EditSinglePage>
      </SinglePageWithCustomPaddingNavPanel>
    );
  }
}

const mapStateToProps = state => {
  return {
    devices: state.devices,
    router: state.router
  };
};

export default connect(mapStateToProps)(DeviceAddContainer);
