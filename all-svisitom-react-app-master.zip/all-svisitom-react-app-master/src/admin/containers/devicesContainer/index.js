import React from 'react'
import {pushHistory, setCustomHistoryPath, setTitle, toCustomPath, toRoomAdd} from "../../../common/actions/router";
import strings from "../../localization/all";
import connect from "react-redux/es/connect/connect";
import {fetchCheckDevicesOnline, fetchDevices, fetchMoreDevices} from "../../../common/actions/devices";
import {ErrorToast} from "../../../common/Toasts";
import SinglePageWithCustomPaddingNavPanel
  from "../../../common/components/PageContainers/singlePageCustomPaddingNavPanel";
import MaterialList from "../../../common/components/MaterialList/MaterialList";
import MaterialListItem from "../../../common/components/MaterialListItem/twoLineItem";
import SearchInput from "../../../common/components/SearchInput";
import CircleLoaderOrButtonShowMore from "../../../common/components/MaterialList/CircleLoaderOrButtonShowMore";
import {saveDevicesQuery, saveObjectsQuery} from "../../actions/admin";
import AddRow from "../../../common/components/MaterialList/AddRow";

class DevicesContainer extends React.Component {

  constructor () {
    super();
    this.state = {
      keywords: '',
      order: '+device_name',
      limit: 20,
      offset: 0,
    }
  }

  componentDidMount() {
    const { dispatch } = this.props;
    dispatch(setTitle(strings.title_all_devices));
    dispatch(setCustomHistoryPath("/"));

    this.setState({
      filter: this.props.admin.devices_query.filter.keywords
    },function() {
      this.showQuery()
    });
  }

  saveQuery() {
    const {dispatch} = this.props;

    let data = {
      filter: {
        keywords: this.state.keywords
      }
    };

    dispatch(saveDevicesQuery(data))
  }

  showQuery() {
    const { dispatch } = this.props;
    (async () => {
      try {
        let data = {
          filter: {
            keywords: this.state.keywords
          },
          limit: this.state.limit+1,
          offset: 0,
          order: this.state.order
        };

        await dispatch(fetchDevices(data));

        let {devices} = this.props;
        if (devices.devices.error) {
          ErrorToast(devices.devices.error);
          return;
        }
        if (devices.devices.result){
          let serialNumbers = [];
          for (let device of devices.devices.result) {
            serialNumbers.push(device.device_serial);
          }
          dispatch(fetchCheckDevicesOnline({ serials: serialNumbers })).then(
            res => {
              if (res.payload.error) {
                ErrorToast(res.payload.error);
              }
            }
          );
        }
      } catch (e) {
        console.log(e);
      }finally {
      }
    })();
  }

  more() {
    const { dispatch } = this.props;

    let data = {
      filter: {
        keywords: this.state.keywords
      },
      limit: this.state.limit,
      offset: this.state.offset+this.state.limit+1,
      order: this.state.order
    };

    (async () => {
      try {
        await dispatch(fetchMoreDevices(data));
        let {devices} = this.props;
        if (devices.devices.error) {
          ErrorToast(devices.devices.error);
          return;
        }

        if (devices.devices.result) {
          let offset = this.state.offset + this.state.limit;
          this.setState({
            offset: offset
          });
        }
      } catch (e) {
        console.log(e);
        ErrorToast()
      }
    })();
  }

  gotoDevice(device_id) {
    const { dispatch } = this.props;
    dispatch(pushHistory(this.props.location.pathname));
    dispatch(toCustomPath('/devices/'+device_id));
  }

  toAddDevice() {
    const { dispatch } = this.props;
    dispatch(pushHistory(this.props.location.pathname));
    dispatch(toCustomPath('/devices/add'));
  }

  toSelectNewDevice() {
    const { dispatch } = this.props;
    dispatch(pushHistory(this.props.location.pathname));
    dispatch(toCustomPath('/newDevices'));
  }

  render() {
    let devicesList = [];
    let fetching = false;
    let hasMore = false;

    let {devices, checkDevicesOnline} = this.props.devices;
    if (this.props.devices) {
      fetching = this.props.admin.isFetching
    }

    if (devices && devices.result) {
      devicesList = devices.result;
      if (devicesList.length >= this.state.offset + this.state.limit) {
        devicesList = devicesList.slice(0, this.state.offset + this.state.limit);
        hasMore = true;
      }
    }

    return (
      <SinglePageWithCustomPaddingNavPanel>
        {this.renderQueryField()}

        {
          !fetching &&
            <div className="add-row-two-buttons">
              <AddRow
                text={strings.button_add_manually}
                onClick={this.toAddDevice.bind(this)}
              />
              <AddRow
                text={strings.button_activate}
                onClick={this.toSelectNewDevice.bind(this)}
              />
            </div>
        }

        <MaterialList
          emptyText={fetching? '' : strings.nothing_found}>
          {devicesList.map((device, index) => (
              <MaterialListItem
                key={device.device_id}
                item_id={device.device_id}
                icon="devices"
                iconStyle={{
                  color:
                    checkDevicesOnline.result &&
                    checkDevicesOnline.result[device.device_serial] === "online"
                      ? "#99cc66"
                      : "red"
                }}
                gotoItem={this.gotoDevice.bind(this)}
                firstLineContent={device.device_serial}
                secondLineContent={device.device_name}
              />
            )
          )
          }
        </MaterialList>
        <CircleLoaderOrButtonShowMore
          fetching={fetching}
          hasMore={hasMore}
          onShowMoreClick={this.more.bind(this)}
        />
      </SinglePageWithCustomPaddingNavPanel>
    )
  }

  renderQueryField() {
    return (
      <div className="query-container">
        <SearchInput
          id="query_string"
          query={this.state.query_string}
          placeholder={strings.search}
          onChange={this.handleInputChange.bind(this)}
          onSearch={this.handleSearch.bind(this)} />
      </div>
    )
  }

  handleInputChange(event) {
    const id = event.target.id;
    const value = event.target.value;
    this.setState({[id]: value});
  }

  handleSearchInputChange(value) {
    this.setState({
      keywords: value
    })
  }

  handleSearch(query_string) {
    let _this = this;

    this.setState({
      keywords: query_string
    }, function() {
      _this.saveQuery();
      _this.showQuery();
    })
  }
}

const mapStateToProps = (state, ownProps) => {
  return {
    admin: state.admin,
    objects: state.objects,
    devices: state.devices,
  }
};

export default connect(mapStateToProps)(DevicesContainer)
