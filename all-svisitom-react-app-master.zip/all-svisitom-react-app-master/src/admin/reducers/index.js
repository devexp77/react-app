import { combineReducers } from "redux";
import { routerReducer } from "react-router-redux";

import user from "../../common/reducers/user";
import billing from "../../common/reducers/billing";
import admin from "./admin";
import audit from "./audit";
import plans from "../../common/reducers/plans";
import notifications from "../../common/reducers/notifications";
import image from "../../common/reducers/image";
import objects from "../../common/reducers/objects";
import router from "../../common/reducers/router";
import bento from '../../common/reducers/bento';
import devices from '../../common/reducers/devices';

export default combineReducers({
  routing: routerReducer,
  user,
  billing,
  admin,
  audit,
  notifications,
  objects,
  plans,
  router,
  image,
  bento,
  devices,
});
