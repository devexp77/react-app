import {
  REQUEST_AUDIT_EVENTS,
  RECEIVE_AUDIT_EVENTS,
  RECEIVE_AUDIT_EVENTS_MORE,
  CLEAR_AUDIT_EVENTS,
  SAVE_AUDIT_QUERY
} from '../actions/audit'


export default function admin(state = {
  isFetching: false,
  events: [],
  audit_query: {
    query_string: ''
  }
}, action){
  switch (action.type) {
    case CLEAR_AUDIT_EVENTS:
    return {
      ...state,
      events: []
    }
    case REQUEST_AUDIT_EVENTS:
      return {
        ...state,
        isFetching: true
      }
    case RECEIVE_AUDIT_EVENTS:
      return {
        ...state,
        isFetching: false,
        events: action.payload
      }
    case RECEIVE_AUDIT_EVENTS_MORE:
      if (action.payload.result) {
        if (state.events.result) {
          var obj = state.events;
          var length = obj.result.length;
          var i = 0;
          for (var prop in action.payload.result) {
            obj.result[length] = action.payload.result[prop];
            length++;
            i++;
          }
          return {
            ...state,
            isFetching: false,
            events: obj
          }
        } else {
          return {
            ...state,
            isFetching: false,
            events: action.payload
          }
        }
      }
    case SAVE_AUDIT_QUERY:
      return {
        ...state,
        audit_query: action.payload
      }
    default:
      return state
  }
}
