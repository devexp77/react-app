import {
  REQUEST_USERS,
  RECEIVE_USERS,
  RECEIVE_MORE_USERS,
  CLEAR_USER_LIST,
  REQUEST_USER_INFO,
  RECEIVE_USER_INFO,
  SAVE_USERS_QUERY,
  SAVE_OBJECTS_QUERY,
  ADMIN_SET_USER,
  CLEAR_USER_INFO,
  SAVE_DEVICES_QUERY,
  ADMIN_REQUEST_SET_OBJECT_BLOCKED,
  ADMIN_RECEIVE_SET_OBJECT_BLOCKED,
  ADMIN_REQUEST_SET_OBJECT_SUSPENDED,
  ADMIN_RECEIVE_SET_OBJECT_SUSPENDED,
  ADMIN_REQUEST_SET_PROMO_PERIOD_DEADLINE,
  ADMIN_RECEIVE_SET_PROMO_PERIOD_DEADLINE,
  ADMIN_REQUEST_CLEAR_PROMO_PERIOD_DEADLINE,
  ADMIN_RECEIVE_CLEAR_PROMO_PERIOD_DEADLINE,
} from '../actions/admin'


export default function admin(state = {
  isFetching: false,
  users: [],
  user: {},
  users_query: {
    query_string: '',
    query_order: '+surname'
  },
  user_page: {
    expanded_item: ''
  },
  objects_query: {
    filter: {
        keywords: ''
    },
    query_order: '+name'
  },
  devices_query: {
    filter: {
      keywords: ''
    }
  },

  objectOperationIsFetching: false,
  objectOperationStatus: {},

  billingOperationIsFetching: false,
  billingOperationStatus: {},
}, action){
  switch (action.type) {
    case CLEAR_USER_LIST:
      return {
        ...state,
        users: []
      };
    case CLEAR_USER_INFO:
      return {
        ...state,
        user: {}
      };
    case REQUEST_USERS:
      return {
        ...state,
        isFetching: true
      };
    case RECEIVE_USERS:
      return {
        ...state,
        isFetching: false,
        users: action.payload
      };
    case RECEIVE_MORE_USERS:
      if (action.payload.result) {
        if (state.users.result) {
          var obj = state.users;
          var length = obj.result.length;
          var i = 0;
          for (var prop in action.payload.result) {
            obj.result[length] = action.payload.result[prop];
            length++;
            i++;
          }
          return {
            ...state,
            isFetching: false,
            users: obj
          }
        } else {
          return {
            ...state,
            isFetching: false,
            users: action.payload
          }
        }
      } else {
        return {
          ...state
        }
      }
    case REQUEST_USER_INFO:
      return {
        ...state,
        isFetching: true
      };
    case RECEIVE_USER_INFO:
      return {
        ...state,
        isFetching: false,
        user: action.payload
      };
    case SAVE_USERS_QUERY:
      return {
        ...state,
        users_query: action.payload
      };
    case ADMIN_SET_USER:
      return {
        ...state,
        set_user_response: action.payload
      };
    case SAVE_OBJECTS_QUERY:
      return {
        ...state,
        objects_query: action.payload
      };

    case ADMIN_REQUEST_SET_OBJECT_BLOCKED:
      return {
        ...state,
        objectOperationIsFetching: true
      };
    case ADMIN_RECEIVE_SET_OBJECT_BLOCKED:
      return {
        ...state,
        objectOperationIsFetching: false,
        objectOperationStatus: action.payload
      };

    case ADMIN_REQUEST_SET_OBJECT_SUSPENDED:
      return {
        ...state,
        objectOperationIsFetching: true
      };
    case ADMIN_RECEIVE_SET_OBJECT_SUSPENDED:
      return {
        ...state,
        objectOperationIsFetching: false,
        objectOperationStatus: action.payload
      };

    case ADMIN_REQUEST_SET_PROMO_PERIOD_DEADLINE:
    case ADMIN_REQUEST_CLEAR_PROMO_PERIOD_DEADLINE:
      return {
        ...state,
        billingOperationIsFetching: true
      };
    case ADMIN_RECEIVE_SET_PROMO_PERIOD_DEADLINE:
    case ADMIN_RECEIVE_CLEAR_PROMO_PERIOD_DEADLINE:
      return {
        ...state,
        billingOperationIsFetching: false,
        billingOperationStatus: action.payload
      };

    case SAVE_DEVICES_QUERY:
      return {
        ...state,
        devices_query: action.payload
      };

    default:
      return state
  }
}
