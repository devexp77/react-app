import { Route, IndexRoute } from 'react-router';
import React from 'react';

import App from './containers/App';
import StartPage from './containers/startPageContainer/startPage';
import UsersContainer from './containers/usersContainer'
import ObjectsContainer from './containers/objectsContainer'
import UserCardContainer from './containers/userCardContainer'
import AuditContainer from './containers/auditContainer'
import ObjectCardContainer from './containers/objectCardContainer'
import PlansContainer from './containers/plansContainer'
import DevicesContainer from './containers/devicesContainer'
import DeviceAddContainer from './containers/deviceAddContainer'
import DeviceContainer from './containers/deviceContainer'
import DeviceCreateTunnel from './containers/deviceCreateTunnelContainer'
import NewDevicesContainer from './containers/newDevicesContainer'
import NewDeviceAddContainer from './containers/newDeviceAddContainer'
import NewDeviceAddSuccessContainer from './containers/newDeviceAddSuccessContainer'

import {checkAdmin}     from '../common/checkFunctions/checkAdmin';
//import {checkRoutes}     from '../common/checkFunctions/checkRoutes';

export default function configRoutes(store) {
  function _ensureAdmin(nextState, replace, callback) {
    checkAdmin(nextState, callback, store);
  }

  return (
    <Route path="/" component={App}>
      <IndexRoute component={StartPage} onEnter={_ensureAdmin}/>
      <Route path="users" component={UsersContainer} onEnter={_ensureAdmin} />
      <Route path="users/:user_id" component={UserCardContainer} onEnter={_ensureAdmin} />
      <Route path="audit" component={AuditContainer} onEnter={_ensureAdmin} />
      <Route path="objects" component={ObjectsContainer} onEnter={_ensureAdmin} />
      <Route path="objects/:object_id" component={ObjectCardContainer} onEnter={_ensureAdmin} />
      <Route path="plans" component={PlansContainer} onEnter={_ensureAdmin} />
      <Route path="devices" onEnter={_ensureAdmin}>
        <IndexRoute component={DevicesContainer} onEnter={_ensureAdmin}/>
        <Route path="add" component={DeviceAddContainer} onEnter={_ensureAdmin} />
        <Route path=":device_id" onEnter={_ensureAdmin}>
          <IndexRoute component={DeviceContainer} onEnter={_ensureAdmin} />
          <Route path="tunnel" component={DeviceCreateTunnel} onEnter={_ensureAdmin} />
        </Route>
      </Route>
      <Route path="newDevices" onEnter={_ensureAdmin}>
        <IndexRoute component={NewDevicesContainer} onEnter={_ensureAdmin}/>
        <Route path="success" component={NewDeviceAddSuccessContainer} onEnter={_ensureAdmin} />
        <Route path=":temp_serial" component={NewDeviceAddContainer} onEnter={_ensureAdmin} />
      </Route>
    </Route>
  )
}
