import fetch from 'isomorphic-fetch';
import {jsonRPCRequest} from "../../common/actions/asyncActions";
import { push } from 'react-router-redux';
import { HOST_NAME, FULL_HOST_NAME, PROTOCOL } from '../../common/constants';
import { checkAuth } from '../../common/actions/user'

export const REQUEST_AUDIT_EVENTS = 'REQUEST_AUDIT_EVENTS'
export const RECEIVE_AUDIT_EVENTS = 'RECEIVE_AUDIT_EVENTS'
export const RECEIVE_AUDIT_EVENTS_MORE = 'RECEIVE_AUDIT_EVENTS_MORE'
export const CLEAR_AUDIT_EVENTS = 'CLEAR_AUDIT_EVENTS'
export const SAVE_AUDIT_QUERY = 'SAVE_AUDIT_QUERY'

const AUDIT_SERVICE_URL =`${PROTOCOL}//api.${HOST_NAME}/audit/`

export const gotoAudit = () => dispatch =>{
  dispatch(push('/audit'));
};


export const saveAuditQuery = (query_data) => ({
  type: SAVE_AUDIT_QUERY,
  payload: query_data
})

export const clearAuditEvents = () => ({
  type: CLEAR_AUDIT_EVENTS
})



export const requestAuditEvents = () => ({
  type: REQUEST_AUDIT_EVENTS
})

export const receiveAuditEvents = (json) => ({
  type: RECEIVE_AUDIT_EVENTS,
  payload: json
})

export const receiveAuditEventsMore = (json) => ({
  type: RECEIVE_AUDIT_EVENTS_MORE,
  payload: json
})

export const fetchAuditEvents = (data) => dispatch => {
  var method = 'get_events'
  dispatch(requestAuditEvents())
  return jsonRPCRequest(AUDIT_SERVICE_URL, method, data)
  .then(response => response.json())
  .then(json => dispatch(checkAuth(json)))
  .then(json => dispatch(receiveAuditEvents(json)))
}

export const fetchAuditEventsMore = (data) => dispatch => {
  console.log('fetchAuditEventsMore')
  console.log(data)
  var method = 'get_events'
  dispatch(requestAuditEvents())
  return jsonRPCRequest(AUDIT_SERVICE_URL,method, data)
  .then(response => response.json())
  .then(json => dispatch(checkAuth(json)))
  .then(json => dispatch(receiveAuditEventsMore(json), ))
}
