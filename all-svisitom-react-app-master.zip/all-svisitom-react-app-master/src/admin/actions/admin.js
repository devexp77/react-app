import fetch from 'isomorphic-fetch';
import {jsonRPCRequest} from "../../common/actions/asyncActions";
import { push } from 'react-router-redux';
import { FULL_HOST_NAME, HOST_NAME, PROTOCOL } from '../../common/constants';
import { checkAuth } from '../../common/actions/user'


export const REQUEST_USER_INFO = 'REQUEST_USER_INFO';
export const RECEIVE_USER_INFO = 'RECEIVE_USER_INFO';
export const CLEAR_USER_INFO = 'CLEAR_USER_INFO';
export const REQUEST_USERS = 'REQUEST_USERS';
export const RECEIVE_USERS = 'RECEIVE_USERS';
export const RECEIVE_MORE_USERS = 'RECEIVE_MORE_USERS';
export const CLEAR_USER_LIST = 'CLEAR_USER_LIST';
export const ADMIN_SET_USER = 'ADMIN_SET_USER';
export const SAVE_USERS_QUERY = 'SAVE_USERS_QUERY';
export const SAVE_DEVICES_QUERY = 'SAVE_DEVICES_QUERY';

export const SAVE_OBJECTS_QUERY = 'SAVE_OBJECTS_QUERY';

export const ADMIN_REQUEST_SET_OBJECT_BLOCKED = 'ADMIN_REQUEST_SET_OBJECT_BLOCKED';
export const ADMIN_RECEIVE_SET_OBJECT_BLOCKED = 'ADMIN_RECEIVE_SET_OBJECT_BLOCKED';

export const ADMIN_REQUEST_SET_OBJECT_SUSPENDED = 'ADMIN_REQUEST_SET_OBJECT_SUSPENDED';
export const ADMIN_RECEIVE_SET_OBJECT_SUSPENDED = 'ADMIN_RECEIVE_SET_OBJECT_SUSPENDED';

export const ADMIN_REQUEST_SET_PROMO_PERIOD_DEADLINE = 'ADMIN_REQUEST_SET_PROMO_PERIOD_DEADLINE';
export const ADMIN_RECEIVE_SET_PROMO_PERIOD_DEADLINE = 'ADMIN_RECEIVE_SET_PROMO_PERIOD_DEADLINE';

export const ADMIN_REQUEST_CLEAR_PROMO_PERIOD_DEADLINE = 'ADMIN_REQUEST_CLEAR_PROMO_PERIOD_DEADLINE';
export const ADMIN_RECEIVE_CLEAR_PROMO_PERIOD_DEADLINE = 'ADMIN_RECEIVE_CLEAR_PROMO_PERIOD_DEADLINE';



const USER_SERVICE_URL =`${PROTOCOL}//api.${HOST_NAME}/users/`;
const OBJECT_SERVICE_URL =`${PROTOCOL}//api.${HOST_NAME}/objects/`;
const BILLING_SERVICE_URL =`${PROTOCOL}//api.${HOST_NAME}/billing/`;

export const toUsers = () => dispatch =>{
  dispatch(push('/users'));
};

export const gotoUser = (user_id) => dispatch =>{
  dispatch(push('/users/' + user_id));
};

export const gotoObject = (object_id) => dispatch => {
  dispatch(push('/objects/' + object_id))
};

export const saveUsersQuery = (query_data) => ({
  type: SAVE_USERS_QUERY,
  payload: query_data
});

export const clearUserList = () => ({
  type: CLEAR_USER_LIST
});

export const clearUserInfo = () => ({
  type: CLEAR_USER_INFO
});

export const requestUsers = () => ({
  type: REQUEST_USERS
});

export const receiveUsers = (json) => ({
  type: RECEIVE_USERS,
  payload: json
});

export const receiveMoreUsers = (json) => ({
  type: RECEIVE_MORE_USERS,
  payload: json
});

export const fetchUsers = (data) => dispatch => {
  var method = 'get_users';
  dispatch(requestUsers());
  return jsonRPCRequest(USER_SERVICE_URL, method, data)
  .then(response => response.json())
  .then(json => dispatch(checkAuth(json)))
  .then(json => dispatch(receiveUsers(json)))
};

export const fetchMoreUsers = (data) => dispatch => {
  var method = 'get_users';
  dispatch(requestUsers());
  return jsonRPCRequest(USER_SERVICE_URL,method, data)
  .then(response => response.json())
  .then(json => dispatch(checkAuth(json)))
  .then(json => dispatch(receiveMoreUsers(json), ))
};

export const requestUser = () => ({
  type: REQUEST_USER_INFO
});

export const receiveUser = (json) => ({
  type: RECEIVE_USER_INFO,
  payload: json
});

export const fetchUser = (data) => dispatch => {
  var method = 'get_user';
  dispatch(requestUser());
  return jsonRPCRequest(USER_SERVICE_URL,method, data)
    .then(response => response.json())
    .then(json => dispatch(checkAuth(json)))
    .then(json => dispatch(receiveUser(json), ))
};

export const setUser = (json) => ({
  type: ADMIN_SET_USER,
  payload: json
});

export const fetchSetUser = (data) => dispatch => {
  var method = 'set_user';
  return jsonRPCRequest(USER_SERVICE_URL, method, data)
    .then(response => response.json())
    .then(json => dispatch(checkAuth(json)))
    .then(json => dispatch(setUser(json)))
};




export const saveObjectsQuery = (query_data) => ({
  type: SAVE_OBJECTS_QUERY,
  payload: query_data
});



export const requestSetObjectBlocked = () => ({
    type: ADMIN_REQUEST_SET_OBJECT_BLOCKED
});

export const receiveSetObjectBlocked = (json) => ({
  type: ADMIN_RECEIVE_SET_OBJECT_BLOCKED,
  payload: json
});

export const fetchSetObjectBlocked = (data) => dispatch => {
  var method = 'set_blocked';
  dispatch(requestSetObjectBlocked());
  return jsonRPCRequest(OBJECT_SERVICE_URL, method, data)
    .then(response => response.json())
    .then(json => dispatch(checkAuth(json)))
    .then(json => dispatch(receiveSetObjectBlocked(json)))
};



export const requestSetObjectSuspended = () => ({
    type: ADMIN_REQUEST_SET_OBJECT_SUSPENDED
});

export const receiveSetObjectSuspended = (json) => ({
  type: ADMIN_RECEIVE_SET_OBJECT_SUSPENDED,
  payload: json
});

export const fetchSetObjectSuspended = (data) => dispatch => {
  var method = 'set_suspended';
  dispatch(requestSetObjectSuspended());
  return jsonRPCRequest(OBJECT_SERVICE_URL, method, data)
    .then(response => response.json())
    .then(json => dispatch(checkAuth(json)))
    .then(json => dispatch(receiveSetObjectSuspended(json)))
};



export const requestSetPromoPeriodDeadline = () => ({
  type: ADMIN_REQUEST_SET_PROMO_PERIOD_DEADLINE
});

export const receiveSetPromoPeriodDeadline = (json) => ({
  type: ADMIN_RECEIVE_SET_PROMO_PERIOD_DEADLINE,
  payload: json
});

export const fetchSetPromoPeriodDeadline = (data) => dispatch => {
  let method = 'set_promo_period_deadline';
  dispatch(requestSetPromoPeriodDeadline());
  return jsonRPCRequest(BILLING_SERVICE_URL, method, data)
    .then(response => response.json())
    .then(json => dispatch(checkAuth(json)))
    .then(json => dispatch(receiveSetPromoPeriodDeadline(json)))
};



export const requestClearPromoPeriodDeadline = () => ({
  type: ADMIN_REQUEST_CLEAR_PROMO_PERIOD_DEADLINE
});

export const receiveClearPromoPeriodDeadline = (json) => ({
  type: ADMIN_RECEIVE_CLEAR_PROMO_PERIOD_DEADLINE,
  payload: json
});

export const fetchClearPromoPeriodDeadline = (data) => dispatch => {
  let method = 'clear_promo_period_deadline';
  dispatch(requestClearPromoPeriodDeadline());
  return jsonRPCRequest(BILLING_SERVICE_URL, method, data)
    .then(response => response.json())
    .then(json => dispatch(checkAuth(json)))
    .then(json => dispatch(receiveClearPromoPeriodDeadline(json)))
};


export const saveDevicesQuery = (query_data) => ({
  type: SAVE_DEVICES_QUERY,
  payload: query_data
});


