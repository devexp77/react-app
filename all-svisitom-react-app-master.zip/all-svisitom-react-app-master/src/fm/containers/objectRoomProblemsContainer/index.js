import React, { Component, Fragment } from "react";
import { connect } from "react-redux";

import {
  toRoot,
  setTitle,
  setCustomHistoryPath,
  toCustomPath,
  pushHistory,
  setNavPanelContainer
} from "../../../common/actions/router";
import { fetchRoomById } from "../../../common/actions/rooms";
import { fetchObjectById } from "../../../common/actions/objects";

import CircleLoader from "../../../common/components/CircleLoader";

import strings from "../../localization/all";

import { ErrorToast } from "../../../common/Toasts/error";
import SinglePageWithCustomPaddingNavPanel from "../../../common/components/PageContainers/singlePageCustomPaddingNavPanel";
import {
  facilityProblemByIdReceive,
  fetchFacilityProblemById,
  fetchFacilityProblems,
  fetchRoomFacilityConfigByRoomId
} from "../../../common/actions/facility";
import ProfileInfo from "../../../common/components/ProfileInfo";
import "./style.css";
import MaterialList from "../../../common/components/MaterialList/MaterialList";
import MaterialListItem from "../../../common/components/MaterialListItem/twoLineItem";
import InputField from "../../../common/components/Inputs/inputField";
import Dropzone from "react-dropzone";
import update from "immutability-helper";
import { FlatButton, RaisedButton } from "../../../common/components/Button";
import { fetchSetImage } from "../../../common/actions/image";
import TextareaField from "../../../common/components/Inputs/textarea";
import MaterialSurface from "../../../common/components/PageContainers/materialSurface";
import {
  fetchAddFmRequest,
  fetchAddGroupFmRequest,
  saveFmRequestData
} from "../../../common/actions/facility_requests";
import FmRequestImagePreview from "../../../common/components/FmRequestImagePreview";
import { isValidEmail } from "../../../common/validation/email";
import drawImageToCanvas from "../../../common/util/drawImageToCanvas";
import { PhotoSwipeGallery } from "react-photoswipe";
const EXIF = require("exif-js");
import { ErrorClass } from "../../../common/validation/errorClass";
import { fetchAddActivity } from "../../../common/actions/activity";
import getBlobByImgSrc from "../../../common/util/getBlobByImgSrc";
import format from "string-format";
import Signature from "../../../common/components/Signature";
import fetch from "isomorphic-fetch";
import PdfViewer from "../../../common/components/PdfViewer";
import {
  clearFmDocuments,
  fetchFmDocuments
} from "../../../common/actions/document_attachments";
import Accordion, {
  AccordionCard,
  AccordionWrapper
} from "../../../common/components/Accordion";
import Icon from "../../../common/components/Icon";
import listToTree from "../../../common/util/listToTree";
import CheckBoxTree from "../../../common/components/CheckBoxTree";
import Moment from "react-moment";
import { Link } from "react-router";
import AddRow from "../../../common/components/MaterialList/AddRow";
import EmptyDialog from "../../../common/components/EmptyDialog";
import common_strings from "../../../common/localization/all";
import DeletePopUp from "../../../common/components/DeletePopUp";

class RoomContainer extends Component {
  constructor() {
    super();
    this.state = {
      renderRequest: false,
      activeWindow: "request",
      categoryTitle: "",
      structure: [],
      request_details: "",
      request_quantity: "1",
      imageGallery: [],
      imagesBlob: [],
      phone_number_for_notification: "",
      label_email_for_notification: "",
      validEmailHint: "",
      signature: null,
      flatDataSet: [],
      dataSet: [],
      expanded: [],
      checked: [],
      request_composition: [],
      prevActiveWindow: "",
      facilityProblemsForStructure: []
    };

    this.defaultFieldsConfig = [
      {
        name: "detail"
      },
      {
        name: "photo"
      }
    ];
  }

  componentDidMount() {
    window.scrollTo(0, 0);
    this.pageLoad();
  }

  componentDidUpdate(prevProps) {
    if (prevProps.params.problem_id !== this.props.params.problem_id) {
      this.pageLoad();
    }
  }

  async pageLoad() {
    const { dispatch } = this.props;
    const { problem_id, object_id, room_id } = this.props.params;
    dispatch(
      setNavPanelContainer({
        container: "container custom",
        location: this.props.location.pathname,
        width: "600px"
      })
    );

    dispatch(clearFmDocuments());

    try {
      await this.getObject();
      await this.getRoom();
      await this.getConfig();

      if (problem_id === "more") {
        dispatch(setCustomHistoryPath(`/${object_id}/rooms/${room_id}`));
        this.setState({
          categoryTitle: strings.title_select_problem
        });
        this.setState({
          renderRequest: false
        });
        await this.getAllProblemCategories();
      } else {
        let problem = this.findProblemInTree(problem_id);
        if (problem) {
          // проблема является категорией
          if (this.isCategory(problem)) {
            dispatch(setCustomHistoryPath(`/${object_id}/rooms/${room_id}`));

            const activeProblem = await this.getActiveProblem(problem_id);

            // тип проблемы состоит в группе - отправляем на страницу родителя группы
            if (activeProblem.group_root_id) {
              dispatch(
                toCustomPath(
                  `/${object_id}/rooms/${room_id}/${
                    activeProblem.group_root_id
                  }`
                )
              );
              return;
            }

            // тип проблемы не является категорией - стандартное отправление обращения
            if (!activeProblem.is_group) {
              this.setState({
                categoryTitle: activeProblem.name,
                renderRequest: false
              });

              let problem_ids = [];
              for (let i in problem.children) {
                problem_ids.push(problem.children[i].id);
              }
              await this.getProblems(problem_ids);
            }

            // тип обращения является групповым
            if (activeProblem.is_group) {
              const structure = await this.getStructure(problem);

              this.setState({
                structure: structure,
                facilityProblemsForStructure: this.props.facility
                  .facilityProblems.result
              });

              if (structure.length > 1) {
                dispatch(
                  setCustomHistoryPath(
                    `/${object_id}/rooms/${room_id}/${
                      structure[structure.length - 2].id
                    }`
                  )
                );
              } else {
                dispatch(
                  setCustomHistoryPath(`/${object_id}/rooms/${room_id}`)
                );
              }

              this.getDocuments();

              let problem_ids = [];
              let problems = [...problem.children];

              let i = 0;
              do {
                problem_ids.push(problems[i].id);
                if (problems[i].children && problems[i].children.length > 0) {
                  for (let j in problems[i].children) {
                    problems[i].children[j].parent = problems[i].id;
                    problems.push(problems[i].children[j]);
                  }
                }
                i++;
              } while (i < problems.length);

              await this.getProblems(problem_ids);
              const { facilityProblems } = this.props.facility;

              if (facilityProblems.result) {
                let allConfig = [];
                Object.assign(allConfig, facilityProblems.result);

                let forDataSet = [];
                let expanded = [];

                for (let config of allConfig) {
                  forDataSet.push({
                    problem_id: config.problem_id,
                    value: config.problem_id,
                    label: this.renderCheckBoxTreeLabel(config),
                    parent_id:
                      config.parent_id === problem_id ? "" : config.parent_id,
                    icon: <Icon name={config.icon_name} />,
                    className: "sv-checkbox-line",
                    showCheckbox: false
                  });
                  expanded.push(config.problem_id);
                }

                let dataSet = listToTree(forDataSet, {
                  idKey: "problem_id",
                  parentKey: "parent_id"
                });

                this.setState(prevState => {
                  return {
                    dataSet: dataSet,
                    flatDataSet: forDataSet,
                    expanded: expanded,
                    request_composition: [activeProblem],
                    renderRequest: true,
                    activeWindow: "groupRequest",
                    facilityProblemsForStructure: prevState.facilityProblemsForStructure.concat(
                      facilityProblems.result
                    )
                  };
                });
              }
            }
          } else {
            const activeProblem = await this.getActiveProblem(problem_id);
            const structure = await this.getStructure(problem);
            this.setState({ structure: structure });
            if (structure.length > 1) {
              dispatch(
                setCustomHistoryPath(
                  `/${object_id}/rooms/${room_id}/${
                    structure[structure.length - 2].id
                  }`
                )
              );
            } else {
              dispatch(setCustomHistoryPath(`/${object_id}/rooms/${room_id}`));
            }

            this.getDocuments();

            this.setState({
              renderRequest: true,
              activeWindow: "request"
            });
          }
        }
      }
    } catch (e) {
      ErrorToast();
      console.log(e);
    }
  }

  renderCheckBoxTreeLabel(problem) {
    return (
      <Fragment>
        <div>{problem.name}</div>
        {problem.is_payable && (
          <div className={`problem-price-in-tree`}>
            {format(strings.problem_price, problem.price)}
          </div>
        )}
      </Fragment>
    );
  }

  getDocuments() {
    const { dispatch } = this.props;
    const documents_ids = this.collectDocumentsIds();

    if (documents_ids.length > 0) {
      dispatch(
        fetchFmDocuments({
          filter: {
            document_attachment_ids: documents_ids
          }
        })
      ).then(res => {
        if (res.payload.error) {
          ErrorToast(res.payload.error);
        }
      });
    }
  }

  collectDocumentsIds() {
    const { facilityProblemById } = this.props.facility;
    let documents_ids = [];
    if (facilityProblemById.result && facilityProblemById.result.documents) {
      for (let document of facilityProblemById.result.documents) {
        documents_ids.push(document.document_id);
      }
    }

    return documents_ids;
  }

  async getObject() {
    const { dispatch } = this.props;
    const { object_id } = this.props.params;
    const { objectById } = this.props.objects;
    try {
      if (
        objectById &&
        objectById.result &&
        objectById.result.object_id === object_id
      ) {
        return true;
      } else {
        await dispatch(fetchObjectById({ object_id: object_id }));
        if (this.props.objects.objectById.result) {
          return true;
        }

        if (this.props.objects.objectById.error) {
          ErrorToast(this.props.objects.objectById.error);
          dispatch(toRoot());
          return false;
        }
      }
    } catch (e) {
      ErrorToast();
      console.log(e);
    }
  }

  async getRoom() {
    const { dispatch } = this.props;
    const { room_id } = this.props.params;
    const { roomById } = this.props.rooms;
    const { objectById } = this.props.objects;
    try {
      if (objectById.result) {
        if (roomById.result && roomById.result.room_id === room_id) {
          return true;
        } else {
          await dispatch(fetchRoomById({ room_id: room_id }));
          if (this.props.rooms.roomById.result) {
            dispatch(
              setTitle(
                `${objectById.result.name}, ${
                  this.props.rooms.roomById.result.name
                }`
              )
            );
            return true;
          }

          if (this.props.rooms.roomById.error) {
            ErrorToast(this.props.rooms.roomById.error);
            this.toHistoryPath();
            return false;
          }
        }
      }
    } catch (e) {
      ErrorToast();
      console.log(e);
    }
  }

  async getConfig() {
    const { dispatch } = this.props;
    const { room_id, object_id } = this.props.params;
    const { roomFacilityConfigByRoomId } = this.props.facility;
    try {
      if (
        roomFacilityConfigByRoomId &&
        roomFacilityConfigByRoomId.result &&
        roomFacilityConfigByRoomId.result.room_id === room_id
      ) {
        return true;
      } else {
        await dispatch(fetchRoomFacilityConfigByRoomId({ room_id: room_id }));
        if (this.props.facility.roomFacilityConfigByRoomId.result) {
          return true;
        }

        if (this.props.facility.roomFacilityConfigByRoomId.error) {
          ErrorToast(this.props.facility.roomFacilityConfigByRoomId.error);
          this.toHistoryPath();
          return false;
        }
      }
    } catch (e) {
      ErrorToast();
      console.log(e);
    }
  }

  async getAllProblemCategories() {
    const { dispatch, params } = this.props;
    const { roomFacilityConfigByRoomId } = this.props.facility;
    try {
      if (
        roomFacilityConfigByRoomId.result &&
        roomFacilityConfigByRoomId.result.all_problems &&
        roomFacilityConfigByRoomId.result.all_problems.length > 0
      ) {
        let problemCategories = [];
        const { all_problems } = roomFacilityConfigByRoomId.result;

        for (let i in all_problems) {
          problemCategories.push(all_problems[i].id);
        }

        await dispatch(
          fetchFacilityProblems({
            filter: {
              problem_ids: problemCategories,
              check_resident_room_id: params.room_id
            }
          })
        );

        const { facilityProblems } = this.props.facility;
        if (facilityProblems.result) {
          return true;
        }
        if (facilityProblems.error) {
          ErrorToast(facilityProblems.error);
          return false;
        }
      }
    } catch (e) {
      ErrorToast();
      console.log(e);
    }
  }

  findProblemInTree(problem_id) {
    const { roomFacilityConfigByRoomId } = this.props.facility;
    if (
      roomFacilityConfigByRoomId.result &&
      roomFacilityConfigByRoomId.result.all_problems &&
      roomFacilityConfigByRoomId.result.all_problems.length > 0
    ) {
      let allProblems = [];

      Object.assign(
        allProblems,
        roomFacilityConfigByRoomId.result.all_problems
      );

      let i = 0;
      do {
        if (problem_id === allProblems[i].id) {
          return allProblems[i];
        }

        if (allProblems[i].children && allProblems[i].children.length > 0) {
          for (let j in allProblems[i].children) {
            allProblems[i].children[j].parent_id = allProblems[i].id;
            allProblems.push(allProblems[i].children[j]);
          }
        }
        i++;
      } while (i < allProblems.length);
    }
  }

  isCategory(problem) {
    return !!(problem.children && problem.children.length > 0);
  }

  async getStructure(problem) {
    let structureIds = this.restructurTree(problem);
    await this.getProblems(structureIds);
    const { facilityProblems } = this.props.facility;
    if (facilityProblems.result) {
      let structure = [];
      for (let i in facilityProblems.result) {
        structure.push({
          id: facilityProblems.result[i].problem_id,
          name: facilityProblems.result[i].name,
          icon_name: facilityProblems.result[i].icon_name
        });
      }
      return structure;
    }
    if (facilityProblems.error) {
      ErrorToast(facilityProblems.error);
      return false;
    }
  }

  async getStructureFromLoaded(problem) {
    let structureIds = this.restructurTree(problem);
    console.log(structureIds);

    const { facilityProblemsForStructure } = this.state;

    let structure = [];
    for (let i in facilityProblemsForStructure) {
      if (
        structureIds.indexOf(facilityProblemsForStructure[i].problem_id) > -1
      ) {
        structure.push({
          id: facilityProblemsForStructure[i].problem_id,
          name: facilityProblemsForStructure[i].name,
          icon_name: facilityProblemsForStructure[i].icon_name
        });
      }
    }
    return structure;
  }

  restructurTree(problem) {
    let structure = [];
    structure.push(problem.id);
    while (problem.parent_id) {
      problem = this.findProblemInTree(problem.parent_id);
      structure.push(problem.id);
    }
    return structure.reverse();
  }

  async getProblems(problem_ids) {
    const { dispatch, params } = this.props;
    try {
      await dispatch(
        fetchFacilityProblems({
          filter: {
            problem_ids: problem_ids,
            check_resident_room_id: params.room_id
          }
        })
      );

      const { facilityProblems } = this.props.facility;
      if (facilityProblems.result) {
        return true;
      }
      if (facilityProblems.error) {
        ErrorToast(facilityProblems.error);
        return false;
      }
    } catch (e) {
      ErrorToast();
      console.log(e);
    }
  }

  async getActiveProblem(problem_id) {
    const { facilityProblemById } = this.props.facility;
    let activeProblem = {};
    if (
      !(
        facilityProblemById.result &&
        facilityProblemById.result.problem_id === problem_id
      )
    ) {
      await this.getProblem(problem_id);
    }

    if (
      this.props.facility.facilityProblemById.result &&
      this.props.facility.facilityProblemById.result.problem_id === problem_id
    ) {
      activeProblem = this.props.facility.facilityProblemById.result;
    }

    return activeProblem;
  }

  async getProblem(problem_id) {
    const { dispatch } = this.props;
    try {
      await dispatch(
        fetchFacilityProblemById({
          problem_id: problem_id
        })
      );

      const { facilityProblemById } = this.props.facility;
      if (facilityProblemById.result) {
        return true;
      }
      if (facilityProblemById.error) {
        ErrorToast(facilityProblemById.error);
        return false;
      }
    } catch (e) {
      ErrorToast();
      console.log(e);
    }
  }

  toHistoryPath() {
    const { dispatch } = this.props;
    const fromHistory = this.props.router.history.pop();
    const historyPath = fromHistory
      ? fromHistory
      : this.props.router.customHistoryPath;
    dispatch(toCustomPath(historyPath));
  }

  toProblem = problem => {
    const { dispatch } = this.props;
    dispatch(facilityProblemByIdReceive({ result: problem }));
    const { object_id, room_id } = this.props.params;

    dispatch(pushHistory(this.props.location.pathname));
    dispatch(
      toCustomPath(`/${object_id}/rooms/${room_id}/${problem.problem_id}`)
    );
  };

  handleInputChange(event) {
    const id = event.target.id;
    const value = event.target.value;
    this.setState({ [id]: value });

    if (id === "email_for_notification") {
      this.validateEmail(value);
    }
  }

  handleQuantityInputChange(event) {
    const id = event.target.id;
    let value = parseFloat(event.target.value);

    if (value < 0) {
      value = value * -1;
    }

    if (value === 0) {
      value = 1;
    }

    if (value % 1 !== 0) {
      value = Math.round(value);
    }

    this.setState({ [id]: value });
  }

  async handleDrop(dropped) {
    for (let file of dropped) {
      let result = await getBlobByImgSrc(file.preview);
      this.setState(prevState => {
        return update(prevState, {
          imageGallery: {
            $push: [result.galleryImage]
          },
          imagesBlob: { $push: [result.blob] }
        });
      });
    }
  }

  async handleSubmit() {
    const { dispatch } = this.props;

    let emailValid = true;

    if (!this.props.user.user.result && this.state.email_for_notification) {
      emailValid = this.validateEmail(this.state.email_for_notification);
    }

    if (emailValid) {
      const data = {
        object: {
          object_id: this.props.objects.objectById.result.object_id,
          name: this.props.objects.objectById.result.name
        },
        room: {
          room_id: this.props.rooms.roomById.result.room_id,
          name: this.props.rooms.roomById.result.name,
          tags: this.props.rooms.roomById.result.tags
        },
        problem: this.state.structure
      };

      let { fields_config } = this.props.facility.facilityProblemById.result;
      if (fields_config === undefined || fields_config === null) {
        fields_config = this.defaultFieldsConfig;
      }
      for (let i = 0; i < fields_config.length; i++) {
        const fc = fields_config[i];
        if (fc.name === "detail") {
          data.detail = this.state.request_details;
        } else if (fc.name === "quantity") {
          data.quantity = parseFloat(this.state.request_quantity);
        }
      }

      if (!this.props.user.user.result) {
        data.email_for_notification = this.state.email_for_notification;
        data.phone_number_for_notification = this.state.phone_number_for_notification;
        data.language_for_notification = strings.getLanguage();
        data.timezone_offset_for_notification = new Date().getTimezoneOffset();
      }

      await dispatch(fetchAddFmRequest(data));

      if (this.props.facility_requests.requestOperationStatus.result) {
        dispatch(
          saveFmRequestData(
            this.props.facility_requests.requestOperationStatus.result
          )
        );

        if (this.state.imagesBlob.length > 0) {
          for (let i in this.state.imagesBlob) {
            let fd = new FormData();
            fd.append("file", this.state.imagesBlob[i], "file.jpg");
            fd.append("entity_type", "facility_request");
            fd.append(
              "entity_id",
              this.props.facility_requests.requestOperationStatus.result
                .facility_request_id
            );
            fd.append("suffix", i);

            await dispatch(fetchSetImage(fd)).then(res => {
              if (res.payload.error) {
                ErrorToast(res.payload.error);
              }
            });
          }
        }

        if (this.state.signature) {
          let res = await fetch(this.state.signature);
          let blob = await res.blob();
          let fd = new FormData();
          fd.append("file", blob, "file.png");
          fd.append("entity_type", "facility_signature");
          fd.append(
            "entity_id",
            this.props.facility_requests.requestOperationStatus.result
              .facility_request_id
          );
          fd.append("suffix", "creator");

          await dispatch(fetchSetImage(fd)).then(res => {
            if (res.payload && res.payload.error) {
              ErrorToast(res.payload.error);
            }

            if (res.payload && res.payload.result) {
              this.setState({
                signature: null
              });
            }
          });
        }

        if (this.props.user.user.result) {
          const dataActivity = {
            user_id: this.props.user.user.result.user_id,
            entity_type: "object",
            entity_id: this.props.params.object_id,
            activity_type: "facility_request"
          };
          await dispatch(fetchAddActivity(dataActivity));
          const { addActivityStatus } = this.props.activity;
          if (addActivityStatus.error) {
            ErrorToast(addActivityStatus.error);
          }
        }

        dispatch(toCustomPath("/success"));
      }
      if (this.props.facility_requests.requestOperationStatus.error) {
        ErrorToast(this.props.facility_requests.requestOperationStatus.error);
      }
    } else {
      ErrorToast(strings.hint_invalid_email, "incorrect_email");
    }
  }

  async handleGroupSubmit() {
    const { dispatch } = this.props;
    console.log(this.state);
    let emailValid = true;

    if (!this.props.user.user.result && this.state.email_for_notification) {
      emailValid = this.validateEmail(this.state.email_for_notification);
    }

    if (emailValid) {
      const common_data = {
        object: {
          object_id: this.props.objects.objectById.result.object_id,
          name: this.props.objects.objectById.result.name
        },
        room: {
          room_id: this.props.rooms.roomById.result.room_id,
          name: this.props.rooms.roomById.result.name,
          tags: this.props.rooms.roomById.result.tags
        }
      };

      if (!this.props.user.user.result) {
        common_data.email_for_notification = this.state.email_for_notification;
        common_data.phone_number_for_notification = this.state.phone_number_for_notification;
        common_data.language_for_notification = strings.getLanguage();
        common_data.timezone_offset_for_notification = new Date().getTimezoneOffset();
      }

      let root_facility_request = {};
      Object.assign(root_facility_request, common_data);

      root_facility_request.problem = this.state.structure;

      let { fields_config } = this.props.facility.facilityProblemById.result;
      if (fields_config === undefined || fields_config === null) {
        fields_config = this.defaultFieldsConfig;
      }
      for (let i = 0; i < fields_config.length; i++) {
        const fc = fields_config[i];
        if (fc.name === "detail") {
          root_facility_request.detail = this.state.request_details;
        } else if (fc.name === "quantity") {
          root_facility_request.quantity = parseFloat(
            this.state["request_quantity_" + this.props.params.problem_id] || 1
          );
        }
      }

      let child_facility_requests = [];
      if (this.state.request_composition.length > 1) {
        for (let i = 0; i < this.state.request_composition.length; i++) {
          if (i !== 0) {
            let child_facility_request = {};
            Object.assign(child_facility_request, common_data);
            const problemInTree = this.findProblemInTree(
              this.state.request_composition[i].problem_id
            );

            child_facility_request.problem = await this.getStructureFromLoaded(
              problemInTree
            );
            let { fields_config } = this.state.request_composition[i];
            if (fields_config === undefined || fields_config === null) {
              fields_config = this.defaultFieldsConfig;
            }
            for (let j = 0; j < fields_config.length; j++) {
              const fc = fields_config[j];
              if (fc.name === "quantity") {
                child_facility_request.quantity = parseFloat(
                  this.state[
                    "request_quantity_" +
                      this.state.request_composition[i].problem_id
                  ] || 1
                );
              }
            }

            child_facility_requests.push(child_facility_request);
          }
        }
      }

      const data = {
        root_facility_request: root_facility_request,
        child_facility_requests: child_facility_requests
      };

      await dispatch(fetchAddGroupFmRequest(data));

      if (this.props.facility_requests.requestOperationStatus.result) {
        dispatch(
          saveFmRequestData(
            this.props.facility_requests.requestOperationStatus.result
          )
        );

        if (this.state.imagesBlob.length > 0) {
          for (let i in this.state.imagesBlob) {
            let fd = new FormData();
            fd.append("file", this.state.imagesBlob[i], "file.jpg");
            fd.append("entity_type", "facility_request");
            fd.append(
              "entity_id",
              this.props.facility_requests.requestOperationStatus.result
                .facility_request_id
            );
            fd.append("suffix", i);

            await dispatch(fetchSetImage(fd)).then(res => {
              if (res.payload.error) {
                ErrorToast(res.payload.error);
              }
            });
          }
        }

        if (this.state.signature) {
          let res = await fetch(this.state.signature);
          let blob = await res.blob();
          let fd = new FormData();
          fd.append("file", blob, "file.png");
          fd.append("entity_type", "facility_signature");
          fd.append(
            "entity_id",
            this.props.facility_requests.requestOperationStatus.result
              .facility_request_id
          );
          fd.append("suffix", "creator");

          await dispatch(fetchSetImage(fd)).then(res => {
            if (res.payload && res.payload.error) {
              ErrorToast(res.payload.error);
            }

            if (res.payload && res.payload.result) {
              this.setState({
                signature: null
              });
            }
          });
        }

        if (this.props.user.user.result) {
          const dataActivity = {
            user_id: this.props.user.user.result.user_id,
            entity_type: "object",
            entity_id: this.props.params.object_id,
            activity_type: "facility_request"
          };
          await dispatch(fetchAddActivity(dataActivity));
          const { addActivityStatus } = this.props.activity;
          if (addActivityStatus.error) {
            ErrorToast(addActivityStatus.error);
          }
        }

        dispatch(toCustomPath("/success"));
      }
      if (this.props.facility_requests.requestOperationStatus.error) {
        ErrorToast(this.props.facility_requests.requestOperationStatus.error);
      }
    } else {
      ErrorToast(strings.hint_invalid_email, "incorrect_email");
    }
  }

  getProblemPageTitle(is_payable) {
    let title = "";
    if (this.state.structure.length > 0) {
      for (let i in this.state.structure) {
        if (Number(i) === 0) {
          title = this.state.structure[i].name;
        } else if (
          is_payable &&
          Number(i) === this.state.structure.length - 1
        ) {
        } else {
          title += " · " + this.state.structure[i].name;
        }
      }
    }
    return title;
  }

  validateEmail(value) {
    let inviteEmailValid = true;
    let validEmailHint = "";

    if (value.length === 0 || !isValidEmail(value)) {
      inviteEmailValid = false;
      validEmailHint = strings.hint_invalid_email;
    }

    this.setState({
      validEmailHint: validEmailHint
    });

    return inviteEmailValid;
  }

  errorClass(error) {
    if (error.length === 0) {
      return "success";
    } else if (error === "init") {
      return "";
    } else {
      return "wrong";
    }
  }

  filterDataSet() {
    let forDataSet = [...this.state.flatDataSet];

    let selectedProblemsIds = [];
    for (let problem of this.state.request_composition) {
      selectedProblemsIds.push(problem.problem_id);
    }

    for (let item of forDataSet) {
      if (selectedProblemsIds.indexOf(item.problem_id) > -1) {
        item.className = "sv-checkbox-line disabled";
      } else {
        item.className = "sv-checkbox-line";
      }
    }

    let dataSet = listToTree(forDataSet, {
      idKey: "problem_id",
      parentKey: "parent_id"
    });

    this.setState({ dataSet: dataSet });
  }

  selectProblem(problem_id) {
    const { facilityProblems } = this.props.facility;
    if (
      facilityProblems.result &&
      facilityProblems.result.length > 0 &&
      facilityProblems.result.find(problem => problem.problem_id === problem_id)
    ) {
      const problem = facilityProblems.result.find(
        problem => problem.problem_id === problem_id
      );
      this.setState(
        {
          request_composition: update(this.state.request_composition, {
            $push: [problem]
          })
        },
        () => {
          this.AddFacilityProblemModal.close();
          this.filterDataSet();
        }
      );
    } else {
      this.AddFacilityProblemModal.close();
    }
  }

  isFieldEnabled(fieldName, problem) {
    if (!this.props.facility.facilityProblemById.result) {
      return false;
    }

    problem = problem || this.props.facility.facilityProblemById.result;

    let { fields_config } = problem;
    if (fields_config === undefined || fields_config === null) {
      fields_config = this.defaultFieldsConfig;
    }

    return fields_config.filter(fc => fc.name === fieldName).length > 0;
  }

  getTotalPrice() {
    const { facilityProblemById } = this.props.facility;
    const price = facilityProblemById.result
      ? facilityProblemById.result.price
      : 0;
    const quantity = +this.state.request_quantity || 1;

    return price * quantity;
  }

  renderProblemsList() {
    const { facilityProblems } = this.props.facility;
    return (
      <SinglePageWithCustomPaddingNavPanel width={`600px`}>
        {facilityProblems.result && facilityProblems.result.length > 0 && (
          <ProfileInfo.Title
            title={this.state.categoryTitle}
            style={{ textAlign: "center" }}
          />
        )}

        <MaterialList emptyText={strings.title_can_not_send_request_to_this_room}>
          {facilityProblems.result &&
            facilityProblems.result.map((problem, index) => (
              <MaterialListItem
                key={index}
                item_id={problem.problem_id}
                firstLineContent={problem.name}
                secondLineContent={
                  problem.is_payable
                    ? format(strings.problem_price, problem.price)
                    : ""
                }
                icon={
                  problem.icon_name ? problem.icon_name : `sv-icon-fm-other`
                }
                gotoItem={() => this.toProblem(problem)}
              />
            ))}
        </MaterialList>
      </SinglePageWithCustomPaddingNavPanel>
    );
  }

  renderGroupRequest() {
    return (
      <SinglePageWithCustomPaddingNavPanel width={`600px`}>
        <ProfileInfo.Title
          title={this.getProblemPageTitle()}
          style={{ textAlign: "center" }}
        />

        {this.renderSelectedItems()}

        {this.renderCommonFields()}

        {this.renderFieldsForUnAuthorizedUser()}

        {this.renderPhotoField()}

        {this.renderDocuments()}

        {this.renderSignatureImg()}

        {this.renderConfirmButton(this.handleGroupSubmit.bind(this))}

        {this.renderAddFacilityProblemModal()}
      </SinglePageWithCustomPaddingNavPanel>
    );
  }

  renderAddFacilityProblemModal() {
    return (
      <EmptyDialog
        id={`facility_problems`}
        header={strings.title_select_request_types}
        closeButton
        ref={element => {
          this.AddFacilityProblemModal = element;
        }}
      >
        <div style={{ padding: "10px 1.5rem 0" }}>
          <CheckBoxTree
            nodes={this.state.dataSet || []}
            expanded={this.state.expanded}
            onClick={onClicked => this.selectProblem(onClicked.value)}
            clickOnlyOnChildren
          />
        </div>
      </EmptyDialog>
    );
  }

  renderSecondLineContent(problem) {
    const cost =
      problem.price *
      (this.state["request_quantity_" + problem.problem_id] || 1);
    return (
      <div className={`calculate-total`}>
        {problem.is_payable ? (
          <Fragment>
            <div className={`price`}>
              {format(strings.problem_price, problem.price)}
            </div>
            {this.isFieldEnabled("quantity", problem) && (
              <Fragment>
                <div className={`multiply-sign`}>&#215;</div>
                <div className={`quantity`}>
                  <InputField
                    id={"request_quantity_" + problem.problem_id}
                    type="number"
                    min={1}
                    value={
                      this.state["request_quantity_" + problem.problem_id] || 1
                    }
                    handleInputChange={this.handleQuantityInputChange.bind(
                      this
                    )}
                    label={strings.label_fm_request_quantity}
                  />
                </div>
                <div className={`multiply-sign`}>=</div>
                <div className={`total`}>
                  {format(strings.problem_price, cost)}
                </div>
              </Fragment>
            )}
          </Fragment>
        ) : this.isFieldEnabled("quantity", problem) ? (
          <div className={`quantity`}>
            <InputField
              id={"request_quantity_" + problem.problem_id}
              type="number"
              min={1}
              value={this.state["request_quantity_" + problem.problem_id] || 1}
              handleInputChange={this.handleQuantityInputChange.bind(this)}
            />
          </div>
        ) : null}
      </div>
    );
  }

  getTotal() {
    let total = 0;
    for (let problem of this.state.request_composition) {
      total +=
        problem.price *
        (this.state[`request_quantity_` + problem.problem_id] || 1);
    }
    return total;
  }

  deleteFromComposition(problem) {
    let index = this.state.request_composition.indexOf(problem);

    if (index > -1) {
      this.setState(
        prevState => {
          let request_composition = prevState.request_composition;
          request_composition.splice(index, 1);
          return {
            request_composition: request_composition
          };
        },
        () => this.filterDataSet()
      );
    }
  }

  renderSelectedItems() {
    const { facilityProblemById } = this.props.facility;
    const total =
      facilityProblemById.result && facilityProblemById.result.is_payable
        ? this.getTotal()
        : 0;
    return (
      <Fragment>
        <ProfileInfo.Title title={strings.title_facility_request_composition} />
        <AddRow
          text={strings.button_add_facility_request_options}
          onClick={() => this.AddFacilityProblemModal.open()}
        />
        <MaterialList>
          {this.state.request_composition.map((problem, index) => (
            <MaterialListItem
              key={problem.problem_id + "_" + index}
              item_id={problem.problem_id}
              icon={problem.icon_name}
              firstLineContent={problem.name}
              secondLineContent={this.renderSecondLineContent(problem)}
              lineButtonClick={
                problem.problem_id !== this.props.params.problem_id
                  ? () => this.deleteFromComposition(problem)
                  : null
              }
              buttonIcon={`close`}
              buttonClassName={`color-grey`}
            />
          ))}
        </MaterialList>

        <div
          style={{
            padding: "8px 0",
            marginBottom: "15px",
            textAlign: "right",
            fontWeight: "500"
          }}
        >
          {facilityProblemById.result &&
            facilityProblemById.result.is_payable &&
            format(strings.problem_total_price, total)}
        </div>
      </Fragment>
    );
  }

  renderFieldsForUnAuthorizedUser() {
    if (!this.props.user.user.result) {
      return (
        <MaterialSurface marginBottom smallPadding>
          <InputField
            id={`email_for_notification`}
            value={this.state.email_for_notification}
            handleInputChange={this.handleInputChange.bind(this)}
            label={strings.label_email_for_notification}
            errorClass={this.errorClass.bind(this)}
            error={this.state.validEmailHint}
          />

          <InputField
            id={`phone_number_for_notification`}
            value={this.state.phone_number_for_notification}
            handleInputChange={this.handleInputChange.bind(this)}
            label={strings.label_phone_number_for_notification}
          />
        </MaterialSurface>
      );
    } else return null;
  }

  renderDocuments() {
    const { facilityProblemDocuments } = this.props.document_attachments;
    if (
      facilityProblemDocuments.result &&
      facilityProblemDocuments.result.length > 0
    ) {
      return (
        <Fragment>
          <ProfileInfo.Title title={strings.title_documents} />
          <AccordionWrapper id={`documents_accordion`} marginBottom>
            {facilityProblemDocuments.result.map(document => (
              <AccordionCard
                renderWhenOpened
                divHeightWhileRendering={500}
                parent_id={`documents_accordion`}
                key={document.document_attachment_id}
                header={document.name}
                noPadding
              >
                <PdfViewer file={document.document_attachment_url} />
              </AccordionCard>
            ))}
          </AccordionWrapper>
        </Fragment>
      );
    } else return null;
  }

  renderSignatureImg() {
    if (this.state.signature) {
      return (
        <MaterialSurface marginBottom>
          <img className={`signature-img`} src={this.state.signature} />
        </MaterialSurface>
      );
    } else return null;
  }

  renderConfirmButton(submit) {
    return this.isFieldEnabled("creator_signature") && !this.state.signature ? (
      <Fragment>
        <ProfileInfo.Title title={strings.title_fm_request_need_signature} />
        <RaisedButton
          onClick={() => this.toggleActiveWindow("signature")}
          position={`left`}
        >
          {strings.button_request_signature}
        </RaisedButton>
      </Fragment>
    ) : (
      <RaisedButton onClick={submit} position={`left`}>
        {strings.button_send_fm_request}
      </RaisedButton>
    );
  }

  renderPhotoField() {
    return (
      this.isFieldEnabled("photo") && (
        <React.Fragment>
          <Dropzone
            onDrop={this.handleDrop.bind(this)}
            multiple={true}
            className={`dropzone`}
            activeClassName={`dropzone-active`}
          >
            <div className={`add-photo-button clearfix`}>
              <i className="material-icons">add_a_photo</i>
              <span>{strings.title_add_photo}</span>
            </div>
          </Dropzone>

          {this.state.imageGallery.length > 0 && (
            <MaterialSurface className={`clearfix`} smallPadding marginBottom>
              <PhotoSwipeGallery
                items={this.state.imageGallery}
                thumbnailContent={item => (
                  <FmRequestImagePreview src={item.src} count={3} />
                )}
                options={{
                  closeOnScroll: false,
                  shareEl: false,
                  captionEl: false,
                  clickToCloseNonZoomable: false
                }}
              />
            </MaterialSurface>
          )}
        </React.Fragment>
      )
    );
  }

  render() {
    const { objectById, objectByIdIsFetching } = this.props.objects;
    const { roomById, roomByIdIsFetching } = this.props.rooms;
    const {
      facilityProblemsIsFetching,
      roomFacilityConfigByRoomId,
      roomFacilityConfigByRoomIdIsFetching
    } = this.props.facility;

    if (
      objectByIdIsFetching ||
      roomByIdIsFetching ||
      roomFacilityConfigByRoomIdIsFetching ||
      facilityProblemsIsFetching
    ) {
      return (
        <SinglePageWithCustomPaddingNavPanel>
          <CircleLoader />
        </SinglePageWithCustomPaddingNavPanel>
      );
    }
    if (
      objectById.result &&
      roomById.result &&
      roomFacilityConfigByRoomId.result
    ) {
      if (this.state.renderRequest) {
        switch (this.state.activeWindow) {
          case "groupRequest":
            return this.renderGroupRequest();

          case "request":
            return this.renderRequest();

          case "signature":
            return this.renderSignature();

          default:
            return null;
        }
      } else return this.renderProblemsList();
    } else return null;
  }

  renderPayableFields() {
    const { facilityProblemById } = this.props.facility;
    const is_payable =
      facilityProblemById.result && facilityProblemById.result.is_payable;
    if (is_payable) {
      return (
        <Fragment>
          <MaterialSurface marginBottom smallPadding>
            <TextareaField
              id="problem"
              value={facilityProblemById.result.name}
              readOnly
            />
            <InputField
              id="problem_price"
              value={format(
                strings.problem_price,
                facilityProblemById.result.price
              )}
              handleInputChange={this.handleInputChange.bind(this)}
              label={strings.label_fm_request_price}
              readOnly
              inputStyle={{ color: "grey" }}
            />

            {this.isFieldEnabled("quantity") && (
              <InputField
                id="request_quantity"
                type="number"
                value={this.state.request_quantity}
                handleInputChange={this.handleInputChange.bind(this)}
                label={strings.label_fm_request_quantity}
              />
            )}

            <div
              style={{
                borderTop: "1px solid #ccc",
                padding: "8px 30px",
                marginLeft: "-30px",
                marginRight: "-30px",
                marginBottom: "-10px",
                textAlign: "right",
                fontWeight: "500"
              }}
            >
              {format(strings.problem_total_price, this.getTotalPrice())}
            </div>
          </MaterialSurface>
        </Fragment>
      );
    } else return null;
  }

  renderCommonFields() {
    const { facilityProblemById } = this.props.facility;
    const is_payable =
      facilityProblemById.result && facilityProblemById.result.is_payable;
    if (
      this.isFieldEnabled("detail") ||
      (this.isFieldEnabled("quantity") && !is_payable)
    ) {
      return (
        <MaterialSurface marginBottom smallPadding>
          {this.isFieldEnabled("detail") && (
            <TextareaField
              id="request_details"
              value={this.state.request_details}
              handleInputChange={this.handleInputChange.bind(this)}
              label={strings.label_fm_request_description}
            />
          )}

          {this.isFieldEnabled("quantity") &&
            !(
              facilityProblemById.result &&
              (facilityProblemById.result.is_payable ||
                facilityProblemById.result.is_group)
            ) && (
              <InputField
                id="request_quantity"
                type="number"
                min={1}
                value={this.state.request_quantity}
                handleInputChange={this.handleQuantityInputChange.bind(this)}
                label={strings.label_fm_request_quantity}
              />
            )}
        </MaterialSurface>
      );
    } else return null;
  }

  renderRequest() {
    const { facilityProblemById } = this.props.facility;
    const is_payable =
      facilityProblemById.result && facilityProblemById.result.is_payable;
    return (
      <SinglePageWithCustomPaddingNavPanel width={`600px`}>
        <ProfileInfo.Title
          title={this.getProblemPageTitle(is_payable)}
          style={{ textAlign: "center" }}
        />

        {this.renderPayableFields()}

        {this.renderCommonFields()}

        {this.renderFieldsForUnAuthorizedUser()}

        {this.renderPhotoField()}

        {this.renderDocuments()}
        {this.renderSignatureImg()}

        {this.renderConfirmButton(this.handleSubmit.bind(this))}
      </SinglePageWithCustomPaddingNavPanel>
    );
  }

  renderSignature() {
    const { facilityProblemById } = this.props.facility;
    return (
      <SinglePageWithCustomPaddingNavPanel width={`600px`}>
        <Signature
          cancelFunction={() =>
            this.toggleActiveWindow(this.state.prevActiveWindow)
          }
          submitFunction={this.getSignature}
          signatureText={
            (facilityProblemById.result &&
              facilityProblemById.result.creator_signature_text) ||
            ""
          }
        />
      </SinglePageWithCustomPaddingNavPanel>
    );
  }

  toggleActiveWindow = window => {
    this.setState(prevState => {
      return {
        activeWindow: window,
        prevActiveWindow: prevState.activeWindow
      };
    });
  };

  getSignature = signature => {
    this.setState(
      {
        signature: signature
      },
      () => this.toggleActiveWindow(this.state.prevActiveWindow)
    );
  };

  componentWillUnmount() {
    const { dispatch } = this.props;
    dispatch(clearFmDocuments());
  }
}

const mapStateToProps = state => {
  return {
    rooms: state.rooms,
    objects: state.objects,
    facility: state.facility,
    facility_requests: state.facility_requests,
    router: state.router,
    user: state.user,
    activity: state.activity,
    document_attachments: state.document_attachments
  };
};

export default connect(mapStateToProps)(RoomContainer);
