import React, { Component } from "react";
import { connect } from "react-redux";

import {
  fetchObjects,
  fetchMoreObjects,
  clearObjects,
  fetchObjectsCount
} from "../../../common/actions/objects";
import {
  setCustomHistoryPath,
  setNavPanelContainer,
  setTitle,
  toFMObjectRoomChoose,
  toRoot
} from "../../../common/actions/router";
import { saveQuery } from "../../actions/add_request";

import ObjectMaterialListItem from "../../../common/components/MaterialListItem/objectListItem";

import ShowOnMap from "../../components/ShowOnMap";
import { ButtonShowMore } from "../../../common/components/MaterialList";
import { MaterialCardList } from "../../../common/components/MaterialCardList";
import CircleLoader from "../../../common/components/CircleLoader";
import { MapWithMarkers, ObjectMarker } from "../../../common/components/Map";
import { ErrorToast } from "../../../common/Toasts/error";

import strings from "../../localization/all";
import common_strings from "../../../common/localization/all";

import "./style.css";

import {
  fetchMoreObjectsImage,
  fetchObjectsImage
} from "../../../common/actions/image";
import { clearObjectPlan } from "../../../common/actions/plans";
import ContainerPageNavPanel from "../../../common/components/PageContainers/containerPageNavPanel";

class ObjectSearchContainer extends Component {
  constructor(props) {
    super(props);

    var initKeywords = "";
    var initDate = new Date();
    if (this.props.add_request && this.props.add_request.object_query) {
      if (this.props.add_request.object_query.query_string) {
        initKeywords = this.props.add_request.object_query.query_string;
      }
      if (this.props.add_request.object_query.query_date) {
        initDate = this.props.add_request.object_query.query_date;
      }
    }

    this.state = {
      keywords: initKeywords,
      query_date: initDate,
      limit: 20,
      offset: 0,
      order: "+name",
      mapVisible: false,
      invalidSearch: false
    };
  }

  componentDidMount() {
    const { dispatch } = this.props;
    dispatch(setTitle(strings.title_all_objects));
    dispatch(setCustomHistoryPath(`/`));
    dispatch(
      setNavPanelContainer({
        container: "container",
        location: this.props.location.pathname
      })
    );

    if (!this.state.keywords) {
      dispatch(toRoot());
    }

    window.scrollTo(0, 0);
    this.showQuery();
  }

  collectObjectIds(objects) {
    let objectIds = [];
    for (let i = 0; i < objects.length; i++) {
      objectIds.push(objects[i].object_id);
    }
    return objectIds;
  }

  showQuery() {
    const { dispatch } = this.props;

    var query_data = {
      query_string: this.state.keywords,
      query_date: this.state.query_date
    };
    dispatch(saveQuery(query_data));

    (async () => {
      try {
        var data = {
          filter: {
            keywords: this.state.keywords,
            blocked: false,
            suspended: false,
            scheduled_delete: false,
            visible_for_facility: true
          },
          limit: this.state.limit + 1,
          offset: 0,
          order: this.state.order
        };

        const countData = {
          filter: {
            keywords: this.state.keywords,
            blocked: false,
            suspended: false,
            scheduled_delete: false,
            visible_for_facility: true
          }
        };

        dispatch(fetchObjectsCount(countData));

        const _this = this;
        dispatch(fetchObjects(data)).then(function(res) {
          if (res.payload.result) {
            const imgData = {
              entity_type: "objects",
              entity_ids: _this.collectObjectIds(res.payload.result)
            };
            dispatch(fetchObjectsImage(imgData));
          }
        });
      } catch (e) {
        ErrorToast();
        console.log(e);
      } finally {
      }
    })();
  }

  toFMObjectRoomChoose(object_id) {
    const { dispatch } = this.props;
    dispatch(toFMObjectRoomChoose(object_id));
  }

  more() {
    const { dispatch } = this.props;

    const data = {
      filter: {
        keywords: this.state.keywords,
        blocked: false,
        suspended: false,
        scheduled_delete: false,
        visible_for_facility: true
      },
      limit: this.state.limit,
      offset: this.state.offset + this.state.limit + 1,
      order: this.state.order
    };

    (async () => {
      try {
        const _this = this;
        dispatch(fetchMoreObjects(data)).then(function(res) {
          if (res.payload.result) {
            const offset = _this.state.offset + _this.state.limit;
            _this.setState({
              offset: offset
            });

            const imgData = {
              entity_type: "objects",
              entity_ids: _this.collectObjectIds(res.payload.result)
            };
            dispatch(fetchMoreObjectsImage(imgData));
          }

          if (res.payload.error) {
            ErrorToast(res.payload.error);
          }
        });
      } catch (e) {
        ErrorToast();
        console.log(e);
      } finally {
      }
    })();
  }

  getImagePath(object_id) {
    let imgSrc = "";
    if (
      this.props.image.objectsImage.result &&
      this.props.image.objectsImage.result[object_id]
    ) {
      imgSrc = this.props.image.objectsImage.result[object_id];
    }
    return imgSrc;
  }

  getDeclineOfNum(number, titles) {
    const cases = [2, 0, 1, 1, 1, 2];
    return titles[
      number % 100 > 4 && number % 100 < 20
        ? 2
        : cases[number % 10 < 5 ? number % 10 : 5]
    ];
  }

  renderCountTitle() {
    const { objectsCount } = this.props.objects;

    const count = objectsCount.result ? objectsCount.result : 0;
    switch (strings.getLanguage()) {
      case "en":
        return `${count} ${this.getDeclineOfNum(count, [
          "object found",
          "objects found",
          "objects found"
        ])} found`;

      case "ru":
        return `${this.getDeclineOfNum(count, [
          "найден",
          "найдено",
          "найдено"
        ])} ${count} ${this.getDeclineOfNum(count, [
          "объект",
          "объекта",
          "объектов"
        ])}`;

      default:
        return "";
    }
  }

  toggleMapVisibility() {
    this.setState({
      mapVisible: !this.state.mapVisible
    });
  }

  render() {
    var allObjects = [];
    var fetching = false;
    var hasMore = false;

    if (this.props.objects) {
      fetching = this.props.objects.objectsIsFetching;
    }

    if (
      this.props.objects &&
      this.props.objects.allObjects &&
      this.props.objects.allObjects.result
    ) {
      allObjects = this.props.objects.allObjects.result;
      if (allObjects.length > this.state.offset + this.state.limit) {
        allObjects = allObjects.slice(0, this.state.offset + this.state.limit);
        hasMore = true;
      }
    }

    const { objectsCount, objectsCountIsFetching } = this.props.objects;

    return (
      <ContainerPageNavPanel>
        {!fetching && (
          <div className="object-search-form-title">
            <div className="osf-title">
              {this.state.keywords}
              {!objectsCountIsFetching || !fetching
                ? ": " + this.renderCountTitle()
                : ""}
            </div>
            {objectsCount.result > 0 && (
              <div className="osf-show-on-map shadow">
                <ShowOnMap onClick={this.toggleMapVisibility.bind(this)} />
              </div>
            )}
          </div>
        )}

        <div
          key={`map-full-screen`}
          className={`full-screen-map-container ${
            !this.state.mapVisible ? "d-none" : ""
          }`}
        >
          <div
            className={`button-full-screen-exit shadow`}
            onClick={this.toggleMapVisibility.bind(this)}
          >
            <div className={`float-left`}>{common_strings.button_close}</div>
            <i className="material-icons float-left">close</i>
          </div>
          <MapWithMarkers entityClassName={`request-add-full-screen`}>
            {allObjects.map((object, index) => (
              <ObjectMarker
                key={"marker" + index}
                object={object}
                onClick={this.toFMObjectRoomChoose.bind(this, object.object_id)}
              />
            ))}
          </MapWithMarkers>
        </div>

        <MaterialCardList emptyText={fetching ? null : ""}>
          {allObjects.map((object, index) => (
            <ObjectMaterialListItem
              imageUrl={this.getImagePath(object.object_id)}
              key={index}
              object={object}
              onClick={this.toFMObjectRoomChoose.bind(this, object.object_id)}
            />
          ))}
        </MaterialCardList>

        {fetching ? (
          <CircleLoader />
        ) : hasMore ? (
          <ButtonShowMore onClick={this.more.bind(this)} />
        ) : null}
      </ContainerPageNavPanel>
    );
  }

  componentWillUnmount() {
    const { dispatch } = this.props;
    dispatch(clearObjects());
    dispatch(clearObjectPlan());
  }
}

const mapStateToProps = (state, ownProps) => {
  return {
    objects: state.objects,
    add_request: state.add_request,
    image: state.image
  };
};

export default connect(mapStateToProps)(ObjectSearchContainer);
