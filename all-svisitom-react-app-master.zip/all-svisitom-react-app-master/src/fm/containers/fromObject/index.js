import React, { Component } from "react";
import { connect } from "react-redux";

import { toCustomPath } from "../../../common/actions/router";
import { setFromObjectFlag } from "../../../common/actions/facility";

class FromObject extends Component {
  componentDidMount() {
    window.scrollTo(0, 0);
    const { dispatch, params } = this.props;

    dispatch(setFromObjectFlag());
    dispatch(toCustomPath(`/${params.object_id}/rooms`));
  }

  render() {
    return null;
  }
}

const mapStateToProps = state => {
  return {
    facility: state.rooms,
    objects: state.objects
  };
};

export default connect(mapStateToProps)(FromObject);
