import React, { Fragment } from "react";
import { connect } from "react-redux";

import {
  clearObjects,
  fetchObjectsByIds
} from "../../../common/actions/objects";
import { saveQuery } from "../../actions/add_request";
import { pushHistory, toCustomPath } from "../../../common/actions/router";
import { CDN_URL } from "../../../common/constants";

import SearchWithQR from "../../components/SearchWithQR";
import CityCard from "../../components/CityCard";
import CityCards from "../../components/CityCards";

import strings from "../../localization/all";

import "./style.css";
import { ErrorToast } from "../../../common/Toasts";
import { fetchObjectsImage } from "../../../common/actions/image";
import { MaterialCardList } from "../../../common/components/MaterialCardList";
import ObjectMaterialListItem from "../../../common/components/MaterialListItem/objectListItem";
import { fetchActivities } from "../../../common/actions/activity";
import CircleLoader from "../../../common/components/CircleLoader";

class StartPageContainer extends React.Component {
  constructor(props) {
    super(props);

    this.state = {
      keywords: "",
      invalid_try: false,
      objects: [],
      objectsReceived: false
    };

    this.relevantObjectsCount = 4;
  }

  componentDidMount() {
    this.collectUserObjects();
  }

  async collectUserObjects() {
    if (!this.props.user.user.result) {
      this.setState({
        objectsReceived: true
      });
      return;
    }

    const { dispatch } = this.props;
    const { user_id } = this.props.user.user.result;

    try {
      let dataActivity = {
        filter: {
          user_id: user_id,
          entity_type: "object",
          activity_type: "facility_request"
        },
        limit: this.relevantObjectsCount,
        offset: 0,
        order: "-create_date"
      };
      await dispatch(fetchActivities(dataActivity));
      let { activities } = this.props.activity;
      if (activities.error) {
        ErrorToast(activities.error);
        return;
      }

      let objects_ids = [];
      for (let i = 0; i < activities.result.length; i++) {
        objects_ids.push(activities.result[i].entity_id);
      }

      // Get objects img
      const imgData = {
        entity_type: "objects",
        entity_ids: objects_ids
      };
      dispatch(fetchObjectsImage(imgData));
      // Get objects
      await dispatch(fetchObjectsByIds({ objects_ids: objects_ids }));
      if (this.props.objects.objectsByIds.error) {
        ErrorToast(this.props.objects.objectsByIds.error);
        return;
      }

      // Sort objects by name
      let objects = this.props.objects.objectsByIds.result;
      objects = objects.filter(obj => !obj.scheduled_delete);

      // Update state with objects
      this.setState({
        objects: objects,
        objectsReceived: true
      });
    } catch (e) {
      console.log(e);
      ErrorToast();
    }
  }

  handleChangeQueryString(query) {
    this.setState({ keywords: query });
  }

  handleSearch(query_string) {
    if (!query_string) {
      this.setState({
        invalid_try: true
      });
      return;
    }

    let { dispatch } = this.props;
    dispatch(clearObjects());

    let query_data = {
      query_string: query_string
    };
    dispatch(saveQuery(query_data));
    dispatch(toCustomPath("search"));
  }

  handleCityClick(cityName) {
    var { dispatch } = this.props;
    dispatch(clearObjects());

    var query_data = {
      query_string: cityName
    };
    dispatch(saveQuery(query_data));
    dispatch(toCustomPath("/search"));
  }

  qrClick() {
    const { dispatch } = this.props;
    dispatch(pushHistory(this.props.location.pathname));
    dispatch(toCustomPath(`/qr`));
  }

  getImagePath(object_id) {
    let imgSrc = "";
    if (
      this.props.image.objectsImage.result &&
      this.props.image.objectsImage.result[object_id]
    ) {
      imgSrc = this.props.image.objectsImage.result[object_id];
    }
    return imgSrc;
  }

  toObject(object_id) {
    const { dispatch } = this.props;
    dispatch(toCustomPath(`/${object_id}/rooms`));
  }

  render() {
    return (
      <div className="start-object-search container">
        <div
          className="start-object-search-form-background"
          style={{
            backgroundImage: `url(${CDN_URL}/img/request/search-background.jpg?date=2018-07-06)`
          }}
        />
        <div className="start-object-search-form-container">
          <div className="start-object-search-form">
            <div className="start-object-search-form-title">
              {strings.header_find_object}
            </div>
            <SearchWithQR
              id={`keywords`}
              query_string={this.state.keywords}
              placeholder={strings.search_placeholder}
              onChangeQueryString={this.handleChangeQueryString.bind(this)}
              onSearch={this.handleSearch.bind(this)}
              invalid={this.state.invalid_try}
              qrClick={this.qrClick.bind(this)}
            />
          </div>
        </div>

        {this.state.objectsReceived ? (
          this.state.objects.length > 0 ? (
            <React.Fragment>
              <div
                className="start-object-popular-cities"
                style={{ marginTop: "20px" }}
              >
                {strings.recent_objects}
              </div>
              <MaterialCardList>
                {this.state.objects.map(obj => (
                  <ObjectMaterialListItem
                    imageUrl={this.getImagePath(obj.object_id)}
                    key={obj.object_id}
                    object={obj}
                    onClick={this.toObject.bind(this, obj.object_id)}
                  />
                ))}
              </MaterialCardList>
            </React.Fragment>
          ) : (
            <Fragment>
              <div className="start-object-popular-cities">
                {strings.popular_cities}
              </div>

              <CityCards>
                <CityCard
                  city="Москва"
                  imageUrl={`${CDN_URL}/img/cities/russia/moscow.jpg`}
                  onClick={this.handleCityClick.bind(this, "Москва")}
                />
                <CityCard
                  city="Санкт-Петербург"
                  imageUrl={`${CDN_URL}/img/cities/russia/saint-petersburg.jpg`}
                  onClick={this.handleCityClick.bind(this, "Санкт-Петербург")}
                />
                <CityCard
                  city="Калуга"
                  imageUrl={`${CDN_URL}/img/cities/russia/kaluga.jpg`}
                  onClick={this.handleCityClick.bind(this, "Калуга")}
                />
              </CityCards>
            </Fragment>
          )
        ) : (
          <CircleLoader />
        )}
      </div>
    );
  }
}

const mapStateToProps = (state, ownProps) => {
  return {
    objects: state.objects,
    add_request: state.add_request,
    image: state.image,
    user: state.user,
    activity: state.activity
  };
};

export default connect(mapStateToProps)(StartPageContainer);
