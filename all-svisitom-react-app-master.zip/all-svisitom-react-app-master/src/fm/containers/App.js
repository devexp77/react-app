import React, { Component } from "react";
import { connect } from "react-redux";
import { fetchUserGlobal } from "../../common/actions/user";
import { HOST_NAME } from "../../common/constants";
import { PROTOCOL } from "../../common/constants";

import Header from "../../common/containers/headerContainer/header";
import Footer from "../../common/components/Footer/footer";
import Preloader from "../../common/components/Preloader/preloader";
import FormSubmitCircleLoader from "../../common/components/FormSubmitCircleLoader";
import DemoModeWidget from '../../common/components/demo'

import strings from "../localization/all";
import common_strings from "../../common/localization/all";

import { init_support } from "../../common/util/support";
import SupportWidget from "../../common/components/support";
import UseCookies from "../../common/components/UseCookies";
import connectSocket from "../../common/util/socket";
import NavPanel from "../../common/components/NavPanel/navPanel";

class AppContainer extends Component {
  constructor() {
    super();
    this.socket = null;
    this.state = {
      socket: null
    };
  }
  componentDidMount() {
    document.title =
      strings.header_facility_management + " - " + common_strings.product_name;

    const { dispatch } = this.props;

    (async () => {
      await dispatch(fetchUserGlobal());

      const { user } = this.props.user;
      if (user.result) {
        init_support(user.result);
        this.setState({ socket: connectSocket(user) });
      }
    })();
  }

  getNavPanelContainer() {
    const { navPanelContainer } = this.props.router;
    let containerClass = "container custom";

    if (
      navPanelContainer &&
      navPanelContainer.location &&
      navPanelContainer.location === this.props.location.pathname
    ) {
      containerClass = navPanelContainer.container;
    }

    return containerClass;
  }

  getNavPanelWidth() {
    const { navPanelContainer } = this.props.router;
    if (
      navPanelContainer &&
      navPanelContainer.location &&
      navPanelContainer.location === this.props.location.pathname &&
      navPanelContainer.width
    ) {
      return navPanelContainer.width;
    } else return null;
  }

  render() {
    moment.locale(strings.getLanguage());

    const { routerPrevPath } = this.props.router;
    let inverseColor = false;
    if (routerPrevPath && routerPrevPath === "/") {
      inverseColor = true;
    }

    const { userGlobalIsFetching } = this.props.user;
    if (userGlobalIsFetching) {
      return <Preloader />;
    }

    const startPage = this.props.location.pathname === "/";
    const successPage = this.props.location.pathname === "/success";

    let prevButton = !!this.props.router.customHistoryPath;
    return [
      <Header
        key={`header`}
        logout={`${PROTOCOL}//${HOST_NAME}/logout`}
        login={`${PROTOCOL}//${HOST_NAME}/authorize/svisitom?next=${encodeURIComponent(
          window.location.href
        )}`}
        mainPage={`/#/`}
        containerClass={"container"}
        productName={strings.header_facility_management}
        inverseColor={inverseColor}
        socket={this.state.socket}
      />,
      !startPage && !successPage && (
        <NavPanel
          navigationTitle={this.props.router.title}
          prevButton={prevButton}
          containerClass={this.getNavPanelContainer()}
          width={this.getNavPanelWidth()}
          key={`nav`}
        />
      ),
      <FormSubmitCircleLoader key={`loader`} />,
      React.cloneElement(this.props.children, { key: "children" }),
      startPage && <Footer key={`footer`} />,
      <SupportWidget key={`support`} />,
      <UseCookies key={`cookies`} />,
      <DemoModeWidget key={"demo-mode-widget"}/>,
      <div key="video-tips" id="video-tips" />
    ];
  }
  componentWillUnmount() {
    this.state.socket.close();
    this.state.socket = null;
  }
}

const mapStateToProps = state => {
  return {
    user: state.user,
    router: state.router
  };
};

export default connect(mapStateToProps)(AppContainer);
