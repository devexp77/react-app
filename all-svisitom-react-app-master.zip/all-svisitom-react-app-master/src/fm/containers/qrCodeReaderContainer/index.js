import React, { Component } from "react";
import { connect } from "react-redux";
import {
  pushHistory,
  setCustomHistoryPath,
  setTitle,
} from "../../../common/actions/router";

import strings from "../../localization/all";
import "./style.css";

import SinglePageWithCustomPaddingNavPanel from "../../../common/components/PageContainers/singlePageCustomPaddingNavPanel";

import QrReader from "react-qr-reader";

import { isMobile} from "react-device-detect";
import {
  FULL_HOST_NAME, HOST_NAME,
  IDLE_WAIT,
  PROTOCOL
} from "../../../common/constants";
import { ErrorToast } from "../../../common/Toasts";

class QrCodeReaderContainer extends Component {
  constructor(props) {
    super(props);
    let idleTimer = null;
    this.state = {
      delay: 100,
      result: "No result",
      idleWait: IDLE_WAIT,
      allowRender: false,
      date: new Date()
    };
    this.handleScan = this.handleScan.bind(this);
    this.handleError = this.handleError.bind(this);
  }

  componentDidMount() {
    this.initFunction();
    setTimeout(() => {
      this.setState({ allowRender: true });
    }, 200);
  }

  initFunction() {
    const { dispatch } = this.props;
    dispatch(setTitle(strings.title_find_room));
    dispatch(setCustomHistoryPath("/"));
  }

  handleScan(data) {
    const { dispatch } = this.props;
    if (data) {
      if (data.startsWith(`${PROTOCOL}//${FULL_HOST_NAME}`)) {
        dispatch(pushHistory(this.props.location.pathname));
        window.location.href = data;
      }
      else {
        ErrorToast("Неправильный QR код", 'incorrect_qr');
      }
    }

  }

  handleError(err) {
    console.error(err);
  }

  render() {
    if (this.state.allowRender) {
      return (
        <SinglePageWithCustomPaddingNavPanel className={`fm-qr-reader ${isMobile && "mobile"}`}>
          <div className={`title-enter-qr`}>
            <p>{strings.title_enter_qr}</p>
          </div>

          <div className={`qr-code-container`}>
            {isMobile && <img className="qr-code-logo" src={`${PROTOCOL}//cdn.${HOST_NAME}/img/qr-code.svg`}/>}
            <QrReader
              delay={this.state.delay}
              facingMode={"environment"}
              onError={this.handleError}
              onScan={this.handleScan}
              style={{ width: "100%" }}
            />
          </div>
        </SinglePageWithCustomPaddingNavPanel>
      );
    } else return null;
  }
}

const mapStateToProps = state => {
  return {
    router: state.router,
    objects: state.objects
  };
};

export default connect(mapStateToProps)(QrCodeReaderContainer);
