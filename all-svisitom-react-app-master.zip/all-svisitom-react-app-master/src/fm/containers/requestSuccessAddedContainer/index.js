import React, { Component } from "react";
import { connect } from "react-redux";
import format from 'string-format';

import "./style.css";

import { Link } from "react-router";
import strings from "../../localization/all";

import SinglePageCustomPadding from "../../../common/components/PageContainers/singlePageCustomPadding";
import ContainerPage from "../../../common/components/PageContainers/contentContainer";
import { clearHistory, toCustomPath } from "../../../common/actions/router";
import {ErrorToast} from "../../../common/Toasts";
import Icon from '../../../common/components/Icon';
import {HOST_NAME, PROTOCOL} from "../../../common/constants";

class RequestSuccessAddedContainer extends Component {
  constructor(props) {
    super(props);
  }

  componentDidMount() {
    const { dispatch } = this.props;
    window.scrollTo(0, 0);
    dispatch(clearHistory());
    const { requestData } = this.props.facility_requests;
    if (!requestData.problem) {
      dispatch(toCustomPath("/"));
    }
  }

  async initData() {
    const { dispatch } = this.props;
    await dispatch(fetchFmRequestRecordById({
      facility_request_id: this.props.facility_requests.requestData.facility_request_id
    }));

    let {requestRecordById} = this.props.facility_requests;
    if (requestRecordById.error) {
      ErrorToast(this.props.facility_requests.requestRecordById.error);
      dispatch(toCustomPath("/"));
      return;
    }

    this.setState({
      dataReceived: true
    })

  }

  componentWillUnmount() {
    const { dispatch } = this.props;
  }

  static getProblemPageTitle(structure) {
    let title = "";
    if (structure.length > 0) {
      for (let i in structure) {
        if (i == 0) {
          title = structure[i].name;
        } else {
          title += " · " + structure[i].name;
        }
      }
    }
    return title;
  }

  render() {
    const { requestData } = this.props.facility_requests;
    const { fromObject } = this.props.facility;
    const {objectById} = this.props.objects;

    if (requestData.problem) {
      return (
        <SinglePageCustomPadding>
          <ContainerPage>
            <div className="request-add clearfix">
              <div className="congratulations-icon">
                <Icon name="sv-icon-congratulations" />
              </div>
              <h4 style={{ fontSize: "2rem" }}>
                {format(strings.fm_request_finish_header, requestData.number)}
              </h4>
              <h5
                style={{
                  fontSize: "1.5rem",
                  marginTop: "50px",
                  marginBottom: "0"
                }}
              >{`${requestData.object.name}, ${requestData.room.name}`}</h5>
              <h5
                style={{
                  fontSize: "1.2rem",
                  marginBottom: "50px",
                  color: "grey"
                }}
              >
                {RequestSuccessAddedContainer.getProblemPageTitle(requestData.problem)}
              </h5>
              <h5
                style={{
                  fontSize: "1.2rem",
                  color: "grey"
                }}
              >
                {strings.fm_request_finish_hint}
              </h5>
              <Link to={`/${requestData.object.object_id}/rooms/${requestData.room.room_id}`} className="btn btn-flat btn-block">
                {strings.button_send_another_request}
              </Link>

              {fromObject &&
              <a href={`${PROTOCOL}//${objectById.result.domain_name}.${HOST_NAME}/#/facilityRequests`}
                 className="btn btn-flat btn-block">
                {strings.button_goto_object}
              </a>
              }
            </div>
          </ContainerPage>
        </SinglePageCustomPadding>
      );
    } else return null;
  }
}

const mapStateToProps = state => {
  return {
    facility_requests: state.facility_requests,
    facility: state.facility,
    objects: state.objects,
  };
};

export default connect(mapStateToProps)(RequestSuccessAddedContainer);
