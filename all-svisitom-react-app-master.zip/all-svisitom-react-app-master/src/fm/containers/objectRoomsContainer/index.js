import React, { Component } from "react";
import { connect } from "react-redux";

import {
  toRoomAdd,
  toRoom,
  toRoot,
  setTitle,
  setCustomHistoryPath,
  pushHistory,
  toCustomPath
} from "../../../common/actions/router";
import {
  fetchRooms,
  fetchMoreRooms,
  clearRooms
} from "../../../common/actions/rooms";
import {
  fetchAddresseesByIds,
  clearAddresseesByIds
} from "../../../common/actions/addressee";
import { fetchObjectById } from "../../../common/actions/objects";

import SearchInput from "../../../common/components/SearchInput";
import {
  MaterialList,
  CircleLoaderOrButtonShowMore,
  AddRow
} from "../../../common/components/MaterialList";
import MaterialListItem from "../../../common/components/MaterialListItem/twoLineItem";
import CircleLoader from "../../../common/components/CircleLoader";

import strings from "../../localization/all";
import common_strings from "../../../common/localization/all";

import { ErrorToast } from "../../../common/Toasts/error";
import SinglePageWithCustomPaddingNavPanel from "../../../common/components/PageContainers/singlePageCustomPaddingNavPanel";
import "./style.css";
import {
  fetchFmRequestsCount,
  fetchFmRequestsCountByRoomsIds
} from "../../../common/actions/facility_requests";
import format from "string-format";

class RoomsContainer extends Component {
  constructor() {
    super();
    this.state = {
      keywords: "",
      limit: 20,
      offset: 0,
      order: "-create_date",
      anyDataReceived: false,
      hasAnyData: false
    };
  }

  componentDidMount() {
    const { objectById } = this.props.objects;
    window.scrollTo(0, 0);
    const { dispatch } = this.props;

    dispatch(setCustomHistoryPath(`/search`));

    const object_id = this.props.params.object_id;

    (async () => {
      try {
        if (
          objectById &&
          objectById.result &&
          objectById.result.object_id === object_id
        ) {
          this.showResult();
        } else {
          const data = {
            object_id: object_id
          };
          await dispatch(fetchObjectById(data));
          if (this.props.objects.objectById.result) {
            this.showResult();
          }

          if (this.props.objects.objectById.error) {
            ErrorToast(this.props.objects.objectById.error);
            dispatch(toRoot());
          }
        }
      } catch (e) {
        ErrorToast();
        console.log(e);
      } finally {
      }
    })();
  }

  handleInputChange(event) {
    const id = event.target.id;
    const value = event.target.value;
    this.setState({ [id]: value });
  }

  Search(value) {
    const { dispatch } = this.props;
    dispatch(clearRooms());
    this.setState(
      {
        keywords: value,
        offset: 0
      },
      function() {
        this.showResult();
      }
    );
  }

  showResult() {
    const { objectById } = this.props.objects;
    const { dispatch } = this.props;

    dispatch(
      setTitle(
        objectById && objectById.result && objectById.result.name
          ? objectById.result.name
          : strings.title_all_rooms
      )
    );

    (async () => {
      try {
        if (this.props.objects.objectById.result) {
          const data = {
            filter: {
              keywords: this.state.keywords,
              object_id: this.props.objects.objectById.result.object_id,
              has_facility_config: true
            },
            limit: this.state.limit + 1,
            offset: this.state.offset,
            order: this.state.order
          };
          await dispatch(fetchRooms(data));

          const { rooms } = this.props.rooms;

          if (rooms.result) {
            if (this.state.keywords === "" && rooms.result.length > 0) {
              this.setState({
                hasAnyData: true
              });
            }

            const list = this.collectRoomIds(this.state.offset);
            if (list.length > 0) {
              dispatch(
                fetchFmRequestsCountByRoomsIds({
                  room_ids: list,
                  statuses: ["accepted", "in_work", "done"]
                })
              );
            }
          } else {
            ErrorToast(rooms.error);
          }

          this.setState({
            anyDataReceived: true
          });
        }
      } catch (e) {
        ErrorToast();
        console.log(e);
      } finally {
      }
    })();
  }

  collectRoomIds(startIndex) {
    if (!startIndex) {
      startIndex = 0;
    }

    const { rooms } = this.props.rooms;

    let list = [];
    if (rooms.result) {
      for (let index = startIndex; index < rooms.result.length; index++) {
        list.push(rooms.result[index].room_id);
      }
    }

    return list;
  }

  showMore() {
    const { dispatch } = this.props;

    (async () => {
      try {
        if (this.props.objects.objectById.result) {
          const data = {
            filter: {
              keywords: this.state.keywords,
              object_id: this.props.objects.objectById.result.object_id,
              has_facility_config: true
            },
            limit: this.state.limit,
            offset: this.state.offset + this.state.limit + 1,
            order: this.state.order
          };
          await dispatch(fetchMoreRooms(data));

          const { rooms } = this.props.rooms;

          if (rooms.result) {
            let list = this.collectRoomIds(
              this.state.offset + this.state.limit
            );
            if (list.length > 0) {
              dispatch(
                fetchFmRequestsCountByRoomsIds({
                  room_ids: list,
                  statuses: ["accepted", "in_work", "done"]
                })
              );
            }

            const offset = this.state.offset + this.state.limit;
            this.setState({
              offset: offset
            });
          } else {
            ErrorToast(rooms.error);
          }
        }
      } catch (e) {
        ErrorToast();
        console.log(e);
      } finally {
      }
    })();
  }

  emptyText() {
    const { rooms } = this.props.rooms;
    if (rooms.error) {
      return string.empty_text_data_load_failure;
    } else if (this.state.hasAnyData) {
      return strings.nothing_found;
    } else {
      return strings.no_rooms;
    }
  }

  toRoom(room_id) {
    const { dispatch } = this.props;
    dispatch(pushHistory(this.props.location.pathname));
    dispatch(toRoom(this.props.params.object_id, room_id));
  }

  toRoomRequests = room_id => {
    const { dispatch } = this.props;
    dispatch(pushHistory(this.props.location.pathname));
    dispatch(
      toCustomPath(this.props.location.pathname + "/" + room_id + "/requests")
    );
  };

  render() {
    let rooms = [];
    let fetching = !this.state.anyDataReceived;
    let hasMore = false;

    if (this.props.rooms) {
      fetching |= this.props.rooms.roomsIsFetching;
    }

    if (
      this.props.rooms &&
      this.props.rooms.rooms &&
      this.props.rooms.rooms.result
    ) {
      rooms = this.props.rooms.rooms.result;
      if (rooms.length > this.state.offset + this.state.limit) {
        rooms = rooms.slice(0, this.state.offset + this.state.limit);
        hasMore = true;
      }
    }

    const { requestsCountByRoomIds } = this.props.facility_requests;
    const { objectById, objectByIdIsFetching } = this.props.objects;

    if (objectByIdIsFetching) {
      return (
        <SinglePageWithCustomPaddingNavPanel>
          <CircleLoader />
        </SinglePageWithCustomPaddingNavPanel>
      );
    }
    if (objectById.result) {
      return (
        <SinglePageWithCustomPaddingNavPanel>
          <p className={`select-action-title`}>{strings.title_select_room}</p>
          {this.state.hasAnyData && (
            <SearchInput
              id={`keywords`}
              query={this.state.keywords}
              placeholder={common_strings.search_placeholder}
              onChange={this.handleInputChange.bind(this)}
              onSearch={this.Search.bind(this)}
            />
          )}

          <MaterialList emptyText={fetching ? null : this.emptyText()}>
            {rooms.map((room, index) => (
              <MaterialListItem
                key={index}
                item_id={room.room_id}
                firstLineContent={room.name}
                secondLineContent={
                  <React.Fragment>
                    {room.tags && room.tags.length > 0 ? (
                      <React.Fragment>
                        {room.tags.map((tag, index) => (
                          <span key={index}>
                            {index !== 0 && ", "}
                            {tag.tag_text}
                          </span>
                        ))}
                        <br />
                      </React.Fragment>
                    ) : null}
                    <span>
                      {format(
                        strings.subtitle_request_count_in_room,
                        requestsCountByRoomIds.result &&
                          requestsCountByRoomIds.result[room.room_id]
                          ? requestsCountByRoomIds.result &&
                              requestsCountByRoomIds.result[room.room_id]
                          : 0
                      )}
                    </span>
                  </React.Fragment>
                }
                icon={`business`}
                gotoItem={this.toRoom.bind(this)}
              />
            ))}
          </MaterialList>

          <CircleLoaderOrButtonShowMore
            fetching={fetching}
            hasMore={hasMore}
            onShowMoreClick={this.showMore.bind(this)}
          />
        </SinglePageWithCustomPaddingNavPanel>
      );
    } else return null;
  }

  componentWillUnmount() {
    const { dispatch } = this.props;
    dispatch(clearAddresseesByIds());
    dispatch(clearRooms());
  }
}

const mapStateToProps = state => {
  return {
    rooms: state.rooms,
    objects: state.objects,
    addressee: state.addressee,
    facility_requests: state.facility_requests
  };
};

export default connect(mapStateToProps)(RoomsContainer);
