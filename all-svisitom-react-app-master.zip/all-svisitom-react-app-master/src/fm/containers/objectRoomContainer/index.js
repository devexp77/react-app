import React, { Component } from "react";
import { connect } from "react-redux";

import {
  toRoot,
  setTitle,
  setCustomHistoryPath,
  toCustomPath,
  pushHistory,
  setNavPanelContainer
} from "../../../common/actions/router";
import { fetchRoomById, clearRoomById } from "../../../common/actions/rooms";
import { fetchObjectById } from "../../../common/actions/objects";

import CircleLoader from "../../../common/components/CircleLoader";

import strings from "../../localization/all";

import { ErrorToast } from "../../../common/Toasts/error";
import SinglePageWithCustomPaddingNavPanel from "../../../common/components/PageContainers/singlePageCustomPaddingNavPanel";
import {
  fetchFacilityProblems,
  fetchRoomFacilityConfigByRoomId
} from "../../../common/actions/facility";
import ProfileInfo from "../../../common/components/ProfileInfo";

import FavoriteFacilityProblems from "../../../common/components/favoriteFacilityProblems";
import { fetchFmRequestsCountByRoomsIds } from "../../../common/actions/facility_requests";
import format from "string-format";

class RoomContainer extends Component {
  constructor() {
    super();
    this.state = {};
  }

  componentDidMount() {
    window.scrollTo(0, 0);
    const { dispatch } = this.props;

    const object_id = this.props.params.object_id;
    dispatch(setCustomHistoryPath(`${object_id}/rooms`));
    dispatch(
      setNavPanelContainer({
        container: "container custom",
        location: this.props.location.pathname,
        width: "600px"
      })
    );

    (async () => {
      try {
        await this.getObject();
        await this.getRoom();
        await this.getConfig();
        await this.getFavouriteProblems();
        dispatch(
          fetchFmRequestsCountByRoomsIds({
            room_ids: [this.props.params.room_id],
            statuses: ["accepted", "in_work", "done"]
          })
        );
      } catch (e) {
        ErrorToast();
        console.log(e);
      } finally {
      }
    })();
  }

  async getObject() {
    const { dispatch } = this.props;
    const { object_id } = this.props.params;
    const { objectById } = this.props.objects;
    try {
      if (
        objectById &&
        objectById.result &&
        objectById.result.object_id === object_id
      ) {
        return true;
      } else {
        await dispatch(fetchObjectById({ object_id: object_id }));
        if (this.props.objects.objectById.result) {
          return true;
        }

        if (this.props.objects.objectById.error) {
          ErrorToast(this.props.objects.objectById.error);
          dispatch(toRoot());
          return false;
        }
      }
    } catch (e) {
      ErrorToast();
      console.log(e);
    }
  }

  async getRoom() {
    const { dispatch } = this.props;
    const { room_id, object_id } = this.props.params;
    const { roomById } = this.props.rooms;
    const { objectById } = this.props.objects;
    try {
      if (objectById.result) {
        if (roomById.result && roomById.result.room_id === room_id) {
          dispatch(
            setTitle(
              `${objectById.result.name}, ${
                this.props.rooms.roomById.result.name
              }`
            )
          );
          return true;
        } else {
          await dispatch(fetchRoomById({ room_id: room_id }));
          if (this.props.rooms.roomById.result) {
            dispatch(
              setTitle(
                `${objectById.result.name}, ${
                  this.props.rooms.roomById.result.name
                }`
              )
            );
            return true;
          }

          if (this.props.rooms.roomById.error) {
            ErrorToast(this.props.rooms.roomById.error);
            this.toHistoryPath();
            return false;
          }
        }
      }
    } catch (e) {
      ErrorToast();
      console.log(e);
    }
  }

  async getConfig() {
    const { dispatch } = this.props;
    const { room_id } = this.props.params;
    const { roomFacilityConfigByRoomId } = this.props.facility;
    try {
      if (
        roomFacilityConfigByRoomId &&
        roomFacilityConfigByRoomId.result &&
        roomFacilityConfigByRoomId.result.room_id === room_id
      ) {
        return true;
      } else {
        await dispatch(fetchRoomFacilityConfigByRoomId({ room_id: room_id }));
        if (this.props.facility.roomFacilityConfigByRoomId.result) {
          return true;
        }

        if (this.props.facility.roomFacilityConfigByRoomId.error) {
          ErrorToast(this.props.facility.roomFacilityConfigByRoomId.error);
          this.toHistoryPath();
          return false;
        }
      }
    } catch (e) {
      ErrorToast();
      console.log(e);
    }
  }

  async getFavouriteProblems() {
    const { dispatch, params } = this.props;
    const { roomFacilityConfigByRoomId } = this.props.facility;
    try {
      if (
        roomFacilityConfigByRoomId.result &&
        roomFacilityConfigByRoomId.result.favourite_problems &&
        roomFacilityConfigByRoomId.result.favourite_problems.length > 0
      ) {
        await dispatch(
          fetchFacilityProblems({
            filter: {
              problem_ids: roomFacilityConfigByRoomId.result.favourite_problems,
              check_resident_room_id: params.room_id
            }
          })
        );

        const { facilityProblems } = this.props.facility;
        if (facilityProblems.result) {
          if (facilityProblems.result.length > 0){
            return true
          } else {
            dispatch(toCustomPath(`${this.props.location.pathname}/more`));
          }
        }
        if (facilityProblems.error) {
          ErrorToast(facilityProblems.error);
          return false;
        }
      } else if (
        roomFacilityConfigByRoomId.result &&
        roomFacilityConfigByRoomId.result.favourite_problems.length === 0
      ) {
        dispatch(toCustomPath(`${this.props.location.pathname}/more`));
      }
    } catch (e) {
      ErrorToast();
      console.log(e);
    }
  }

  toHistoryPath() {
    const { dispatch } = this.props;
    const fromHistory = this.props.router.history.pop();
    const historyPath = fromHistory
      ? fromHistory
      : this.props.router.customHistoryPath;
    dispatch(toCustomPath(historyPath));
  }

  toProblem = problem_id => {
    const { dispatch } = this.props;
    dispatch(pushHistory(this.props.location.pathname));
    dispatch(toCustomPath(`${this.props.location.pathname}/${problem_id}`));
  };

  toRoomRequests = () => {
    const { dispatch } = this.props;
    dispatch(pushHistory(this.props.location.pathname));
    dispatch(toCustomPath(this.props.location.pathname + "/requests"));
  };

  render() {
    const { room_id } = this.props.params;
    const { requestsCountByRoomIds } = this.props.facility_requests;
    const { objectById, objectByIdIsFetching } = this.props.objects;
    const { roomById, roomByIdIsFetching } = this.props.rooms;
    const { user } = this.props.user;
    const {
      facilityProblems,
      facilityProblemsIsFetching,
      roomFacilityConfigByRoomId,
      roomFacilityConfigByRoomIdIsFetching
    } = this.props.facility;

    if (
      objectByIdIsFetching ||
      roomByIdIsFetching ||
      roomFacilityConfigByRoomIdIsFetching ||
      facilityProblemsIsFetching
    ) {
      return (
        <SinglePageWithCustomPaddingNavPanel>
          <CircleLoader />
        </SinglePageWithCustomPaddingNavPanel>
      );
    }
    if (
      objectById.result &&
      roomById.result &&
      roomFacilityConfigByRoomId.result
    ) {
      return (
        <SinglePageWithCustomPaddingNavPanel width={`600px`}>
          <ProfileInfo.Title
            title={strings.title_select_problem}
            style={{ textAlign: "center" }}
          />
          <FavoriteFacilityProblems
            problems={facilityProblems.result}
            onClick={this.toProblem}
          />

          <div style={{ textAlign: "center", marginTop: "10px" }}>
            <span
              style={
                requestsCountByRoomIds.result &&
                requestsCountByRoomIds.result[room_id] &&
                user.result
                  ? {
                      color: "#207ea9",
                      cursor: "pointer"
                    }
                  : {}
              }
              onClick={e => {
                if (
                  requestsCountByRoomIds.result &&
                  requestsCountByRoomIds.result[room_id] &&
                  user.result
                ) {
                  e.stopPropagation();
                  this.toRoomRequests();
                }
              }}
            >
              {format(
                strings.subtitle_request_count_in_room,
                requestsCountByRoomIds.result &&
                  requestsCountByRoomIds.result[room_id]
                  ? requestsCountByRoomIds.result &&
                      requestsCountByRoomIds.result[room_id]
                  : 0
              )}
            </span>
          </div>
        </SinglePageWithCustomPaddingNavPanel>
      );
    } else return null;
  }

  componentWillUnmount() {
    const { dispatch } = this.props;
    // dispatch(clearRoomById());
  }
}

const mapStateToProps = state => {
  return {
    rooms: state.rooms,
    objects: state.objects,
    facility: state.facility,
    facility_requests: state.facility_requests,
    user: state.user,
    router: state.router
  };
};

export default connect(mapStateToProps)(RoomContainer);
