import React, { Component } from "react";
import { connect } from "react-redux";

import {
  toCustomPath
} from "../../../common/actions/router";
import { fetchRoomById } from "../../../common/actions/rooms";

class ToFullLink extends Component {
  constructor() {
    super();
    this.state = {};
  }

  componentDidMount() {
    window.scrollTo(0, 0);
    const { dispatch } = this.props;

    const room_id = this.props.params.room_id;

    const data = {
      room_id: room_id
    };
    dispatch(fetchRoomById(data)).then(res => {
      if (res.payload.result) {
        const object_id = res.payload.result.object_id;
        dispatch(toCustomPath(`/${object_id}/rooms/${room_id}`));
      }
      if (res.payload.error) {
        dispatch(toCustomPath(`/`));
      }
    });
  }

  render(){
    return null;
  }
}

const mapStateToProps = state => {
  return {
    rooms: state.rooms,
    objects: state.objects
  };
};

export default connect(mapStateToProps)(ToFullLink);
