import React, { Component } from "react";
import { connect } from "react-redux";

import {setCustomHistoryPath, setTitle, toCustomPath} from "../../../common/actions/router";
import { fetchRoomById } from "../../../common/actions/rooms";
import { fetchFmRequestRecords } from "../../../common/actions/facility_requests";
import { ErrorToast } from "../../../common/Toasts";
import MaterialSurface from "../../../common/components/PageContainers/materialSurface";
import Request from "../../../common/components/RequestDetails";
import SinglePageWithCustomPaddingNavPanel from "../../../common/components/PageContainers/singlePageCustomPaddingNavPanel";
import CircleLoader from "../../../common/components/CircleLoader";
import strings from "../../localization/all";
import ProfileInfo from "../../../common/components/ProfileInfo";


class FacilityRequestsByRoomContainer extends Component {
  constructor() {
    super();
    this.state = {};
  }

  componentDidMount() {
    window.scrollTo(0, 0);
    const { dispatch } = this.props;
    dispatch(setCustomHistoryPath(`${this.props.params.object_id}/rooms`));

    const room_id = this.props.params.room_id;
    dispatch(fetchRoomById({room_id: room_id})).then(res => {
      if (res.payload.result){
        dispatch(setTitle(res.payload.result.name));
      }
      if(res.payload.error){
        ErrorToast(res.payload.error);
        this.toHistoryPath();
      }
    });

    const data = {
      filter: {
        object_id: this.props.params.object_id,
        room_ids: [room_id],
        statuses: ["accepted", "in_work", "done"]
      },
      order: '-create_date'
    };
    dispatch(fetchFmRequestRecords(data)).then(res => {
      if (res.payload.result) {
      }
      if (res.payload.error) {
        ErrorToast(res.payload.error);
      }
    });
  }

  toHistoryPath() {
    const { dispatch } = this.props;
    const fromHistory = this.props.router.history.pop();
    const historyPath = fromHistory
      ? fromHistory
      : this.props.router.customHistoryPath;
    dispatch(toCustomPath(historyPath));
  }

  render() {
    const {
      requestRecords,
      requestRecordsIsFetching
    } = this.props.facility_requests;

    if (requestRecordsIsFetching) {
      return (
        <SinglePageWithCustomPaddingNavPanel>
          <CircleLoader />
        </SinglePageWithCustomPaddingNavPanel>
      );
    }

    if (requestRecords.result) {
      return (
        <SinglePageWithCustomPaddingNavPanel>
          <ProfileInfo.Title title={strings.title_requests_in_work + ":"} />
          {requestRecords.result &&
            requestRecords.result.map((request, index) => (
              <Request.Container noStyle key={index}>
                <MaterialSurface marginBottom >
                  <Request.RecordNumber record={request} />
                  <Request.FmRequestStatus record={request} />
                  <Request.Margin />
                  <Request.ProblemDetail record={request} />
                  <Request.Margin />
                  <Request.Master master={request.assigned_to} />
                  <Request.FmRequestDate
                    date={request.expiration_date}
                    field={`expiration`}
                  />
                  <Request.FmRequestDate
                    date={request.execution_date}
                    field={`execution`}
                  />
                  <Request.FmRequestDate
                    date={request.closing_date}
                    field={`closing`}
                  />
                  <Request.Margin />
                  <Request.FmRequestDate
                    date={request.create_date}
                    field={`create`}
                  />
                  <Request.FacilityRequestDetails record={request} />
                </MaterialSurface>
              </Request.Container>
            ))}
        </SinglePageWithCustomPaddingNavPanel>
      );
    } else {
      return null;
    }
  }
}

const mapStateToProps = state => {
  return {
    rooms: state.rooms,
    objects: state.objects,
    facility_requests: state.facility_requests
  };
};

export default connect(mapStateToProps)(FacilityRequestsByRoomContainer);
