import {Route, IndexRoute} from 'react-router';
import React               from 'react';

import App from './containers/App';

import StartPageContainer from './containers/startPageContainer';
import FromObject from './containers/fromObject';
import ObjectSearch from './containers/objectSearchContainer';
import ObjectRooms from './containers/objectRoomsContainer';
import ObjectRoom from './containers/objectRoomContainer';
import ObjectRoomProblem from './containers/objectRoomProblemsContainer';
import ToFullLink from './containers/toFullLink';
import QrCodeReader from './containers/qrCodeReaderContainer';
import SuccessAdded   from './containers/requestSuccessAddedContainer';
import FacilityRequestsByRoomContainer   from './containers/facilityRequestsByRoomContainer';


export default function configRoutes(store) {

    return (
        <Route path="/" component={App}>
            <IndexRoute component={StartPageContainer}/>
            <Route path="/search" component={ObjectSearch}/>
            <Route path="/success" component={SuccessAdded}/>
            <Route path="/qr" component={QrCodeReader}/>
            <Route path="/fromObject/:object_id/rooms" component={FromObject}/>
            <Route path="/:room_id" component={ToFullLink}/>
            <Route path="/:object_id/rooms" component={ObjectRooms}/>
            <Route path="/:object_id/rooms/:room_id" component={ObjectRoom}/>
            <Route path="/:object_id/rooms/:room_id/requests" component={FacilityRequestsByRoomContainer}/>
            <Route path="/:object_id/rooms/:room_id/:problem_id" component={ObjectRoomProblem}/>



        </Route>
    )
}
