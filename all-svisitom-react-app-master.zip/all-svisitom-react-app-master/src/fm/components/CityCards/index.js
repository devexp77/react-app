import React from 'react'

import './style.css'

const CityCards = ({children}) => (
  <div className="city-cards">
    {children}
  </div>
)

export default CityCards;
