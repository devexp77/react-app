import React from 'react';

import MaterialListItem from '../../../common/components/MaterialListItem/twoLineItem'

class ObjectMaterialListItem extends React.Component {
  render() {
    var object = this.props.object

    return (
      <MaterialListItem
        item_id={object.object_id}
        firstLineContent={object.name}
        secondLineContent={`${object.city} ${object.address}`}
        icon={`business`}
        gotoItem={this.props.gotoItem}
      />
    )
  }
}

export default ObjectMaterialListItem
