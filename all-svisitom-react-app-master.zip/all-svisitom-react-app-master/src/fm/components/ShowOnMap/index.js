import React from 'react'

import strings from '../../localization/all'

import './style.css'

const ShowOnMap = ({onClick}) => (
  <div className="show-on-map-area" onClick={onClick}>
    <div className="rect-background"></div>
    <div className="text">{strings.show_on_map}</div>
  </div>
)

export default ShowOnMap;
