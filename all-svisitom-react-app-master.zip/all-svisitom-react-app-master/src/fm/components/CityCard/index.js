import React from 'react';

import './style.css'

const CityCard = ({city, imageUrl, onClick}) => (
  <div className="city-card waves-effect" onClick={onClick}>
    <div className="city-image"
      style={{
        backgroundImage: `url(${imageUrl})`
      }}
    />
    <div className="city-gradient">
    </div>
    <div className="city-name">
      {city}
    </div>
  </div>
)

export default CityCard;
