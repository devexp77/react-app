import React from "react";

import common_strings from "../../../common/localization/all";

import "./style.css";
import Icon from "../../../common/components/Icon";

/*
  Props:
    placeholder
    query_string
    onChangeQueryString
    onChangeQueryDate
*/

class SearchWithQR extends React.Component {
  constructor(props) {
    super(props);

    this.state = {
      query_string: this.props.query_string || ""
    };
  }

  componentDidMount() {}

  handleInputChange(event) {
    this.setState({ query_string: event.target.value });
    if (this.props.onChangeQueryString) {
      this.props.onChangeQueryString(event.target.value);
    }
  }

  handleInputKeyPress(event) {
    if (event.key == "Enter") {
      this.handleSearchButtonClick();
    }
  }

  handleClearButtonClick() {
    this.setState({ query_string: "" }, () => {
      if (this.props.onChangeQueryString) {
        this.props.onChangeQueryString("");
      }
      this.handleSearchButtonClick();
    });
  }

  handleSearchButtonClick() {
    if (this.props.onSearch) {
      this.props.onSearch(this.state.query_string);
    }
  }

  render() {
    return (
      <div
        className={
          this.props.containerClassName
            ? this.props.containerClassName
            : "request-object-search-wrapper"
        }
      >
        <div
          className={"search-query" + (this.props.invalid ? " invalid" : "")}
        >
          <div className="location-icon">
            <Icon name="sv-icon-location-on"/>
          </div>
          <input
            type="text"
            placeholder={this.props.placeholder}
            value={this.state.query_string}
            onChange={event => this.handleInputChange(event)}
            onKeyPress={event => this.handleInputKeyPress(event)}
          />

          <div
            className="clear-button"
            onClick={() => this.handleClearButtonClick()}
          >
            <Icon name="sv-icon-clear" />
          </div>
        </div>
        <div className="search-qr" onClick={this.props.qrClick}>
          <Icon name={`sv-icon-qr_code`} />
        </div>
        <div className="search-button">
          <button
            type="button"
            className={`btn btn-small btn-primary waves-effect`}
            onClick={() => this.handleSearchButtonClick()}
          >
            {common_strings.button_search}
          </button>
        </div>
      </div>
    );
  }
}

export default SearchWithQR;
