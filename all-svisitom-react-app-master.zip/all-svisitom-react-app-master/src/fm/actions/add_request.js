export const SAVE_SEARCH_OBJECT_QUERY = 'SAVE_SEARCH_OBJECT_QUERY'

export const saveQuery = (query) => ({
  type: SAVE_SEARCH_OBJECT_QUERY,
  payload: query
})
