import { combineReducers } from "redux";
import { routerReducer } from "react-router-redux";

import user from "../../common/reducers/user";
import router from "../../common/reducers/router";
import objects from "../../common/reducers/objects";
import addressee from "../../common/reducers/addressee";
import rooms from "../../common/reducers/rooms";
import notifications from "../../common/reducers/notifications";
import add_request from "./add_request";
import image from "../../common/reducers/image";
import bento from '../../common/reducers/bento';
import facility from '../../common/reducers/facility';
import facility_requests from '../../common/reducers/facility_requests';
import activity from '../../common/reducers/activity';
import document_attachments from '../../common/reducers/document_attachments';

export default combineReducers({
  routing: routerReducer,
  router,
  user,
  objects,
  addressee,
  rooms,
  notifications,
  add_request,
  image,
  bento,
  facility,
  facility_requests,
  activity,
  document_attachments,
});
