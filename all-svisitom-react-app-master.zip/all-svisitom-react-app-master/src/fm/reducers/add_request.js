import {
  SAVE_SEARCH_OBJECT_QUERY
} from '../actions/add_request'


export default function objects(state = {
  object_query: {}
}, action){
  switch (action.type) {
    case SAVE_SEARCH_OBJECT_QUERY:
    return {
      ...state,
      object_query: action.payload
    }

    default:
    return state
  }
}
