import React from 'react';
import ReactDOM from 'react-dom';
import { Provider } from 'react-redux';
import { createStore, applyMiddleware } from 'redux';
import { routerMiddleware } from 'react-router-redux';
import thunk from 'redux-thunk';
import { Router, Route, hashHistory } from 'react-router';
import { syncHistoryWithStore } from 'react-router-redux';
import 'babel-polyfill';

import reducer from './reducers/'

import configRoutes from './routes.js'
import NotFound from '../common/components/Errors/notFound';


const middleware = applyMiddleware(
  routerMiddleware(hashHistory),
  thunk
);

const store = createStore(reducer, middleware
);
const history = syncHistoryWithStore(hashHistory, store);

ReactDOM.render(

  <Provider store={store}>

    <Router history={history}>
      {configRoutes(store)}
      <Route path='*' component={NotFound} />
    </Router>

  </Provider>,
  document.getElementById('root')
);

